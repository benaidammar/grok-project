import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  Boxes,
  Compass,
  Droplets,
  Factory,
  FileSpreadsheet,
  Gauge,
  Landmark,
  LineChart as LineIcon,
  Network,
  Shield,
  Sparkles,
  Wrench,
} from "lucide-react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useDesk, canEditEngineering, moduleOpen, type ViewId } from "@/lib/store";
import { networkToCsv, testsToCsv, buildDemonstrationAsset } from "@/lib/eng/demo";
import { assetFromTests, parseWellTests } from "@/lib/eng/ingest";
import { co2MassTd, emissions, espScreen, fracPkn, gasLiftOptimum, gasLiftResponse, salineCapacity, srpDisplacement } from "@/lib/eng/screens";
import type { AssetModel } from "@/lib/eng/types";

const NAV: { id: ViewId; label: string; icon: typeof Gauge }[] = [
  { id: "executive", label: "Executive", icon: Landmark },
  { id: "surveillance", label: "Surveillance", icon: Activity },
  { id: "wells", label: "Wells and nodal", icon: Gauge },
  { id: "network", label: "Network", icon: Network },
  { id: "condensate", label: "Gas condensate", icon: Droplets },
  { id: "lift", label: "Artificial lift", icon: Wrench },
  { id: "optimize", label: "Optimization", icon: Compass },
  { id: "forecast", label: "Forecast", icon: LineIcon },
  { id: "ai", label: "AI laboratory", icon: Sparkles },
  { id: "screening", label: "CCUS, flare, frac", icon: Factory },
  { id: "data", label: "Data and configuration", icon: FileSpreadsheet },
  { id: "method", label: "Method and limits", icon: Shield },
  { id: "commercial", label: "Commercial", icon: Boxes },
];

function mm(n: number): string {
  return Number.isFinite(n) ? (n / 1e6).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "—";
}
function n1(n: number, d = 1): string {
  return Number.isFinite(n) ? n.toLocaleString("en-US", { maximumFractionDigits: d, minimumFractionDigits: d }) : "—";
}
function usd(n: number): string {
  return Number.isFinite(n) ? n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }) : "—";
}

function Chip({ tone, children }: { tone: "ok" | "warn" | "bad" | "info"; children: string }) {
  const cls =
    tone === "ok"
      ? "bg-ok-soft text-ok"
      : tone === "warn"
        ? "bg-warn-soft text-warn"
        : tone === "bad"
          ? "bg-bad-soft text-bad"
          : "bg-brass-soft text-brass";
  return <span className={`chip ${cls}`}>{children}</span>;
}

function Kpi({ label, value, unit, note }: { label: string; value: string; unit?: string; note?: string }) {
  return (
    <div className="card p-4">
      <div className="text-sm text-muted">{label}</div>
      <div className="num display mt-1 text-3xl text-ink">
        {value}
        {unit ? <span className="ml-2 font-sans text-sm text-muted">{unit}</span> : null}
      </div>
      {note ? <div className="mt-2 text-xs text-muted">{note}</div> : null}
    </div>
  );
}

function download(name: string, body: string, type = "text/csv") {
  const blob = new Blob([body], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

export function Desk() {
  const desk = useDesk();
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => {
    try {
      const raw = localStorage.getItem("meridian-v19");
      if (raw) {
        const saved = JSON.parse(raw) as { asset?: AssetModel; role?: typeof desk.role; licence?: typeof desk.licence };
        if (saved.asset?.tests?.length) {
          desk.commit(saved.asset, "Restored browser copy");
          if (saved.role) desk.setRole(saved.role);
          if (saved.licence) desk.setLicence(saved.licence);
        }
      }
    } catch {
      /* ignore broken local copies */
    }
    setHydrated(true);
    // load once
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem("meridian-v19", JSON.stringify({ asset: desk.asset, role: desk.role, licence: desk.licence }));
  }, [hydrated, desk.asset, desk.role, desk.licence]);

  return (
    <div className="desk md:grid md:grid-cols-[16.5rem_1fr]">
      <aside className="side md:min-h-screen md:sticky md:top-0 md:h-screen md:overflow-y-auto p-4">
        <div className="display text-3xl leading-none">MERIDIAN</div>
        <div className="mt-1 text-sm text-sidemuted">V19 · Production digital twin</div>
        <div className="mt-4 text-sm">
          <div className="text-sidemuted">Asset</div>
          <div>{desk.asset.name}</div>
          <div className="mt-2 text-sidemuted">Role on this browser</div>
          <select className="field mt-1 bg-sidebar text-sidefg" value={desk.role} onChange={(e) => desk.setRole(e.target.value as typeof desk.role)}>
            <option value="engineer">Engineer</option>
            <option value="manager">Manager</option>
            <option value="viewer">Viewer</option>
          </select>
        </div>
        <label className="mobile-nav mt-4 block text-sm">
          <span className="text-sidemuted">Section</span>
          <select className="field mt-1 bg-sidebar text-sidefg" value={desk.view} onChange={(e) => desk.setView(e.target.value as ViewId)}>
            {NAV.map((n) => (
              <option key={n.id} value={n.id}>
                {n.label}
              </option>
            ))}
          </select>
        </label>
        <nav className="side-scroll mt-4 grid gap-1">
          {NAV.map((n) => {
            const Icon = n.icon;
            return (
              <button key={n.id} className="navbtn" data-on={desk.view === n.id} onClick={() => desk.setView(n.id)}>
                <Icon size={16} />
                {n.label}
              </button>
            );
          })}
        </nav>
      </aside>
      <main className="min-w-0 px-4 py-5 md:px-8">
        <header className="mb-5 flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="text-sm text-muted">Commercial petroleum production digital twin</div>
            <h1 className="display text-4xl leading-tight">{NAV.find((n) => n.id === desk.view)?.label}</h1>
          </div>
          <div className="flex flex-wrap gap-2">
            <Chip tone={desk.asset.synthetic ? "warn" : "info"}>{desk.asset.synthetic ? "Synthetic demonstration" : "Customer file — unverified"}</Chip>
            <Chip tone="info">Not field-validated</Chip>
            <Chip tone="ok">Software-tested</Chip>
          </div>
        </header>
        <p className="mb-5 max-w-4xl text-sm text-muted">{desk.asset.provenance}</p>
        {desk.view === "executive" && <Executive />}
        {desk.view === "surveillance" && <Surveillance />}
        {desk.view === "wells" && <Wells />}
        {desk.view === "network" && <NetworkView />}
        {desk.view === "condensate" && <Condensate />}
        {desk.view === "lift" && <Lift />}
        {desk.view === "optimize" && <Optimize />}
        {desk.view === "forecast" && <Forecast />}
        {desk.view === "ai" && <AiLab />}
        {desk.view === "screening" && <Screening />}
        {desk.view === "data" && <DataView />}
        {desk.view === "method" && <Method />}
        {desk.view === "commercial" && <Commercial />}
      </main>
    </div>
  );
}

function Executive() {
  const { snap, asset } = useDesk();
  const base = snap.optimization.base;
  const margin = snap.optimization.maxMargin;
  const deltaGas = margin.feasible && base.feasible ? margin.gasSm3d - base.gasSm3d : NaN;
  const deltaMargin = margin.feasible && base.feasible ? margin.revenueUsdD - base.revenueUsdD : NaN;
  const same = snap.wells.every((w) => w.banking.light === snap.wells[0]?.banking.light);
  const chart = snap.fieldSeries.map((r) => ({
    date: r.date.slice(0, 7),
    Actual: +(r.gas / 1e6).toFixed(3),
    Nomination: Number.isFinite(r.nomination) ? +(r.nomination / 1e6).toFixed(3) : null,
  }));
  return (
    <div className="grid gap-4">
      <div className="grid gap-3 md:grid-cols-4">
        <Kpi label="Latest test gas" value={mm(snap.latest.gas)} unit="MMSm3/d" note={snap.latest.date || "No tests"} />
        <Kpi label="Nomination gap" value={mm(snap.latest.gap)} unit="MMSm3/d" note="Actual operating tests minus stored nomination" />
        <Kpi label="Condensate / water" value={`${n1(snap.latest.cond, 1)} / ${n1(snap.latest.water, 1)}`} unit="m3/d" />
        <Kpi label="Illustrative margin" value={usd(snap.economics.marginUsdD)} note={snap.economics.note} />
      </div>
      <section className="card p-4">
        <h2 className="text-lg font-semibold">Actual versus nomination</h2>
        <p className="text-sm text-muted">Monthly operating point (median wellhead pressure on multi-rate days). Not a daily allocated volume.</p>
        <div className="mt-3 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chart}>
              <CartesianGrid stroke="var(--color-line)" />
              <XAxis dataKey="date" tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
              <YAxis tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
              <Tooltip />
              <Line type="monotone" dataKey="Actual" stroke="var(--color-brass)" dot={false} strokeWidth={2} />
              <Line type="monotone" dataKey="Nomination" stroke="var(--color-ink)" dot={false} strokeWidth={1.5} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>
      <section className="card p-4">
        <h2 className="text-lg font-semibold">Screened recommendation</h2>
        {margin.feasible ? (
          <>
            <p className="mt-2 text-sm">
              {margin.name}. Inlet {n1(margin.facilityBara)} bara. Expected gas {mm(margin.gasSm3d)} MMSm3/d ({deltaGas >= 0 ? "+" : ""}
              {mm(deltaGas)} versus the configured case). Expected margin {usd(margin.revenueUsdD)} ({deltaMargin >= 0 ? "+" : ""}
              {usd(deltaMargin)} per day).
            </p>
            <p className="mt-2 text-sm text-muted">{margin.confidence} Bottleneck segment: {margin.bottleneck}. Peak erosional utilisation {(margin.maxErosional * 100).toFixed(0)}%.</p>
          </>
        ) : (
          <p className="mt-2 text-sm">No feasible improvement inside the searched limits. {margin.violations.join(" ")}</p>
        )}
        <ul className="mt-3 grid gap-2 text-sm">
          {margin.assumptions.slice(0, 3).map((a) => (
            <li key={a}>· {a}</li>
          ))}
        </ul>
      </section>
      <section className="card overflow-x-auto p-4">
        <h2 className="mb-2 text-lg font-semibold">Why the gap is, or is not, explained</h2>
        <table className="data">
          <thead>
            <tr>
              <th>Cause</th>
              <th>Status</th>
              <th>Evidence</th>
            </tr>
          </thead>
          <tbody>
            {snap.gapCauses.map((c) => (
              <tr key={c.cause}>
                <td>{c.cause}</td>
                <td>
                  <Chip tone={c.status === "indicated" ? "warn" : c.status === "not measured" ? "info" : "ok"}>{c.status}</Chip>
                </td>
                <td>{c.detail}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {same ? <p className="mt-3 text-sm text-muted">The banking screen returned the same colour on every well. Without a laboratory dew point it is not ranking wells.</p> : null}
      </section>
      <div className="grid gap-3 md:grid-cols-3">
        <Kpi label="Facility gas utilisation" value={n1((snap.latest.gas / asset.facility.gasCapSm3d) * 100, 0)} unit="%" note={`Cap ${mm(asset.facility.gasCapSm3d)} MMSm3/d`} />
        <Kpi label="Water utilisation" value={n1((snap.latest.water / asset.facility.waterCapM3d) * 100, 0)} unit="%" note={`Cap ${n1(asset.facility.waterCapM3d, 0)} m3/d`} />
        <Kpi label="Deferment on the event log" value={mm(snap.defermentSm3)} unit="MMSm3" note="Duration times the stated lost rate. Not inferred from the monthly tests." />
      </div>
      <p className="text-sm text-muted">Booked 1P/2P/3P: {asset.reserves.source}</p>
    </div>
  );
}

function Surveillance() {
  const { snap, asset } = useDesk();
  return (
    <div className="grid gap-4">
      <div className="card overflow-x-auto p-4">
        <table className="data">
          <thead>
            <tr>
              <th>Well</th>
              <th>Date</th>
              <th>WHP bara</th>
              <th>Gas MMSm3/d</th>
              <th>CGR</th>
              <th>WGR</th>
              <th>Network limit</th>
              <th>Loading</th>
            </tr>
          </thead>
          <tbody>
            {snap.wells.map((w) => (
              <tr key={w.well}>
                <td>{w.well}</td>
                <td>{w.date}</td>
                <td className="num">{n1(w.whp)}</td>
                <td className="num">{mm(w.gas)}</td>
                <td className="num">{n1(w.cgr, 1)}</td>
                <td className="num">{n1(w.wgr, 1)}</td>
                <td>{snap.network.limitedBy[w.well]}</td>
                <td>{w.loading ? <Chip tone="warn">Below Turner</Chip> : <Chip tone="ok">Above Turner</Chip>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <section className="card p-4 text-sm">
        <h2 className="text-lg font-semibold">Quality checks</h2>
        <ul className="mt-2 grid gap-1">
          {snap.qc.map((q) => (
            <li key={q.message}>
              <Chip tone={q.level === "fail" ? "bad" : q.level === "warn" ? "warn" : "info"}>{q.level}</Chip> {q.message}
            </li>
          ))}
        </ul>
        <p className="mt-3 text-muted">Clusters (k-means on CGR, WGR, nominal decline, WHP — descriptive only): {snap.clusters.map((c) => `${c.well}→${c.cluster + 1}`).join(", ")}.</p>
        <p className="mt-2 text-muted">Downtime events stored: {asset.downtime.length}. Drilling rows: {asset.drilling.length}.</p>
      </section>
    </div>
  );
}

function Wells() {
  const { snap, asset } = useDesk();
  const [id, setId] = useState(asset.wells[0]?.id ?? "");
  const well = snap.wells.find((w) => w.well === id) ?? snap.wells[0];
  return (
    <div className="grid gap-4">
      <label className="max-w-xs text-sm">
        Well
        <select className="field mt-1" value={well?.well ?? ""} onChange={(e) => setId(e.target.value)}>
          {snap.wells.map((w) => (
            <option key={w.well}>{w.well}</option>
          ))}
        </select>
      </label>
      {well ? (
        <>
          <div className="grid gap-3 md:grid-cols-4">
            <Kpi label="Flowing BHP screen" value={n1(well.pwf)} unit="bara" note="Dry-gas column, 40 °C wellhead. Liquids ignored." />
            <Kpi label="p/z reservoir pressure" value={n1(well.pr)} unit="bara" note="Configured path, not a static survey." />
            <Kpi label="Absolute open flow" value={well.deliverability ? mm(well.deliverability.aof) : "—"} unit="MMSm3/d" note={well.deliverability ? `n ${n1(well.deliverability.n, 2)}, R² ${n1(well.deliverability.r2, 2)}` : "Needs a multi-rate test"} />
            <Kpi label="Turner critical rate" value={mm(well.turner)} unit="MMSm3/d" note="20% uplift on Turner 1969. Compare with the latest test, not a forecast." />
          </div>
          <section className="card p-4 text-sm">
            <h2 className="text-lg font-semibold">Deliverability flags</h2>
            <p className="mt-2">{well.deliverability ? well.deliverability.flags.join(" ") || "No flag on the latest multi-rate test." : "No multi-rate day with at least three rates."}</p>
            <p className="mt-2 text-muted">Wellhead curve: {well.curve ? `${well.curve.quality}. Fitted WHP ${n1(well.curve.whpMin)}–${n1(well.curve.whpMax)} bara. R² ${n1(well.curve.r2, 2)}.` : "Not enough spread to fit."}</p>
          </section>
        </>
      ) : (
        <p>No wells loaded.</p>
      )}
    </div>
  );
}

function NetworkView() {
  const { snap, asset } = useDesk();
  const rows = [...snap.network.segments].sort((a, b) => b.util - a.util);
  return (
    <div className="grid gap-4">
      <div className="grid gap-3 md:grid-cols-3">
        <Kpi label="Solved gas at configured inlet" value={mm(snap.network.gasTotal)} unit="MMSm3/d" note={snap.network.converged ? `Converged in ${snap.network.iterations} iterations` : "Did not converge"} />
        <Kpi label="Solved condensate" value={n1(snap.network.condTotal, 1)} unit="m3/d" />
        <Kpi label="Inlet used" value={n1(asset.facility.inletBara)} unit="bara" />
      </div>
      <div className="card overflow-x-auto p-4">
        <table className="data">
          <thead>
            <tr>
              <th>Segment</th>
              <th>Gas MMSm3/d</th>
              <th>Upstream bara</th>
              <th>Drop bar</th>
              <th>Velocity m/s</th>
              <th>Erosional use</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((s) => (
              <tr key={s.id + s.to}>
                <td>
                  {s.id} → {s.to} · {n1(s.diameterIn, 1)} in
                </td>
                <td className="num">{mm(s.q)}</td>
                <td className="num">{n1(s.pUp)}</td>
                <td className="num">{n1(s.dp)}</td>
                <td className="num">{n1(s.velocity, 2)}</td>
                <td>
                  <Chip tone={s.util > 1 ? "bad" : s.util > 0.8 ? "warn" : "ok"}>{n1(s.util * 100, 0)}%</Chip>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="mt-3 text-sm text-muted">API RP 14E with C = 100, homogeneous density. Friction uses a Chisholm multiplier. Liquid holdup is not in the hydrostatic term.</p>
      </div>
    </div>
  );
}

function Condensate() {
  const { snap } = useDesk();
  return (
    <div className="card overflow-x-auto p-4">
      <h2 className="text-lg font-semibold">Banking and dew-point screen</h2>
      <p className="mt-1 text-sm text-muted">Heuristic dew point from initial CGR, gas gravity and temperature, ±25%, unless a laboratory value is stored. Not Nemeth–Kennedy.</p>
      <table className="data mt-3">
        <thead>
          <tr>
            <th>Well</th>
            <th>Screen</th>
            <th>Pd bara</th>
            <th>Band</th>
            <th>Latest CGR</th>
            <th>Evidence</th>
          </tr>
        </thead>
        <tbody>
          {snap.wells.map((w) => (
            <tr key={w.well}>
              <td>{w.well}</td>
              <td>
                <Chip tone={w.banking.light === "red" ? "bad" : w.banking.light === "green" ? "ok" : "warn"}>{w.banking.light}</Chip>
              </td>
              <td className="num">{n1(w.pdScreen, 0)}</td>
              <td className="num">
                {n1(w.pdBand[0], 0)}–{n1(w.pdBand[1], 0)}
              </td>
              <td className="num">{n1(w.cgr, 1)}</td>
              <td className="max-w-xl">{w.banking.evidence.join(" ")}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Lift() {
  const { snap } = useDesk();
  const [esp, setEsp] = useState({ frequencyHz: 55, baseHz: 60, stages: 80, headPerStageM: 12, bepM3d: 250, rateM3d: 220, intakeBara: 40, dischargeRequiredBara: 90, sg: 0.82, ratedKw: 160, minIntakeBara: 18 });
  const result = useMemo(() => espScreen(esp), [esp]);
  const gl = gasLiftOptimum(350, 0.05, 0.008);
  return (
    <div className="grid gap-4">
      <section className="card p-4">
        <h2 className="text-lg font-semibold">Gas-well liquid loading</h2>
        <p className="text-sm text-muted">Applied to the loaded asset. Artificial-lift calculators below are worked examples. They are not North Ridge measurements and they are not added into field totals.</p>
        <ul className="mt-2 text-sm">
          {snap.wells.map((w) => (
            <li key={w.well}>
              {w.well}: test {mm(w.gas)} vs Turner {mm(w.turner)} MMSm3/d — {w.loading ? "below" : "above"}
            </li>
          ))}
        </ul>
      </section>
      <section className="card p-4">
        <h2 className="text-lg font-semibold">ESP envelope — worked example</h2>
        <div className="mt-3 grid gap-3 md:grid-cols-3">
          {(
            [
              ["frequencyHz", "Frequency Hz"],
              ["stages", "Stages"],
              ["rateM3d", "Rate m3/d"],
              ["intakeBara", "Intake bara"],
              ["dischargeRequiredBara", "Required discharge bara"],
              ["ratedKw", "Motor kW"],
            ] as const
          ).map(([key, label]) => (
            <label key={key} className="text-sm">
              {label}
              <input
                className="field mt-1"
                type="number"
                value={esp[key]}
                onChange={(e) => setEsp({ ...esp, [key]: Number(e.target.value) })}
              />
            </label>
          ))}
        </div>
        <p className="mt-3 text-sm">
          Head available {n1(result.headAvailableM, 0)} m, required {n1(result.headRequiredM, 0)} m, load {n1(result.load * 100, 0)}%. {result.inEnvelope ? "Inside this simplified envelope." : result.flags.join(" ")}
        </p>
        <p className="mt-2 text-sm text-muted">Affinity-shifted head, not a vendor pump curve. Hydraulic allowance 62% of rated power is an assumption.</p>
      </section>
      <section className="card p-4 text-sm">
        <h2 className="text-lg font-semibold">Gas-lift and SRP screens — worked examples</h2>
        <p className="mt-2">
          Response-curve optimum injection {n1(gl.qInj, 1)} thousand Sm3/d equivalent units give {n1(gl.qLiq, 1)} m3/d liquid on q = qmax(1−e^(−kq))e^(−cq). At 2× that injection the curve returns {n1(gasLiftResponse(gl.qInj * 2, 350, 0.05, 0.008), 1)} m3/d. This is not the V18 drift-flux traverse.
        </p>
        <p className="mt-2">SRP displacement at 1.5 in, 120 in stroke, 7 spm, 80% efficiency: {n1(srpDisplacement(1.5, 120, 7, 0.8), 0)} bbl/d using 0.1166 D²SN·eff.</p>
      </section>
    </div>
  );
}

function Optimize() {
  const { snap, licence } = useDesk();
  if (!moduleOpen(licence.edition, "optimize")) return <Locked name="Optimization" />;
  const rows = [snap.optimization.base, snap.optimization.maxGas, snap.optimization.maxMargin, snap.optimization.minEnergy, snap.optimization.minFlare];
  return (
    <div className="grid gap-4">
      <div className="card overflow-x-auto p-4">
        <table className="data">
          <thead>
            <tr>
              <th>Case</th>
              <th>Inlet</th>
              <th>Gas</th>
              <th>Margin $/d</th>
              <th>Power kW</th>
              <th>Flare</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.name}>
                <td className="max-w-sm">{r.name}</td>
                <td className="num">{n1(r.facilityBara)}</td>
                <td className="num">{mm(r.gasSm3d)}</td>
                <td className="num">{usd(r.revenueUsdD)}</td>
                <td className="num">{n1(r.powerKw, 0)}</td>
                <td className="num">{mm(r.flareSm3d)}</td>
                <td>{r.feasible ? <Chip tone="ok">feasible</Chip> : <Chip tone="bad">rejected</Chip>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <section className="card p-4 text-sm">
        <h2 className="text-lg font-semibold">Constraints and confidence</h2>
        <p className="mt-2">{rows.find((r) => !r.feasible)?.violations.join(" ") || "Every displayed case honoured gas, condensate, water, erosional velocity and the fitted wellhead-pressure range."}</p>
        <p className="mt-2 text-muted">{snap.optimization.maxMargin.confidence}</p>
        <ul className="mt-2 grid gap-1">
          {snap.optimization.maxMargin.assumptions.map((a) => (
            <li key={a}>· {a}</li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function Forecast() {
  const { snap, asset } = useDesk();
  const chart = snap.wells[0]?.forecast.rows.filter((_, i) => i % 2 === 0).map((r) => {
    const point: Record<string, number | string> = { t: r.tYears.toFixed(1) };
    for (const w of snap.wells) {
      const row = w.forecast.rows[Math.round(r.tYears * 12)];
      point[w.well] = row ? +(row.p50 / 1e6).toFixed(3) : 0;
    }
    return point;
  });
  return (
    <div className="grid gap-4">
      <div className="grid gap-3 md:grid-cols-3">
        <Kpi label="Technical EUR, 10 years" value={n1(snap.technicalEurSm3 / 1e9, 2)} unit="billion Sm3" note="Sum of modified-hyperbolic P50 integrals to the economic limit. Not PRMS 1P, 2P or 3P." />
        <Kpi label="1P / 2P / 3P" value="Not stored" note={asset.reserves.source} />
        <Kpi label="Planned well" value={asset.drilling[0]?.well ?? "None"} note={asset.drilling[0]?.note ?? "No schedule row."} />
      </div>
      <div className="card h-72 p-4">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chart}>
            <CartesianGrid stroke="var(--color-line)" />
            <XAxis dataKey="t" tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
            <YAxis tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
            <Tooltip />
            {snap.wells.map((w, i) => (
              <Line key={w.well} type="monotone" dataKey={w.well} dot={false} stroke={i === 0 ? "var(--color-brass)" : "var(--color-ink)"} strokeWidth={i === 0 ? 2 : 1} />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="card overflow-x-auto p-4">
        <table className="data">
          <thead>
            <tr>
              <th>Well</th>
              <th>qi</th>
              <th>D 1/yr</th>
              <th>b</th>
              <th>Fit R²</th>
              <th>Holdout MAPE vs naive</th>
            </tr>
          </thead>
          <tbody>
            {snap.wells.map((w) => (
              <tr key={w.well}>
                <td>{w.well}</td>
                <td className="num">{w.forecast.ok ? mm(w.forecast.qi) : "—"}</td>
                <td className="num">{w.forecast.ok ? n1(w.forecast.d, 3) : "—"}</td>
                <td className="num">{w.forecast.ok ? n1(w.forecast.b, 2) : "—"}</td>
                <td className="num">{w.forecast.ok ? n1(w.forecast.r2, 2) : w.forecast.message}</td>
                <td>
                  {w.forecast.holdout
                    ? `${n1(w.forecast.holdout.arpsMape * 100, 0)}% vs ${n1(w.forecast.holdout.naiveMape * 100, 0)}%`
                    : "Too few tests"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="mt-3 text-sm text-muted">P10/P90 bands use a log-residual scale, not a bootstrap of a commercial reserves tool. Modified hyperbolic switches to 6%/yr exponential.</p>
      </div>
    </div>
  );
}

function AiLab() {
  const { snap, licence } = useDesk();
  if (!moduleOpen(licence.edition, "ai")) return <Locked name="AI laboratory" />;
  const ml = snap.ml;
  return (
    <div className="grid gap-4">
      <section className="card p-4 text-sm">
        <h2 className="text-lg font-semibold">Gas-rate model</h2>
        <p className="mt-2">{ml.reason}</p>
        <p className="mt-2">Target: {ml.target}. Features: {ml.features.join(", ")}.</p>
        <p className="mt-2">
          Train {ml.nTrain}, test {ml.nTest}. {ml.hyperparameters}
        </p>
        {ml.status === "ran" ? (
          <table className="data mt-3">
            <thead>
              <tr>
                <th>Model</th>
                <th>MAE Sm3/d</th>
                <th>RMSE</th>
                <th>R²</th>
              </tr>
            </thead>
            <tbody>
              {(
                [
                  ["Ridge", ml.ridge],
                  ["Stump gradient boosting", ml.gbm],
                  ["Persistence baseline", ml.naive],
                ] as const
              ).map(([name, m]) => (
                <tr key={name}>
                  <td>{name}</td>
                  <td className="num">{n1(m.mae, 0)}</td>
                  <td className="num">{n1(m.rmse, 0)}</td>
                  <td className="num">{n1(m.r2, 3)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : null}
        <p className="mt-3 text-muted">
          {ml.status === "ran" && ml.ridge.mae < ml.naive.mae
            ? "Ridge beat persistence on the time holdout by MAE. The margin may be small. It is not an approval to replace the physics model."
            : "Do not prefer the learned model over persistence unless its test MAE is lower. Physics constraints still govern the optimizer."}
        </p>
      </section>
      {ml.status === "ran" ? (
        <section className="card p-4 text-sm">
          <h2 className="text-lg font-semibold">Explainability</h2>
          <p className="mt-2">{ml.linearShapNote}</p>
          <p className="mt-2">One test row, linear contributions: {ml.shapSample.map((s) => `${s.feature} ${n1(s.value, 0)}`).join("; ")}.</p>
          <p className="mt-2">Permutation importance (rise in test MAE): {ml.permutation.map((p) => `${p.feature} ${n1(p.deltaMae, 0)}`).join("; ")}.</p>
          <p className="mt-2">Residual flags with absolute z above 3: {ml.residuals.filter((r) => r.flag).length} of {ml.residuals.length} test rows.</p>
          <ul className="mt-2">
            {ml.leakageControls.map((c) => (
              <li key={c}>· {c}</li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}

function Screening() {
  const { snap, asset } = useDesk();
  const [store, setStore] = useState({ area: "", h: "", phi: "", sw: "0.3", eff: "0.02", p: "150", t: "60" });
  const [frac, setFrac] = useState({ qM3Min: 4, tMin: 45, hM: 30, eGpa: 28, nu: 0.23, muCp: 25, clMSqrtMin: 0.0005 });
  const ready = ["area", "h", "phi"].every((k) => Number(store[k as "area"]) > 0);
  const cap = ready ? salineCapacity(Number(store.area), Number(store.h), Number(store.phi), Number(store.sw), Number(store.p), Number(store.t), Number(store.eff)) : null;
  const geom = fracPkn(frac);
  const co2 = co2MassTd(snap.latest.gas, asset.fluid.co2Pct);
  const em = emissions(snap.latest.gas, asset.fluid.co2Pct, asset.facility.measuredFlareSm3d ?? snap.flare.modelExcess);
  return (
    <div className="grid gap-4">
      <section className="card p-4 text-sm">
        <h2 className="text-lg font-semibold">CO2 in the produced stream</h2>
        <p className="mt-2">
          {n1(co2, 1)} t/d of CO2 in the latest test gas at {asset.fluid.co2Pct} mol%. This is composition, not a combustion inventory.
        </p>
        <p className="mt-2">
          Measured flare: {asset.facility.measuredFlareSm3d == null ? "not loaded" : asset.facility.measuredFlareSm3d}. Model excess over the sales cap at the solved network point: {mm(snap.flare.modelExcess)} MMSm3/d.
        </p>
        <p className="mt-2">{em.note} Screening combusted {n1(em.combustedTco2d, 2)} t/d, unburnt-equivalent {n1(em.unburntTco2d, 2)} t/d, using the measured flare if present and otherwise the model excess — say which one you mean before quoting it.</p>
        <p className="mt-2">Compression at the configured inlet: {n1(snap.energy.powerKw, 0)} kW. {snap.energy.note}</p>
      </section>
      <section className="card p-4 text-sm">
        <h2 className="text-lg font-semibold">Saline storage screen</h2>
        <p className="mt-1 text-muted">Left blank until you enter site numbers. The demonstration does not invent a storage site.</p>
        <div className="mt-3 grid gap-3 md:grid-cols-4">
          {(
            [
              ["area", "Area km²"],
              ["h", "Net thickness m"],
              ["phi", "Porosity fraction"],
              ["eff", "Efficiency fraction"],
            ] as const
          ).map(([k, label]) => (
            <label key={k}>
              {label}
              <input className="field mt-1" value={store[k]} onChange={(e) => setStore({ ...store, [k]: e.target.value })} />
            </label>
          ))}
        </div>
        <button
          className="btn btn-ghost mt-3"
          onClick={() => setStore({ area: "25", h: "40", phi: "0.18", sw: "0.35", eff: "0.02", p: "150", t: "62" })}
        >
          Load labelled what-if assumptions
        </button>
        {cap ? (
          <p className="mt-3">
            {n1(cap.mt, 2)} Mt at ρ {n1(cap.rho, 0)} kg/m3. {cap.note} These inputs are what-if values, not a survey.
          </p>
        ) : (
          <p className="mt-3">Blocked: area, thickness and porosity are required.</p>
        )}
      </section>
      <section className="card p-4 text-sm">
        <h2 className="text-lg font-semibold">PKN fracture screen</h2>
        <div className="mt-3 grid gap-3 md:grid-cols-4">
          {(
            [
              ["qM3Min", "Rate m3/min"],
              ["tMin", "Time min"],
              ["hM", "Height m"],
              ["muCp", "Viscosity cP"],
            ] as const
          ).map(([k, label]) => (
            <label key={k}>
              {label}
              <input className="field mt-1" type="number" value={frac[k]} onChange={(e) => setFrac({ ...frac, [k]: Number(e.target.value) })} />
            </label>
          ))}
        </div>
        {"error" in geom ? <p className="mt-3">{geom.error}</p> : <p className="mt-3">Half-length {n1(geom.lengthM, 0)} m, max width {n1(geom.widthMm, 1)} mm, net pressure {n1(geom.pNetBar, 1)} bar, efficiency {n1(geom.efficiency * 100, 0)}%. {geom.note}</p>}
      </section>
    </div>
  );
}

function DataView() {
  const desk = useDesk();
  const edit = canEditEngineering(desk.role);
  const [msg, setMsg] = useState("");
  const [unit, setUnit] = useState("bara");
  const [datum, setDatum] = useState<"absolute" | "gauge">("absolute");
  function patch(fn: (a: AssetModel) => AssetModel, action: string) {
    if (!edit && desk.role === "viewer") {
      setMsg("Viewers cannot change data.");
      return;
    }
    desk.commit(fn(desk.asset), action);
  }
  return (
    <div className="grid gap-4">
      <section className="card grid gap-3 p-4 md:grid-cols-2">
        <label className="text-sm">
          Asset name
          <input className="field mt-1" defaultValue={desk.asset.name} disabled={!edit} key={desk.asset.name} onBlur={(e) => patch((a) => ({ ...a, name: e.target.value }), "Renamed asset")} />
        </label>
        <label className="text-sm">
          Gas gravity
          <input className="field mt-1" type="number" step="0.01" defaultValue={desk.asset.fluid.gasSg} disabled={!edit} key={desk.asset.fluid.gasSg} onBlur={(e) => patch((a) => ({ ...a, fluid: { ...a.fluid, gasSg: Number(e.target.value) } }), "Edited gas gravity")} />
        </label>
        <label className="text-sm">
          CO2 mol %
          <input className="field mt-1" type="number" defaultValue={desk.asset.fluid.co2Pct} disabled={!edit} key={desk.asset.fluid.co2Pct} onBlur={(e) => patch((a) => ({ ...a, fluid: { ...a.fluid, co2Pct: Number(e.target.value) } }), "Edited CO2")} />
        </label>
        <label className="text-sm">
          Laboratory dew point bara (blank = screen only)
          <input
            className="field mt-1"
            defaultValue={desk.asset.fluid.dewPointBara ?? ""}
            disabled={!edit}
            key={String(desk.asset.fluid.dewPointBara)}
            onBlur={(e) =>
              patch(
                (a) => ({
                  ...a,
                  fluid: {
                    ...a.fluid,
                    dewPointBara: e.target.value.trim() === "" ? null : Number(e.target.value),
                    dewPointSource: e.target.value.trim() === "" ? a.fluid.dewPointSource : "User-entered laboratory or agreed value.",
                  },
                }),
                "Edited dew point",
              )
            }
          />
        </label>
        <label className="text-sm">
          Facility inlet bara
          <input className="field mt-1" type="number" defaultValue={desk.asset.facility.inletBara} disabled={!edit} key={desk.asset.facility.inletBara} onBlur={(e) => patch((a) => ({ ...a, facility: { ...a.facility, inletBara: Number(e.target.value) } }), "Edited inlet pressure")} />
        </label>
        <label className="text-sm">
          Gas capacity Sm3/d
          <input className="field mt-1" type="number" defaultValue={desk.asset.facility.gasCapSm3d} disabled={!edit} key={desk.asset.facility.gasCapSm3d} onBlur={(e) => patch((a) => ({ ...a, facility: { ...a.facility, gasCapSm3d: Number(e.target.value) } }), "Edited gas cap")} />
        </label>
        <label className="text-sm">
          Illustrative gas price USD/MMBtu
          <input className="field mt-1" type="number" step="0.1" disabled={desk.role === "viewer"} defaultValue={desk.asset.economics.gasUsdPerMmbtu} key={desk.asset.economics.gasUsdPerMmbtu} onBlur={(e) => patch((a) => ({ ...a, economics: { ...a.economics, gasUsdPerMmbtu: Number(e.target.value), priceStatus: "User-entered price. Not checked against a published index." } }), "Edited gas price")} />
        </label>
        <label className="text-sm">
          Illustrative condensate USD/bbl
          <input className="field mt-1" type="number" disabled={desk.role === "viewer"} defaultValue={desk.asset.economics.condUsdPerBbl} key={desk.asset.economics.condUsdPerBbl} onBlur={(e) => patch((a) => ({ ...a, economics: { ...a.economics, condUsdPerBbl: Number(e.target.value) } }), "Edited condensate price")} />
        </label>
      </section>
      <section className="card p-4 text-sm">
        <h2 className="text-lg font-semibold">Import well tests</h2>
        <div className="mt-2 flex flex-wrap gap-2">
          <select className="field max-w-40" value={unit} onChange={(e) => setUnit(e.target.value)}>
            <option>bara</option>
            <option>barg</option>
            <option>psi</option>
            <option>bar</option>
          </select>
          <select className="field max-w-40" value={datum} onChange={(e) => setDatum(e.target.value as "absolute" | "gauge")}>
            <option value="absolute">absolute</option>
            <option value="gauge">gauge</option>
          </select>
        </div>
        <input
          className="mt-3 block text-sm"
          type="file"
          accept=".csv,text/csv"
          disabled={desk.role === "viewer"}
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            const text = await file.text();
            const parsed = parseWellTests(text, unit, datum);
            if ("error" in parsed) {
              setMsg(parsed.error);
              return;
            }
            desk.commit(assetFromTests(desk.asset, parsed.rows, file.name), `Imported ${file.name}`);
            setMsg(parsed.notes.join(" "));
          }}
        />
        {msg ? <p className="mt-2">{msg}</p> : null}
        <div className="mt-3 flex flex-wrap gap-2">
          <button className="btn btn-ghost" onClick={() => download("north-ridge-tests.csv", testsToCsv(buildDemonstrationAsset()))}>
            Download demonstration tests
          </button>
          <button className="btn btn-ghost" onClick={() => download("network-template.csv", networkToCsv(desk.asset))}>
            Download network table
          </button>
          <button className="btn btn-ghost" onClick={() => download(`${desk.asset.id}.json`, JSON.stringify(desk.asset, null, 2), "application/json")}>
            Export asset JSON
          </button>
          <button
            className="btn btn-primary"
            disabled={!edit}
            onClick={() => {
              desk.commit(buildDemonstrationAsset(), "Restored demonstration asset");
              setMsg("Demonstration asset restored. It is synthetic.");
            }}
          >
            Restore demonstration
          </button>
        </div>
      </section>
      <section className="card p-4 text-sm">
        <h2 className="text-lg font-semibold">Audit</h2>
        <ul className="mt-2">
          {desk.audit.length === 0 ? <li>No local actions yet.</li> : desk.audit.map((a) => <li key={a.at + a.action}>{a.at.slice(0, 19).replace("T", " ")} · {a.role} · {a.action}</li>)}
        </ul>
      </section>
    </div>
  );
}

function Method() {
  const rows = [
    ["Units and datum", "Implemented", "Tested", "Gauge versus absolute is never inferred silently."],
    ["DAK Z, Sutton, Lee viscosity", "Implemented", "Tested at standard conditions", "Not a lab EOS. N2 shift omitted."],
    ["Dry-gas wellbore column", "Implemented", "Tested: static column and friction direction", "Liquids in the tubing are ignored."],
    ["Rawlins–Schellhardt", "Implemented", "Tested: recovers C and n on a clean set", "Needs stabilised multi-rate tests."],
    ["Arps / modified hyperbolic", "Implemented", "Tested on a clean hyperbola; holdout reported per well", "Not a PRMS reserves case."],
    ["Tree network", "Implemented", "Tested: pressure drop rises with rate; rate cap is hard", "No loops except by equivalent diameter. Not OLGA or PIPESIM."],
    ["Optimizer", "Implemented", "Tested: infeasible points are rejected", "Search is a grid, not a global proof."],
    ["Ridge, stump boosting, k-means", "Implemented", "Tested: tiny samples are refused; metrics are computed", "Not XGBoost and not TreeSHAP. Linear SHAP assumes independent features."],
    ["Turner loading", "Implemented", "Velocity sign tested", "Critical-rate comparison, not a transient loader."],
    ["ESP, gas lift, SRP", "Screening calculators", "Formula and envelope tests", "Not vendor curves and not the full V18 drift-flux traverse."],
    ["PKN frac, PR CO2 storage", "Screening", "Finite length and density band tested", "Not a fracture design and not a storage permit."],
    ["RNSE field validation", "Not in this release", "V18 buyer package had no private sample data", "Do not claim a history match that was not supplied."],
  ];
  return (
    <div className="card overflow-x-auto p-4">
      <table className="data">
        <thead>
          <tr>
            <th>Item</th>
            <th>State</th>
            <th>Evidence</th>
            <th>Limit</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r[0]}>
              {r.map((c) => (
                <td key={c}>{c}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Commercial() {
  const { licence, setLicence, role } = useDesk();
  return (
    <div className="grid gap-4">
      <section className="card p-4 text-sm">
        <h2 className="display text-3xl">MERIDIAN</h2>
        <p className="mt-2 max-w-3xl">
          A production-engineering workstation for operators who will not buy a five-product enterprise stack. Physics first, data second, a small learned model only where a holdout says it earns its place.
        </p>
        <p className="mt-3">Edition on this browser: {licence.edition}. {licence.note}</p>
        <label className="mt-3 block max-w-xs">
          Edition label
          <select
            className="field mt-1"
            disabled={role === "viewer"}
            value={licence.edition}
            onChange={(e) => setLicence({ ...licence, edition: e.target.value as typeof licence.edition })}
          >
            <option value="evaluation">Evaluation — modules open</option>
            <option value="professional">Professional — modules open</option>
            <option value="core">Core — AI and optimizer closed</option>
          </select>
        </label>
      </section>
      <section className="card overflow-x-auto p-4 text-sm">
        <h2 className="text-lg font-semibold">Indicative annual licence — estimates, not a quote</h2>
        <table className="data mt-2">
          <thead>
            <tr>
              <th>Offer</th>
              <th>What it is</th>
              <th>Indicative USD / year</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Core</td>
              <td>One asset, surveillance, wells, network, forecast. Up to 5 users.</td>
              <td>18,000 – 28,000</td>
            </tr>
            <tr>
              <td>Professional</td>
              <td>Core plus optimizer and the AI laboratory. Up to 3 assets or 15 users.</td>
              <td>36,000 – 55,000</td>
            </tr>
            <tr>
              <td>Setup</td>
              <td>Configuration, unit mapping, one history load, a workshop. Services, not software.</td>
              <td>12,000 – 30,000 once</td>
            </tr>
            <tr>
              <td>Engineering support</td>
              <td>Optional study days after go-live.</td>
              <td>1,600 – 2,200 per day</td>
            </tr>
          </tbody>
        </table>
        <p className="mt-3 text-muted">These ranges are planning assumptions for an SME offer. They are not surveyed market prices, not a contract, and not evidence of customers.</p>
      </section>
      <section className="card p-4 text-sm">
        <h2 className="text-lg font-semibold">What this release does not claim</h2>
        <ul className="mt-2 grid gap-1">
          <li>· No certification, no regulator approval, no partnership.</li>
          <li>· No customer deployment.</li>
          <li>· No closed-loop control.</li>
          <li>· The licence key is a label. Protection against copying is organisational, not cryptographic.</li>
          <li>· V18’s Python package remains in the release archive for the buyer’s own offline tests. The product you are using is this application.</li>
        </ul>
      </section>
    </div>
  );
}

function Locked({ name }: { name: string }) {
  return (
    <section className="card p-4">
      <h2 className="text-lg font-semibold">{name} is not in the Core edition</h2>
      <p className="mt-2 text-sm">Switch the edition label to Evaluation or Professional on the Commercial page. This is a product gate for the demonstration, not a server entitlement check.</p>
    </section>
  );
}
