import { create } from "zustand";
import { analyse, type Snapshot } from "@/lib/eng/analyse";
import { buildDemonstrationAsset } from "@/lib/eng/demo";
import type { AssetModel, AuditEvent, LicenceRecord, Role } from "@/lib/eng/types";

export type ViewId =
  | "executive"
  | "surveillance"
  | "wells"
  | "network"
  | "condensate"
  | "lift"
  | "optimize"
  | "forecast"
  | "ai"
  | "screening"
  | "data"
  | "method"
  | "commercial";

const demo = buildDemonstrationAsset();

const licence0: LicenceRecord = {
  holder: "Evaluation holder",
  edition: "evaluation",
  seats: 5,
  assets: 1,
  expiry: "2027-12-31",
  key: "EVAL-MERIDIAN-19",
  note: "Evaluation record stored in this browser. It is an operational label, not a cryptographic lock.",
};

type Desk = {
  role: Role;
  view: ViewId;
  asset: AssetModel;
  snap: Snapshot;
  licence: LicenceRecord;
  audit: AuditEvent[];
  setRole: (role: Role) => void;
  setView: (view: ViewId) => void;
  setLicence: (licence: LicenceRecord) => void;
  commit: (asset: AssetModel, action: string) => void;
  log: (action: string) => void;
};

export const useDesk = create<Desk>((set, get) => ({
  role: "engineer",
  view: "executive",
  asset: demo,
  snap: analyse(demo),
  licence: licence0,
  audit: [],
  setRole: (role) => set({ role }),
  setView: (view) => set({ view }),
  setLicence: (licence) => set({ licence }),
  log: (action) =>
    set({
      audit: [{ at: new Date().toISOString(), role: get().role, action }, ...get().audit].slice(0, 80),
    }),
  commit: (asset, action) => {
    if (get().role === "viewer") return;
    set({
      asset,
      snap: analyse(asset),
      audit: [{ at: new Date().toISOString(), role: get().role, action }, ...get().audit].slice(0, 80),
    });
  },
}));

export function canEditEngineering(role: Role): boolean {
  return role === "engineer";
}

export function moduleOpen(edition: LicenceRecord["edition"], mod: "ai" | "optimize"): boolean {
  if (edition === "core") return false;
  return mod === "ai" || mod === "optimize" || edition === "evaluation" || edition === "professional";
}
