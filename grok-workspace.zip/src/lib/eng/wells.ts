import { ATM_BAR, clamp, linreg, mean, quantile } from "./units.ts";
import { GasPVT, bottomholeFromWellhead, dewPressureScreen } from "./pvt.ts";

export const T_WH_C = 40;

export type WellGeom = { tvdM: number; idIn: number; tResC: number };

export function fitBackpressure(
  q: number[],
  pwf: number[],
  pr: number,
  nFixed?: number,
): { C: number; n: number; r2: number; nPts: number } | null {
  const x: number[] = [];
  const y: number[] = [];
  for (let i = 0; i < q.length; i++) {
    const dp2 = pr * pr - pwf[i]! * pwf[i]!;
    if (q[i]! > 0 && dp2 > 0) {
      x.push(Math.log(dp2));
      y.push(Math.log(q[i]!));
    }
  }
  if (x.length < 2) return null;
  let n = nFixed;
  if (n == null) {
    const fit = linreg(x, y);
    if (!fit) return null;
    n = fit.slope;
  }
  const lc = mean(y.map((yi, i) => yi - n! * x[i]!));
  const pred = x.map((xi) => lc + n! * xi);
  const yMean = mean(y);
  const ssRes = y.reduce((s, yi, i) => s + (yi - pred[i]!) ** 2, 0);
  const ssTot = y.reduce((s, yi) => s + (yi - yMean) ** 2, 0);
  const r2 = 1 - ssRes / Math.max(ssTot, 1e-12);
  return { C: Math.exp(lc), n, r2, nPts: x.length };
}

export function aofSm3d(C: number, n: number, pr: number): number {
  return C * Math.max(pr * pr - ATM_BAR * ATM_BAR, 0) ** n;
}

export function nodalRate(gas: GasPVT, geom: WellGeom, C: number, n: number, pr: number, whp: number): number {
  const nn = clamp(n, 0.5, 1);
  if (!(C > 0) || !(pr > 1)) return 0;
  const qs = aofSm3d(C, nn, pr);
  const f = (q: number) => {
    const pwfIpr = Math.sqrt(Math.max(pr * pr - (q / C) ** (1 / nn), 0));
    const pwfTub = bottomholeFromWellhead(gas, whp, T_WH_C, geom.tResC, geom.tvdM, q, geom.idIn);
    return pwfIpr - pwfTub;
  };
  const hi = Math.min(qs * 0.999, 8e6);
  if (!(hi > 10) || f(10) <= 0) return 0;
  if (f(hi) >= 0) return hi;
  let lo = 10;
  let h = hi;
  for (let i = 0; i < 48; i++) {
    const mid = 0.5 * (lo + h);
    if (f(mid) > 0) lo = mid;
    else h = mid;
  }
  return 0.5 * (lo + h);
}

export function iprCurve(C: number, n: number, pr: number, steps = 24): { pwf: number; q: number }[] {
  const nn = clamp(n, 0.5, 1);
  const out: { pwf: number; q: number }[] = [];
  for (let i = 0; i <= steps; i++) {
    const pwf = pr * (1 - i / steps) * 0.98 + ATM_BAR * (i / steps);
    const dp2 = pr * pr - pwf * pwf;
    const q = dp2 > 0 ? C * dp2 ** nn : 0;
    out.push({ pwf, q });
  }
  return out;
}

export function vlpCurve(
  gas: GasPVT,
  geom: WellGeom,
  whp: number,
  qMax: number,
  steps = 18,
): { pwf: number; q: number }[] {
  const out: { pwf: number; q: number }[] = [];
  for (let i = 0; i <= steps; i++) {
    const q = (qMax * i) / steps;
    out.push({ q, pwf: bottomholeFromWellhead(gas, whp, T_WH_C, geom.tResC, geom.tvdM, q, geom.idIn) });
  }
  return out;
}

export function arps(t: number, qi: number, d: number, b: number): number {
  const bb = Math.max(b, 1e-4);
  return qi * (1 + bb * d * t) ** (-1 / bb);
}

export function modifiedHyperbolic(t: number, qi: number, d: number, b: number, dLim = 0.06): number {
  const bb = Math.max(b, 1e-4);
  const tSw = d > dLim ? (d / dLim - 1) / (bb * d) : 0;
  if (t < tSw) return qi * (1 + bb * d * t) ** (-1 / bb);
  const qSw = qi * (1 + bb * d * tSw) ** (-1 / bb);
  return qSw * Math.exp(-dLim * (t - tSw));
}

export function fitArps(t: number[], q: number[]): { qi: number; d: number; b: number; r2: number } | null {
  const xs: number[] = [];
  const ys: number[] = [];
  for (let i = 0; i < t.length; i++) {
    if (Number.isFinite(t[i]) && Number.isFinite(q[i]) && q[i]! > 0) {
      xs.push(t[i]!);
      ys.push(q[i]!);
    }
  }
  if (xs.length < 4) return null;
  let best: { qi: number; d: number; b: number; sse: number } | null = null;
  const bs = [0.05, 0.2, 0.4, 0.6, 0.8, 1];
  const ds: number[] = [];
  for (let i = 0; i < 18; i++) ds.push(0.03 * 1.18 ** i);
  for (const b of bs) {
    for (const d of ds) {
      const shape = xs.map((tt) => Math.log(arps(tt, 1, d, b)));
      const lqi = mean(ys.map((yy, i) => Math.log(yy) - shape[i]!));
      const qi = Math.exp(lqi);
      let sse = 0;
      for (let i = 0; i < xs.length; i++) {
        const e = Math.log(ys[i]!) - Math.log(Math.max(arps(xs[i]!, qi, d, b), 1e-6));
        sse += e * e;
      }
      if (!best || sse < best.sse) best = { qi, d, b, sse };
    }
  }
  if (!best) return null;
  const pred = xs.map((tt) => arps(tt, best!.qi, best!.d, best!.b));
  const yMean = mean(ys);
  const ssTot = ys.reduce((s, yy) => s + (yy - yMean) ** 2, 0);
  const ssRes = ys.reduce((s, yy, i) => s + (yy - pred[i]!) ** 2, 0);
  return { ...best, r2: ssTot > 0 ? 1 - ssRes / ssTot : 1 };
}

/** Turner (1969) critical velocity with the commonly applied 20% uplift. sigma dyn/cm, densities kg/m3. */
export function turnerVelocityMs(rhoG: number, rhoL = 720, sigmaDyn = 20): number {
  const rhoGft = rhoG * 0.06242796;
  const rhoLft = rhoL * 0.06242796;
  const vFt = 1.593 * (sigmaDyn * (rhoLft - rhoGft) / rhoGft ** 2) ** 0.25;
  return vFt * 0.3048;
}

export function turnerRateSm3d(gas: GasPVT, whp: number, tWh: number, idIn: number, rhoL = 720): number {
  const rhoG = gas.rhoKgM3(whp, tWh);
  const v = turnerVelocityMs(rhoG, rhoL);
  const area = Math.PI * (idIn * 0.0254) ** 2 / 4;
  const qActual = v * area;
  const bg = Math.max(gas.bg(whp, tWh), 1e-6);
  return (qActual * 86400) / bg;
}

export type ForecastRow = { tYears: number; p10: number; p50: number; p90: number };

export function forecastWell(
  dates: string[],
  rates: number[],
  years = 10,
  qEcon = 2e4,
): { ok: boolean; message: string; qi: number; d: number; b: number; r2: number; eurSm3: number; rows: ForecastRow[]; holdout: { arpsMape: number; naiveMape: number; n: number } | null } {
  const t0 = Date.parse(dates[0] + "T00:00:00Z");
  const t = dates.map((d) => (Date.parse(d + "T00:00:00Z") - t0) / (86400e3 * 365.25));
  const fit = fitArps(t, rates);
  if (!fit) return { ok: false, message: "Fewer than 4 positive tests — decline fit refused.", qi: NaN, d: NaN, b: NaN, r2: NaN, eurSm3: NaN, rows: [], holdout: null };
  const resid = rates.map((q, i) => Math.log(q) - Math.log(Math.max(arps(t[i]!, fit.qi, fit.d, fit.b), 1)));
  const sd = Math.sqrt(mean(resid.map((r) => r * r)));
  const tLast = t[t.length - 1]!;
  const rows: ForecastRow[] = [];
  let eur = 0;
  let prevT = 0;
  let prevQ = 0;
  for (let m = 0; m <= years * 12; m++) {
    const ty = m / 12;
    const p50raw = modifiedHyperbolic(tLast + ty, fit.qi, fit.d, fit.b);
    const p50 = p50raw < qEcon ? 0 : p50raw;
    const p10 = p50 === 0 ? 0 : p50 * Math.exp(-1.2816 * sd);
    const p90 = p50 === 0 ? 0 : p50 * Math.exp(1.2816 * sd);
    if (m > 0) eur += 0.5 * (prevQ + p50) * (ty - prevT) * 365.25;
    prevT = ty;
    prevQ = p50;
    rows.push({ tYears: ty, p10, p50, p90 });
  }
  let holdout: { arpsMape: number; naiveMape: number; n: number } | null = null;
  if (rates.length >= 8) {
    const k = Math.max(4, Math.floor(rates.length * 0.7));
    const fitH = fitArps(t.slice(0, k), rates.slice(0, k));
    if (fitH) {
      const te = rates.slice(k);
      const tt = t.slice(k);
      let ae = 0;
      let an = 0;
      const last = rates[k - 1]!;
      for (let i = 0; i < te.length; i++) {
        const pred = modifiedHyperbolic(tt[i]!, fitH.qi, fitH.d, fitH.b);
        ae += Math.abs(pred / te[i]! - 1);
        an += Math.abs(last / te[i]! - 1);
      }
      holdout = { arpsMape: ae / te.length, naiveMape: an / te.length, n: te.length };
    }
  }
  return {
    ok: true,
    message: sd > 0.25 ? `Log residual scatter ${(sd * 100).toFixed(0)}%. Ranges are wide. Not a PRMS reserves case.` : "Software fit only. Not a PRMS reserves case.",
    ...fit,
    eurSm3: eur,
    rows,
    holdout,
  };
}

export function bankingScore(input: {
  whp: number[];
  cgr: number[];
  pwf: number[];
  pr: number[];
  q: number[];
  pd: number;
}): { points: number; light: "red" | "amber" | "green" | "grey"; evidence: string[] } {
  if (input.q.length < 8) return { points: 0, light: "grey", evidence: ["Fewer than 8 tests — inconclusive."] };
  const evidence: string[] = [];
  let pts = 0;
  const below = input.pwf.filter((p) => p < input.pd).length / input.pwf.length;
  evidence.push(`Flowing BHP below screening dew point in ${(below * 100).toFixed(0)}% of tests (Pd ${input.pd.toFixed(0)} bara).`);
  if (below > 0.8) pts += 2;
  else if (below > 0.3) pts += 1;
  const pairs = input.whp.map((w, i) => ({ w, c: input.cgr[i]! })).filter((p) => p.c > 0);
  if (pairs.length >= 8) {
    const rho = spearman(
      pairs.map((p) => p.w),
      pairs.map((p) => p.c),
    );
    evidence.push(`CGR vs WHP Spearman ${rho.toFixed(2)} (rank correlation, not a causal test).`);
    if (rho > 0.5) pts += 1;
  }
  const pi = input.q.map((q, i) => q / Math.max(input.pr[i]! ** 2 - input.pwf[i]! ** 2, 1));
  const k = Math.max(3, Math.floor(pi.length / 4));
  const first = medianOf(pi.slice(0, k));
  const last = medianOf(pi.slice(-k));
  const ratio = last / Math.max(first, 1e-9);
  evidence.push(`Productivity index, last/first quarter = ${ratio.toFixed(2)} (using the configured pressure path).`);
  if (ratio < 0.5) pts += 2;
  else if (ratio < 0.75) pts += 1;
  const light = pts >= 4 ? "red" : pts >= 2 ? "amber" : "green";
  evidence.push("A falling PI also comes from depletion, water, scale or a wrong reservoir pressure. This is not a diagnosis.");
  return { points: pts, light, evidence };
}

function medianOf(xs: number[]): number {
  const s = [...xs].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)] ?? NaN;
}

function spearman(xs: number[], ys: number[]): number {
  const rx = ranks(xs);
  const ry = ranks(ys);
  const fit = linreg(rx, ry);
  return fit ? fit.slope * (std(rx) / Math.max(std(ry), 1e-9)) : 0;
}

function ranks(xs: number[]): number[] {
  const idx = xs.map((v, i) => ({ v, i })).sort((a, b) => a.v - b.v);
  const r = new Array<number>(xs.length);
  for (let i = 0; i < idx.length; i++) r[idx[i]!.i] = i + 1;
  return r;
}

function std(xs: number[]): number {
  const m = mean(xs);
  return Math.sqrt(mean(xs.map((x) => (x - m) ** 2)));
}

export function pzPressure(pInit: number, pNow: number, z: (p: number) => number, fraction: number): number {
  const pzi = pInit / z(pInit);
  const pzn = pNow / z(pNow);
  const pz = pzi + (pzn - pzi) * clamp(fraction, 0, 1);
  let p = pNow;
  for (let i = 0; i < 20; i++) p = pz * z(p);
  return p;
}

export { dewPressureScreen, quantile };
