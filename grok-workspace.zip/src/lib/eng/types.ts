export type Role = "engineer" | "manager" | "viewer";

export type TestRow = {
  well: string;
  date: string;
  whpBara: number;
  gasSm3d: number;
  condM3d: number;
  waterM3d: number;
};

export type WellMaster = {
  id: string;
  tvdM: number;
  tubingIdIn: number;
  lift: "flowing" | "gas-lift" | "esp" | "srp";
};

export type NetNode = {
  id: string;
  kind: "well" | "manifold" | "facility";
  to: string;
  lengthM: number;
  diameterIn: number;
  elevationM: number;
  roughnessMm: number;
};

export type AssetModel = {
  id: string;
  name: string;
  country: string;
  synthetic: boolean;
  provenance: string;
  fluid: {
    gasSg: number;
    co2Pct: number;
    h2sPpm: number;
    n2Pct: number;
    condDensity: number;
    waterDensity: number;
    ghvMjPerSm3: number;
    dewPointBara: number | null;
    dewPointSource: string;
  };
  reservoir: { tResC: number; pInitBara: number; pNowBara: number };
  facility: {
    id: string;
    inletBara: number;
    gasCapSm3d: number;
    condCapM3d: number;
    waterCapM3d: number;
    salesCapSm3d: number;
    dischargeBara: number;
    compressorEfficiency: number;
    measuredFlareSm3d: number | null;
  };
  economics: {
    gasUsdPerMmbtu: number;
    condUsdPerBbl: number;
    waterUsdPerM3: number;
    powerUsdPerKwh: number;
    fixedOpexUsdPerDay: number;
    currency: string;
    priceStatus: string;
  };
  wells: WellMaster[];
  nodes: NetNode[];
  tests: TestRow[];
  nominations: { date: string; gasSm3d: number }[];
  downtime: { start: string; end: string; system: string; planned: boolean; reason: string; lostGasSm3d: number }[];
  drilling: { well: string; spud: string; expectedGasSm3d: number; note: string }[];
  reserves: { p1Sm3: number | null; p2Sm3: number | null; p3Sm3: number | null; source: string };
};

export type AuditEvent = { at: string; role: Role; action: string };

export type LicenceRecord = {
  holder: string;
  edition: "evaluation" | "core" | "professional";
  seats: number;
  assets: number;
  expiry: string;
  key: string;
  note: string;
};
