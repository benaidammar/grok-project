/** Canonical units: pressure bara, temperature degC, gas Sm3/d (15 C, 1.01325 bar), liquid m3/d, length m. */

export const ATM_BAR = 1.01325;

const P_TO_BAR: Record<string, number> = {
  bar: 1,
  psi: 0.0689475729,
  kpa: 0.01,
  mpa: 10,
  pa: 1e-5,
  "kgf/cm2": 0.980665,
  atm: 1.01325,
  psig: 0.0689475729,
  psia: 0.0689475729,
  barg: 1,
  bara: 1,
};

const GAS_TO_SM3D: Record<string, number> = {
  "sm3/d": 1,
  "1000 sm3/d": 1e3,
  "ksm3/d": 1e3,
  "msm3/d": 1e6,
  "mmsm3/d": 1e6,
  "mscf/d": 28.3168,
  "mmscf/d": 28316.8,
  "scf/d": 0.0283168,
};

const LIQ_TO_M3D: Record<string, number> = {
  "m3/d": 1,
  "sm3/d": 1,
  "bbl/d": 0.158987,
  "stb/d": 0.158987,
  bpd: 0.158987,
};

export function pToBara(x: number, unit = "bar", datum: "gauge" | "absolute" = "gauge"): number {
  const u = unit.toLowerCase();
  const f = P_TO_BAR[u];
  if (f == null) throw new Error(`Unknown pressure unit: ${unit}`);
  let d = datum;
  if (u === "psig" || u === "barg") d = "gauge";
  if (u === "psia" || u === "bara") d = "absolute";
  const bar = x * f;
  return d === "gauge" ? bar + ATM_BAR : bar;
}

export function gasToSm3d(x: number, unit = "Sm3/d"): number {
  const f = GAS_TO_SM3D[unit.toLowerCase()];
  if (f == null) throw new Error(`Unknown gas unit: ${unit}`);
  return x * f;
}

export function liqToM3d(x: number, unit = "m3/d"): number {
  const f = LIQ_TO_M3D[unit.toLowerCase()];
  if (f == null) throw new Error(`Unknown liquid unit: ${unit}`);
  return x * f;
}

export function bblPerM3(): number {
  return 6.28981;
}

export function mscfPerSm3(): number {
  return 1 / 28.3168;
}

/** Illustrative energy conversion. Not a measured heating value. */
export function sm3ToMmbtu(sm3: number, ghvMjPerSm3: number): number {
  return (sm3 * ghvMjPerSm3) / 1055.05585262;
}

export function median(xs: number[]): number {
  const v = xs.filter((n) => Number.isFinite(n)).sort((a, b) => a - b);
  if (!v.length) return NaN;
  const m = Math.floor(v.length / 2);
  return v.length % 2 ? v[m]! : 0.5 * (v[m - 1]! + v[m]!);
}

export function mean(xs: number[]): number {
  const v = xs.filter((n) => Number.isFinite(n));
  if (!v.length) return NaN;
  return v.reduce((a, b) => a + b, 0) / v.length;
}

export function quantile(xs: number[], p: number): number {
  const v = xs.filter((n) => Number.isFinite(n)).sort((a, b) => a - b);
  if (!v.length) return NaN;
  const i = (v.length - 1) * p;
  const lo = Math.floor(i);
  const hi = Math.ceil(i);
  if (lo === hi) return v[lo]!;
  return v[lo]! * (hi - i) + v[hi]! * (i - lo);
}

export function clamp(x: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, x));
}

export function linreg(xs: number[], ys: number[]): { slope: number; intercept: number; r2: number } | null {
  const n = xs.length;
  if (n < 2 || n !== ys.length) return null;
  let sx = 0;
  let sy = 0;
  let sxx = 0;
  let sxy = 0;
  let syy = 0;
  for (let i = 0; i < n; i++) {
    sx += xs[i]!;
    sy += ys[i]!;
    sxx += xs[i]! * xs[i]!;
    sxy += xs[i]! * ys[i]!;
    syy += ys[i]! * ys[i]!;
  }
  const d = n * sxx - sx * sx;
  if (Math.abs(d) < 1e-12) return null;
  const slope = (n * sxy - sx * sy) / d;
  const intercept = (sy - slope * sx) / n;
  const sse = syy - 2 * intercept * sy - 2 * slope * sxy + n * intercept * intercept + 2 * intercept * slope * sx + slope * slope * sxx;
  const sst = syy - (sy * sy) / n;
  const r2 = sst > 1e-12 ? 1 - sse / sst : 1;
  return { slope, intercept, r2 };
}

export function formatNum(n: number, digits = 1): string {
  if (!Number.isFinite(n)) return "—";
  const abs = Math.abs(n);
  if (abs !== 0 && (abs >= 1e6 || abs < 0.01)) return n.toExponential(2);
  return n.toLocaleString("en-US", { maximumFractionDigits: digits, minimumFractionDigits: digits });
}
