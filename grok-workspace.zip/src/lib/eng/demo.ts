import type { AssetModel, TestRow } from "./types.ts";
import { GasPVT } from "./pvt.ts";
import { nodalRate, pzPressure } from "./wells.ts";

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const TRUTH = [
  { id: "NR-01", C: 42, n: 0.86, tvd: 2480, idIn: 3.958, whp0: 102, whp1: 84, cgr: 72, wgr: 1.4, cgrDrop: 0.02, wgrRise: 0.02 },
  { id: "NR-02", C: 30, n: 0.8, tvd: 2520, idIn: 3.958, whp0: 108, whp1: 90, cgr: 128, wgr: 2.6, cgrDrop: 0.45, wgrRise: 0.08 },
  { id: "NR-03", C: 22, n: 0.9, tvd: 2460, idIn: 3.476, whp0: 96, whp1: 78, cgr: 38, wgr: 6, cgrDrop: 0.05, wgrRise: 1.1 },
  { id: "NR-04", C: 58, n: 0.78, tvd: 2410, idIn: 3.958, whp0: 98, whp1: 80, cgr: 64, wgr: 1.1, cgrDrop: 0.03, wgrRise: 0.02 },
  { id: "NR-05", C: 14, n: 0.88, tvd: 2580, idIn: 2.992, whp0: 118, whp1: 104, cgr: 48, wgr: 5.5, cgrDrop: 0.08, wgrRise: 0.25 },
  { id: "NR-06", C: 36, n: 0.83, tvd: 2440, idIn: 3.958, whp0: 94, whp1: 76, cgr: 86, wgr: 2, cgrDrop: 0.04, wgrRise: 0.05 },
] as const;

function monthDate(i: number): string {
  const y = 2023 + Math.floor(i / 12);
  const m = (i % 12) + 1;
  return `${y}-${String(m).padStart(2, "0")}-15`;
}

export function buildDemonstrationAsset(): AssetModel {
  const gas = new GasPVT(0.73, 3.2, 12, 1.1);
  const rand = mulberry32(19);
  const tests: TestRow[] = [];
  const months = 30;
  const ratesPreview: number[] = [];
  for (let i = 0; i < months; i++) {
    const frac = i / (months - 1);
    const pr = pzPressure(286, 224, (p) => gas.z(p, 108), frac);
    let monthGas = 0;
    for (const w of TRUTH) {
      const whp = w.whp0 + (w.whp1 - w.whp0) * frac + (rand() - 0.5) * 1.2;
      let q = nodalRate(gas, { tvdM: w.tvd, idIn: w.idIn, tResC: 108 }, w.C, w.n, pr, whp);
      q *= 1 + (rand() - 0.5) * 0.03;
      const cgr = Math.max(8, w.cgr * (1 - w.cgrDrop * frac));
      const wgr = w.wgr * (1 + w.wgrRise * frac);
      const row: TestRow = {
        well: w.id,
        date: monthDate(i),
        whpBara: +whp.toFixed(2),
        gasSm3d: Math.max(0, q),
        condM3d: (Math.max(0, q) / 1e6) * cgr,
        waterM3d: (Math.max(0, q) / 1e6) * wgr,
      };
      tests.push(row);
      monthGas += row.gasSm3d;
      if (i === 8 || i === 20) {
        for (const extra of [-18, -9, 8]) {
          const whp2 = whp + extra;
          let q2 = nodalRate(gas, { tvdM: w.tvd, idIn: w.idIn, tResC: 108 }, w.C, w.n, pr, whp2);
          q2 *= 1 + (rand() - 0.5) * 0.02;
          tests.push({
            well: w.id,
            date: monthDate(i),
            whpBara: +whp2.toFixed(2),
            gasSm3d: Math.max(0, q2),
            condM3d: (Math.max(0, q2) / 1e6) * cgr,
            waterM3d: (Math.max(0, q2) / 1e6) * wgr,
          });
        }
      }
    }
    ratesPreview.push(monthGas);
  }
  const nominations = ratesPreview.map((g, i) => ({
    date: monthDate(i),
    gasSm3d: 1.72e6 * (1 - 0.08 * (i / (months - 1))),
  }));
  return {
    id: "north-ridge-demo",
    name: "North Ridge (demonstration)",
    country: "Synthetic — not a real licence area",
    synthetic: true,
    provenance:
      "Generated inside MERIDIAN from published screening equations (Rawlins–Schellhardt, dry-gas column, Sutton/DAK). It is not RNSE and it is not a customer measurement. V18 shipped without private field data, so V19 does not claim an RNSE history match.",
    fluid: {
      gasSg: 0.73,
      co2Pct: 3.2,
      h2sPpm: 12,
      n2Pct: 1.1,
      condDensity: 745,
      waterDensity: 1040,
      ghvMjPerSm3: 37.5,
      dewPointBara: null,
      dewPointSource: "No laboratory dew point is stored. The condensate page uses the V18 CGR/gravity/temperature screen and shows its ±25% band.",
    },
    reservoir: { tResC: 108, pInitBara: 286, pNowBara: 224 },
    facility: {
      id: "CPF",
      inletBara: 48,
      gasCapSm3d: 2.35e6,
      condCapM3d: 460,
      waterCapM3d: 190,
      salesCapSm3d: 2.05e6,
      dischargeBara: 74,
      compressorEfficiency: 0.72,
      measuredFlareSm3d: null,
    },
    economics: {
      gasUsdPerMmbtu: 3.8,
      condUsdPerBbl: 62,
      waterUsdPerM3: 6,
      powerUsdPerKwh: 0.09,
      fixedOpexUsdPerDay: 22000,
      currency: "USD",
      priceStatus: "Illustrative demonstration prices. Not a published index and not a customer contract.",
    },
    wells: TRUTH.map((w) => ({ id: w.id, tvdM: w.tvd, tubingIdIn: w.idIn, lift: "flowing" as const })),
    nodes: [
      { id: "NR-01", kind: "well", to: "MN", lengthM: 2600, diameterIn: 6, elevationM: 124, roughnessMm: 0.046 },
      { id: "NR-02", kind: "well", to: "MN", lengthM: 3400, diameterIn: 6, elevationM: 131, roughnessMm: 0.046 },
      { id: "NR-04", kind: "well", to: "MN", lengthM: 1900, diameterIn: 6, elevationM: 118, roughnessMm: 0.046 },
      { id: "MN", kind: "manifold", to: "CPF", lengthM: 7200, diameterIn: 12, elevationM: 96, roughnessMm: 0.046 },
      { id: "NR-03", kind: "well", to: "MS", lengthM: 4100, diameterIn: 6, elevationM: 142, roughnessMm: 0.046 },
      { id: "NR-05", kind: "well", to: "MS", lengthM: 11200, diameterIn: 3.5, elevationM: 168, roughnessMm: 0.046 },
      { id: "MS", kind: "manifold", to: "CPF", lengthM: 8600, diameterIn: 8, elevationM: 110, roughnessMm: 0.046 },
      { id: "NR-06", kind: "well", to: "CPF", lengthM: 4800, diameterIn: 8, elevationM: 102, roughnessMm: 0.046 },
      { id: "CPF", kind: "facility", to: "", lengthM: 0, diameterIn: 0, elevationM: 42, roughnessMm: 0.046 },
    ],
    tests,
    nominations,
    downtime: [
      {
        start: "2025-06-02",
        end: "2025-06-05",
        system: "CPF export compressor",
        planned: false,
        reason: "Unplanned seal failure (synthetic event)",
        lostGasSm3d: 1.15e6,
      },
    ],
    drilling: [
      {
        well: "NR-07",
        spud: "2026-09-01",
        expectedGasSm3d: 180000,
        note: "Planning assumption supplied for the demonstration schedule. Not a reservoir simulation and not a reserves addition.",
      },
    ],
    reserves: {
      p1Sm3: null,
      p2Sm3: null,
      p3Sm3: null,
      source: "No PRMS volumes are stored. Technical EUR on the forecast page is a decline-curve integral, not 1P/2P/3P.",
    },
  };
}

export function testsToCsv(asset: AssetModel): string {
  const header = "well,date,whp_bara,gas_sm3d,cond_m3d,water_m3d";
  const lines = asset.tests.map((t) => [t.well, t.date, t.whpBara, t.gasSm3d.toFixed(1), t.condM3d.toFixed(2), t.waterM3d.toFixed(2)].join(","));
  return [header, ...lines].join("\n");
}

export function networkToCsv(asset: AssetModel): string {
  const header = "site,identity,to_node,length_m,diameter_inch,elevation_m,roughness_mm";
  const lines = asset.nodes.map((n) => [n.id, n.kind, n.to, n.lengthM, n.diameterIn, n.elevationM, n.roughnessMm].join(","));
  return [header, ...lines].join("\n");
}
