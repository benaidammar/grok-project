import type { AssetModel } from "./types.ts";
import { FastGas, GasPVT, bottomholeFromWellhead, dewPressureScreen } from "./pvt.ts";
import { bblPerM3, median } from "./units.ts";
import { T_WH_C, aofSm3d, bankingScore, fitBackpressure, forecastWell, pzPressure, turnerRateSm3d } from "./wells.ts";
import { compressionKw, fitWellheadCurve, searchFacilityPressure, solveNetwork, type SolveInput, type WellCurve } from "./network.ts";
import { kMeansWells, runForecastModel, type Row } from "./learn.ts";
import { emissions } from "./screens.ts";

export type QcItem = { level: "fail" | "warn" | "info"; message: string };

export type WellRow = {
  well: string;
  date: string;
  whp: number;
  gas: number;
  cond: number;
  water: number;
  cgr: number;
  wgr: number;
  pwf: number;
  pr: number;
  turner: number;
  loading: boolean;
  curve: WellCurve | null;
  deliverability: { C: number; n: number; r2: number; aof: number; pr: number; nPts: number; flags: string[] } | null;
  forecast: ReturnType<typeof forecastWell>;
  banking: ReturnType<typeof bankingScore>;
  pdScreen: number;
  pdBand: [number, number];
};

export type Snapshot = {
  generatedAt: string;
  modelNotes: string[];
  qc: QcItem[];
  dates: string[];
  fieldSeries: { date: string; gas: number; cond: number; water: number; nomination: number }[];
  latest: { date: string; gas: number; cond: number; water: number; nomination: number; gap: number };
  wells: WellRow[];
  clusters: ReturnType<typeof kMeansWells>;
  network: ReturnType<typeof solveNetwork>;
  curves: Record<string, WellCurve>;
  optimization: {
    base: ReturnType<typeof searchFacilityPressure>;
    maxGas: ReturnType<typeof searchFacilityPressure>;
    maxMargin: ReturnType<typeof searchFacilityPressure>;
    minEnergy: ReturnType<typeof searchFacilityPressure>;
    minFlare: ReturnType<typeof searchFacilityPressure>;
  };
  economics: {
    gasUsdPerSm3: number;
    condUsdPerM3: number;
    revenueUsdD: number;
    waterCostUsdD: number;
    powerUsdD: number;
    fixedUsdD: number;
    marginUsdD: number;
    note: string;
  };
  energy: { powerKw: number; note: string };
  flare: { measured: number | null; modelExcess: number; emissions: ReturnType<typeof emissions> };
  defermentSm3: number;
  ml: ReturnType<typeof runForecastModel>;
  technicalEurSm3: number;
  gapCauses: { cause: string; detail: string; status: "indicated" | "not indicated" | "not measured" }[];
};

function byWell(asset: AssetModel, well: string) {
  return asset.tests.filter((t) => t.well === well).sort((a, b) => a.date.localeCompare(b.date) || a.whpBara - b.whpBara);
}

function operatingPoints(asset: AssetModel, well: string) {
  const rows = byWell(asset, well);
  const dates = [...new Set(rows.map((r) => r.date))];
  return dates.map((date) => {
    const day = rows.filter((r) => r.date === date);
    const med = median(day.map((r) => r.whpBara));
    return day.reduce((best, r) => (Math.abs(r.whpBara - med) < Math.abs(best.whpBara - med) ? r : best));
  });
}

export function analyse(asset: AssetModel): Snapshot {
  const gas = new GasPVT(asset.fluid.gasSg, asset.fluid.co2Pct, asset.fluid.h2sPpm, asset.fluid.n2Pct);
  const fast = new FastGas(gas, 42, 220);
  const op = Object.fromEntries(asset.wells.map((w) => [w.id, operatingPoints(asset, w.id)]));
  const dates = op[asset.wells[0]!.id]?.map((r) => r.date) ?? [];
  const fieldGasByDate = dates.map((date) => asset.wells.reduce((s, w) => s + (op[w.id]!.find((r) => r.date === date)?.gasSm3d ?? 0), 0));
  const totalCum = fieldGasByDate.reduce((s, g, i) => {
    if (i === 0) return 0;
    const dt = (Date.parse(dates[i]! + "T00:00:00Z") - Date.parse(dates[i - 1]! + "T00:00:00Z")) / 86400e3;
    return s + 0.5 * (fieldGasByDate[i]! + fieldGasByDate[i - 1]!) * dt;
  }, 0);
  const cumAt = (date: string) => {
    let c = 0;
    for (let i = 1; i < dates.length; i++) {
      const dt = (Date.parse(dates[i]! + "T00:00:00Z") - Date.parse(dates[i - 1]! + "T00:00:00Z")) / 86400e3;
      c += 0.5 * (fieldGasByDate[i]! + fieldGasByDate[i - 1]!) * dt;
      if (dates[i]! >= date) break;
    }
    return c;
  };
  const prAt = (date: string) =>
    pzPressure(asset.reservoir.pInitBara, asset.reservoir.pNowBara, (p) => gas.z(p, asset.reservoir.tResC), totalCum > 0 ? cumAt(date) / totalCum : 0);

  const curves: Record<string, WellCurve> = {};
  const wells: WellRow[] = asset.wells.map((master) => {
    const series = op[master.id] ?? [];
    const last = series[series.length - 1];
    const fitPts = series.slice(-12);
    const curve = last ? fitWellheadCurve(fitPts.map((r) => r.whpBara), fitPts.map((r) => r.gasSm3d), master.id) : null;
    if (curve) curves[master.id] = curve;
    const dayGroups = new Map<string, typeof asset.tests>();
    for (const r of byWell(asset, master.id)) {
      const list = dayGroups.get(r.date) ?? [];
      list.push(r);
      dayGroups.set(r.date, list);
    }
    let deliverability: WellRow["deliverability"] = null;
    const multi = [...dayGroups.entries()].filter(([, rows]) => rows.length >= 3).sort((a, b) => b[0].localeCompare(a[0]));
    if (multi[0] && last) {
      const [date, rows] = multi[0];
      const pr = prAt(date);
      const pwf = rows.map((r) => bottomholeFromWellhead(gas, r.whpBara, T_WH_C, asset.reservoir.tResC, master.tvdM, r.gasSm3d, master.tubingIdIn));
      const fit = fitBackpressure(rows.map((r) => r.gasSm3d), pwf, pr);
      const flags: string[] = [];
      if (!fit) flags.push("Not fittable.");
      else {
        if (rows.length < 4) flags.push("Fewer than 4 rates.");
        if (fit.n < 0.5 || fit.n > 1) flags.push(`Exponent ${fit.n.toFixed(2)} is outside 0.5–1.`);
        if (fit.r2 < 0.9) flags.push("R² below 0.90.");
      }
      if (fit) {
        const nn = Math.min(1, Math.max(0.5, fit.n));
        const clipped = Math.abs(nn - fit.n) > 1e-6 ? fitBackpressure(rows.map((r) => r.gasSm3d), pwf, pr, nn) : fit;
        const use = clipped ?? fit;
        deliverability = { C: use.C, n: fit.n, r2: fit.r2, aof: aofSm3d(use.C, nn, pr), pr, nPts: rows.length, flags };
      }
    }
    const pwfSeries = series.map((r) => bottomholeFromWellhead(gas, r.whpBara, T_WH_C, asset.reservoir.tResC, master.tvdM, r.gasSm3d, master.tubingIdIn));
    const prSeries = series.map((r) => prAt(r.date));
    const cgrSeries = series.map((r) => (r.gasSm3d > 0 ? r.condM3d / (r.gasSm3d / 1e6) : NaN));
    const initialCgr = median(cgrSeries.slice(0, 3).filter((x) => Number.isFinite(x)));
    const pd = asset.fluid.dewPointBara ?? (Number.isFinite(initialCgr) ? dewPressureScreen(initialCgr, asset.fluid.gasSg, asset.reservoir.tResC) : NaN);
    const banking = bankingScore({
      whp: series.map((r) => r.whpBara),
      cgr: cgrSeries,
      pwf: pwfSeries,
      pr: prSeries,
      q: series.map((r) => r.gasSm3d),
      pd,
    });
    const t0 = series[0] ? Date.parse(series[0].date + "T00:00:00Z") : 0;
    const forecast = forecastWell(
      series.map((r) => r.date),
      series.map((r) => r.gasSm3d),
    );
    void t0;
    const cgr = last && last.gasSm3d > 0 ? last.condM3d / (last.gasSm3d / 1e6) : 0;
    const wgr = last && last.gasSm3d > 0 ? last.waterM3d / (last.gasSm3d / 1e6) : 0;
    const turner = last ? turnerRateSm3d(gas, last.whpBara, T_WH_C, master.tubingIdIn, asset.fluid.condDensity) : NaN;
    return {
      well: master.id,
      date: last?.date ?? "",
      whp: last?.whpBara ?? NaN,
      gas: last?.gasSm3d ?? 0,
      cond: last?.condM3d ?? 0,
      water: last?.waterM3d ?? 0,
      cgr,
      wgr,
      pwf: pwfSeries[pwfSeries.length - 1] ?? NaN,
      pr: prSeries[prSeries.length - 1] ?? NaN,
      turner,
      loading: Number.isFinite(turner) && (last?.gasSm3d ?? 0) < turner,
      curve,
      deliverability,
      forecast,
      banking,
      pdScreen: pd,
      pdBand: [pd * 0.75, pd * 1.25] as [number, number],
    };
  });

  const choke: Record<string, number> = {};
  const cgr: Record<string, number> = {};
  const wgr: Record<string, number> = {};
  for (const w of wells) {
    choke[w.well] = w.whp;
    cgr[w.well] = w.cgr;
    wgr[w.well] = w.wgr;
  }
  const baseInput: Omit<SolveInput, "facilityBara" | "gas"> = {
    edges: asset.nodes.map((n) => ({ ...n })),
    facilityId: asset.facility.id,
    curves,
    chokeBara: choke,
    cgr,
    wgr,
  };
  const relieve = (delta: number): Omit<SolveInput, "facilityBara" | "gas"> => ({
    ...baseInput,
    chokeBara: Object.fromEntries(Object.entries(choke).map(([k, v]) => [k, Math.max(40, v - delta)])),
  });
  const network = solveNetwork({ ...baseInput, facilityBara: asset.facility.inletBara, gas: fast });
  const gasUsd = (asset.economics.gasUsdPerMmbtu * asset.fluid.ghvMjPerSm3) / 1055.05585262;
  const condUsd = asset.economics.condUsdPerBbl * bblPerM3();
  const optArgs = {
    pMin: Math.max(28, asset.facility.inletBara - 18),
    pMax: Math.min(asset.facility.dischargeBara - 2, asset.facility.inletBara + 12),
    gasCap: asset.facility.gasCapSm3d,
    condCap: asset.facility.condCapM3d,
    waterCap: asset.facility.waterCapM3d,
    salesCap: asset.facility.salesCapSm3d,
    dischargeBara: asset.facility.dischargeBara,
    eta: asset.facility.compressorEfficiency,
    tC: 42,
    gas,
    fast,
    gasUsdPerSm3: gasUsd,
    condUsdPerM3: condUsd,
    waterUsdPerM3: asset.economics.waterUsdPerM3,
    powerUsdPerKwh: asset.economics.powerUsdPerKwh,
    fixedOpexUsdPerDay: asset.economics.fixedOpexUsdPerDay,
  };
  const runObj = (objective: "gas" | "margin" | "energy" | "flare", name: string, minGasFraction?: number) => {
    let picked = searchFacilityPressure({
      ...optArgs,
      base: baseInput,
      objective,
      name,
      minGasFraction,
    });
    for (const delta of [6, 12, 18]) {
      const row = searchFacilityPressure({
        ...optArgs,
        base: relieve(delta),
        objective,
        name: `${name} · wellhead floor reduced ${delta} bar (not below 40 bara)`,
        minGasFraction,
      });
      const better =
        row.feasible &&
        (!picked.feasible ||
          (objective === "gas" && row.gasSm3d > picked.gasSm3d + 50) ||
          (objective === "margin" && row.revenueUsdD > picked.revenueUsdD + 1) ||
          (objective === "energy" && row.powerKw < picked.powerKw - 0.5 && row.gasSm3d >= picked.gasSm3d * 0.97) ||
          (objective === "flare" && row.flareSm3d < picked.flareSm3d - 1));
      if (better) picked = row;
    }
    return picked;
  };
  const optimization = {
    base: searchFacilityPressure({
      ...optArgs,
      base: baseInput,
      pMin: asset.facility.inletBara,
      pMax: asset.facility.inletBara,
      step: 1,
      objective: "gas",
      name: "Configured inlet and current wellhead floors",
    }),
    maxGas: runObj("gas", "Maximum gas"),
    maxMargin: runObj("margin", "Maximum operating margin"),
    minEnergy: runObj("energy", "Lower compression power", 0.97),
    minFlare: runObj("flare", "Minimum sales-cap flare"),
  };
  const power = compressionKw(gas, Math.min(network.gasTotal, asset.facility.salesCapSm3d), asset.facility.inletBara, asset.facility.dischargeBara, 42, asset.facility.compressorEfficiency);
  const latestDate = dates[dates.length - 1] ?? "";
  const latestGas = wells.reduce((s, w) => s + w.gas, 0);
  const latestCond = wells.reduce((s, w) => s + w.cond, 0);
  const latestWater = wells.reduce((s, w) => s + w.water, 0);
  const nomination = asset.nominations.find((n) => n.date === latestDate)?.gasSm3d ?? NaN;
  const revenue = (Number.isFinite(nomination) ? Math.min(latestGas, asset.facility.salesCapSm3d) : latestGas) * gasUsd + latestCond * condUsd;
  const waterCost = latestWater * asset.economics.waterUsdPerM3;
  const powerUsd = power * 24 * asset.economics.powerUsdPerKwh;
  const mlRows: Row[] = [];
  for (const w of asset.wells) {
    const series = op[w.id] ?? [];
    for (let i = 1; i < series.length; i++) {
      const prev = series[i - 1]!;
      const cur = series[i]!;
      mlRows.push({
        well: w.id,
        date: cur.date,
        y: cur.gasSm3d,
        x: [prev.gasSm3d, cur.whpBara, prev.whpBara, prev.gasSm3d > 0 ? prev.condM3d / (prev.gasSm3d / 1e6) : 0],
      });
    }
  }
  const qc: QcItem[] = [];
  if (asset.synthetic) qc.push({ level: "info", message: "Demonstration dataset. Do not present these numbers as a real field." });
  for (const t of asset.tests) {
    if (t.gasSm3d < 0 || t.condM3d < 0 || t.waterM3d < 0) qc.push({ level: "fail", message: `Negative rate on ${t.well} ${t.date}.` });
  }
  const dup = new Set<string>();
  for (const t of asset.tests) {
    const k = `${t.well}|${t.date}|${t.whpBara}`;
    if (dup.has(k)) qc.push({ level: "warn", message: `Duplicate well/date/WHP ${k}.` });
    dup.add(k);
  }
  if (!asset.fluid.dewPointBara) qc.push({ level: "warn", message: "No laboratory dew point. Condensate banking uses a screening pressure only." });
  qc.push({ level: "info", message: "Reservoir pressure path is linear p/z between the configured initial and current pressures. It is not a measured survey unless you replace it." });
  if (asset.reserves.p1Sm3 == null) qc.push({ level: "info", message: "1P/2P/3P are blank. Nothing on the forecast page should be read as booked reserves." });

  const loadingWells = wells.filter((w) => w.loading).map((w) => w.well);
  const banked = wells.filter((w) => w.banking.light === "red" || w.banking.light === "amber").map((w) => w.well);
  const bottleneck = [...network.segments].sort((a, b) => b.util - a.util)[0];
  const gap = Number.isFinite(nomination) ? latestGas - nomination : NaN;
  const gapCauses: Snapshot["gapCauses"] = [
    {
      cause: "Decline versus nomination",
      detail: Number.isFinite(gap) && gap < 0 ? `Latest operating tests are ${(-gap / 1e6).toFixed(3)} MMSm3/d under the stored nomination.` : "Latest tests meet or exceed the nomination.",
      status: Number.isFinite(gap) && gap < -1e4 ? "indicated" : "not indicated",
    },
    {
      cause: "Liquid loading screen",
      detail: loadingWells.length ? `${loadingWells.join(", ")} produce below the Turner rate at the latest WHP.` : "No well is below its Turner rate on the latest test.",
      status: loadingWells.length ? "indicated" : "not indicated",
    },
    {
      cause: "Network utilisation",
      detail: bottleneck ? `Highest erosional utilisation is ${(bottleneck.util * 100).toFixed(0)}% on ${bottleneck.id} → ${bottleneck.to}.` : "No segments.",
      status: bottleneck && bottleneck.util > 0.8 ? "indicated" : "not indicated",
    },
    {
      cause: "Condensate-banking screen",
      detail: banked.length ? `${banked.join(", ")} have an amber or red screen. This is not a diagnosis.` : "No amber or red banking screen.",
      status: banked.length ? "indicated" : "not indicated",
    },
    {
      cause: "Measured flare",
      detail: asset.facility.measuredFlareSm3d == null ? "No measured flare series is loaded." : `Measured flare ${asset.facility.measuredFlareSm3d} Sm3/d.`,
      status: "not measured",
    },
  ];

  const fieldSeries = dates.map((date) => ({
    date,
    gas: asset.wells.reduce((s, w) => s + (op[w.id]!.find((r) => r.date === date)?.gasSm3d ?? 0), 0),
    cond: asset.wells.reduce((s, w) => s + (op[w.id]!.find((r) => r.date === date)?.condM3d ?? 0), 0),
    water: asset.wells.reduce((s, w) => s + (op[w.id]!.find((r) => r.date === date)?.waterM3d ?? 0), 0),
    nomination: asset.nominations.find((n) => n.date === date)?.gasSm3d ?? NaN,
  }));

  const defermentSm3 = asset.downtime.reduce((s, e) => {
    const days = Math.max(0, (Date.parse(e.end + "T00:00:00Z") - Date.parse(e.start + "T00:00:00Z")) / 86400e3);
    return s + days * e.lostGasSm3d;
  }, 0);

  return {
    generatedAt: "computed-with-snapshot",
    modelNotes: [
      ...gas.notes,
      "Wellhead temperature is assumed to be 40 °C for the gas column.",
      "Network liquid is a friction multiplier only. It does not add a hydrostatic holdup term.",
      "AI forecasts do not replace the decline curve or the network solve.",
    ],
    qc,
    dates,
    fieldSeries,
    latest: { date: latestDate, gas: latestGas, cond: latestCond, water: latestWater, nomination, gap },
    wells,
    clusters: kMeansWells(wells.map((w) => ({ well: w.well, cgr: w.cgr, wgr: w.wgr, decline: w.forecast.ok ? w.forecast.d : 0, whp: w.whp }))),
    network,
    curves,
    optimization,
    economics: {
      gasUsdPerSm3: gasUsd,
      condUsdPerM3: condUsd,
      revenueUsdD: revenue,
      waterCostUsdD: waterCost,
      powerUsdD: powerUsd,
      fixedUsdD: asset.economics.fixedOpexUsdPerDay,
      marginUsdD: revenue - waterCost - powerUsd - asset.economics.fixedOpexUsdPerDay,
      note: asset.economics.priceStatus,
    },
    energy: {
      powerKw: power,
      note: `Polytropic compression from ${asset.facility.inletBara} to ${asset.facility.dischargeBara} bara, n=1.28, efficiency ${asset.facility.compressorEfficiency}. Screening power only — not a compressor datasheet.`,
    },
    flare: {
      measured: asset.facility.measuredFlareSm3d,
      modelExcess: Math.max(0, network.gasTotal - asset.facility.salesCapSm3d),
      emissions: emissions(latestGas, asset.fluid.co2Pct, asset.facility.measuredFlareSm3d ?? 0),
    },
    defermentSm3,
    ml: runForecastModel(mlRows, ["Previous gas", "WHP", "Previous WHP", "Previous CGR"]),
    technicalEurSm3: wells.reduce((s, w) => s + (w.forecast.ok ? w.forecast.eurSm3 : 0), 0),
    gapCauses,
  };
}
