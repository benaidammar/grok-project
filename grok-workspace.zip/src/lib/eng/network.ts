import { FastGas, GasPVT } from "./pvt.ts";

export type Edge = {
  id: string;
  to: string;
  kind: "well" | "manifold" | "facility";
  lengthM: number;
  diameterIn: number;
  elevationM: number;
  roughnessMm: number;
};

export type WellCurve = {
  well: string;
  C: number;
  n: number;
  ps: number;
  r2: number;
  quality: string;
  nPts: number;
  whpMin: number;
  whpMax: number;
};

export function fitWellheadCurve(whp: number[], q: number[], well: string): WellCurve | null {
  const pts = whp.map((p, i) => ({ p, q: q[i]! })).filter((r) => r.p > 1 && r.q > 0);
  if (pts.length < 3) return null;
  const pmax = Math.max(...pts.map((r) => r.p));
  let best: { C: number; n: number; ps: number; sse: number } | null = null;
  for (let ip = 0; ip <= 16; ip++) {
    const ps = pmax * (1.05 + ip * 0.06);
    for (let n = 0.55; n <= 1.001; n += 0.05) {
      const x = pts.map((r) => Math.log(Math.max(ps * ps - r.p * r.p, 1)));
      const y = pts.map((r) => Math.log(r.q));
      const lc = y.reduce((s, yi, i) => s + yi - n * x[i]!, 0) / y.length;
      const C = Math.exp(lc);
      let sse = 0;
      for (let i = 0; i < y.length; i++) sse += (y[i]! - (lc + n * x[i]!)) ** 2;
      if (!best || sse < best.sse) best = { C, n, ps, sse };
    }
  }
  if (!best) return null;
  const y = pts.map((r) => Math.log(r.q));
  const yMean = y.reduce((s, v) => s + v, 0) / y.length;
  const ssTot = y.reduce((s, v) => s + (v - yMean) ** 2, 0);
  const r2 = ssTot > 0 ? 1 - best.sse / ssTot : 1;
  return {
    well,
    C: best.C,
    n: best.n,
    ps: best.ps,
    r2,
    quality: r2 >= 0.8 ? "acceptable screen fit" : "weak fit — treat rates as indicative",
    nPts: pts.length,
    whpMin: Math.min(...pts.map((r) => r.p)),
    whpMax: Math.max(...pts.map((r) => r.p)),
  };
}

export function curveRate(c: WellCurve, p: number): number {
  const v = Math.max(c.ps * c.ps - p * p, 0);
  return c.C * v ** c.n;
}

export type Hydraulics = {
  pUp: number;
  dp: number;
  velocity: number;
  erosional: number;
  util: number;
  phi2: number;
};

export function segmentHydraulics(
  gas: FastGas,
  pDown: number,
  qSm3d: number,
  lengthM: number,
  dzM: number,
  idIn: number,
  roughMm: number,
  liquidM3d: number,
  liquidDensity = 780,
): Hydraulics {
  const d = Math.max(idIn, 0.5) * 0.0254;
  const area = (Math.PI * d * d) / 4;
  const mg = (Math.max(qSm3d, 0) * gas.rhoStd) / 86400;
  const ml = (Math.max(liquidM3d, 0) * liquidDensity) / 86400;
  const R = 8.314462618;
  let pUp = pDown + 2;
  let phi2 = 1;
  for (let it = 0; it < 16; it++) {
    const pAvg = Math.max(0.5 * (pUp + pDown), 1);
    const z = gas.z(pAvg);
    const mu = Math.max(gas.muPas(pAvg), 1e-6);
    const rhoG = (pAvg * 1e5 * gas.M) / (z * R * gas.tk);
    const gFlux = mg / area;
    const re = Math.max((gFlux * d) / mu, 2300);
    const rel = (roughMm * 1e-3) / d;
    const f = 1 / (-1.8 * Math.log10((rel / 3.7) ** 1.11 + 6.9 / re)) ** 2;
    const aLraw = (gas.M * 9.80665 * dzM) / (z * R * gas.tk);
    const aL = Math.abs(aLraw) < 1e-6 ? (aLraw >= 0 ? 1e-6 : -1e-6) : aLraw;
    const b = (f * gFlux ** 2 * z * R * gas.tk) / (2 * d * gas.M);
    const X = mg > 1e-8 ? (ml / mg) * Math.sqrt(rhoG / liquidDensity) : 0;
    phi2 = 1 + 20 * X + X * X;
    const E = Math.exp(-2 * aL);
    const F = (1 - E) / aL;
    const p2 = ((pDown * 1e5) ** 2 + b * phi2 * lengthM * F) / Math.max(E, 1e-6);
    const next = Math.sqrt(Math.max(p2, 0)) / 1e5;
    if (Math.abs(next - pUp) < 1e-3) {
      pUp = next;
      break;
    }
    pUp = next;
  }
  const pAvg = Math.max(0.5 * (pUp + pDown), 1);
  const bg = gas.bg(pAvg);
  const volG = (Math.max(qSm3d, 0) * bg) / 86400;
  const volL = Math.max(liquidM3d, 0) / 86400;
  const v = (volG + volL) / area;
  const rhoMix = (mg + ml) / Math.max(volG + volL, 1e-9);
  const ve = (0.3048 * 100 * Math.sqrt(16.01846)) / Math.sqrt(Math.max(rhoMix, 1));
  return { pUp, dp: pUp - pDown, velocity: v, erosional: ve, util: v / ve, phi2 };
}

export type SolveInput = {
  edges: Edge[];
  facilityId: string;
  facilityBara: number;
  curves: Record<string, WellCurve>;
  chokeBara: Record<string, number>;
  /** Stock-tank condensate, m3 per million Sm3. */
  cgr: Record<string, number>;
  /** Stock-tank water, m3 per million Sm3. */
  wgr: Record<string, number>;
  gas: FastGas;
  maxRate?: Record<string, number>;
};

export type SolveResult = {
  converged: boolean;
  iterations: number;
  rates: Record<string, number>;
  liquid: Record<string, number>;
  cond: Record<string, number>;
  water: Record<string, number>;
  whp: Record<string, number>;
  limitedBy: Record<string, "choke" | "network" | "shut-in" | "cap">;
  segments: {
    id: string;
    to: string;
    q: number;
    pUp: number;
    pDown: number;
    dp: number;
    velocity: number;
    erosional: number;
    util: number;
    diameterIn: number;
  }[];
  gasTotal: number;
  liquidTotal: number;
  condTotal: number;
  waterTotal: number;
  outsideFit: string[];
};

export function solveNetwork(input: SolveInput): SolveResult {
  const nodes = input.edges;
  const byId = new Map(nodes.map((n) => [n.id, n]));
  const order: Edge[] = [];
  const done = new Set<string>([input.facilityId]);
  const pending = nodes.filter((n) => n.kind !== "facility" && n.to);
  for (let guard = 0; guard < 30 && pending.length; guard++) {
    for (let i = 0; i < pending.length; ) {
      if (done.has(pending[i]!.to) && byId.has(pending[i]!.to)) {
        order.push(pending[i]!);
        done.add(pending[i]!.id);
        pending.splice(i, 1);
      } else i++;
    }
  }
  const wells = nodes.filter((n) => n.kind === "well").map((n) => n.id);
  const upstream = new Map<string, string[]>();
  const kids = (id: string): string[] => {
    if (upstream.has(id)) return upstream.get(id)!;
    const children = nodes.filter((n) => n.to === id);
    const list = children.flatMap((c) => (c.kind === "well" ? [c.id] : kids(c.id)));
    upstream.set(id, list);
    return list;
  };
  for (const n of nodes) kids(n.id);

  const rates: Record<string, number> = {};
  for (const w of wells) {
    const c = input.curves[w];
    const choke = input.chokeBara[w] ?? (c ? c.ps * 0.7 : 50);
    rates[w] = c ? curveRate(c, choke) : 0;
  }
  let converged = false;
  let iterations = 0;
  let lastSeg: SolveResult["segments"] = [];
  const whp: Record<string, number> = {};
  const limited: SolveResult["limitedBy"] = {};
  const outsideFit: string[] = [];
  for (let it = 0; it < 28; it++) {
    iterations = it + 1;
    const p: Record<string, number> = { [input.facilityId]: input.facilityBara };
    const segs: SolveResult["segments"] = [];
    for (const edge of order) {
      const wellsUp = edge.kind === "well" ? [edge.id] : kids(edge.id);
      const q = wellsUp.reduce((s, w) => s + (rates[w] ?? 0), 0);
      const liq = wellsUp.reduce((s, w) => s + ((rates[w] ?? 0) / 1e6) * ((input.cgr[w] ?? 0) + (input.wgr[w] ?? 0)), 0);
      const down = byId.get(edge.to);
      const dz = (down?.elevationM ?? 0) - edge.elevationM;
      const h = segmentHydraulics(input.gas, p[edge.to] ?? input.facilityBara, q, Math.max(edge.lengthM, 1), dz, edge.diameterIn, edge.roughnessMm || 0.046, liq);
      p[edge.id] = h.pUp;
      segs.push({
        id: edge.id,
        to: edge.to,
        q,
        pUp: h.pUp,
        pDown: p[edge.to] ?? input.facilityBara,
        dp: h.dp,
        velocity: h.velocity,
        erosional: h.erosional,
        util: h.util,
        diameterIn: edge.diameterIn,
      });
    }
    lastSeg = segs;
    let maxRel = 0;
    for (const w of wells) {
      const c = input.curves[w];
      const pNode = p[w] ?? input.facilityBara;
      const choke = input.chokeBara[w] ?? pNode;
      let pFlow = Math.max(pNode, choke);
      let why: SolveResult["limitedBy"][string] = pNode > choke + 0.2 ? "network" : "choke";
      let qNew = c ? curveRate(c, pFlow) : 0;
      const cap = input.maxRate?.[w];
      if (cap != null && qNew > cap) {
        qNew = cap;
        why = "cap";
      }
      if (qNew < 1) why = "shut-in";
      if (c && pFlow < c.whpMin - 0.5) outsideFit.push(w);
      const prev = rates[w] ?? 0;
      let next = 0.45 * prev + 0.55 * qNew;
      if (cap != null) next = Math.min(next, cap);
      maxRel = Math.max(maxRel, Math.abs(next - prev) / Math.max(prev, next, 1));
      rates[w] = next;
      whp[w] = pFlow;
      limited[w] = why;
    }
    if (maxRel < 2e-3 && it > 2) {
      converged = true;
      break;
    }
  }
  const liquid: Record<string, number> = {};
  const cond: Record<string, number> = {};
  const water: Record<string, number> = {};
  for (const w of wells) {
    cond[w] = ((rates[w] ?? 0) / 1e6) * (input.cgr[w] ?? 0);
    water[w] = ((rates[w] ?? 0) / 1e6) * (input.wgr[w] ?? 0);
    liquid[w] = cond[w] + water[w];
  }
  return {
    converged,
    iterations,
    rates,
    liquid,
    cond,
    water,
    whp,
    limitedBy: limited,
    segments: lastSeg,
    gasTotal: wells.reduce((s, w) => s + (rates[w] ?? 0), 0),
    liquidTotal: wells.reduce((s, w) => s + (liquid[w] ?? 0), 0),
    condTotal: wells.reduce((s, w) => s + (cond[w] ?? 0), 0),
    waterTotal: wells.reduce((s, w) => s + (water[w] ?? 0), 0),
    outsideFit,
  };
}

export type Objective = "gas" | "margin" | "energy" | "flare";

export type OptScenario = {
  name: string;
  facilityBara: number;
  gasSm3d: number;
  condM3d: number;
  waterM3d: number;
  revenueUsdD: number;
  powerKw: number;
  flareSm3d: number;
  feasible: boolean;
  violations: string[];
  bottleneck: string;
  maxErosional: number;
  assumptions: string[];
  confidence: string;
};

export function equivalentDiameter(d1: number, d2: number): number {
  return (d1 ** 2.5 + d2 ** 2.5) ** (1 / 2.5);
}

export function compressionKw(gas: GasPVT, qSm3d: number, p1: number, p2: number, tC: number, eta: number): number {
  if (!(p2 > p1 + 0.2) || !(qSm3d > 0) || !(eta > 0)) return 0;
  const z = gas.z(0.5 * (p1 + p2), tC);
  const mDot = gas.kgPerSec(qSm3d);
  const mMol = gas.molWeight() * 1e-3;
  const n = 1.28;
  const rp = p2 / p1;
  const w = ((n / (n - 1)) * mDot * z * (8.314462618 / mMol) * (tC + 273.15) * (rp ** ((n - 1) / n) - 1)) / eta;
  return Math.max(w, 0) / 1000;
}

export function searchFacilityPressure(args: {
  base: Omit<SolveInput, "facilityBara" | "gas">;
  pMin: number;
  pMax: number;
  step?: number;
  gasCap: number;
  condCap: number;
  waterCap: number;
  salesCap: number;
  dischargeBara: number;
  eta: number;
  tC: number;
  gas: GasPVT;
  fast: FastGas;
  gasUsdPerSm3: number;
  condUsdPerM3: number;
  waterUsdPerM3: number;
  powerUsdPerKwh: number;
  fixedOpexUsdD: number;
  objective: Objective;
  name: string;
  minGasFraction?: number;
}): OptScenario {
  let best: OptScenario | null = null;
  let bestScore = -Infinity;
  const step = args.step ?? 2;
  const assumptions = [
    "Isothermal tree, Darcy–Haaland friction, Chisholm multiplier on the friction term only (no liquid holdup).",
    "Well rates come from a fitted wellhead back-pressure curve. Choke floors are the loaded operating wellhead pressures.",
    "Compression power uses polytropic n = 1.28 and the configured efficiency. Fuel is not subtracted from sales unless noted.",
    "Prices are the values stored on the asset. Demonstration prices are illustrative, not a market quote.",
    "Screening result. Not history-matched to a measured network and not a commercial simulator.",
  ];
  let peakGas = 0;
  const candidates: { row: OptScenario; score: number }[] = [];
  for (let p = args.pMin; p <= args.pMax + 1e-9; p += step) {
    const solved = solveNetwork({ ...args.base, facilityBara: p, gas: args.fast });
    const power = compressionKw(args.gas, Math.min(solved.gasTotal, args.salesCap), p, Math.max(args.dischargeBara, p), args.tC, args.eta);
    const flare = Math.max(0, solved.gasTotal - args.salesCap);
    const sales = Math.min(solved.gasTotal, args.salesCap);
    const revenue =
      sales * args.gasUsdPerSm3 +
      solved.condTotal * args.condUsdPerM3 -
      solved.waterTotal * args.waterUsdPerM3 -
      power * 24 * args.powerUsdPerKwh -
      args.fixedOpexUsdPerDay;
    const violations: string[] = [];
    if (!solved.converged) violations.push("Network iteration did not converge.");
    if (solved.gasTotal > args.gasCap * 1.001) violations.push("Gas handling capacity exceeded.");
    if (solved.condTotal > args.condCap * 1.001) violations.push("Condensate handling capacity exceeded.");
    if (solved.waterTotal > args.waterCap * 1.001) violations.push("Water handling capacity exceeded.");
    const maxU = solved.segments.reduce((m, s) => Math.max(m, s.util), 0);
    if (maxU > 1) violations.push("API RP 14E erosional velocity (C=100) exceeded.");
    if (solved.outsideFit.length) violations.push(`Wellhead pressure left the fitted range for ${solved.outsideFit.join(", ")}.`);
    const feasible = violations.length === 0 && solved.gasTotal > 0;
    const bottleneck = [...solved.segments].sort((a, b) => b.util - a.util)[0];
    const row: OptScenario = {
      name: args.name,
      facilityBara: +p.toFixed(2),
      gasSm3d: solved.gasTotal,
      condM3d: solved.condTotal,
      waterM3d: solved.waterTotal,
      revenueUsdD: revenue,
      powerKw: power,
      flareSm3d: flare,
      feasible,
      violations,
      bottleneck: bottleneck ? `${bottleneck.id} → ${bottleneck.to}` : "—",
      maxErosional: maxU,
      assumptions,
      confidence: feasible
        ? "Software-tested screening model. Not independently field-validated."
        : "Infeasible under the stated constraints. Not an operating recommendation.",
    };
    if (feasible) peakGas = Math.max(peakGas, solved.gasTotal);
    const score = args.objective === "gas" ? solved.gasTotal : args.objective === "margin" ? revenue : args.objective === "energy" ? -power : -flare;
    candidates.push({ row, score });
  }
  for (const c of candidates) {
    if (!c.row.feasible) continue;
    if (args.objective === "energy" && args.minGasFraction && c.row.gasSm3d < peakGas * args.minGasFraction) continue;
    if (c.score > bestScore) {
      bestScore = c.score;
      best = c.row;
    }
  }
  if (best) return best;
  return {
    name: args.name,
    facilityBara: NaN,
    gasSm3d: 0,
    condM3d: 0,
    waterM3d: 0,
    revenueUsdD: 0,
    powerKw: 0,
    flareSm3d: 0,
    feasible: false,
    violations: ["No facility pressure in the searched range satisfied the stated constraints."],
    bottleneck: "—",
    maxErosional: NaN,
    assumptions,
    confidence: "No feasible point. Do not treat as an operating recommendation.",
  };
}
