import assert from "node:assert/strict";
import test from "node:test";
import { pToBara } from "./units.ts";
import { GasPVT, bottomholeFromWellhead, co2DensityPr, dewPressureScreen, zFactor } from "./pvt.ts";
import { aofSm3d, arps, fitArps, fitBackpressure, nodalRate, turnerVelocityMs } from "./wells.ts";
import { equivalentDiameter, segmentHydraulics, solveNetwork } from "./network.ts";
import { FastGas } from "./pvt.ts";
import { espScreen, fracPkn, gasLiftOptimum, srpDisplacement } from "./screens.ts";
import { runForecastModel } from "./learn.ts";
import { buildDemonstrationAsset } from "./demo.ts";
import { analyse } from "./analyse.ts";

test("pressure datum is explicit", () => {
  const psig = pToBara(100, "psi", "gauge");
  const psia = pToBara(100, "psi", "absolute");
  assert.ok(Math.abs(psig - (100 * 0.0689475729 + 1.01325)) < 1e-9);
  assert.ok(psia < psig);
});

test("sweet-gas Z is near 1 at standard conditions", () => {
  const z = zFactor(0.7, 0, 0, 1.01325, 15);
  assert.ok(z > 0.97 && z < 1.03, `z=${z}`);
});

test("static column exceeds WHP and friction adds pressure", () => {
  const gas = new GasPVT(0.7, 2, 0, 0);
  const stat = bottomholeFromWellhead(gas, 80, 40, 110, 2500, 0, 4);
  const flow = bottomholeFromWellhead(gas, 80, 40, 110, 2500, 5e5, 4);
  assert.ok(stat > 80, `static ${stat}`);
  assert.ok(flow > stat, `flow ${flow} static ${stat}`);
});

test("back-pressure fit recovers C and n", () => {
  const C = 0.02;
  const n = 0.82;
  const pr = 200;
  const pwf = [150, 120, 90, 60];
  const q = pwf.map((p) => C * (pr * pr - p * p) ** n);
  const fit = fitBackpressure(q, pwf, pr);
  assert.ok(fit);
  assert.ok(Math.abs(fit!.n - n) / n < 0.02, JSON.stringify(fit));
  assert.ok(Math.abs(fit!.C - C) / C < 0.03, JSON.stringify(fit));
  assert.ok(aofSm3d(fit!.C, fit!.n, pr) > q[0]!);
});

test("Arps fit recovers a clean hyperbolic", () => {
  const t = Array.from({ length: 16 }, (_, i) => i * 0.5);
  const q = t.map((tt) => arps(tt, 1e6, 0.2, 0.5));
  const fit = fitArps(t, q);
  assert.ok(fit);
  assert.ok(Math.abs(fit!.qi / 1e6 - 1) < 0.08, JSON.stringify(fit));
  assert.ok(Math.abs(fit!.d - 0.2) < 0.06, JSON.stringify(fit));
});

test("nodal rate rises as WHP falls and stays below AOF", () => {
  const gas = new GasPVT(0.73, 3, 0, 0);
  const geom = { tvdM: 2500, idIn: 3.96, tResC: 108 };
  const hi = nodalRate(gas, geom, 40, 0.85, 250, 110);
  const lo = nodalRate(gas, geom, 40, 0.85, 250, 70);
  assert.ok(lo > hi && hi > 0, `${hi} ${lo}`);
  assert.ok(lo < aofSm3d(40, 0.85, 250));
});

test("line pressure drop rises with rate", () => {
  const gas = new FastGas(new GasPVT(0.73, 3, 0, 0), 40, 200);
  const a = segmentHydraulics(gas, 50, 2e5, 8000, 0, 6, 0.046, 10);
  const b = segmentHydraulics(gas, 50, 8e5, 8000, 0, 6, 0.046, 40);
  assert.ok(b.pUp > a.pUp, `${a.pUp} ${b.pUp}`);
  assert.ok(b.velocity > a.velocity);
});

test("network honours a hard well cap", () => {
  const gas = new FastGas(new GasPVT(0.7, 0, 0, 0), 40, 200);
  const solved = solveNetwork({
    edges: [
      { id: "W1", kind: "well", to: "CPF", lengthM: 1000, diameterIn: 8, elevationM: 10, roughnessMm: 0.046 },
      { id: "CPF", kind: "facility", to: "", lengthM: 0, diameterIn: 0, elevationM: 0, roughnessMm: 0.046 },
    ],
    facilityId: "CPF",
    facilityBara: 40,
    curves: { W1: { well: "W1", C: 500, n: 0.8, ps: 120, r2: 1, quality: "test", nPts: 5, whpMin: 40, whpMax: 110 } },
    chokeBara: { W1: 50 },
    cgr: { W1: 50 },
    wgr: { W1: 2 },
    gas,
    maxRate: { W1: 100000 },
  });
  assert.ok(solved.converged, "did not converge");
  assert.ok(solved.rates.W1! <= 100000 + 1, String(solved.rates.W1));
});

test("parallel-line equivalent diameter exceeds either line", () => {
  const de = equivalentDiameter(6, 6);
  assert.ok(de > 6 && de < 10);
});

test("dew point screen rises with CGR and is not labelled as a lab value", () => {
  assert.ok(dewPressureScreen(80, 0.73, 108) > dewPressureScreen(20, 0.73, 108));
});

test("Peng–Robinson CO2 density is in a dense-phase band at 150 bar, 60 C", () => {
  const rho = co2DensityPr(150, 60).rho;
  assert.ok(rho > 250 && rho < 900, String(rho));
});

test("ESP screen rejects an impossible head requirement", () => {
  const bad = espScreen({
    frequencyHz: 50,
    baseHz: 60,
    stages: 10,
    headPerStageM: 8,
    bepM3d: 200,
    rateM3d: 180,
    intakeBara: 30,
    dischargeRequiredBara: 180,
    sg: 0.85,
    ratedKw: 80,
    minIntakeBara: 15,
  });
  assert.equal(bad.inEnvelope, false);
});

test("gas-lift optimum is inside the searched response and SRP displacement matches the API coefficient", () => {
  const opt = gasLiftOptimum(400, 0.08, 0.01);
  assert.ok(opt.qInj > 0 && opt.qLiq > 0);
  assert.ok(Math.abs(srpDisplacement(1.5, 100, 8, 0.8) - 0.1166 * 2.25 * 100 * 8 * 0.8) < 1e-6);
});

test("PKN screen returns a finite length", () => {
  const g = fracPkn({ qM3Min: 4, tMin: 40, hM: 25, eGpa: 28, nu: 0.24, muCp: 20, clMSqrtMin: 0.0004 });
  assert.ok(!("error" in g), JSON.stringify(g));
  if (!("error" in g)) assert.ok(g.lengthM > 1 && g.widthMm > 0);
});

test("ML refuses a tiny sample and does not beat a report with invented accuracy", () => {
  const refused = runForecastModel(
    Array.from({ length: 4 }, (_, i) => ({ y: 10 + i, x: [9 + i, 1, 1, 1], date: `2024-0${i + 1}-01`, well: "A" })),
    ["lag"],
  );
  assert.equal(refused.status, "refused");
});

test("demonstration asset analyses, stays inside capacity, and keeps reserves blank", () => {
  const asset = buildDemonstrationAsset();
  assert.equal(asset.synthetic, true);
  assert.equal(asset.reserves.p2Sm3, null);
  assert.ok(asset.tests.length > 100);
  const snap = analyse(asset);
  assert.equal(snap.network.converged, true);
  assert.ok(snap.latest.gas > 0);
  assert.ok(snap.wells.every((w) => w.gas >= 0));
  assert.ok(snap.optimization.maxGas.feasible);
  assert.ok(snap.optimization.maxGas.gasSm3d <= asset.facility.gasCapSm3d * 1.001);
  assert.ok(snap.ml.status === "ran");
  assert.ok(snap.ml.nTest > 0);
  assert.ok(Number.isFinite(snap.ml.ridge.mae));
  const loaded = snap.wells.filter((w) => w.loading).length;
  assert.ok(loaded >= 0);
  for (const row of snap.optimization.maxGas.violations) assert.ok(!/exceeded/.test(row));
});

test("Turner velocity is positive", () => {
  const v = turnerVelocityMs(80, 720, 20);
  assert.ok(v > 0.2 && v < 20, String(v));
});
