/** Screening calculators. Each result states that it is not a specialist simulator. */

import { co2DensityPr, co2DensityStd } from "./pvt.ts";

export function espScreen(input: {
  frequencyHz: number;
  baseHz: number;
  stages: number;
  headPerStageM: number;
  bepM3d: number;
  rateM3d: number;
  intakeBara: number;
  dischargeRequiredBara: number;
  sg: number;
  ratedKw: number;
  minIntakeBara: number;
}): { headAvailableM: number; headRequiredM: number; load: number; flags: string[]; inEnvelope: boolean } {
  const f = input.frequencyHz / input.baseHz;
  const qBep = input.bepM3d * f;
  const affinity = input.rateM3d / Math.max(qBep, 1e-6);
  const headStage = input.headPerStageM * f * f * Math.max(0, 1 - 0.65 * (affinity - 1) ** 2);
  const headAvailableM = headStage * input.stages;
  const rho = input.sg * 1000;
  const headRequiredM = (Math.max(input.dischargeRequiredBara - input.intakeBara, 0) * 1e5) / (rho * 9.80665);
  const hydraulicKw = (rho * 9.80665 * (input.rateM3d / 86400) * headRequiredM) / 1000;
  const load = hydraulicKw / Math.max(input.ratedKw * 0.62, 0.1);
  const flags: string[] = [];
  if (input.intakeBara < input.minIntakeBara) flags.push("Intake pressure is below the configured minimum.");
  if (affinity < 0.5 || affinity > 1.35) flags.push("Rate is outside 50–135% of the affinity-shifted BEP. Envelope is a screen, not a pump curve.");
  if (headAvailableM + 1 < headRequiredM) flags.push("Estimated head does not meet the required discharge.");
  if (load > 1) flags.push("Hydraulic load exceeds the derated motor power (62% hydraulic allowance).");
  return { headAvailableM, headRequiredM, load, flags, inEnvelope: flags.length === 0 };
}

/** Saturating gas-lift response with an injection penalty. Not a drift-flux traverse. */
export function gasLiftResponse(qInj: number, qMax: number, k: number, penalty: number): number {
  return qMax * (1 - Math.exp(-k * Math.max(qInj, 0))) * Math.exp(-penalty * Math.max(qInj, 0));
}

export function gasLiftOptimum(qMax: number, k: number, penalty: number): { qInj: number; qLiq: number } {
  if (!(k > penalty)) return { qInj: 0, qLiq: gasLiftResponse(0, qMax, k, penalty) };
  const qInj = Math.log(k / penalty) / (k + penalty);
  return { qInj, qLiq: gasLiftResponse(qInj, qMax, k, penalty) };
}

export function srpDisplacement(diamIn: number, strokeIn: number, spm: number, eff: number): number {
  return 0.1166 * diamIn * diamIn * strokeIn * spm * eff;
}

function gamma(z: number): number {
  const p = [676.5203681218851, -1259.1392167224028, 771.3234287776531, -176.6150291621406, 12.507343278686905, -0.13857109526572012, 9.984369654078776e-6, 1.5056327351493116e-7];
  if (z < 0.5) return Math.PI / (Math.sin(Math.PI * z) * gamma(1 - z));
  z -= 1;
  let x = 0.9999999999998099;
  for (let i = 0; i < p.length; i++) x += p[i]! / (z + i + 1);
  const t = z + p.length - 0.5;
  return Math.sqrt(2 * Math.PI) * t ** (z + 0.5) * Math.exp(-t) * x;
}

export function fracPkn(input: {
  qM3Min: number;
  tMin: number;
  hM: number;
  eGpa: number;
  nu: number;
  muCp: number;
  clMSqrtMin: number;
}): { lengthM: number; widthMm: number; pNetBar: number; efficiency: number; note: string } | { error: string } {
  const ep = (input.eGpa * 1e9) / (1 - input.nu ** 2);
  const q = input.qM3Min / 60;
  const t = input.tMin * 60;
  const vol = q * t;
  const cl = input.clMSqrtMin / Math.sqrt(60);
  const coef = 2.5;
  let eta = 0.7;
  let out: { L: number; w: number; vf: number } | null = null;
  for (let it = 0; it < 30; it++) {
    const alpha = 0.5 + 0.3 * eta;
    const g = (gamma(alpha + 1) * gamma(1.5)) / gamma(alpha + 1.5);
    const f = (L: number) => {
      const w = coef * ((q * (input.muCp * 1e-3) * L) / ep) ** 0.25;
      const A = 2 * L * input.hM;
      const k = Math.PI / 4;
      return w * k * A + 4 * cl * A * Math.sqrt(t) * g - vol;
    };
    let lo = 0.05;
    let hi = 5000;
    if (f(lo) > 0 || f(hi) < 0) return { error: "PKN material balance did not bracket a length. Check rate, height and leakoff." };
    for (let i = 0; i < 48; i++) {
      const mid = 0.5 * (lo + hi);
      if (f(mid) > 0) hi = mid;
      else lo = mid;
    }
    const L = 0.5 * (lo + hi);
    const w = coef * ((q * (input.muCp * 1e-3) * L) / ep) ** 0.25;
    const vf = w * (Math.PI / 4) * (2 * L * input.hM);
    const etaNew = Math.max(0.05, Math.min(0.98, vf / vol));
    out = { L, w, vf };
    if (Math.abs(etaNew - eta) < 1e-3) {
      eta = etaNew;
      break;
    }
    eta = etaNew;
  }
  if (!out) return { error: "PKN screen failed to converge." };
  const pNet = (ep * out.w) / (2 * input.hM);
  return {
    lengthM: out.L,
    widthMm: out.w * 1e3,
    pNetBar: pNet / 1e5,
    efficiency: eta,
    note: "PKN + Carter leakoff, coefficient 2.5. Published width coefficients vary about 2.0–3.3. Not a 3D fracture design.",
  };
}

export function co2MassTd(qSm3d: number, co2MolPct: number): number {
  return (qSm3d * (co2MolPct / 100) * co2DensityStd()) / 1000;
}

export function salineCapacity(areaKm2: number, hM: number, phi: number, sw: number, pBara: number, tC: number, efficiency: number): { mt: number; rho: number; note: string } {
  const rho = co2DensityPr(pBara, tC).rho;
  const pore = areaKm2 * 1e6 * hM * phi * (1 - sw);
  const mt = (pore * efficiency * rho) / 1e9;
  return {
    mt,
    rho,
    note: "Volumetric screen M = A·h·φ·(1−Sw)·ρ·E using Peng–Robinson pure CO2. Efficiency is an input, not a DOE-NETL draw. Not a storage permit calculation.",
  };
}

export function emissions(gasSm3d: number, co2MolPct: number, flareSm3d: number, flareEf = 0.98): {
  producedTco2d: number;
  combustedTco2d: number;
  unburntTco2d: number;
  note: string;
} {
  const y = co2MolPct / 100;
  const produced = co2MassTd(gasSm3d, co2MolPct);
  const flaredStream = co2MassTd(flareSm3d, co2MolPct);
  const methaneExtra = ((flareSm3d * (1 - y) * (1 - flareEf) * co2DensityStd() * (16.04 / 44.01)) / 1000) * 28;
  return {
    producedTco2d: produced,
    combustedTco2d: flaredStream * flareEf,
    unburntTco2d: flaredStream * (1 - flareEf) + methaneExtra,
    note: "CO2 in the produced stream is not the same as combusted CO2. Unburnt flare uses a methane GWP of 28 over 100 years as a screening factor, not an inventory.",
  };
}
