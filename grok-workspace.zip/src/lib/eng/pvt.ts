/** Screening-grade gas PVT. Sutton (1985) + Wichert–Aziz (1972) + Dranchuk–Abou-Kassem (1975) + Lee–Gonzalez–Eakin (1966).
 * Not a laboratory equation of state. N2 shift is ignored, matching V18, and is reported when N2 is non-zero.
 */

import { ATM_BAR } from "./units.ts";

const R_SI = 8.314462618;
const M_AIR = 28.9647;
const A = {
  A1: 0.3265,
  A2: -1.07,
  A3: -0.5339,
  A4: 0.01569,
  A5: -0.05165,
  A6: 0.5475,
  A7: -0.7361,
  A8: 0.1844,
  A9: 0.1056,
  A10: 0.6134,
  A11: 0.721,
};

export type PseudoCritical = { tpcK: number; ppcBara: number; n2Ignored: boolean };

export function pseudoCritical(gasSg: number, co2Pct: number, h2sPpm: number): PseudoCritical {
  let tpc = 169.2 + 349.5 * gasSg - 74 * gasSg * gasSg;
  let ppc = 756.8 - 131 * gasSg - 3.6 * gasSg * gasSg;
  const a = co2Pct / 100 + h2sPpm / 1e6;
  const b = h2sPpm / 1e6;
  if (a > 0) {
    const eps = 120 * (a ** 0.9 - a ** 1.6) + 15 * (b ** 0.5 - b ** 4);
    const tpcC = tpc - eps;
    ppc = (ppc * tpcC) / (tpc + b * (1 - b) * eps);
    tpc = tpcC;
  }
  return { tpcK: tpc / 1.8, ppcBara: ppc * 0.0689475729, n2Ignored: false };
}

function zOfRho(rho: number, tpr: number): number {
  const r2 = rho * rho;
  const t2 = tpr * tpr;
  const t3 = t2 * tpr;
  const t4 = t3 * tpr;
  const t5 = t4 * tpr;
  return (
    1 +
    (A.A1 + A.A2 / tpr + A.A3 / t3 + A.A4 / t4 + A.A5 / t5) * rho +
    (A.A6 + A.A7 / tpr + A.A8 / t2) * r2 -
    A.A9 * (A.A7 / tpr + A.A8 / t2) * rho ** 5 +
    A.A10 * (1 + A.A11 * r2) * (r2 / t3) * Math.exp(-A.A11 * r2)
  );
}

export function zFactor(gasSg: number, co2Pct: number, h2sPpm: number, pBara: number, tC: number): number {
  const pc = pseudoCritical(gasSg, co2Pct, h2sPpm);
  const ppr = Math.max(pBara, 0.05) / pc.ppcBara;
  const tpr = (tC + 273.15) / pc.tpcK;
  let rho = (0.27 * ppr) / tpr;
  for (let i = 0; i < 60; i++) {
    const z = zOfRho(rho, tpr);
    const f = (0.27 * ppr) / (z * tpr) - rho;
    const h = 1e-6;
    const zh = zOfRho(rho + h, tpr);
    const fh = (0.27 * ppr) / (zh * tpr) - (rho + h);
    const d = (fh - f) / h;
    const step = Math.abs(d) > 1e-12 ? f / d : 0;
    rho = Math.min(3, Math.max(1e-6, rho - step));
    if (Math.abs(step) < 1e-10) break;
  }
  return (0.27 * ppr) / (rho * tpr);
}

export class GasPVT {
  readonly pc: PseudoCritical;
  readonly notes: string[] = [];
  readonly gasSg: number;
  readonly co2Pct: number;
  readonly h2sPpm: number;
  readonly n2Pct: number;
  readonly tStdC: number;
  readonly pStdBar: number;

  constructor(gasSg = 0.7, co2Pct = 0, h2sPpm = 0, n2Pct = 0, tStdC = 15, pStdBar = ATM_BAR) {
    this.gasSg = gasSg;
    this.co2Pct = co2Pct;
    this.h2sPpm = h2sPpm;
    this.n2Pct = n2Pct;
    this.tStdC = tStdC;
    this.pStdBar = pStdBar;
    this.pc = pseudoCritical(gasSg, co2Pct, h2sPpm);
    if (n2Pct > 0.05) {
      this.notes.push("N2 pseudo-critical shift is not applied (V18 convention). Effect is second-order for small N2.");
    }
    this.notes.push("Z: Dranchuk–Abou-Kassem. Viscosity: Lee–Gonzalez–Eakin. Pseudo-criticals: Sutton + Wichert–Aziz.");
  }

  molWeight(): number {
    return M_AIR * this.gasSg;
  }

  z(pBara: number, tC: number): number {
    return zFactor(this.gasSg, this.co2Pct, this.h2sPpm, pBara, tC);
  }

  rhoKgM3(pBara: number, tC: number): number {
    return (pBara * 1e5 * this.molWeight() * 1e-3) / (this.z(pBara, tC) * R_SI * (tC + 273.15));
  }

  bg(pBara: number, tC: number): number {
    return (this.z(pBara, tC) * (tC + 273.15) * this.pStdBar) / (pBara * (this.tStdC + 273.15));
  }

  muCp(pBara: number, tC: number): number {
    const m = this.molWeight();
    const tr = (tC + 273.15) * 1.8;
    const rhoGcc = this.rhoKgM3(pBara, tC) / 1000;
    const k = ((9.379 + 0.01607 * m) * tr ** 1.5) / (209.2 + 19.26 * m + tr);
    const x = 3.448 + 986.4 / tr + 0.01009 * m;
    const y = 2.447 - 0.2224 * x;
    return 1e-4 * k * Math.exp(x * rhoGcc ** y);
  }

  rhoStdKgPerSm3(): number {
    return (this.pStdBar * 1e5 * this.molWeight() * 1e-3) / (R_SI * (this.tStdC + 273.15));
  }

  kgPerSec(qSm3d: number): number {
    return (qSm3d * this.rhoStdKgPerSm3()) / 86400;
  }
}

/** Isothermal-average gas column. Dry-gas screening: liquids are ignored. */
export function bottomholeFromWellhead(
  gas: GasPVT,
  whpBara: number,
  tWhC: number,
  tBhC: number,
  tvdM: number,
  qSm3d = 0,
  idIn = 4,
  roughMm = 0.0457,
  mdM?: number,
): number {
  const md = mdM ?? tvdM;
  const tAvg = 0.5 * (tWhC + tBhC) + 273.15;
  const mKg = gas.molWeight() * 1e-3;
  const d = idIn * 0.0254;
  const area = (Math.PI * d * d) / 4;
  let pBh = whpBara * 1.1;
  for (let i = 0; i < 40; i++) {
    const pAvg = 0.5 * (whpBara + pBh);
    const z = gas.z(pAvg, tAvg - 273.15);
    const aL = (mKg * 9.80665 * tvdM) / (z * R_SI * tAvg);
    const gFlux = gas.kgPerSec(qSm3d) / area;
    const mu = gas.muCp(pAvg, tAvg - 273.15) * 1e-3;
    const re = Math.max((gFlux * d) / Math.max(mu, 1e-8), 5e3);
    const f = 1 / (-1.8 * Math.log10(6.9 / re + (roughMm * 1e-3 / d / 3.7) ** 1.11)) ** 2;
    const bOverA = ((f * gFlux ** 2 * z ** 2 * R_SI ** 2 * tAvg ** 2) / (2 * d * mKg ** 2 * 9.80665)) * (md / Math.max(tvdM, 1));
    const e2 = Math.exp(2 * aL);
    const p2 = (whpBara * 1e5) ** 2 * e2 + bOverA * (e2 - 1);
    const next = Math.sqrt(Math.max(p2, 0)) / 1e5;
    if (Math.abs(next - pBh) < 1e-4) return next;
    pBh = next;
  }
  return pBh;
}

export class FastGas {
  readonly p: number[];
  readonly zs: number[];
  readonly mus: number[];
  readonly M: number;
  readonly tk: number;
  readonly rhoStd: number;
  readonly gas: GasPVT;
  readonly tC: number;

  constructor(gas: GasPVT, tC: number, pmax = 400) {
    this.gas = gas;
    this.tC = tC;
    this.M = gas.molWeight() * 1e-3;
    this.tk = tC + 273.15;
    this.rhoStd = gas.rhoStdKgPerSm3();
    this.p = [];
    this.zs = [];
    this.mus = [];
    const n = 240;
    for (let i = 0; i < n; i++) {
      const p = 0.8 + ((pmax - 0.8) * i) / (n - 1);
      this.p.push(p);
      this.zs.push(gas.z(p, tC));
      this.mus.push(gas.muCp(p, tC));
    }
  }

  private interp(grid: number[], p: number): number {
    if (p <= this.p[0]!) return grid[0]!;
    const last = this.p.length - 1;
    if (p >= this.p[last]!) return grid[last]!;
    let lo = 0;
    let hi = last;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if (this.p[mid]! <= p) lo = mid;
      else hi = mid;
    }
    const t = (p - this.p[lo]!) / (this.p[hi]! - this.p[lo]!);
    return grid[lo]! * (1 - t) + grid[hi]! * t;
  }

  z(p: number): number {
    return this.interp(this.zs, p);
  }
  muPas(p: number): number {
    return this.interp(this.mus, p) * 1e-3;
  }
  rho(p: number): number {
    return (p * 1e5 * this.M) / (this.z(p) * R_SI * this.tk);
  }
  bg(p: number): number {
    return (this.z(p) * this.tk * this.gas.pStdBar) / (p * (this.gas.tStdC + 273.15));
  }
}

/** Peng–Robinson, pure CO2. Screening density — not Span–Wagner and not a mixture EOS. */
export function co2DensityPr(pBara: number, tC: number): { rho: number; z: number } {
  const Tc = 304.1282;
  const Pc = 73.773;
  const w = 0.22394;
  const T = tC + 273.15;
  const Tr = T / Tc;
  const kappa = 0.37464 + 1.54226 * w - 0.26992 * w * w;
  const alpha = (1 + kappa * (1 - Math.sqrt(Tr))) ** 2;
  const R = 83.144626181; // bar cm3 / mol K
  const a = (0.45724 * R * R * Tc * Tc) / Pc;
  const b = (0.0778 * R * Tc) / Pc;
  const A = (a * alpha * pBara) / (R * R * T * T);
  const B = (b * pBara) / (R * T);
  const roots = cubicRoots(-(1 - B), A - 3 * B * B - 2 * B, -(A * B - B * B - B * B * B)).filter((z) => z > B);
  const z = roots.length ? (Tr < 1 && pBara > Pc * 0.5 ? Math.min(...roots) : Math.max(...roots)) : 1;
  const zUse = z > 0.05 ? z : 0.3;
  const rho = (pBara * 1e5 * 0.04401) / (zUse * R_SI * T);
  return { rho, z: zUse };
}

function cubicRoots(a: number, b: number, c: number): number[] {
  const p = b - (a * a) / 3;
  const q = c + (2 * a * a * a) / 27 - (a * b) / 3;
  const disc = (q * q) / 4 + (p * p * p) / 27;
  const shift = -a / 3;
  if (disc > 1e-10) {
    const s = Math.sqrt(disc);
    const u = Math.cbrt(-q / 2 + s);
    const v = Math.cbrt(-q / 2 - s);
    return [u + v + shift];
  }
  const r = Math.sqrt(Math.max(-p / 3, 0));
  const arg = Math.max(-1, Math.min(1, r === 0 ? 0 : -q / (2 * r * r * r)));
  const phi = Math.acos(arg);
  return [0, 1, 2].map((k) => 2 * r * Math.cos((phi + 2 * Math.PI * k) / 3) + shift);
}

export function co2DensityStd(tC = 15, pBar = ATM_BAR): number {
  const z = tC <= 20 ? 0.994 : 0.995;
  return (44.01e-3 * pBar * 1e5) / (z * R_SI * (tC + 273.15));
}

/** Heuristic dew-point screen from V18. Not Nemeth–Kennedy. ±25% band. Lab value overrides. */
export function dewPressureScreen(cgr: number, gasSg = 0.7, tC = 100): number {
  const P0 = 60;
  const P1 = 105;
  const CGR0 = 15;
  const c = Math.max(cgr, 0);
  return (P0 + P1 * Math.log1p(c / CGR0)) * (1 + 0.5 * (gasSg - 0.7)) * Math.exp(-0.002 * (tC - 100));
}
