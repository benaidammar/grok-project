/** Small, explicit models. No fabricated accuracy. Refusal when the sample is too short.
 * Linear SHAP is exact only under a feature-independence assumption. TreeSHAP is not claimed.
 */

import { mean } from "./units.ts";

export type Row = { y: number; x: number[]; date: string; well: string };

export type MlReport = {
  status: "ran" | "refused";
  reason: string;
  target: string;
  features: string[];
  nTrain: number;
  nTest: number;
  ridge: { mae: number; rmse: number; r2: number };
  gbm: { mae: number; rmse: number; r2: number };
  naive: { mae: number; rmse: number; r2: number };
  permutation: { feature: string; deltaMae: number }[];
  linearShapNote: string;
  shapSample: { feature: string; value: number }[];
  residuals: { date: string; well: string; actual: number; ridge: number; z: number; flag: boolean }[];
  hyperparameters: string;
  leakageControls: string[];
};

function metrics(actual: number[], pred: number[]): { mae: number; rmse: number; r2: number } {
  const n = actual.length;
  if (!n) return { mae: NaN, rmse: NaN, r2: NaN };
  let se = 0;
  let ae = 0;
  const yBar = mean(actual);
  let sst = 0;
  for (let i = 0; i < n; i++) {
    const e = pred[i]! - actual[i]!;
    se += e * e;
    ae += Math.abs(e);
    sst += (actual[i]! - yBar) ** 2;
  }
  return { mae: ae / n, rmse: Math.sqrt(se / n), r2: sst > 0 ? 1 - se / sst : NaN };
}

function solve(a: number[][], b: number[]): number[] | null {
  const n = b.length;
  const m = a.map((row, i) => [...row, b[i]!]);
  for (let col = 0; col < n; col++) {
    let pivot = col;
    for (let r = col + 1; r < n; r++) if (Math.abs(m[r]![col]!) > Math.abs(m[pivot]![col]!)) pivot = r;
    if (Math.abs(m[pivot]![col]!) < 1e-12) return null;
    if (pivot !== col) {
      const tmp = m[col]!;
      m[col] = m[pivot]!;
      m[pivot] = tmp;
    }
    const div = m[col]![col]!;
    for (let c = col; c <= n; c++) m[col]![c]! /= div;
    for (let r = 0; r < n; r++) {
      if (r === col) continue;
      const f = m[r]![col]!;
      for (let c = col; c <= n; c++) m[r]![c]! -= f * m[col]![c]!;
    }
  }
  return m.map((row) => row[n]!);
}

type Stump = { feature: number; threshold: number; left: number; right: number };

function fitGbm(X: number[][], y: number[], nTrees = 40, lr = 0.15): { predict: (x: number[]) => number; trees: Stump[] } {
  const pred = new Array(y.length).fill(mean(y));
  const trees: Stump[] = [];
  const fCount = X[0]?.length ?? 0;
  for (let t = 0; t < nTrees; t++) {
    const resid = y.map((yi, i) => yi - pred[i]!);
    let best: Stump | null = null;
    let bestSse = Infinity;
    for (let f = 0; f < fCount; f++) {
      const vals = [...new Set(X.map((row) => row[f]!))].sort((a, b) => a - b);
      const cuts = vals.length < 2 ? [] : vals.slice(0, -1).map((v, i) => 0.5 * (v + vals[i + 1]!));
      const step = Math.max(1, Math.floor(cuts.length / 12));
      for (let c = 0; c < cuts.length; c += step) {
        const thr = cuts[c]!;
        const L: number[] = [];
        const R: number[] = [];
        for (let i = 0; i < X.length; i++) (X[i]![f]! <= thr ? L : R).push(resid[i]!);
        if (L.length < 2 || R.length < 2) continue;
        const left = mean(L);
        const right = mean(R);
        let sse = 0;
        for (const v of L) sse += (v - left) ** 2;
        for (const v of R) sse += (v - right) ** 2;
        if (sse < bestSse) {
          bestSse = sse;
          best = { feature: f, threshold: thr, left, right };
        }
      }
    }
    if (!best) break;
    trees.push(best);
    for (let i = 0; i < X.length; i++) {
      const leaf = X[i]![best.feature]! <= best.threshold ? best.left : best.right;
      pred[i] += lr * leaf;
    }
  }
  const base = mean(y);
  return {
    trees,
    predict: (x) => {
      let yhat = base;
      for (const tree of trees) yhat += lr * (x[tree.feature]! <= tree.threshold ? tree.left : tree.right);
      return yhat;
    },
  };
}

export function runForecastModel(rows: Row[], featureNames: string[]): MlReport {
  const refused = (reason: string): MlReport => ({
    status: "refused",
    reason,
    target: "Next gas rate, Sm3/d",
    features: featureNames,
    nTrain: 0,
    nTest: 0,
    ridge: { mae: NaN, rmse: NaN, r2: NaN },
    gbm: { mae: NaN, rmse: NaN, r2: NaN },
    naive: { mae: NaN, rmse: NaN, r2: NaN },
    permutation: [],
    linearShapNote: "Not computed.",
    shapSample: [],
    residuals: [],
    hyperparameters: "Ridge λ = 1 on standardized features. GBM: 40 depth-1 trees, learning rate 0.15.",
    leakageControls: ["Time order preserved.", "No random shuffle across time.", "Standardization statistics from the training block only."],
  });
  const byWell = new Map<string, Row[]>();
  for (const r of rows) {
    const list = byWell.get(r.well) ?? [];
    list.push(r);
    byWell.set(r.well, list);
  }
  const train: Row[] = [];
  const test: Row[] = [];
  for (const list of byWell.values()) {
    const sorted = [...list].sort((a, b) => a.date.localeCompare(b.date));
    if (sorted.length < 8) continue;
    const k = Math.floor(sorted.length * 0.7);
    train.push(...sorted.slice(0, k));
    test.push(...sorted.slice(k));
  }
  if (train.length < 16 || test.length < 6) {
    return refused(`Need at least 8 ordered tests on enough wells to hold out a test block. Usable train ${train.length}, test ${test.length}.`);
  }
  const dim = featureNames.length;
  const mu = new Array(dim).fill(0);
  const sd = new Array(dim).fill(1);
  for (let j = 0; j < dim; j++) {
    const col = train.map((r) => r.x[j]!);
    mu[j] = mean(col);
    const v = mean(col.map((x) => (x - mu[j]!) ** 2));
    sd[j] = Math.sqrt(v) > 1e-9 ? Math.sqrt(v) : 1;
  }
  const scale = (x: number[]) => x.map((v, j) => (v - mu[j]!) / sd[j]!);
  const Xt = train.map((r) => [1, ...scale(r.x)]);
  const p = dim + 1;
  const ata = Array.from({ length: p }, () => new Array(p).fill(0));
  const atb = new Array(p).fill(0);
  const lambda = 1;
  for (let i = 0; i < Xt.length; i++) {
    for (let a = 0; a < p; a++) {
      atb[a] += Xt[i]![a]! * train[i]!.y;
      for (let b = 0; b < p; b++) ata[a]![b] += Xt[i]![a]! * Xt[i]![b]!;
    }
  }
  for (let a = 1; a < p; a++) ata[a]![a] += lambda;
  const beta = solve(ata, atb);
  if (!beta) return refused("Ridge system was singular. Model refused rather than returning a number.");
  const predictRidge = (x: number[]) => {
    const s = [1, ...scale(x)];
    return s.reduce((acc, v, i) => acc + v * beta[i]!, 0);
  };
  const gbm = fitGbm(train.map((r) => scale(r.x)), train.map((r) => r.y));
  const actual = test.map((r) => r.y);
  const ridgePred = test.map((r) => predictRidge(r.x));
  const gbmPred = test.map((r) => gbm.predict(scale(r.x)));
  const naivePred = test.map((r) => r.x[0]!);
  const permutation = featureNames.map((feature, j) => {
    const shuffled = test.map((r) => r.x.slice());
    const col = shuffled.map((r) => r[j]!);
    for (let i = col.length - 1; i > 0; i--) {
      const k = (i * 17) % (i + 1);
      const tmp = col[i]!;
      col[i] = col[k]!;
      col[k] = tmp;
    }
    shuffled.forEach((r, i) => (r[j] = col[i]!));
    const pred = shuffled.map((x) => predictRidge(x));
    return { feature, deltaMae: metrics(actual, pred).mae - metrics(actual, ridgePred).mae };
  });
  const last = test[test.length - 1]!;
  const scaledLast = scale(last.x);
  const shapSample = featureNames.map((feature, j) => ({
    feature,
    value: (scaledLast[j]! - 0) * beta[j + 1]!,
  }));
  const resid = test.map((r, i) => r.y - ridgePred[i]!);
  const rMean = mean(resid);
  const rSd = Math.sqrt(mean(resid.map((e) => (e - rMean) ** 2))) || 1;
  return {
    status: "ran",
    reason: "Time-based holdout on the loaded tests. Metrics are calculated, not assumed.",
    target: "Gas rate at the test date, Sm3/d",
    features: featureNames,
    nTrain: train.length,
    nTest: test.length,
    ridge: metrics(actual, ridgePred),
    gbm: metrics(actual, gbmPred),
    naive: metrics(actual, naivePred),
    permutation: permutation.sort((a, b) => b.deltaMae - a.deltaMae),
    linearShapNote:
      "Values are exact linear-model SHAP contributions for one test row under feature independence (φj = βj · z_j, training mean of z is 0). This is not TreeSHAP and ignores feature dependence.",
    shapSample,
    residuals: test.map((r, i) => {
      const z = (r.y - ridgePred[i]! - rMean) / rSd;
      return { date: r.date, well: r.well, actual: r.y, ridge: ridgePred[i]!, z, flag: Math.abs(z) > 3 };
    }),
    hyperparameters: "Ridge λ = 1 on standardized inputs, intercept unpenalized. GBM: 40 regression stumps, learning rate 0.15, trained on the training block only.",
    leakageControls: [
      "Split is the last 30% of dates within each well, not a random row split.",
      "Feature scaling mean and standard deviation are fit on the training block only.",
      "Lag features use prior tests only.",
      "The model does not override the network or deliverability constraints.",
    ],
  };
}

export type Cluster = { well: string; cluster: number; cgr: number; wgr: number; decline: number; whp: number };

export function kMeansWells(points: { well: string; cgr: number; wgr: number; decline: number; whp: number }[], k = 3): Cluster[] {
  if (points.length < k) return points.map((p) => ({ ...p, cluster: 0 }));
  const cols: (keyof Omit<(typeof points)[0], "well">)[] = ["cgr", "wgr", "decline", "whp"];
  const stats = Object.fromEntries(
    cols.map((c) => {
      const xs = points.map((p) => p[c]);
      const m = mean(xs);
      const s = Math.sqrt(mean(xs.map((x) => (x - m) ** 2))) || 1;
      return [c, { m, s }];
    }),
  ) as Record<(typeof cols)[number], { m: number; s: number }>;
  const z = (p: (typeof points)[0]) => cols.map((c) => (p[c] - stats[c].m) / stats[c].s);
  let centers = points.slice(0, k).map(z);
  let labels = new Array(points.length).fill(0);
  for (let it = 0; it < 24; it++) {
    labels = points.map((p) => {
      const v = z(p);
      let best = 0;
      let dist = Infinity;
      centers.forEach((c, i) => {
        const d = v.reduce((s, x, j) => s + (x - c[j]!) ** 2, 0);
        if (d < dist) {
          dist = d;
          best = i;
        }
      });
      return best;
    });
    centers = centers.map((_, i) => {
      const members = points.filter((_, j) => labels[j] === i).map(z);
      if (!members.length) return centers[i]!;
      return cols.map((_, j) => mean(members.map((m) => m[j]!)));
    });
  }
  return points.map((p, i) => ({ ...p, cluster: labels[i]! }));
}
