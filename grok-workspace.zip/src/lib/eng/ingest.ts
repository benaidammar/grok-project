import type { AssetModel, TestRow } from "./types.ts";
import { gasToSm3d, liqToM3d, pToBara } from "./units.ts";

export type ImportResult = { rows: TestRow[]; notes: string[] } | { error: string };

const SYNONYM: Record<string, string[]> = {
  well: ["well", "puits", "site", "uwi", "name"],
  date: ["date", "time", "jour", "month"],
  whp: ["whp", "thp", "wellhead", "pwh", "pt_tete"],
  gas: ["gas", "qg", "gaz", "gas_sm3d", "gas_rate"],
  cond: ["cond", "condensate", "condensat", "qc"],
  water: ["water", "eau", "qw"],
};

function norm(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
}

export function parseWellTests(text: string, pressureUnit = "bara", datum: "gauge" | "absolute" = "absolute", gasUnit = "Sm3/d", liquidUnit = "m3/d"): ImportResult {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).filter((l) => l.trim().length);
  if (lines.length < 2) return { error: "The file needs a header and at least one row." };
  const header = splitCsv(lines[0]!).map(norm);
  const col = (key: string) => header.findIndex((h) => SYNONYM[key]!.some((s) => h === s || h.includes(s)));
  const iw = col("well");
  const id = col("date");
  const ig = col("gas");
  if (iw < 0 || id < 0 || ig < 0) return { error: "Could not find well, date and gas columns. Expected names such as well, date, gas or qg." };
  const ip = col("whp");
  const ic = col("cond");
  const iq = col("water");
  const notes = [
    ip < 0 ? "No wellhead pressure column. WHP will be blank and deliverability will not run." : `Pressure read as ${pressureUnit} (${datum}).`,
    `Gas read as ${gasUnit}. Liquids read as ${liquidUnit}.`,
  ];
  const rows: TestRow[] = [];
  for (let i = 1; i < lines.length; i++) {
    const c = splitCsv(lines[i]!);
    if (!c[iw] || !c[id]) continue;
    const gas = gasToSm3d(Number(c[ig]), gasUnit);
    if (!Number.isFinite(gas)) continue;
    const whpRaw = ip >= 0 ? Number(c[ip]) : NaN;
    rows.push({
      well: c[iw]!.trim(),
      date: c[id]!.trim().slice(0, 10),
      whpBara: Number.isFinite(whpRaw) ? pToBara(whpRaw, pressureUnit, datum) : NaN,
      gasSm3d: gas,
      condM3d: ic >= 0 && Number.isFinite(Number(c[ic])) ? liqToM3d(Number(c[ic]), liquidUnit) : 0,
      waterM3d: iq >= 0 && Number.isFinite(Number(c[iq])) ? liqToM3d(Number(c[iq]), liquidUnit) : 0,
    });
  }
  if (!rows.length) return { error: "No numeric data rows were read." };
  return { rows, notes };
}

function splitCsv(line: string): string[] {
  const out: string[] = [];
  let cur = "";
  let q = false;
  for (const ch of line) {
    if (ch === '"') q = !q;
    else if (ch === "," && !q) {
      out.push(cur.trim());
      cur = "";
    } else cur += ch;
  }
  out.push(cur.trim());
  return out;
}

export function assetFromTests(base: AssetModel, rows: TestRow[], fileName: string): AssetModel {
  const ids = [...new Set(rows.map((r) => r.well))];
  const wells = ids.map((id) => base.wells.find((w) => w.id === id) ?? { id, tvdM: base.reservoir.pNowBara ? base.wells[0]?.tvdM ?? 2500 : 2500, tubingIdIn: base.wells[0]?.tubingIdIn ?? 3.958, lift: "flowing" as const });
  const known = new Set(ids);
  const nodes = [
    ...wells.map((w, i) => ({
      id: w.id,
      kind: "well" as const,
      to: base.facility.id,
      lengthM: 3000 + i * 200,
      diameterIn: 6,
      elevationM: 80,
      roughnessMm: 0.046,
    })),
    ...base.nodes.filter((n) => n.kind === "facility"),
  ];
  return {
    ...base,
    id: `import-${fileName.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}`,
    name: fileName.replace(/\.[^.]+$/, ""),
    synthetic: false,
    provenance: `Imported from ${fileName}. Network lengths are placeholders until a network file is loaded. Not validated.`,
    wells,
    nodes: nodes.some((n) => n.kind === "facility") ? nodes : [...nodes, { id: base.facility.id, kind: "facility", to: "", lengthM: 0, diameterIn: 0, elevationM: 0, roughnessMm: 0.046 }],
    tests: rows,
    nominations: [],
    downtime: [],
    drilling: [],
    reserves: { p1Sm3: null, p2Sm3: null, p3Sm3: null, source: "Not supplied with the import." },
  };
  void known;
}
