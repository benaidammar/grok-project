import { createFileRoute } from "@tanstack/react-router";
import { Desk } from "@/components/meridian/desk";

export const Route = createFileRoute("/")({
  component: Desk,
});
