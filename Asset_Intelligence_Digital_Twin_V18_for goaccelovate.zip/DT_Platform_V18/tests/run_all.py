"""Run every module selftest that exists. usage: python tests/run_all.py"""
import importlib
import pkgutil
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import dtp

bad = 0
for pkg in ("core", "mgmt", "lift", "gascond", "frac", "ccus", "ai", "hub"):
    try:
        p = importlib.import_module(f"dtp.{pkg}")
    except Exception:
        continue
    for m in pkgutil.iter_modules(p.__path__):
        mod = importlib.import_module(f"dtp.{pkg}.{m.name}")
        if hasattr(mod, "selftest"):
            t0 = time.time()
            try:
                out = mod.selftest()
                print(f"PASS  dtp.{pkg}.{m.name:<18} {time.time()-t0:5.1f}s")
            except Exception:
                bad += 1
                print(f"FAIL  dtp.{pkg}.{m.name}\n{traceback.format_exc()}")
sys.exit(1 if bad else 0)
