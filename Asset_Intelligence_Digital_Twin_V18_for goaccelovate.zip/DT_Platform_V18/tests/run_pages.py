"""Render pages headlessly with Streamlit's AppTest and report exceptions.
   usage: python tests/run_pages.py [module:function ...]   (default: every page in dtp/ui/pages.py)"""
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ["DTP_AUTOLOAD_SAMPLE"] = "1"
from streamlit.testing.v1 import AppTest

from dtp.ui.pages import PAGES


def run(spec: str, timeout: int = 120) -> tuple[bool, str, float]:
    os.environ["DTP_PAGE"] = spec
    t0 = time.time()
    at = AppTest.from_file(str(ROOT / "tests" / "page_runner.py"), default_timeout=timeout).run()
    errs = [str(e.value) for e in at.exception] + [e.value for e in at.error]
    return (not at.exception), (" | ".join(map(str, errs))[:600] if errs else ""), time.time() - t0


if __name__ == "__main__":
    specs = sys.argv[1:] or [p[2] for p in PAGES]
    bad = 0
    for s in specs:
        ok, msg, dt = run(s)
        print(f"{'PASS' if ok else 'FAIL'}  {s:<40} {dt:5.1f}s  {msg}")
        bad += not ok
    sys.exit(1 if bad else 0)
