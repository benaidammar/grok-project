"""Streamlit script used by tests: renders ONE page with the Field sample loaded.
   DTP_PAGE="dtp.ui.page_esp:render"  python -c "from streamlit.testing.v1 import AppTest; ..."  (see tests/run_pages.py)"""
import importlib
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import streamlit as st

from dtp.ui.bootstrap import build_ctx

st.set_page_config(layout="wide")
mod, fn = os.environ["DTP_PAGE"].split(":")
ctx = build_ctx(st)
getattr(importlib.import_module(mod), fn)(ctx)
