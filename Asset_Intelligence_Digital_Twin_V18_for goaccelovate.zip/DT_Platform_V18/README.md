# Asset Intelligence Digital Twin — V18 Buyer Package

## Purpose
A configurable engineering decision-support platform for upstream assets. The buyer supplies and configures its own field data. This package does not include the developer’s private sample datasets.

## Run
1. Install Python 3.10+ and the packages in `requirements.txt`.
2. Run `streamlit run app.py`.
3. Upload the buyer’s own data through the Data Foundation page, review column mapping, units, datum, quality checks, and asset configuration before using engineering modules.

## Important scope and validation
This is an engineering screening and decision-support application, not a certified simulator or an autonomous control system. Results depend on input quality, selected correlations, configuration, and the applicable operating envelope. A successful software test does not establish field accuracy.

Before operational use, the buyer must calibrate applicable models against its own measured data, compare predictions with independent/held-out observations, document errors and limitations, and obtain qualified engineering approval. No model should be treated as field-validated solely because it runs or produces a result.

The application includes screening-grade methods and generic/default parameters in some modules. Replace defaults with asset-specific and vendor/laboratory data where applicable. Recommendations require engineering review; no closed-loop control is provided.

## Tests
Run `python tests/run_all.py` for module self-tests. These tests assess software behavior only; they do not validate models against any particular field. The former sample-driven page test is not included in this buyer package because private sample data have been removed.
