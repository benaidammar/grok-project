"""One-click launcher: installs missing packages (first run, needs internet) and opens the app.
   Windows: open this file in VS Code / IDLE and press F5, or:  py RUN_ME.py"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from dtp.core import deps

deps.ensure_packages(include_optional=False)
print("Starting the platform... a browser tab opens at http://localhost:8501  (Ctrl+C to stop)")
subprocess.call([sys.executable, "-m", "streamlit", "run", str(ROOT / "app.py")])
