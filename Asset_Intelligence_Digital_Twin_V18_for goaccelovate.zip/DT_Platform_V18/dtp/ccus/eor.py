"""CO2-EOR screening, minimum miscibility pressure, incremental oil; enhanced gas/condensate recovery (voidage replacement) screening."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..core.status import Result, Status
from . import co2props as P


def mmp_cronquist(t_c: float, mw_c5plus: float, vol_pct: float) -> float:
    """Cronquist (1978): MMP[psia] = 15.988 T[F]^(0.744206 + 0.0011038 MW_C5+ + 0.0015279 y_vol%). Return bara."""
    tf = t_c * 1.8 + 32
    return 15.988 * tf ** (0.744206 + 0.0011038 * mw_c5plus + 0.0015279 * vol_pct) * 0.0689476


def mmp_yellig_metcalfe(t_c: float) -> float:
    """Yellig & Metcalfe (1980), pure CO2: MMP[psia] = 1833.7217 + 2.2518055 T + 0.01800674 T^2 - 103949.93/T (T in F). Return bara."""
    tf = t_c * 1.8 + 32
    return (1833.7217 + 2.2518055 * tf + 0.01800674 * tf ** 2 - 103949.93 / tf) * 0.0689476


def screen(api: float, visc_cp: float, depth_m: float, t_c: float, p_res: float, so_pct: float, perm_md: float, mw_c5=180.0, vol_pct=40.0, frac_gradient_bar_m=0.17) -> Result:
    """Textbook-style criteria (Taber, Martin & Seright 1997 ranges; verify) + miscibility check."""
    mmp = [mmp_cronquist(t_c, mw_c5, vol_pct), mmp_yellig_metcalfe(t_c)]
    p_frac = frac_gradient_bar_m * depth_m
    rows = [("Oil gravity > 22 API (miscible > 27)", api > 22, f"{api}"), ("Viscosity < 10 cP", visc_cp < 10, f"{visc_cp}"), ("Depth > 760 m", depth_m > 760, f"{depth_m}"),
            ("Remaining oil saturation > 20 %", so_pct > 20, f"{so_pct}"), ("Permeability > 1 mD (not critical)", perm_md > 1, f"{perm_md}"),
            (f"Pr above MMP (Cronquist {mmp[0]:.0f} / Y-M {mmp[1]:.0f} bara)", p_res > max(mmp), f"{p_res:.0f}"),
            (f"MMP below ~ 90 % fracture pressure ({0.9 * p_frac:.0f} bara)", max(mmp) < 0.9 * p_frac, "")]
    df = pd.DataFrame(rows, columns=["criterion", "pass", "value"])
    res = Result("CO2-EOR screen", dict(table=df, mmp=mmp, miscible=bool(p_res > max(mmp))), Status.UNVALIDATED)
    res.messages.append(f"{int(df['pass'].sum())}/{len(df)} criteria met. Screening only; slim-tube / compositional simulation required.")
    return res


def incremental_oil(co2_t_per_year: float, utilisation_mscf_per_stb: tuple = (4.0, 6.0, 10.0), rho_std: float = 1.872) -> pd.DataFrame:
    """Net utilisation (purchased + recycled-lost CO2 per incremental stb): P10 / P50 / P90 as low-mid-high cases of bbl/yr."""
    t_per_mscf = 28.3168 * rho_std / 1000.0
    rows = [dict(case=n, mscf_per_stb=u, bbl_per_year=co2_t_per_year / (u * t_per_mscf), t_co2_per_bbl=u * t_per_mscf) for n, u in zip(("optimistic", "base", "pessimistic"), utilisation_mscf_per_stb)]
    return pd.DataFrame(rows)


def egr_voidage(gas_sm3d: float, cond_m3d: float, pr_bara: float, t_c: float, bg_prod: float, co2_t_per_day: float) -> dict:
    """Voidage-replacement screen for pressure maintenance with CO2 at reservoir conditions.
    voidage [rm3/d] = gas x Bg(produced); CO2 needed = voidage x rho_CO2(Pr,T); VRR achievable = available / needed."""
    void = gas_sm3d * bg_prod + cond_m3d * 2.0
    rho = float(P.density(pr_bara, t_c))
    need_t = void * rho / 1000.0
    return dict(voidage_rm3d=void, rho_co2=rho, co2_needed_t_d=need_t, vrr=co2_t_per_day / need_t if need_t > 0 else np.nan,
                note="Liquids voidage uses Bo~2 placeholder. Compositional simulation needed for revaporisation, breakthrough and gravity override.")


def selftest() -> dict:
    ym = mmp_yellig_metcalfe(100.0)
    assert 120 < ym < 230, ym
    assert mmp_cronquist(100.0, 180, 40) > 100
    assert incremental_oil(1e5).bbl_per_year.iloc[0] > incremental_oil(1e5).bbl_per_year.iloc[2]
    return dict(ym_100C=ym)
