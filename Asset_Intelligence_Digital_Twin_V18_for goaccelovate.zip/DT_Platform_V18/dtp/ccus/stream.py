"""The CO2 stream handed between CCUS tabs (inventory -> capture -> transport -> utilisation / storage -> accounting)."""
from __future__ import annotations
from dataclasses import dataclass, field

import pandas as pd


@dataclass
class CO2Stream:
    t_per_day: float                  # tonnes CO2 / day contained in the produced gas (average over the planning period)
    mol_frac: float                   # CO2 mole fraction in the produced gas (0-1)  e.g. 0.02 for 2 %
    gas_sm3d: float                   # produced gas rate behind it [Sm3/d]
    pressure_bara: float = 30.0       # pressure at the capture / separation plant inlet
    temp_c: float = 40.0
    h2s_ppm: float = 0.0
    lifetime_years: float = 15.0
    capture_target_pct: float = 100.0 # share of contained CO2 the user wants to capture (spec removal may need less)
    profile: pd.DataFrame | None = None   # columns: year (int), t_per_year (float) - declines with the gas forecast
    source: str = "manual"            # 'well_tests' | 'manual' | 'forecast'
    notes: list = field(default_factory=list)

    @property
    def t_per_year(self) -> float:
        return self.t_per_day * 365.25

    @property
    def mt_total(self) -> float:
        """Total tonnes over the lifetime in Mt (uses profile if given)."""
        if self.profile is not None and len(self.profile):
            return float(self.profile["t_per_year"].sum()) / 1e6
        return self.t_per_year * self.lifetime_years / 1e6
