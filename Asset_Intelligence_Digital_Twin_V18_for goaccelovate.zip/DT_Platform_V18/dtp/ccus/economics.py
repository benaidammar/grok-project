"""Cash-flow engine for any CO2 pathway: NPV, levelised cost, breakeven carbon price, tornado, Monte-Carlo. All inputs are user values."""
from __future__ import annotations
import numpy as np
import pandas as pd


def cashflow_npv(capex: float, opex_fixed_yr: float, opex_var_per_t: float, revenue_per_t: float, t_per_year, discount: float = 0.10,
                 carbon_price: float = 0.0, avoided_fraction: float = 1.0, capex_years: int = 1) -> dict:
    """Year 0..N. t_per_year = tonnes handled each operating year (array). Revenue = product price + carbon price x avoided share."""
    t = np.asarray(t_per_year, float)
    n = len(t)
    cf = np.zeros(n + capex_years)
    cf[:capex_years] -= capex / capex_years
    op = t * (revenue_per_t + carbon_price * avoided_fraction) - opex_fixed_yr - t * opex_var_per_t
    cf[capex_years:] += op
    disc = (1 + discount) ** -np.arange(len(cf))
    npv = float((cf * disc).sum())
    pv_cost = float(capex / capex_years * disc[:capex_years].sum() + ((opex_fixed_yr + t * opex_var_per_t) * disc[capex_years:]).sum())
    pv_t = float((t * avoided_fraction * disc[capex_years:]).sum())
    cum = np.cumsum(cf)
    pay = next((i for i, v in enumerate(cum) if v >= 0), None)
    return dict(npv=npv, lcoc=pv_cost / pv_t if pv_t > 0 else np.nan, payback_year=pay, cashflow=pd.DataFrame(dict(year=np.arange(len(cf)), cashflow=cf, cumulative=cum)))


def breakeven_carbon_price(**kw) -> float:
    a = cashflow_npv(**{**kw, "carbon_price": 0.0})["npv"]
    b = cashflow_npv(**{**kw, "carbon_price": 100.0})["npv"]
    return float(-a / ((b - a) / 100.0)) if b != a else np.nan


def tornado(base: dict, swing: float = 0.3, keys=("capex", "opex_fixed_yr", "opex_var_per_t", "revenue_per_t", "carbon_price", "discount")) -> pd.DataFrame:
    n0 = cashflow_npv(**base)["npv"]
    rows = []
    for k in keys:
        v = base[k]
        if not v:
            continue
        lo = cashflow_npv(**{**base, k: v * (1 - swing)})["npv"]
        hi = cashflow_npv(**{**base, k: v * (1 + swing)})["npv"]
        rows.append(dict(parameter=k, npv_low=lo, npv_high=hi, span=abs(hi - lo)))
    return pd.DataFrame(rows).sort_values("span", ascending=False).assign(npv_base=n0)


def monte_carlo(base: dict, rel_sd: dict | None = None, n: int = 1500, seed: int = 0) -> pd.Series:
    rng = np.random.default_rng(seed)
    sd = {"capex": 0.25, "opex_fixed_yr": 0.15, "revenue_per_t": 0.3, "carbon_price": 0.4, **(rel_sd or {})}
    out = []
    for _ in range(n):
        p = {k: (v * rng.lognormal(0, sd[k]) if k in sd and v else v) for k, v in base.items()}
        out.append(cashflow_npv(**p)["npv"])
    s = pd.Series(out)
    return pd.Series(dict(P10=s.quantile(0.1), P50=s.quantile(0.5), P90=s.quantile(0.9), prob_positive=float((s > 0).mean())))


def selftest() -> dict:
    r = cashflow_npv(capex=1000.0, opex_fixed_yr=0.0, opex_var_per_t=0.0, revenue_per_t=0.0, t_per_year=[10.0] * 5, discount=0.0, avoided_fraction=1.0)
    assert abs(r["lcoc"] - 20.0) < 1e-9, r["lcoc"]                                  # 1000 / 50 t
    kw = dict(capex=1000.0, opex_fixed_yr=10.0, opex_var_per_t=1.0, revenue_per_t=5.0, t_per_year=[100.0] * 10, discount=0.08)
    be = breakeven_carbon_price(**kw)
    assert abs(cashflow_npv(**kw, carbon_price=be)["npv"]) < 1e-6
    return dict(lcoc=r["lcoc"], breakeven=be)
