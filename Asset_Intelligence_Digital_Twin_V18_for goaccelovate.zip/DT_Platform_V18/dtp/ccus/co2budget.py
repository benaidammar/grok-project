"""CO2 inventory: gas production x CO2 mole fraction -> Sm3/d, t/d, t/yr, lifetime profile, uncertainty, spec gap.

Equations
  CO2_Sm3/d = gas_Sm3/d * y_CO2                       (mole fraction = volume fraction at standard conditions, ideal mixing)
  CO2_t/d   = CO2_Sm3/d * rho_std(CO2) / 1000          rho_std from co2props at cfg.t_std_c / p_std_bar (1.87 kg/Sm3 at 15 C)
  spec removal x (mol/d): (n_co2 - x)/(n - x) = spec  ->  x = n (y - spec)/(1 - spec)
The CO2 % is the USER's entered value (or per-well override); it is not a measurement.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core.status import Result, Status
from . import co2props
from .stream import CO2Stream

DEFAULT_DECLINE = 0.08            # 1/yr, used only when the data cannot give a decline (flagged)
FUEL_CO2_KG_PER_SM3 = 2.0         # kg CO2 per Sm3 burnt natural gas (placeholder, gas-gravity dependent)


def rho_std(cfg=None) -> float:
    t, p = (cfg.t_std_c, cfg.p_std_bar) if cfg is not None else (15.0, 1.01325)
    return co2props.gas_density_std(t, p)


def co2_t_per_day(gas_sm3d, mol_frac, cfg=None):
    return np.asarray(gas_sm3d, float) * np.asarray(mol_frac, float) * rho_std(cfg) / 1000.0


# ------------------------------------------------------------------ gas-rate sources
def latest_rates(w: pd.DataFrame, n_tests: int = 1, since=None) -> pd.DataFrame:
    """Per well: mean gas rate of its last `n_tests` test DAYS (multi-rate points on one day are averaged)."""
    rows = []
    for well, g in w.dropna(subset=["gas_sm3d"]).groupby("well"):
        if since is not None:
            g = g[g["date"] >= pd.Timestamp(since)]
        d = g.groupby("date")["gas_sm3d"].mean().sort_index().tail(n_tests)
        if len(d):
            rows.append(dict(well=well, last_test=d.index[-1], gas_sm3d=float(d.mean()), n_tests=len(d)))
    return pd.DataFrame(rows, columns=["well", "last_test", "gas_sm3d", "n_tests"])


def fit_decline(w: pd.DataFrame, years: float = 6.0, min_pts: int = 4) -> pd.DataFrame:
    """Per well exponential decline D [1/yr] from log(q) vs time over the last `years` of tests (day-averaged).
    Wells with too few points get NaN (caller substitutes a flagged default)."""
    rows = []
    for well, g in w.dropna(subset=["gas_sm3d"]).groupby("well"):
        d = g.groupby("date")["gas_sm3d"].mean().sort_index()
        d = d[d > 0]
        if len(d) == 0:
            continue
        d = d[d.index >= d.index[-1] - pd.Timedelta(days=365.25 * years)]
        D = np.nan
        if len(d) >= min_pts and (d.index[-1] - d.index[0]).days > 365:
            t = (d.index - d.index[0]).days.values / 365.25
            D = float(np.clip(-np.polyfit(t, np.log(d.values), 1)[0], 0.0, 0.35))
        rows.append(dict(well=well, decline_per_yr=D, n_pts=len(d)))
    return pd.DataFrame(rows, columns=["well", "decline_per_yr", "n_pts"])


def per_well_table(rates: pd.DataFrame, co2_pct_default: float, overrides: dict | None = None,
                   decline: pd.DataFrame | None = None, cfg=None) -> pd.DataFrame:
    """well, gas, CO2 %, CO2 Sm3/d, t/d, t/yr, decline."""
    t = rates.copy()
    ov = overrides or {}
    t["co2_pct"] = [float(ov.get(w, co2_pct_default)) if ov.get(w) is not None and np.isfinite(ov.get(w, np.nan)) else co2_pct_default
                    for w in t["well"]]
    t["co2_sm3d"] = t["gas_sm3d"] * t["co2_pct"] / 100.0
    t["co2_t_d"] = t["co2_sm3d"] * rho_std(cfg) / 1000.0
    t["co2_t_yr"] = t["co2_t_d"] * 365.25
    if decline is not None and len(decline):
        t = t.merge(decline[["well", "decline_per_yr"]], on="well", how="left")
    else:
        t["decline_per_yr"] = np.nan
    t["decline_assumed"] = t["decline_per_yr"].isna()
    t["decline_per_yr"] = t["decline_per_yr"].fillna(DEFAULT_DECLINE)
    return t


def lifetime_profile(tab: pd.DataFrame, years: int, decline_scale: float = 1.0) -> pd.DataFrame:
    """Annual CO2 t per well and total. Exponential decline; yearly mean rate = q0 (1-e^-D)/D * 365.25."""
    out = {"year": np.arange(1, years + 1)}
    tot = np.zeros(years)
    for _, r in tab.iterrows():
        D = max(r["decline_per_yr"] * decline_scale, 1e-6)
        k = np.arange(years)
        yr = r["co2_t_d"] * 365.25 * np.exp(-D * k) * (1 - np.exp(-D)) / D
        out[r["well"]] = yr
        tot += yr
    out["t_per_year"] = tot
    return pd.DataFrame(out)


def profile_from_forecast(fc: pd.DataFrame, co2_pct_by_well: dict, default_pct: float, years: int, cfg=None) -> pd.DataFrame | None:
    """fc: columns date, well, gas (or p50 / gas_p50 / gas_sm3d) in Sm3/d -> yearly CO2 profile."""
    col = next((c for c in ("p50", "gas_p50", "gas_sm3d", "gas") if c in fc.columns), None)
    if col is None or "date" not in fc.columns:
        return None
    f = fc.copy()
    f["date"] = pd.to_datetime(f["date"])
    if "well" not in f.columns:
        f["well"] = "field"
    f["pct"] = f["well"].map(lambda w: co2_pct_by_well.get(w, default_pct))
    f["t_d"] = f[col] * f["pct"] / 100 * rho_std(cfg) / 1000
    f["year"] = ((f["date"] - f["date"].min()).dt.days // 365.25 + 1).astype(int)
    prof = f.groupby("year")["t_d"].mean().mul(365.25).reset_index(name="t_per_year")
    return prof[prof["year"] <= years].reset_index(drop=True)


def field_forecast_profile(w: pd.DataFrame, pct_by_well: dict, default_pct: float, years: int, cfg=None):
    """Try the gas-condensate forecast module; None if unavailable / incompatible."""
    try:
        from ..gascond.forecast import field_forecast
        fc = field_forecast(w)
        if isinstance(fc, pd.DataFrame):
            return profile_from_forecast(fc, pct_by_well, default_pct, years, cfg)
    except Exception:                       # noqa: BLE001
        return None
    return None


# ------------------------------------------------------------------ stream builder
def build_stream(gas_sm3d: float, co2_pct: float, pressure_bara: float = 30.0, temp_c: float = 40.0, h2s_ppm: float = 0.0,
                 lifetime_years: float = 15.0, decline_per_yr: float = DEFAULT_DECLINE, capture_target_pct: float = 100.0,
                 profile: pd.DataFrame | None = None, source: str = "manual", cfg=None, notes: list | None = None) -> CO2Stream:
    y = co2_pct / 100.0
    n = int(round(lifetime_years))
    if profile is None:
        k = np.arange(n)
        D = max(decline_per_yr, 1e-6)
        t0 = float(co2_t_per_day(gas_sm3d, y, cfg)) * 365.25
        profile = pd.DataFrame({"year": k + 1, "t_per_year": t0 * np.exp(-D * k) * (1 - np.exp(-D)) / D})
    return CO2Stream(t_per_day=float(co2_t_per_day(gas_sm3d, y, cfg)), mol_frac=y, gas_sm3d=float(gas_sm3d), pressure_bara=pressure_bara,
                     temp_c=temp_c, h2s_ppm=h2s_ppm, lifetime_years=lifetime_years, capture_target_pct=capture_target_pct,
                     profile=profile, source=source, notes=notes or [])


def stream_from_table(tab: pd.DataFrame, pressure_bara, temp_c, h2s_ppm, lifetime_years, capture_target_pct, source, cfg=None,
                      profile: pd.DataFrame | None = None, notes=None) -> CO2Stream:
    gas = float(tab["gas_sm3d"].sum())
    co2_sm3 = float(tab["co2_sm3d"].sum())
    prof = profile if profile is not None else lifetime_profile(tab, int(round(lifetime_years)))[["year", "t_per_year"]]
    return CO2Stream(t_per_day=float(tab["co2_t_d"].sum()), mol_frac=co2_sm3 / gas if gas > 0 else 0.0, gas_sm3d=gas,
                     pressure_bara=pressure_bara, temp_c=temp_c, h2s_ppm=h2s_ppm, lifetime_years=lifetime_years,
                     capture_target_pct=capture_target_pct, profile=prof, source=source, notes=notes or [])


# ------------------------------------------------------------------ uncertainty
def uncertainty(tab: pd.DataFrame, years: int, co2_abs_unc_pct: float = 0.3, decline_rel_unc: float = 0.4, n: int = 2000,
                seed: int = 0, cfg=None) -> Result:
    """Monte-Carlo on CO2 % (+- absolute, triangular) and decline (+- relative, triangular): lifetime Mt P10/P50/P90 and first-year t/yr."""
    rng = np.random.default_rng(seed)
    base_pct = float((tab["co2_sm3d"].sum() / tab["gas_sm3d"].sum()) * 100)
    pct = rng.triangular(max(base_pct - co2_abs_unc_pct, 0.01), base_pct, base_pct + co2_abs_unc_pct, n)
    sc = rng.triangular(1 - decline_rel_unc, 1.0, 1 + decline_rel_unc, n)
    q = tab["gas_sm3d"].values[:, None] * 0 + 0.0
    D = tab["decline_per_yr"].values
    gas0 = tab["gas_sm3d"].values
    k = np.arange(years)[None, :, None]
    Dm = np.maximum(D[None, None, :] * sc[:, None, None], 1e-6)
    yr = gas0[None, None, :] * 365.25 * np.exp(-Dm * k) * (1 - np.exp(-Dm)) / Dm            # Sm3 per year, (n, years, wells)
    sm3 = yr.sum(axis=2)
    t = sm3 * (pct[:, None] / 100) * rho_std(cfg) / 1000
    life = t.sum(axis=1) / 1e6
    first = t[:, 0]
    p = lambda a, qn: float(np.percentile(a, qn))
    res = Result("CO2 uncertainty", value=dict(lifetime_Mt=dict(P10=p(life, 10), P50=p(life, 50), P90=p(life, 90)),
                                              first_year_t=dict(P10=p(first, 10), P50=p(first, 50), P90=p(first, 90)),
                                              samples=pd.DataFrame(dict(co2_pct=pct, decline_scale=sc, lifetime_Mt=life))),
                 status=Status.WARN)
    res.messages.append(f"Triangular: CO2 % {base_pct:.2f} +-{co2_abs_unc_pct}, decline x(1 +- {decline_rel_unc}). Ranges are assumptions, not statistics of measurements.")
    if tab["decline_assumed"].any():
        res.assumptions.append("Default decline %.0f %%/yr used for: %s" % (DEFAULT_DECLINE * 100, ", ".join(tab.loc[tab["decline_assumed"], "well"])))
    return res


# ------------------------------------------------------------------ spec gap, partial pressure, extras
def spec_gap(mol_frac: float, spec_pct: float, gas_sm3d: float, captured_possible_share: float = 1.0, cfg=None) -> dict:
    """How much CO2 MUST be removed to reach the sales-gas spec vs how much CAN be captured."""
    y, s = mol_frac, spec_pct / 100.0
    must_frac = max(0.0, (y - s) / (1 - s)) if y > s else 0.0
    must_sm3 = gas_sm3d * must_frac
    total_sm3 = gas_sm3d * y
    return dict(spec_pct=spec_pct, exceeds_spec=y > s, must_remove_sm3d=must_sm3, must_remove_t_d=must_sm3 * rho_std(cfg) / 1000,
                can_capture_sm3d=total_sm3 * captured_possible_share, can_capture_t_d=total_sm3 * captured_possible_share * rho_std(cfg) / 1000,
                optional_t_d=(total_sm3 - must_sm3) * rho_std(cfg) / 1000,
                msg=("Gas meets the CO2 spec: capture is a voluntary climate / utilisation choice, not a processing necessity." if y <= s
                     else "Gas exceeds the CO2 spec: part of the removal is mandatory for sales."))


def partial_pressure(mol_frac: float, p_bara: float) -> float:
    return mol_frac * p_bara


def extra_sources(fuel_gas_sm3d: float = 0.0, flare_sm3d: float = 0.0, factor_kg_per_sm3: float = FUEL_CO2_KG_PER_SM3) -> pd.DataFrame:
    """Combustion CO2 of fuel gas and flare (placeholder factor). 'Avoidable' = flare (routable to sales / reinjection);
    fuel-gas CO2 leaves through dilute flue gas (hard and costly to capture)."""
    rows = [dict(source="Fuel gas combustion (flue gas)", t_d=fuel_gas_sm3d * factor_kg_per_sm3 / 1000, capture="dilute (~3-8 % CO2): costly", avoidable="partly (efficiency)"),
            dict(source="Flaring", t_d=flare_sm3d * factor_kg_per_sm3 / 1000, capture="not capturable; avoid by gas recovery", avoidable="yes (flare-down)")]
    return pd.DataFrame(rows)


def per_t_condensate(co2_t_d: float, cond_m3d: float, cond_density: float = 765.0) -> float:
    t = cond_m3d * cond_density / 1000
    return co2_t_d / t if t > 0 else float("nan")


# ------------------------------------------------------------------ history
def history(w: pd.DataFrame, co2_pct_by_well: dict, default_pct: float, cfg=None) -> pd.DataFrame:
    """Cumulative CO2 'produced to date' = linear interpolation of day-averaged test rates between first and last test, x user CO2 %.
    RECONSTRUCTED from sparse tests, not metered."""
    rows = []
    for well, g in w.dropna(subset=["gas_sm3d"]).groupby("well"):
        d = g.groupby("date")["gas_sm3d"].mean().sort_index()
        if len(d) < 2:
            continue
        days = pd.date_range(d.index[0], d.index[-1], freq="D")
        q = np.interp(days.values.astype("int64"), d.index.values.astype("int64"), d.values)
        pct = co2_pct_by_well.get(well, default_pct)
        t_d = q * pct / 100 * rho_std(cfg) / 1000
        rows.append(pd.DataFrame(dict(date=days, well=well, gas_sm3d=q, co2_t_d=t_d, co2_cum_t=np.cumsum(t_d))))
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame(columns=["date", "well", "gas_sm3d", "co2_t_d", "co2_cum_t"])


def selftest() -> dict:
    t = float(co2_t_per_day(1e6, 0.02))
    assert abs(t - 37.4) < 0.5, t
    s = build_stream(1e6, 2.0, lifetime_years=10, decline_per_yr=0.1)
    assert abs(s.t_per_day - t) < 1e-9
    # first-year mean of an exponential decline must be below the initial rate and cumulative equals integral
    assert s.profile["t_per_year"].iloc[0] < s.t_per_year
    D = 0.1
    assert abs(s.profile["t_per_year"].sum() - s.t_per_year / D * (1 - np.exp(-D * 10))) < 1e-6 * s.t_per_year
    g = spec_gap(0.03, 2.0, 1e6)
    assert g["exceeds_spec"] and abs(g["must_remove_sm3d"] - 1e6 * (0.03 - 0.02) / 0.98) < 1
    assert not spec_gap(0.02, 2.0, 1e6)["exceeds_spec"]
    w = pd.DataFrame(dict(well=["A"] * 5, date=pd.date_range("2018-01-01", periods=5, freq="365D"), gas_sm3d=[1e6 * np.exp(-0.1 * i) for i in range(5)]))
    d = fit_decline(w)
    assert abs(d.decline_per_yr.iloc[0] - 0.1) < 0.01, d
    tab = per_well_table(latest_rates(w), 2.0, decline=d)
    u = uncertainty(tab, 10)
    assert u.value["lifetime_Mt"]["P10"] < u.value["lifetime_Mt"]["P50"] < u.value["lifetime_Mt"]["P90"]
    return dict(t_per_day_1MM_2pct=t, decline_fit=float(d.decline_per_yr.iloc[0]))
