"""CO2 utilisation / storage pathway catalogue, multi-criteria ranking (TOPSIS), chemical mass balances and a portfolio allocator.

ALL value, capacity, energy and score columns are INDICATIVE PLACEHOLDERS for screening and are meant to be edited with local
quotes / market studies. Stoichiometric factors (t CO2 per t product) are exact chemistry; process inputs are typical literature values.
Units: t/yr, USD/t CO2 used (net of direct processing cost, placeholder), kWh/t CO2.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core.status import Result, Status

COLS = ["pathway", "category", "demand_min_tpy", "demand_max_tpy", "purity_req_pct", "extra_inputs", "trl", "permanence",
        "energy_kwh_t", "value_lo_usd_t", "value_hi_usd_t", "climate_factor", "logistics_1to5", "inputs_1to5",
        "min_tpy", "max_tpy", "main_risks", "relevance_remote_sahara_field", "data_needed"]

_P = [
    ("CO2-EOR (miscible / immiscible)", "EOR-EGR", 5e4, 3e6, 95, "oil reservoir above MMP, recycle plant, water for WAG", 9, "long-lived (permanent if monitored)", 120, 10, 45, 0.6, 2, 4, 2e4, 3e6,
     "needs an oil field; early breakthrough; corrosion; produced-gas recycle", "Only if an oil reservoir exists within pipeline/truck reach; the Field-type field itself is gas-condensate", "oil gravity/viscosity, MMP, Soi, pattern, distance"),
    ("CO2-enhanced gas / condensate recovery & pressure maintenance", "EOR-EGR", 2e4, 1e6, 90, "injector wells, compression, produced-gas treatment", 4, "long-lived (partially stored)", 150, 0, 25, 0.5, 4, 4, 1e4, 1e6,
     "early CO2 breakthrough dilutes sales gas; compositional behaviour; gravity override", "Highest synergy: same field, existing wells/ gathering, CO2 at the source", "compositional PVT, voidage, kv/kh, sweep"),
    ("Depleted gas / condensate field storage", "geological storage", 5e4, 5e6, 90, "injection wells, compression, MRV", 7, "permanent", 110, -25, 5, 0.9, 4, 5, 2e4, 5e6,
     "legacy-well leakage, caprock integrity, repressurisation limits", "Strong: depleted reservoir with proven seal; plan with the field's own depletion history", "GIIP, Gp, pressure history, well integrity logs, caprock"),
    ("Saline aquifer storage", "geological storage", 1e5, 1e7, 90, "characterisation wells, seismic, compression, MRV", 8, "permanent", 120, -35, 0, 0.9, 3, 5, 5e4, 1e7,
     "site uncertainty, pressure build-up, faults", "Possible in deep Saharan basins; characterisation cost dominates small streams", "A, h, phi, k, seal, faults, pressure"),
    ("Enhanced coal-bed methane (ECBM)", "geological storage", 1e4, 5e5, 90, "coal seam, injection wells", 5, "long-lived", 130, -10, 10, 0.7, 1, 2, 1e4, 5e5,
     "swelling reduces permeability; few coal seams", "Low relevance (no known coal seams at the field)", "coal seam depth/ permeability"),
    ("Food & beverage grade CO2", "industrial & food", 1e3, 2e5, 99.9, "purification (deodorise, dry, polish), liquefaction, trucking", 9, "short-lived (re-emitted within days)", 250, 40, 150, 0.0, 2, 4, 500, 5e4,
     "quality certification, small local market", "Small local market in the south; needs liquefaction + truck logistics", "market size within 500 km, certification route"),
    ("Dry ice / cold chain", "industrial & food", 5e2, 5e4, 99.5, "liquefaction, pelletiser", 9, "short-lived (re-emitted within days)", 350, 60, 250, 0.0, 2, 4, 200, 2e4,
     "small demand; sublimation losses", "Niche; depends on regional logistics", "customer contracts, distance"),
    ("Greenhouse enrichment (horticulture)", "biological", 1e3, 1e5, 99, "clean CO2 (no H2S/ethylene), heat for evaporator", 9, "short-lived (re-emitted)", 100, 30, 120, 0.0, 3, 3, 500, 3e4,
     "sulphur/ethylene contaminants; seasonal", "Saharan agriculture growth is a real local demand, water is the limit", "greenhouse area, CO2 dose, contaminants"),
    ("Welding / shielding gas and industrial gases", "industrial & food", 1e3, 5e4, 99.8, "purification, cylinders", 9, "short-lived (re-emitted)", 300, 50, 200, 0.0, 2, 4, 200, 1e4,
     "tiny market", "Niche", "local demand"),
    ("Water treatment (pH control, remineralisation)", "industrial & food", 1e3, 1e5, 99, "dosing skid", 9, "short-lived (bicarbonate: months-years)", 50, 30, 100, 0.1, 3, 4, 500, 3e4,
     "small, replaces mineral acids", "Desalination / water-treatment plants in the region", "plant list, dose rates"),
    ("Urea (with ammonia)", "chemicals & fuels", 2e4, 2e6, 99, "NH3 0.567 t/t urea, heat, power", 9, "short-lived (fertiliser re-emits within months)", 250, 0, 60, 0.15, 3, 3, 1e4, 2e6,
     "market price; needs NH3 plant nearby", "Algeria has large ammonia/urea industry - CO2 may replace the plant's own CO2 (limited net benefit)", "NH3 source, urea plant location"),
    ("Methanol (with green H2)", "chemicals & fuels", 5e3, 1e6, 99.5, "H2 0.189 t/t MeOH (green H2 + power ~9-10 MWh/t H2)", 8, "short-lived (re-emitted on use)", 1800, -50, 60, 0.3, 2, 1, 5e3, 1e6,
     "H2 cost, power", "Needs gigawatt-scale solar/electrolysis; remote site favours solar", "power price, electrolyser capex, offtake"),
    ("E-methane (Sabatier) / synthetic gas", "chemicals & fuels", 5e3, 5e5, 99, "H2 0.504 t/t CH4, heat recovery", 7, "short-lived (re-emitted)", 1700, -60, 40, 0.25, 3, 1, 5e3, 5e5,
     "H2 cost; competes with natural gas", "Weak economics in a gas-rich country", "H2 cost, gas price"),
    ("E-fuels (Fischer-Tropsch / e-diesel / e-kerosene)", "chemicals & fuels", 1e4, 1e6, 99, "H2 0.43 t/t fuel, rWGS, FT unit", 6, "short-lived (re-emitted)", 2200, -80, 50, 0.3, 2, 1, 1e4, 1e6,
     "capex, H2", "Long-term export concept only", "H2 cost, certification"),
    ("Formic acid / CO / syngas", "chemicals & fuels", 1e3, 2e5, 99, "H2 or electricity (electro-reduction)", 6, "short-lived (re-emitted)", 1500, -20, 80, 0.2, 2, 2, 1e3, 1e5,
     "selectivity, power", "R&D / pilot", "electrochemical cell performance"),
    ("Polymers & polyols / polycarbonates", "materials", 1e3, 1e5, 99.5, "epoxide co-feed, catalyst", 8, "long-lived (decades in product)", 200, 20, 120, 0.2, 2, 2, 500, 5e4,
     "CO2 only 20-40 % of polymer mass", "Needs a downstream polymer plant", "customer, epoxide supply"),
    ("Mineral carbonation (olivine / steel & mining slag)", "materials", 1e4, 1e6, 80, "olivine 1.6 t/t CO2, grinding, heat, water", 6, "permanent", 600, -80, 0, 0.7, 2, 3, 5e3, 1e6,
     "mining & grinding energy, slow kinetics", "Mining waste / slag could exist in the region; water-limited", "mineral source, water"),
    ("Concrete curing & CO2-cured aggregates", "materials", 1e3, 1e5, 95, "precast plant, cement", 8, "long-lived (permanent in concrete)", 80, 10, 60, 0.4, 3, 4, 500, 5e4,
     "needs precast industry nearby", "Infrastructure growth in the region; precast plant required", "precast volumes"),
    ("Supercritical CO2 extraction / solvent / cleaning", "industrial & food", 1e2, 2e4, 99.9, "high pressure plant", 9, "short-lived (re-emitted)", 400, 100, 400, 0.0, 1, 3, 100, 5e3,
     "small niche", "Negligible volumes", "customer"),
    ("Algae / biomass cultivation", "biological", 5e2, 5e4, 95, "water, nutrients, land, sunlight", 5, "short-lived (re-emitted)", 800, -40, 30, 0.1, 2, 2, 500, 2e4,
     "water, salinity, harvest cost", "Sun is abundant but water is not", "water source, product market"),
    ("CO2 plume geothermal / enhanced geothermal (research)", "geological storage", 5e4, 2e6, 95, "hot permeable reservoir, binary cycle", 3, "long-lived (partially stored)", 100, -20, 10, 0.5, 2, 3, 2e4, 2e6,
     "research stage", "Hot reservoirs exist but concept unproven", "temperature, permeability"),
    ("CO2 as fracturing / stimulation fluid (see Frac page)", "enhanced production fluids", 1e3, 5e4, 98, "liquid CO2 blender, pumping, flowback handling", 6, "long-lived (partially trapped)", 150, 0, 40, 0.3, 3, 4, 500, 3e4,
     "equipment; sand transport; flowback", "Link with the Frac page for tight reservoirs; water saving", "reservoir sensitivity, frac design"),
    ("CO2 for drilling / well clean-out / foam & gas lift", "enhanced production fluids", 5e2, 2e4, 95, "pumping unit", 6, "short-lived (re-emitted)", 100, 10, 60, 0.0, 3, 4, 200, 1e4,
     "small volumes", "Possible well-service use in the same field", "well-service programme"),
    ("Chemical looping / CO2-to-solid carbon (emerging)", "chemicals & fuels", 1e3, 2e5, 95, "H2 or CH4, catalyst/ oxygen carrier", 4, "long-lived (solid carbon)", 900, -60, 20, 0.5, 2, 2, 1e3, 1e5,
     "TRL, catalyst life", "R&D", "pilot data"),
]


def catalogue() -> pd.DataFrame:
    """Default catalogue (placeholders). Edit values in the UI or in this list."""
    return pd.DataFrame(_P, columns=COLS)


# ---- chemical mass balances -----------------------------------------------------------------------------------------------
# t CO2 per t product, t co-reactant per t product, kWh per t product (placeholder). Stoichiometry from molar masses.
CHEM = {
    "urea": dict(co2_per_t=44.01 / 60.06, reactant="NH3", reactant_per_t=2 * 17.031 / 60.06 / 1.0 * 0.5 * 1.0 * 1.0 * 1.0 * 1.0 * 1.0 * 1.0 if False else 2 * 17.031 / 2 / 60.06 * 1.0 * 1.0 + 0.0, kwh_per_t=150),
    "methanol": dict(co2_per_t=44.01 / 32.042, reactant="H2", reactant_per_t=3 * 2.016 / 32.042, kwh_per_t=300),
    "methane (Sabatier)": dict(co2_per_t=44.01 / 16.043, reactant="H2", reactant_per_t=4 * 2.016 / 16.043, kwh_per_t=200),
    "FT fuel (CH2)n": dict(co2_per_t=44.01 / 14.027, reactant="H2", reactant_per_t=3 * 2.016 / 14.027, kwh_per_t=400),
    "formic acid": dict(co2_per_t=44.01 / 46.025, reactant="H2", reactant_per_t=2.016 / 46.025, kwh_per_t=200),
    "mineral carbonate (olivine)": dict(co2_per_t=2 * 44.01 / 140.69, reactant="olivine", reactant_per_t=140.69 / (2 * 44.01) , kwh_per_t=0),
}
CHEM["urea"]["reactant_per_t"] = 2 * 17.031 / 2 / 60.06 * 2 / 2 if False else 17.031 / 60.06 * 2 / 2 * 1.0   # NH3: 2 NH3 -> 1 urea, per tonne urea = 2*17.031/60.06
CHEM["urea"]["reactant_per_t"] = 2 * 17.031 / 60.06


def mass_balance(route: str, co2_tpy: float, h2_kwh_per_kg: float = 52.0, power_price: float = 0.04, factors: dict | None = None) -> Result:
    """Product, co-reactant and energy for a CO2 flow. h2_kwh_per_kg: electrolysis power per kg H2 (placeholder 50-55)."""
    f = dict(CHEM[route])
    if factors:
        f.update(factors)
    product = co2_tpy / f["co2_per_t"]
    react = product * f["reactant_per_t"]
    kwh = product * f["kwh_per_t"]
    h2_power = react * 1000 * h2_kwh_per_kg if f["reactant"] == "H2" else 0.0
    out = dict(route=route, co2_tpy=co2_tpy, product_tpy=product, reactant=f["reactant"], reactant_tpy=react,
               process_kwh=kwh, electrolysis_kwh=h2_power, total_mwh=(kwh + h2_power) / 1e3,
               power_cost_usd=(kwh + h2_power) * power_price)
    return Result("mass balance " + route, out, Status.OK, ["Co-reactant for H2 routes assumes electrolysis power per kg H2 given; stoichiometry exact."],
                  ["h2_kwh_per_kg=%.0f" % h2_kwh_per_kg, "power_price=%.3f USD/kWh" % power_price])


# ---- ranking ---------------------------------------------------------------------------------------------------------------
def scale_match(stream_tpy: float, dmin: float, dmax: float) -> float:
    """1 if the stream fits the typical demand range; <1 if too small to be worth it or exceeding what the use can absorb."""
    if stream_tpy <= 0:
        return 0.0
    if dmin <= stream_tpy <= dmax:
        return 1.0
    if stream_tpy < dmin:
        return float(stream_tpy / dmin)
    return float(np.sqrt(dmax / stream_tpy))


PERM_SCORE = {"permanent": 1.0, "long-lived": 0.7, "short-lived": 0.1}


def perm_score(txt: str) -> float:
    for k, v in PERM_SCORE.items():
        if txt.startswith(k):
            return v
    return 0.3


def criteria_table(cat: pd.DataFrame, stream_tpy: float, purity_pct: float) -> pd.DataFrame:
    d = cat.copy()
    d["climate"] = [0.5 * perm_score(p) + 0.5 * c for p, c in zip(d.permanence, d.climate_factor)]
    d["scale"] = [scale_match(stream_tpy, a, b) for a, b in zip(d.demand_min_tpy, d.demand_max_tpy)]
    d["maturity"] = d.trl / 9.0
    mid = (d.value_lo_usd_t + d.value_hi_usd_t) / 2
    d["economics"] = (mid - mid.min()) / max(mid.max() - mid.min(), 1e-9)
    d["logistics"] = d.logistics_1to5 / 5.0
    d["inputs"] = d.inputs_1to5 / 5.0
    d["purity_ok"] = d.purity_req_pct <= purity_pct
    return d


def topsis(crit: pd.DataFrame, weights: dict) -> pd.DataFrame:
    """TOPSIS closeness (0-1) over the benefit criteria; pathways that fail the purity limit are flagged, not removed."""
    keys = list(weights)
    X = crit[keys].to_numpy(float)
    w = np.array([weights[k] for k in keys], float)
    w = w / w.sum() if w.sum() > 0 else np.ones(len(keys)) / len(keys)
    nrm = np.sqrt((X ** 2).sum(axis=0))
    nrm[nrm == 0] = 1
    V = X / nrm * w
    best, worst = V.max(axis=0), V.min(axis=0)
    dp, dm = np.sqrt(((V - best) ** 2).sum(1)), np.sqrt(((V - worst) ** 2).sum(1))
    out = crit.copy()
    out["topsis"] = dm / np.maximum(dp + dm, 1e-12)
    out["rank"] = out["topsis"].rank(ascending=False, method="min").astype(int)
    return out.sort_values("rank")


# ---- allocator ------------------------------------------------------------------------------------------------------------
def allocate(cat: pd.DataFrame, stream_tpy: float, purity_pct: float, objective: str = "value", exclude_inputs: bool = False,
             exclude: list | None = None) -> Result:
    """Split the stream over pathways: MILP (scipy.optimize.milp) with min/max capacity per pathway, purity filter,
    objective 'value' (USD/yr, placeholders), 'climate' (t CO2 avoided/yr) or 'stored' (permanent/long-lived storage t/yr)."""
    from scipy.optimize import Bounds, LinearConstraint, milp
    d = cat.reset_index(drop=True).copy()
    ok = d.purity_req_pct <= purity_pct
    if exclude_inputs:
        ok &= ~d.extra_inputs.str.contains("H2|NH3|olivine", regex=True)
    if exclude:
        ok &= ~d.pathway.isin(exclude)
    d = d[ok].reset_index(drop=True)
    if d.empty or stream_tpy <= 0:
        return Result("allocator", None, Status.FAIL, ["No pathway left after purity / input filters, or empty stream"])
    n = len(d)
    mid = (d.value_lo_usd_t + d.value_hi_usd_t).to_numpy() / 2
    clim = np.array([0.5 * perm_score(p) + 0.5 * c for p, c in zip(d.permanence, d.climate_factor)])
    stored = np.array([1.0 if perm_score(p) >= 0.7 else 0.0 for p in d.permanence])
    c = {"value": mid, "climate": clim, "stored": stored}[objective]
    mx = np.minimum(d.max_tpy.to_numpy(float), stream_tpy)
    mn = d.min_tpy.to_numpy(float)
    feasible = mn <= mx
    mx = np.where(feasible, mx, 0.0)
    cost = np.concatenate([-c, np.zeros(n)])
    A = np.zeros((2 * n + 1, 2 * n))
    ub = np.zeros(2 * n + 1)
    lb = np.full(2 * n + 1, -np.inf)
    for i in range(n):
        A[i, i], A[i, n + i], ub[i] = 1.0, -mx[i], 0.0                     # x_i <= max_i y_i
        A[n + i, i], A[n + i, n + i], ub[n + i] = -1.0, mn[i], 0.0         # x_i >= min_i y_i
    A[2 * n, :n], ub[2 * n] = 1.0, stream_tpy
    res = milp(cost, constraints=LinearConstraint(A, lb, ub), integrality=np.concatenate([np.zeros(n), np.ones(n)]),
               bounds=Bounds(np.zeros(2 * n), np.concatenate([mx, np.ones(n)])))
    if not res.success:
        return Result("allocator", None, Status.FAIL, ["MILP failed: " + str(res.message)])
    x = res.x[:n]
    x = np.where(x < 1e-6, 0.0, x)
    out = d[["pathway", "category", "permanence"]].copy()
    out["allocated_tpy"] = x
    out["share_pct"] = 100 * x / stream_tpy
    out["value_usd_yr"] = x * mid
    out["avoided_t_yr"] = x * clim
    out = out[out.allocated_tpy > 0].sort_values("allocated_tpy", ascending=False).reset_index(drop=True)
    msgs = []
    unalloc = stream_tpy - x.sum()
    if unalloc > 1:
        msgs.append(f"{unalloc:,.0f} t/yr of the stream is not placed (pathway capacity / minimum-size limits or negative value).")
    st = Status.WARN if msgs else Status.OK
    return Result("portfolio allocation", dict(table=out, unallocated_tpy=unalloc, total_value=float(out.value_usd_yr.sum()),
                  total_avoided=float(out.avoided_t_yr.sum())), st, msgs + ["Values are placeholders: edit the catalogue before using the ranking."],
                  ["catalogue value/capacity columns are indicative"], dict(objective=objective))


def sensitivity(cat: pd.DataFrame, stream_tpy: float, purity_pct: float, objective: str, scales=(0.25, 0.5, 1, 2, 4), **kw) -> pd.DataFrame:
    rows = []
    for s in scales:
        r = allocate(cat, stream_tpy * s, purity_pct, objective, **kw)
        if r.value is not None:
            rows.append(dict(scale=s, stream_tpy=stream_tpy * s, value_usd_yr=r.value["total_value"], avoided_t_yr=r.value["total_avoided"],
                             n_pathways=len(r.value["table"]), unallocated_tpy=r.value["unallocated_tpy"]))
    return pd.DataFrame(rows)


def selftest() -> dict:
    cat = catalogue()
    assert len(cat) >= 22 and list(cat.columns) == COLS
    assert abs(CHEM["urea"]["co2_per_t"] - 0.733) < 0.002, CHEM["urea"]
    assert abs(CHEM["urea"]["reactant_per_t"] - 0.567) < 0.002
    assert abs(CHEM["methanol"]["co2_per_t"] - 1.374) < 0.005
    assert abs(CHEM["methanol"]["reactant_per_t"] - 0.189) < 0.002
    mb = mass_balance("methanol", 1000.0).value
    assert abs(mb["product_tpy"] - 727.9) < 3
    s = 37.4 * 365.25
    r = allocate(cat, s, 99.0, "value")
    assert r.ok
    t = r.value["table"]
    assert t.allocated_tpy.sum() <= s + 1e-6
    mxs = cat.set_index("pathway").max_tpy
    mns = cat.set_index("pathway").min_tpy
    for _, row in t.iterrows():
        assert row.allocated_tpy <= mxs[row.pathway] + 1e-6 and row.allocated_tpy >= mns[row.pathway] - 1e-6
    r2 = allocate(cat, s, 85.0, "climate")
    assert r2.ok and (r2.value["table"].pathway != "Food & beverage grade CO2").all()      # purity filter
    tp = topsis(criteria_table(cat, s, 99.0), dict(climate=1, scale=1, maturity=1, economics=1, logistics=1, inputs=1))
    assert tp["rank"].min() == 1
    return dict(n_paths=len(cat), alloc_value=r.value["total_value"], top=tp.pathway.iloc[0])
