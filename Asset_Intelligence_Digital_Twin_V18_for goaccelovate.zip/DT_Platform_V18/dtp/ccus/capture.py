"""CO2 capture technology screening and mass / energy balance (screening level, UNVALIDATED).

Screening: each technology has windows for CO2 partial pressure (p_CO2 = y x p_feed), CO2 mole fraction, H2S and flow.
Window score = 1 inside, decaying outside (ratio / sqrt-ratio); overall = geometric mean (0-1).
ALL technology numbers (energy, recovery, hydrocarbon loss, capex) are INDICATIVE PLACEHOLDERS - replace with vendor data.
Energy: thermal [GJ/t CO2] and electric [kWh/t] x dilution factor f = 1 + k max(0, (0.05 - y)/0.05) (dilute gas costs more).
Process CO2 = thermal x EF_HEAT + electric x grid EF.  Capex scaled  C = C100 * Q * (Q / 1e5 t/yr)^-0.3 (power-law, exponent 0.7).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core.status import Result, Status
from . import co2budget as B

EF_HEAT_T_PER_GJ = 0.056          # natural-gas combustion, t CO2/GJ (IPCC default ~56.1 kg/GJ)
GRID_EF_T_PER_MWH = 0.45          # PLACEHOLDER (gas-fired grid); editable
LHV_GJ_PER_SM3 = 0.0355           # gas lower heating value, GJ/Sm3 (placeholder, gas-dependent)
COLS = ["tech", "p_lo", "p_hi", "y_lo", "y_hi", "h2s_tol_ppm", "q_lo_tpd", "q_hi_tpd", "recov", "thermal_gj_t", "elec_kwh_t",
        "dilute_k", "purity_pct", "hc_loss_pct", "capex100_usd_tpy", "opex_pct", "trl", "note"]
_T = [
    ("Amine absorption (MEA / activated MDEA)", 0.05, 8, 0.005, 0.30, 1e5, 5, 5000, 0.95, 3.0, 35, 0.4, 99.5, 0.1, 900, 5, 9,
     "Workhorse for dilute / low pCO2; heat-hungry; H2S needs a selective / separate step; degradation, corrosion"),
    ("Hot potassium carbonate (Benfield-type)", 3, 40, 0.05, 0.50, 1e3, 20, 8000, 0.95, 2.0, 25, 0.5, 99.0, 0.1, 800, 5, 9,
     "Needs higher pCO2 (> ~3 bar); good heat integration; tolerates H2S"),
    ("Physical solvent (Selexol / Rectisol)", 5, 100, 0.05, 0.80, 1e5, 20, 20000, 0.90, 0.5, 90, 1.0, 98.0, 1.0, 1100, 4, 9,
     "High pCO2 / high pressure; low heat but co-absorbs hydrocarbons; strong H2S selectivity"),
    ("Polymeric membranes", 2, 60, 0.05, 0.70, 1e4, 5, 2000, 0.80, 0.0, 150, 2.0, 90.0, 3.0, 700, 4, 8,
     "Compact, modular, remote-friendly; methane slip; multi-stage for high purity; fouling by condensate / water"),
    ("Cryogenic / anti-sublimation", 10, 100, 0.30, 0.95, 100, 20, 20000, 0.90, 0.0, 250, 3.0, 99.0, 0.5, 1500, 4, 6,
     "Only for CO2-rich streams (> ~30 %); needs deep dehydration"),
    ("Solid adsorption (PSA / TSA, zeolite / MOF)", 0.5, 20, 0.02, 0.50, 10, 2, 1000, 0.85, 0.5, 200, 0.8, 95.0, 1.5, 1000, 5, 6,
     "Small, modular, water-sensitive; moderate purity; scale-up limited"),
]


def techs() -> pd.DataFrame:
    """Technology table (placeholders). Edit in the UI."""
    return pd.DataFrame(_T, columns=COLS)


def _win(x: float, lo: float, hi: float) -> float:
    if x <= 0:
        return 0.0
    return 1.0 if lo <= x <= hi else (x / lo if x < lo else float(np.sqrt(hi / x)))


def screen(p_feed_bara: float, mol_frac: float, flow_t_d: float, h2s_ppm: float = 0.0, table: pd.DataFrame | None = None) -> Result:
    """Rank technologies by window fit. Returns table with p_CO2, window scores, overall score, class (good/marginal/poor), reasons."""
    t = (table if table is not None else techs()).copy()
    pco2 = B.partial_pressure(mol_frac, p_feed_bara)
    if p_feed_bara <= 0 or mol_frac <= 0 or flow_t_d <= 0:
        return Result("capture screening", None, Status.FAIL, ["Feed pressure, CO2 fraction and flow must be > 0"])
    t["s_pco2"] = [_win(pco2, a, b) for a, b in zip(t.p_lo, t.p_hi)]
    t["s_y"] = [_win(mol_frac, a, b) for a, b in zip(t.y_lo, t.y_hi)]
    t["s_flow"] = [_win(flow_t_d, a, b) for a, b in zip(t.q_lo_tpd, t.q_hi_tpd)]
    t["s_h2s"] = [1.0 if h2s_ppm <= tol else float(np.sqrt(tol / h2s_ppm)) for tol in t.h2s_tol_ppm]
    t["score"] = (t.s_pco2 * t.s_y * t.s_flow * t.s_h2s) ** 0.25
    t["fit"] = pd.cut(t.score, [-1, 0.5, 0.8, 2], labels=["poor", "marginal", "good"]).astype(str)
    why = []
    for _, r in t.iterrows():
        m = []
        if r.s_pco2 < 1:
            m.append(f"pCO2 {pco2:.2f} bar {'below' if pco2 < r.p_lo else 'above'} window {r.p_lo:g}-{r.p_hi:g}")
        if r.s_y < 1:
            m.append(f"CO2 {mol_frac * 100:.1f} % outside {r.y_lo * 100:g}-{r.y_hi * 100:g} %")
        if r.s_flow < 1:
            m.append(f"flow {flow_t_d:.0f} t/d outside {r.q_lo_tpd:g}-{r.q_hi_tpd:g}")
        if r.s_h2s < 1:
            m.append(f"H2S {h2s_ppm:g} ppm > {r.h2s_tol_ppm:g}")
        why.append("; ".join(m) or "inside all windows")
    t["reasons"] = why
    t = t.sort_values("score", ascending=False).reset_index(drop=True)
    res = Result("capture screening", t, Status.UNVALIDATED, [f"p_CO2 = {mol_frac:.3f} x {p_feed_bara:g} bar = {pco2:.2f} bar. Screening only: windows and energies are placeholders; get vendor quotes / pilot."],
                 [])
    if h2s_ppm > 0:
        res.messages.append("H2S co-captured: the CO2 stream needs H2S limits for pipeline / storage (toxicity, corrosion) and a sulphur route.")
    res.meta = dict(pco2_bar=pco2)
    return res


def capex_usd(row, tpy: float) -> float:
    """Power-law capex scaling around the 100 kt/yr reference (exponent 0.7). PLACEHOLDER."""
    return float(row["capex100_usd_tpy"] * tpy * (max(tpy, 1.0) / 1e5) ** -0.3)


def balance(stream, row, capture_pct: float | None = None, grid_ef: float = GRID_EF_T_PER_MWH, ef_heat: float = EF_HEAT_T_PER_GJ,
            spec_pct: float = 2.0, cfg=None) -> Result:
    """Mass / energy balance for one technology. capture_pct = share of contained CO2 captured (default stream target), capped by the
    technology recovery. Also compares 'spec removal only' (remove just enough for the sales spec) with full capture."""
    cp = stream.capture_target_pct if capture_pct is None else capture_pct
    eff = min(cp / 100.0, float(row["recov"]))
    f = 1 + row["dilute_k"] * max(0.0, (0.05 - stream.mol_frac) / 0.05)

    def _e(t_d):
        th, el = t_d * row["thermal_gj_t"] * f, t_d * row["elec_kwh_t"] * f / 1e3      # GJ/d, MWh/d
        co2 = th * ef_heat + el * grid_ef
        return dict(co2_t_d=t_d, thermal_gj_d=th, elec_mwh_d=el, fuel_sm3d=th / LHV_GJ_PER_SM3, process_co2_t_d=co2,
                    process_co2_per_t=co2 / t_d if t_d > 0 else float("nan"))
    cap = stream.t_per_day * eff
    full = _e(cap)
    gap = B.spec_gap(stream.mol_frac, spec_pct, stream.gas_sm3d, eff, cfg)
    spec = _e(min(gap["must_remove_t_d"], cap))
    hc_loss = stream.gas_sm3d * row["hc_loss_pct"] / 100.0
    gas_energy = stream.gas_sm3d * LHV_GJ_PER_SM3
    full.update(captured_pct=eff * 100, hc_loss_sm3d=hc_loss, energy_penalty_pct=100 * (full["thermal_gj_d"] + full["elec_mwh_d"] * 3.6 + hc_loss * LHV_GJ_PER_SM3) / max(gas_energy, 1e-9),
                dilution_factor=f, purity_pct=row["purity_pct"], capex_usd=capex_usd(row, cap * 365.25),
                opex_fixed_usd_yr=capex_usd(row, cap * 365.25) * row["opex_pct"] / 100, tech=row["tech"])
    res = Result("capture balance", dict(full=full, spec_only=spec, spec_gap=gap), Status.UNVALIDATED,
                 ["Energy, recovery and capex are placeholders (see technology table). Fuel for heat assumed natural gas; grid EF %.2f t/MWh." % grid_ef],
                 [f"dilution factor {f:.2f}", f"recovery cap {row['recov'] * 100:.0f} %"])
    if cp / 100 > row["recov"]:
        res.warn(f"Target {cp:.0f} % exceeds technology recovery {row['recov'] * 100:.0f} %: capped.")
    if full["process_co2_per_t"] > 0.5:
        res.warn("Process emissions exceed 0.5 t per t captured: net benefit is eroded - consider lower-carbon energy.")
    return res


def selftest() -> dict:
    s = B.build_stream(1e6, 2.0, pressure_bara=30)
    r = screen(30, 0.02, s.t_per_day)
    assert r.ok and r.value.iloc[0].tech.startswith("Amine"), r.value[["tech", "score"]]
    hi = screen(60, 0.40, 3000)
    assert hi.value.iloc[0].tech.startswith(("Physical", "Cryo", "Hot", "Polymeric")), hi.value[["tech", "score"]]
    row = techs().iloc[0]
    b = balance(s, row, 90, spec_pct=2.0)
    f = b.value["full"]
    assert abs(f["co2_t_d"] - 0.9 * s.t_per_day) < 1e-9 and f["process_co2_t_d"] > 0
    assert b.value["spec_only"]["co2_t_d"] == 0.0                       # gas already at spec -> no mandatory removal
    s3 = B.build_stream(1e6, 3.0)
    b3 = balance(s3, row, 100, spec_pct=2.0).value
    assert 0 < b3["spec_only"]["co2_t_d"] < b3["full"]["co2_t_d"] and b3["full"]["captured_pct"] == 95
    assert capex_usd(row, 2e5) > capex_usd(row, 1e5) and capex_usd(row, 2e5) < 2 * capex_usd(row, 1e5)
    return dict(top=r.value.iloc[0].tech, process_per_t=f["process_co2_per_t"], penalty_pct=f["energy_penalty_pct"])
