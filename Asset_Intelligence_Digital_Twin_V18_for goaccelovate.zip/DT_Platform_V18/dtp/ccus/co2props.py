"""CO2 properties for screening.  Source priority:
   1. CoolProp (Span-Wagner EOS, reference quality) if installed,
   2. embedded lookup table generated from CoolProp (co2_table.npz, T -30..250 C, p 0.5..500 bar; bilinear in T, ln p).
Accuracy of the table: <1% except in the grid cell that straddles the saturation line / critical point (flagged by `near_critical`).
Units: p [bara], T [degC], rho [kg/m3], mu [cP], h [kJ/kg]."""
from __future__ import annotations
from pathlib import Path

import numpy as np

TC, PC, MW = 304.1282, 73.773, 44.0095            # K, bar, g/mol
R = 8.314462618
_TAB = None
try:
    import CoolProp.CoolProp as _CP
except Exception:                                  # noqa: BLE001
    _CP = None


def backend() -> str:
    return "CoolProp (Span-Wagner)" if _CP is not None else "embedded table (from CoolProp, bilinear)"


def _tab():
    global _TAB
    if _TAB is None:
        from scipy.interpolate import RegularGridInterpolator as RGI
        d = np.load(Path(__file__).with_name("co2_table.npz"))
        lp = np.log(d["P"])
        _TAB = dict(rho=RGI((d["T"], lp), d["rho"], bounds_error=False, fill_value=None),
                    mu=RGI((d["T"], lp), d["mu"], bounds_error=False, fill_value=None), wag=d["wagner"])
    return _TAB


def psat_bar(t_c):
    """Saturation pressure below Tc, NaN above. Wagner form refit to CoolProp (max error <0.01%)."""
    t = np.asarray(t_c, float) + 273.15
    tau = 1 - t / TC
    a = _tab()["wag"]
    out = np.full(t.shape, np.nan)
    m = tau > 0
    out[m] = PC * np.exp(TC / t[m] * (a[0] * tau[m] + a[1] * tau[m] ** 1.5 + a[2] * tau[m] ** 2.5 + a[3] * tau[m] ** 5))
    return out if out.ndim else float(out)


def _prop(code, tab_key, p_bara, t_c):
    p, t = np.broadcast_arrays(np.asarray(p_bara, float), np.asarray(t_c, float))
    if _CP is not None:
        out = np.empty(p.shape)
        for idx in np.ndindex(p.shape):
            try:
                out[idx] = _CP.PropsSI(code, "P", max(p[idx], 0.05) * 1e5, "T", t[idx] + 273.15, "CO2")
            except Exception:                      # noqa: BLE001
                out[idx] = np.nan
        out = out * (1e3 if code == "V" else 1.0)
    else:
        pts = np.column_stack([np.clip(t, -30, 250).ravel(), np.log(np.clip(p, 0.5, 500)).ravel()])
        out = _tab()[tab_key](pts).reshape(p.shape)
    return out if out.ndim else float(out)


def density(p_bara, t_c):
    """kg/m3."""
    return _prop("D", "rho", p_bara, t_c)


def viscosity(p_bara, t_c):
    """cP."""
    return _prop("V", "mu", p_bara, t_c)


def enthalpy(p_bara, t_c):
    """kJ/kg (CoolProp only; fallback: ideal-gas cp ~ 0.85 kJ/kg/K + rough departure - returns NaN-free approximation)."""
    p, t = np.broadcast_arrays(np.asarray(p_bara, float), np.asarray(t_c, float))
    if _CP is not None:
        out = np.array([_CP.PropsSI("H", "P", pi * 1e5, "T", ti + 273.15, "CO2") / 1e3 for pi, ti in zip(p.ravel(), t.ravel())]).reshape(p.shape)
    else:
        out = 0.85 * (t + 273.15) - 0.45 * p ** 0.8 * (400 / (t + 273.15)) ** 2     # crude; compression work estimates only
    return out if out.ndim else float(out)


def phase_state(p_bara: float, t_c: float) -> str:
    tk = t_c + 273.15
    if tk > TC and p_bara > PC:
        return "supercritical"
    if tk > TC:
        return "gas (above Tc)"
    return "liquid / dense" if p_bara > psat_bar(t_c) else "gas"


def near_critical(p_bara, t_c, band: float = 0.08) -> bool:
    """True if inside +-8% of (Tc, Pc) or within 3% of the saturation line: property gradients are steep, treat with care."""
    tr, pr = (np.asarray(t_c, float) + 273.15) / TC, np.asarray(p_bara, float) / PC
    near_c = (abs(tr - 1) < band) & (abs(pr - 1) < 3 * band)
    ps = psat_bar(t_c)
    near_s = np.isfinite(ps) & (abs(np.asarray(p_bara, float) / np.where(np.isfinite(ps), ps, 1) - 1) < 0.03)
    return bool(np.any(near_c | near_s))


def gas_density_std(t_c: float = 15.0, p_bar: float = 1.01325) -> float:
    """kg/Sm3 at the platform standard condition."""
    return float(density(p_bar, t_c))


def selftest() -> dict:
    assert abs(psat_bar(0.0) - 34.85) < 0.1 and abs(psat_bar(20.0) - 57.29) < 0.15
    assert 770 < density(60.0, 20.0) < 795, density(60.0, 20.0)
    assert 610 < density(100.0, 40.0) < 645, density(100.0, 40.0)
    assert 1.8 < gas_density_std(15.0) < 2.0
    assert 0.0140 < viscosity(1.01325, 15.0) < 0.0150
    assert 0.040 < viscosity(100.0, 40.0) < 0.056
    return dict(backend=backend(), psat0=psat_bar(0.0), rho_60_20=density(60.0, 20.0), rho_100_40=density(100.0, 40.0),
                mu_100_40=viscosity(100.0, 40.0), rho_std=gas_density_std())
