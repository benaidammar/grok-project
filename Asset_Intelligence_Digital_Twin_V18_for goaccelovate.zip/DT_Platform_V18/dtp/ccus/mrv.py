"""MRV: monitoring plan by risk, anomaly / leak detection on injection data, mass balance, credit explainer."""
from __future__ import annotations
import numpy as np
import pandas as pd


def plan(risk: str = "medium") -> pd.DataFrame:
    base = [("Baseline", "Pre-injection seismic, groundwater & soil-gas chemistry, well integrity logs", "all"),
            ("Injection", "Rate, wellhead & bottomhole P/T, annulus pressure (continuous)", "all"),
            ("Reservoir", "Pressure gauges in observation wells; 4D seismic (interval by risk)", "medium|high"),
            ("Near-surface", "Soil-gas & groundwater sampling, eddy covariance at legacy wells", "medium|high"),
            ("Remote", "InSAR / GNSS ground deformation", "high"), ("Geochemistry", "Brine tracers, isotopes", "high")]
    keep = {"low": ("all",), "medium": ("all", "medium|high"), "high": ("all", "medium|high", "high")}[risk]
    return pd.DataFrame([r for r in base if r[2] in keep], columns=["stage", "measurement", "applies"])


def detect_anomaly(df: pd.DataFrame, z_thr: float = 4.0, cusum_k: float = 0.75, cusum_h: float = 8.0) -> pd.DataFrame:
    """df: time, pressure, rate. Metric = pressure per unit rate (inverse injectivity). Robust z + two-sided CUSUM on the standardised metric."""
    d = df.copy()
    d["metric"] = d.pressure / d.rate.clip(lower=1e-6)
    base = d.metric.iloc[: max(int(len(d) * 0.3), 20)]                 # baseline window = first 30 % (assumed healthy)
    med = base.median()
    mad = 1.4826 * (base - med).abs().median() + 1e-12
    d["z"] = (d.metric - med) / mad
    s_pos = s_neg = 0.0
    pos, neg = [], []
    for z in d.z.values:
        s_pos, s_neg = max(0, s_pos + z - cusum_k), max(0, s_neg - z - cusum_k)
        pos.append(s_pos)
        neg.append(s_neg)
    d["cusum_up"], d["cusum_dn"] = pos, neg
    d["flag"] = (d.z.abs() > z_thr) | (d.cusum_up > cusum_h) | (d.cusum_dn > cusum_h)
    return d


def demo_injection(n: int = 400, leak_at: int = 260, seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    t = np.arange(n)
    rate = 100 + rng.normal(0, 2, n)
    p = 180 + rng.normal(0, 0.4, n)                               # steady injection; real data usually drifts: re-baseline after rate changes
    p[leak_at:] -= np.linspace(0, 6, n - leak_at)                     # slow pressure loss at constant rate
    return pd.DataFrame(dict(time=t, pressure=p, rate=rate))


def reconcile(injected_t: float, stored_t: float, produced_back_t: float = 0.0, meter_unc_pct: float = 2.0) -> dict:
    gap = injected_t - stored_t - produced_back_t
    unc = injected_t * meter_unc_pct / 100.0
    return dict(unexplained_t=gap, meter_uncertainty_t=unc, within_uncertainty=abs(gap) <= unc)


CREDIT_NOTES = ["Additionality: would the project happen without credit revenue (regulation, EOR economics)?", "Permanence: geological storage vs products that re-emit.",
                "Leakage & monitoring: verified by an independent third party.", "Double counting: the same tonne cannot be claimed by emitter and user.",
                "Baseline: avoided vs flaring/venting under the applicable rules.", "This is an explainer, not legal or registry advice."]


def selftest() -> dict:
    d = detect_anomaly(demo_injection())
    assert d.flag.iloc[:200].mean() < 0.05 and d.flag.iloc[300:].any()
    return dict(first_flag=int(d.index[d.flag][d.index[d.flag] > 150][0]))
