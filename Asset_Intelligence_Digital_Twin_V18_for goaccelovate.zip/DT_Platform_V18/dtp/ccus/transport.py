"""CO2 conditioning & transport: staged compression + pumping, dense-phase pipeline hydraulics, truck/ship alternatives.
Properties from co2props (CoolProp or embedded table). Costs = PLACEHOLDERS."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..core.status import Result, Status
from . import co2props as P

R = 8.314462618


def compression(t_per_day: float, p_in: float, p_out: float, t_in_c: float = 40.0, max_ratio: float = 3.2, eta_is: float = 0.78,
                t_inter_c: float = 40.0, p_pump_from: float = 80.0, eta_pump: float = 0.75, k: float = 1.28) -> Result:
    """Gas compression (real-gas Z from co2props, polytropic-like with isentropic exponent k) up to p_pump_from, then pumping of the dense phase.
    Returns stage table and totals (kW, kWh/t)."""
    m = t_per_day * 1000 / 86400.0                                   # kg/s
    stages, p, tin, kw = [], p_in, t_in_c, 0.0
    p_top = min(p_out, p_pump_from)
    n = max(int(np.ceil(np.log(p_top / p_in) / np.log(max_ratio))), 0) if p_top > p_in else 0
    r = (p_top / p_in) ** (1 / n) if n else 1.0
    for i in range(n):
        rho = float(P.density(p, tin))
        z = p * 1e5 * P.MW * 1e-3 / (rho * R * (tin + 273.15))
        w = z * R * (tin + 273.15) / (P.MW * 1e-3) * k / (k - 1) * (r ** ((k - 1) / k) - 1) / eta_is       # J/kg
        stages.append(dict(stage=i + 1, p_in=p, p_out=p * r, ratio=r, z=z, kW=w * m / 1e3, t_out_c=tin + (tin + 273.15) * (r ** ((k - 1) / k) - 1) / eta_is))
        kw += w * m / 1e3
        p, tin = p * r, t_inter_c
    if p_out > p:
        rho = float(P.density(p, t_inter_c))
        wp = (p_out - p) * 1e5 / rho / eta_pump
        stages.append(dict(stage=len(stages) + 1, p_in=p, p_out=p_out, ratio=p_out / p, z=np.nan, kW=wp * m / 1e3, t_out_c=t_inter_c + 5, note="pump (dense phase)"))
        kw += wp * m / 1e3
    df = pd.DataFrame(stages)
    res = Result("CO2 compression / pumping", dict(table=df, kw=kw, kwh_per_t=kw * 24 / max(t_per_day, 1e-9), stages=len(df)), Status.UNVALIDATED,
                 assumptions=[f"isentropic exponent k={k}, efficiency {eta_is}, pump {eta_pump}", "no dehydration / TEG duty included"])
    res.messages.append("Screening estimate (+-20 %): use vendor / process-simulator data for design.")
    return res


def pipeline_dp(t_per_day: float, d_in: float, length_km: float, p_in: float, t_c: float = 20.0, elev_m: float = 0.0, rough_mm: float = 0.045, n: int = 40) -> Result:
    """Isothermal Darcy-Weisbach marching with local density/viscosity. Flags approach to saturation (two-phase risk)."""
    d = d_in * 0.0254
    area = np.pi * d * d / 4
    m = t_per_day * 1000 / 86400.0
    dx = length_km * 1000 / n
    p, rows = p_in, []
    for i in range(n + 1):
        rho, mu = float(P.density(p, t_c)), float(P.viscosity(p, t_c)) * 1e-3
        u = m / (rho * area)
        re = rho * u * d / mu
        f = 1.0 / (-1.8 * np.log10(6.9 / re + (rough_mm * 1e-3 / d / 3.7) ** 1.11)) ** 2
        rows.append(dict(km=i * dx / 1000, p_bara=p, rho=rho, u=u, re=re))
        dp = (f * dx / d * rho * u * u / 2 + rho * 9.81 * elev_m / n) / 1e5
        p -= dp
    df = pd.DataFrame(rows)
    ps = P.psat_bar(t_c)
    margin = df.p_bara.min() - (ps if np.isfinite(ps) else 0)
    res = Result("CO2 dense-phase pipeline", dict(profile=df, dp_bar=float(p_in - df.p_bara.iloc[-1]), p_out=float(df.p_bara.iloc[-1]), v_max=float(df.u.max()),
                                                   psat=float(ps) if np.isfinite(ps) else np.nan), Status.UNVALIDATED)
    if np.isfinite(ps) and margin < 5:
        res.warn(f"Outlet pressure within {margin:.1f} bar of saturation ({ps:.1f} bar at {t_c:.0f} C): two-phase flow risk, increase pressure or diameter.")
    if df.p_bara.iloc[-1] <= 0:
        res.fail("pressure collapses along the line: diameter too small")
    if df.u.max() > 4:
        res.warn("velocity > 4 m/s: erosion/noise risk; typical design 1-3 m/s")
    res.messages.append("Isothermal, steady, single-phase; impurities (H2S, N2, CH4, H2O) shift density and saturation pressure.")
    return res


def diameter_options(t_per_day: float, length_km: float, p_in: float, p_min: float, t_c: float = 20.0, sizes=(2, 3, 4, 6, 8, 10, 12, 16)) -> pd.DataFrame:
    rows = []
    for dn in sizes:
        r = pipeline_dp(t_per_day, dn, length_km, p_in, t_c, n=25)
        v = r.value
        rows.append(dict(diameter_in=dn, dp_bar=v["dp_bar"] if v else np.nan, p_out=v["p_out"] if v else np.nan, v_max=v["v_max"] if v else np.nan,
                         ok=bool(v and v["p_out"] >= p_min and r.status != Status.FAIL)))
    return pd.DataFrame(rows)


def road_ship_cost(t_per_year: float, km: float) -> pd.DataFrame:
    """Placeholder $/t: liquefaction + loading fixed part plus distance part. Truck ~ 20 t loads, rail, small ship."""
    rows = []
    for mode, fixed, var, cap in (("Truck (liquid, -20 C / 20 bar)", 18.0, 0.14, 2e5), ("Rail", 20.0, 0.05, 1e6), ("Ship (coastal)", 28.0, 0.012, 5e6)):
        rows.append(dict(mode=mode, usd_per_t=fixed + var * km, applicable=t_per_year <= cap * 5, note="PLACEHOLDER cost factors"))
    return pd.DataFrame(rows)


def selftest() -> dict:
    c = compression(100, 2, 150)
    assert 40 < c.value["kwh_per_t"] < 160, c.value["kwh_per_t"]
    pl = pipeline_dp(500, 6, 50, 120)
    assert 0 < pl.value["dp_bar"] < 120
    assert pipeline_dp(500, 8, 50, 120).value["dp_bar"] < pl.value["dp_bar"]
    return dict(kwh_t=c.value["kwh_per_t"], dp=pl.value["dp_bar"])
