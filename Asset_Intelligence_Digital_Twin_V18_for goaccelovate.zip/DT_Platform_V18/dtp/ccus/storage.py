"""Storage capacity, injectivity, Hall plot, security checklist. Ranges are literature defaults to be replaced by site data."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..core.status import Result, Status
from ..gascond.pvt import GasPVT
from . import co2props as P


def depleted_field(gp_sm3: float, pr_final_bara: float, t_c: float, pvt: GasPVT, efficiency: float = 0.7, pr_inj_bara: float | None = None) -> Result:
    """Volume replacement: reservoir volume vacated by produced gas V = Gp x Bg(Pr_final); CO2 mass = V x E x rho_CO2(P_inj, T).
    E (0.5-0.9) covers water influx, trapped gas, pressure limits. Pr_inj defaults to the final pressure."""
    pin = pr_inj_bara or pr_final_bara
    v = gp_sm3 * float(pvt.bg(pr_final_bara, t_c))
    rho = float(P.density(pin, t_c))
    m = v * efficiency * rho / 1e9                                  # Mt
    res = Result("Depleted-field storage capacity", dict(mt=m, vacated_rm3=v, rho_co2=rho), Status.UNVALIDATED)
    res.messages.append("Upper-bound style estimate: needs reservoir model, caprock integrity, legacy-well review and pressure limits.")
    return res


def saline(area_km2: float, h_m: float, phi: float, t_c: float, p_bara: float, n: int = 4000, seed: int = 0, e_p10: float = 0.0051, e_p90: float = 0.055) -> Result:
    """DOE-NETL volumetric: M = A h phi rho E, E log-uniform between P10 and P90 efficiency (clastics 0.51-5.5 %, literature range)."""
    rng = np.random.default_rng(seed)
    rho = float(P.density(p_bara, t_c))
    e = np.exp(rng.uniform(np.log(e_p10), np.log(e_p90), n))
    m = area_km2 * 1e6 * h_m * phi * rho * e / 1e9
    res = Result("Saline-aquifer capacity", dict(P10=float(np.percentile(m, 10)), P50=float(np.percentile(m, 50)), P90=float(np.percentile(m, 90)), rho=rho),
                 Status.UNVALIDATED)
    res.messages.append("Efficiency range is generic: replace with site-specific simulation.")
    return res


def injectivity(k_md: float, h_m: float, pr_bara: float, depth_m: float, t_c: float, frac_gradient: float = 0.17, margin: float = 0.9,
                re_m: float = 1000.0, rw_m: float = 0.1, skin: float = 0.0, mu_cp: float | None = None) -> dict:
    """Radial Darcy, single-phase CO2: q_res = 2 pi k h dP / (mu (ln(re/rw)+s)); dP up to margin x fracture pressure - Pr."""
    pmax = margin * frac_gradient * depth_m
    dp = max(pmax - pr_bara, 0.0)
    pm = 0.5 * (pmax + pr_bara)
    mu = (mu_cp if mu_cp else float(P.viscosity(pm, t_c))) * 1e-3
    k = k_md * 9.869e-16
    q = 2 * np.pi * k * h_m * dp * 1e5 / (mu * (np.log(re_m / rw_m) + skin))      # m3/s
    rho = float(P.density(pm, t_c))
    return dict(p_max=pmax, dp=dp, q_t_per_day=q * rho * 86.4, rho=rho, mu_cp=mu * 1e3)


def hall_plot(df: pd.DataFrame) -> pd.DataFrame:
    """df: time (days), pwf, pres, q_t_d. Hall integral H = cum (Pwf-Pr) dt vs cumulative injection; slope ~ 1/injectivity."""
    d = df.sort_values("time").copy()
    dt = np.diff(d.time.values, prepend=d.time.values[0])
    d["H"] = np.cumsum((d.pwf - d.pres) * dt)
    d["Wi"] = np.cumsum(d.q_t_d * dt)
    d["slope"] = np.gradient(d.H, d.Wi.replace(0, np.nan).ffill().bfill() + 1e-9)
    return d


def checklist() -> pd.DataFrame:
    items = ["Caprock thickness, capillary entry pressure, lateral continuity", "Fault & fracture screening; fault reactivation pressure", "Legacy wells inventory: cement quality, abandonment, corrosion",
             "Pressure limit vs fracture gradient; pressure-management plan", "Overlying aquifers / USDW protection; area of review", "Injectivity & reservoir quality (k, h, heterogeneity)",
             "Geochemistry: CO2-brine-rock, impurities (H2S, O2, water), corrosion of completions", "Monitoring plan & baseline surveys", "Leakage response plan and financial responsibility",
             "Regulatory permits and long-term stewardship"]
    return pd.DataFrame(dict(item=items, status="open", evidence=""))


def selftest() -> dict:
    pvt = GasPVT(0.7, 2.0)
    r = depleted_field(1e10, 100.0, 100.0, pvt)
    assert r.value["mt"] > 0
    s = saline(100, 50, 0.2, 60, 150)
    assert s.value["P10"] < s.value["P50"] < s.value["P90"]
    inj = injectivity(100, 30, 150, 2000, 70)
    assert inj["q_t_per_day"] > 0
    t = np.arange(1, 200.0)
    hp = hall_plot(pd.DataFrame(dict(time=t, pwf=200 + 0.02 * t, pres=150, q_t_d=100.0)))
    assert hp.H.is_monotonic_increasing
    return dict(mt=r.value["mt"], inj=inj["q_t_per_day"])
