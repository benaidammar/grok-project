"""Life-cycle CO2 balance: produced -> captured -> (process, transport emissions, leakage) -> stored / utilised by permanence class -> net avoided."""
from __future__ import annotations
import pandas as pd

PERM_FACTOR = {"permanent geological": 1.0, "long-lived product (>100 y)": 0.9, "medium (10-100 y)": 0.4, "short-lived (<1 y, re-emits)": 0.0}


def balance(produced_t: float, captured_t: float, process_t: float, transport_t: float, leak_pct: float, uses: list[dict]) -> dict:
    """uses = [{'name','t','permanence'}]. Net avoided = sum(t x permanence factor) - process - transport - leakage."""
    leak = sum(u["t"] for u in uses if u["permanence"] == "permanent geological") * leak_pct / 100.0
    credited = sum(u["t"] * PERM_FACTOR.get(u["permanence"], 0.0) for u in uses)
    net = credited - process_t - transport_t - leak
    rows = [("CO2 produced with gas", produced_t), ("Not captured", -(produced_t - captured_t)), ("Captured", captured_t), ("Process emissions", -process_t),
            ("Transport emissions", -transport_t), ("Leakage", -leak)]
    rows += [(f"Re-emitted / non-permanent: {u['name']}", -(u["t"] * (1 - PERM_FACTOR.get(u["permanence"], 0.0)))) for u in uses if PERM_FACTOR.get(u["permanence"], 0) < 1]
    return dict(table=pd.DataFrame(rows, columns=["item", "t_co2"]), net_avoided=net, credited=credited, leak=leak,
                note="Boundary: cradle-to-gate of the CCUS chain. Credits need third-party verification (ISO 14064 / registry rules); avoid double counting with the buyer.")


def selftest() -> dict:
    b = balance(1000, 900, 90, 10, 1.0, [{"name": "storage", "t": 800, "permanence": "permanent geological"}, {"name": "beverage", "t": 100, "permanence": "short-lived (<1 y, re-emits)"}])
    assert abs(b["net_avoided"] - (800 - 90 - 10 - 8)) < 1e-9
    return dict(net=b["net_avoided"])
