"""DT Platform - Oil & Gas Asset Intelligence Digital Twin (V18)."""
__version__ = "18.0"
