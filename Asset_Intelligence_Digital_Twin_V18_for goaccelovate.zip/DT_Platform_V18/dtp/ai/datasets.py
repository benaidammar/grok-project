"""Supervised datasets from well tests + synthetic generators with KNOWN physics (so models can be verified against truth).

Regular grid: irregular tests -> cells of `step_months` on a GLOBAL origin; cell value = mean of tests in the cell,
gaps inside a series are linearly interpolated, and an `obs` mask says which cells hold a real test.
Models may train on interpolated cells, but they are ONLY SCORED on observed cells."""
from __future__ import annotations
from dataclasses import dataclass

import numpy as np
import pandas as pd

VARS = {"gas": "gas_sm3d", "whp": "whp_bara", "cgr": "cgr_m3_mmsm3", "wgr": "wgr_m3_mmsm3", "cond": "cond_m3d", "water": "water_m3d"}
DAYS_PER_CELL = 30.4375


@dataclass
class Grid:
    well: str
    cells: np.ndarray        # absolute integer cell index
    y: np.ndarray            # value (interpolated in gaps)
    obs: np.ndarray          # bool: real observation inside the cell

    def upto(self, last_cell: int) -> "Grid":
        m = self.cells <= last_cell
        return Grid(self.well, self.cells[m], self.y[m], self.obs[m])


def global_origin(w: pd.DataFrame) -> pd.Timestamp:
    return pd.Timestamp(w["date"].min()).normalize()


def cell_of(dates, origin, step_months: int = 6) -> np.ndarray:
    d = (pd.to_datetime(dates) - origin).days.values if hasattr(pd.to_datetime(dates), "days") is False else None
    d = np.asarray((pd.to_datetime(dates) - origin).days if isinstance(pd.to_datetime(dates), pd.DatetimeIndex) else (pd.to_datetime(dates) - origin).dt.days)
    return np.floor(d / (DAYS_PER_CELL * step_months)).astype(int)


def well_series(w: pd.DataFrame, well: str, var: str = "gas_sm3d") -> pd.Series:
    d = w.loc[w["well"] == well, ["date", var]].replace([np.inf, -np.inf], np.nan).dropna()
    return d.groupby("date")[var].mean().sort_index()


def to_grid(s: pd.Series, origin, step_months: int = 6, last_cell: int | None = None, well: str = "") -> Grid | None:
    s = s.dropna()
    if s.empty:
        return None
    c = cell_of(s.index, origin, step_months)
    if last_cell is not None:
        keep = c <= last_cell
        s, c = s[keep], c[keep]
        if s.empty:
            return None
    cell_mean = pd.Series(s.values, index=c).groupby(level=0).mean()
    cells = np.arange(cell_mean.index.min(), cell_mean.index.max() + 1)
    y = np.interp(cells, cell_mean.index.values, cell_mean.values)
    obs = np.isin(cells, cell_mean.index.values)
    return Grid(well, cells, y, obs)


def raw_by_well(w: pd.DataFrame, var: str = "gas_sm3d", min_obs: int = 6) -> dict:
    out = {}
    for well in sorted(w["well"].unique()):
        s = well_series(w, well, var)
        s = s[s > 0] if var in ("gas_sm3d", "whp_bara") else s
        if len(s) >= min_obs:
            out[well] = s
    return out


def rate_whp_frame(w: pd.DataFrame, min_pts: int = 8) -> pd.DataFrame:
    """One row per test: well, wid, date, t_yr (years since the global origin), whp, q (Sm3/d), cgr."""
    d = w[["well", "date", "whp_bara", "gas_sm3d", "cgr_m3_mmsm3"]].replace([np.inf, -np.inf], np.nan).dropna(subset=["whp_bara", "gas_sm3d"])
    d = d[(d.whp_bara > 1) & (d.gas_sm3d > 0)].copy()
    n = d.groupby("well")["well"].transform("size")
    d = d[n >= min_pts]
    o = global_origin(w)
    d["t_yr"] = (d["date"] - o).dt.days / 365.25
    codes = {k: i for i, k in enumerate(sorted(d["well"].unique()))}
    d["wid"] = d["well"].map(codes)
    d = d.rename(columns={"whp_bara": "whp", "gas_sm3d": "q", "cgr_m3_mmsm3": "cgr"})
    return d.sort_values(["well", "date"]).reset_index(drop=True)


# ---------------- splits -------------------------------------------------------------------------------
def split_time(d: pd.DataFrame, frac: float = 0.7) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Per well: first `frac` of the tests (in time) train, the rest test. No future information in training."""
    tr, te = [], []
    for _, g in d.groupby("well"):
        g = g.sort_values("date")
        k = int(len(g) * frac)
        tr.append(g.iloc[:k])
        te.append(g.iloc[k:])
    return pd.concat(tr), pd.concat(te)


def split_holdout_wells(d: pd.DataFrame, hold: list) -> tuple[pd.DataFrame, pd.DataFrame]:
    m = d["well"].isin(hold)
    return d[~m], d[m]


def split_random(d: pd.DataFrame, frac: float = 0.7, seed: int = 0) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    m = rng.random(len(d)) < frac
    return d[m], d[~m]


def rolling_cutoffs(last_cell: int, horizon: int, n_origins: int = 3, spacing: int = 2) -> list:
    return [last_cell - horizon - k * spacing for k in range(n_origins)][::-1]


# ---------------- synthetic generators with known truth -----------------------------------------------------
def arps(t, qi, d, b):
    t = np.asarray(t, float)
    return qi * np.exp(-d * t) if b < 1e-6 else qi * (1 + b * d * t) ** (-1.0 / b)


def synth_decline(n: int = 14, qi: float = 1.0, d: float = 0.35, b: float = 0.5, t_max: float = 5.0, noise: float = 0.02, seed: int = 0):
    """Irregular, sparse Arps data. Returns t, q(noisy), q_true function parameters."""
    rng = np.random.default_rng(seed)
    t = np.sort(np.concatenate([[0.0], rng.uniform(0, t_max, n - 1)]))
    q = arps(t, qi, d, b) * (1 + noise * rng.standard_normal(n))
    return t, q, dict(qi=qi, d=d, b=b)


def synth_gas_well(n: int = 80, seed: int = 0, years: float = 15.0, n_wells: int = 1, pr0: float = 300.0, strength: float = 0.3) -> pd.DataFrame:
    """Backpressure physics q = C (a(t)^2 - whp^2)^n with a(t) depleting, times a slow 'unmodelled' loss factor
    (water loading) that a static physics model cannot represent.  Columns match rate_whp_frame (+ q_phys_true)."""
    rng = np.random.default_rng(seed)
    rows = []
    for w in range(n_wells):
        t = np.sort(rng.uniform(0, years, n))
        a = pr0 * (0.85 + 0.3 * rng.random()) * np.exp(-0.045 * t)
        whp = a * np.clip(0.55 + 0.15 * np.sin(t * 1.3) + 0.05 * rng.standard_normal(n), 0.3, 0.9)
        c, nn = 2.0e-3 * (0.8 + 0.4 * rng.random()), 0.85
        qp = c * np.maximum(a ** 2 - whp ** 2, 1.0) ** nn * 1e3
        loss = 1 - strength / (1 + np.exp(-(t - years * 0.55) / 1.2))
        q = qp * loss * np.exp(0.03 * rng.standard_normal(n))
        rows.append(pd.DataFrame(dict(well=f"S{w+1}", wid=w, date=pd.Timestamp("2005-01-01") + pd.to_timedelta(t * 365.25, "D"), t_yr=t, whp=whp, q=q, cgr=np.nan, q_phys_true=qp)))
    return pd.concat(rows).reset_index(drop=True)


def synth_fleet(n_wells: int = 8, n_cells: int = 44, seed: int = 0, noise: float = 0.03, kind: str = "exp") -> dict:
    """Fleet of grids with known decline. kind='exp': pure exponential (best simple model = exp / Arps)."""
    rng = np.random.default_rng(seed)
    out = {}
    for i in range(n_wells):
        cells = np.arange(n_cells)
        qi = 1e6 * (0.5 + rng.random())
        d = 0.03 + 0.03 * rng.random()
        y = qi * np.exp(-d * cells) if kind == "exp" else arps(cells, qi, d * 2, 0.6)
        y = y * np.exp(noise * rng.standard_normal(n_cells))
        out[f"W{i+1}"] = Grid(f"W{i+1}", cells, y, np.ones(n_cells, bool))
    return out


def selftest() -> dict:
    t, q, p = synth_decline()
    assert len(t) == 14 and q[0] > 0
    d = synth_gas_well(60, seed=1)
    tr, te = split_time(d)
    assert tr["date"].max() <= te["date"].min()
    f = synth_fleet(3)
    assert f["W1"].y.shape[0] == 44
    s = pd.Series([1.0, 2.0, 4.0], index=pd.to_datetime(["2000-01-10", "2000-03-01", "2001-01-10"]))
    g = to_grid(s, pd.Timestamp("2000-01-01"), 6)
    assert g.obs.sum() >= 2 and np.isfinite(g.y).all()
    return dict(ok=True, cells=len(g.cells))
