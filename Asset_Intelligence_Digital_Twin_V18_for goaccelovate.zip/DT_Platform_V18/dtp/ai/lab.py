"""Advanced AI lab: honest benchmark first. Candidate forecasters are compared with rolling-origin backtests against naive and Arps baselines;
hybrid physics+ML residual, conformal intervals, optional PINN (torch), and a rule-based surveillance 'agent' that only PROPOSES actions."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.linear_model import Ridge

from ..core.deps import try_import
from ..core.status import Result, Status
from . import datasets as DS

LAGS = 4


# ---------------------------------------------------------------- baselines (per well, on cells)
def f_naive(g: DS.Grid, h: int) -> np.ndarray:
    return np.repeat(g.y[-1], h)


def f_exp(g: DS.Grid, h: int, k: int = 8) -> np.ndarray:
    y = np.log(np.clip(g.y[-k:], 1e-9, None))
    x = g.cells[-k:].astype(float)
    b = np.polyfit(x, y, 1) if len(x) >= 3 else (0.0, y[-1])
    return np.exp(np.polyval(b, g.cells[-1] + np.arange(1, h + 1)))


def _arps_fit(g: DS.Grid):
    t = (g.cells - g.cells[0]).astype(float)
    y = g.y / max(g.y[0], 1e-9)
    try:
        p, _ = curve_fit(lambda t_, d, b: (1 + b * d * t_) ** (-1 / b), t, y, p0=[0.05, 0.5], bounds=([1e-4, 0.01], [1.5, 1.0]), maxfev=4000)
    except Exception:                                           # noqa: BLE001
        return None
    return p, t, g.y[0]


def f_arps(g: DS.Grid, h: int) -> np.ndarray:
    r = _arps_fit(g)
    if r is None:
        return f_exp(g, h)
    (d, b), t, q0 = r
    tf = t[-1] + np.arange(1, h + 1)
    return q0 * (1 + b * d * tf) ** (-1 / b)


# ---------------------------------------------------------------- ML (global across wells)
def _feats(y: np.ndarray, i: int, scale: float) -> list:
    w = y[i - LAGS:i] / scale
    return list(w) + [w[-1] - w[0], np.log(max(w[-1], 1e-6))]


def _train_set(grids: list, cutoff: int):
    X, Y = [], []
    for g in grids:
        gg = g.upto(cutoff)
        if len(gg.y) <= LAGS + 1:
            continue
        s = float(np.mean(gg.y[:LAGS])) or 1.0
        for i in range(LAGS, len(gg.y)):
            X.append(_feats(gg.y, i, s)); Y.append(gg.y[i] / s)
    return np.array(X), np.array(Y)


class MLForecaster:
    def __init__(self, kind="gbm"):
        self.kind = kind

    def fit(self, grids, cutoff):
        X, Y = _train_set(grids, cutoff)
        if len(X) < 15:
            self.m = None
            return self
        self.m = (Ridge(1e-2) if self.kind == "ridge" else GradientBoostingRegressor(n_estimators=120, max_depth=2, learning_rate=0.08, random_state=0)).fit(X, Y)
        return self

    def predict(self, g: DS.Grid, h: int) -> np.ndarray:
        if self.m is None or len(g.y) <= LAGS:
            return f_naive(g, h)
        s = float(np.mean(g.y[:LAGS])) or 1.0
        hist = list(g.y / s)
        for _ in range(h):
            x = np.array(_feats(np.array(hist), len(hist), 1.0))[None]
            hist.append(float(max(self.m.predict(x)[0], 0.0)))
        return np.array(hist[-h:]) * s


class HybridForecaster:
    """Arps (physics) + ML on the log-ratio residual of the training window (learned correction, shrunk)."""
    def fit(self, grids, cutoff):
        self.gb = None
        X, Y = [], []
        for g in grids:
            gg = g.upto(cutoff)
            if len(gg.y) < 10:
                continue
            for k in range(8, len(gg.y) - 1):
                sub = DS.Grid(gg.well, gg.cells[:k], gg.y[:k], gg.obs[:k])
                p = f_arps(sub, 1)[0]
                s = max(sub.y[-1], 1e-9)
                X.append([sub.y[-1] / s, np.log(max(sub.y[-1], 1e-9) / max(sub.y[-4], 1e-9)), k]); Y.append(np.log(max(gg.y[k], 1e-9) / max(p, 1e-9)))
        if len(X) > 30:
            self.gb = GradientBoostingRegressor(n_estimators=60, max_depth=2, learning_rate=0.05, random_state=0).fit(np.array(X), np.array(Y))
        return self

    def predict(self, g, h):
        base = f_arps(g, h)
        if self.gb is None:
            return base
        corr = float(self.gb.predict(np.array([[1.0, np.log(max(g.y[-1], 1e-9) / max(g.y[-4], 1e-9)), len(g.y)]]))[0])
        return base * np.exp(0.5 * np.clip(corr, -0.3, 0.3))


def _mlp_torch(grids, cutoff, epochs=250):
    torch = try_import("torch")
    if torch is None:
        return None
    X, Y = _train_set(grids, cutoff)
    if len(X) < 30:
        return None
    torch.manual_seed(0)
    net = torch.nn.Sequential(torch.nn.Linear(X.shape[1], 16), torch.nn.Tanh(), torch.nn.Linear(16, 1))
    opt = torch.optim.Adam(net.parameters(), 1e-2)
    xt, yt = torch.tensor(X, dtype=torch.float32), torch.tensor(Y, dtype=torch.float32)[:, None]
    for _ in range(epochs):
        opt.zero_grad(); l = ((net(xt) - yt) ** 2).mean(); l.backward(); opt.step()

    class W:
        def predict(self, x):
            with torch.no_grad():
                return net(torch.tensor(x, dtype=torch.float32)).numpy().ravel()
    f = MLForecaster("gbm"); f.m = W()
    return f


# ---------------------------------------------------------------- benchmark
def benchmark(grids: list, horizon: int = 4, n_origins: int = 3, use_torch: bool = True) -> Result:
    """Rolling-origin comparison. Metric: scaled MAE (MAE / mean level) and MASE-like skill vs naive. Wells need >= LAGS+horizon+10 cells."""
    ok = [g for g in grids if len(g.y) >= LAGS + horizon + 10]
    if len(ok) < 2:
        return Result("AI benchmark", None, Status.FAIL, [f"need >= 2 wells with >= {LAGS + horizon + 10} time cells (semi-annual)"])
    last = min(g.cells[-1] for g in ok)
    origins = DS.rolling_cutoffs(int(last), horizon, n_origins)
    rows = []
    for co in origins:
        tr = [g.upto(co) for g in ok]
        models = {"naive": None, "exp": None, "arps": None, "ridge": MLForecaster("ridge").fit(ok, co), "gbm": MLForecaster("gbm").fit(ok, co), "hybrid Arps+ML": HybridForecaster().fit(ok, co)}
        if use_torch:
            m = _mlp_torch(ok, co)
            if m is not None:
                models["MLP (torch)"] = m
        for g, gt in zip(tr, ok):
            if len(g.y) < LAGS + 5:
                continue
            truth = gt.y[(gt.cells > co) & (gt.cells <= co + horizon)]
            if len(truth) < horizon:
                continue
            lvl = float(np.mean(g.y[-4:])) or 1.0
            for name, mdl in models.items():
                pred = f_naive(g, horizon) if name == "naive" else f_exp(g, horizon) if name == "exp" else f_arps(g, horizon) if name == "arps" else mdl.predict(g, horizon)
                rows.append(dict(origin=co, well=g.well, model=name, mae=float(np.mean(np.abs(pred - truth))) / lvl, bias=float(np.mean(pred - truth)) / lvl))
    d = pd.DataFrame(rows)
    sm = d.groupby("model").agg(mae=("mae", "mean"), mae_p90=("mae", lambda x: x.quantile(.9)), bias=("bias", "mean"), n=("mae", "size")).sort_values("mae")
    nv = sm.loc["naive", "mae"]
    sm["skill_vs_naive_pct"] = 100 * (1 - sm.mae / nv)
    best = sm.index[0]
    res = Result("AI benchmark (rolling origin)", dict(summary=sm.reset_index(), detail=d, best=best), Status.UNVALIDATED,
                 [f"{len(ok)} wells, {len(origins)} origins, horizon {horizon} cells (semi-annual)"])
    simple = sm.loc[["naive", "exp", "arps"]].mae.min()
    if sm.loc[best, "mae"] > 0.9 * simple and best not in ("naive", "exp", "arps"):
        res.warn("The advanced model is NOT clearly better than the best simple baseline (<10 % gain): prefer the simple model (handbook rule: benchmark before complexity).")
    return res


def conformal_interval(detail: pd.DataFrame, model: str, level: float = 0.9) -> float:
    r = detail[detail.model == model].mae
    return float(np.quantile(r, level)) if len(r) else float("nan")


# ---------------------------------------------------------------- PINN (optional torch)
def pinn_decline(t, q, steps=1500, seed=0) -> Result:
    """q(t) = NN(t); loss = data + physics residual of the Arps ODE dq/dt = -D q^(1+b) (D, b learnable). Compare with a plain NN and Arps in the page."""
    torch = try_import("torch")
    if torch is None:
        return Result("PINN", None, Status.FAIL, ["torch not installed (pip install torch) - benchmark of the PINN is skipped; Arps / hybrid remain available"])
    torch.manual_seed(seed)
    t_ = torch.tensor(np.asarray(t, float) / max(np.max(t), 1e-9), dtype=torch.float32)[:, None]
    q0 = float(np.max(q))
    q_ = torch.tensor(np.asarray(q, float) / q0, dtype=torch.float32)[:, None]
    net = torch.nn.Sequential(torch.nn.Linear(1, 24), torch.nn.Tanh(), torch.nn.Linear(24, 24), torch.nn.Tanh(), torch.nn.Linear(24, 1), torch.nn.Softplus())
    lD, lb = torch.nn.Parameter(torch.tensor(0.0)), torch.nn.Parameter(torch.tensor(-1.0))
    opt = torch.optim.Adam(list(net.parameters()) + [lD, lb], 5e-3)
    tc = torch.linspace(0, 1.4, 60)[:, None].requires_grad_(True)
    for _ in range(steps):
        opt.zero_grad()
        ld = ((net(t_) - q_) ** 2).mean()
        qc = net(tc)
        dq = torch.autograd.grad(qc.sum(), tc, create_graph=True)[0]
        D, b = torch.exp(lD), torch.sigmoid(lb)
        lp = ((dq + D * qc ** (1 + b)) ** 2).mean()
        (ld + 0.1 * lp).backward(); opt.step()
    tt = torch.linspace(0, 1.4, 80)[:, None]
    with torch.no_grad():
        qq = net(tt).numpy().ravel() * q0
    tmax = float(np.max(t))
    return Result("PINN (Arps ODE prior)", dict(t=tt.numpy().ravel() * tmax, q=qq, D=float(torch.exp(lD).detach()), b=float(torch.sigmoid(lb).detach())), Status.UNVALIDATED,
                  ["Physics prior = hyperbolic Arps ODE; extrapolation beyond data (t>1.0) follows the ODE, not the data. Benchmark against Arps before any use."])


# ---------------------------------------------------------------- graph message passing on the network (GNN-lite, numpy)
def graph_smooth(adj: dict, values: dict, hops: int = 2, alpha: float = 0.5) -> dict:
    """Neighbour-aware features: x' = (1-a) x + a mean(neighbours), repeated `hops` times - the message-passing step of a GNN without learned weights."""
    v = dict(values)
    for _ in range(hops):
        nv = {}
        for n, x in v.items():
            nb = [v[m] for m in adj.get(n, []) if m in v and np.isfinite(v[m])]
            nv[n] = (1 - alpha) * x + alpha * float(np.mean(nb)) if nb else x
        v = nv
    return v


# ---------------------------------------------------------------- surveillance agent (proposes only)
def surveillance_agent(wt: pd.DataFrame, cfg) -> pd.DataFrame:
    """Runs fixed checks over the well tests and returns PROPOSED actions with evidence. No action is executed; every proposal needs human approval (logged)."""
    from ..gascond import banking
    out = []
    for w, g in wt.sort_values("date").groupby("well"):
        l = g.tail(6)
        if len(l) < 4:
            continue
        r = lambda c: (l[c].iloc[-1] / l[c].iloc[0] - 1) if c in l and l[c].iloc[0] else np.nan
        if r("gas_sm3d") < -0.25:
            out.append((w, "Rate decline > 25 % over last 6 tests", f"gas {r('gas_sm3d'):+.0%}", "Review choke/WHP, schedule well test, check deliverability", "medium"))
        if "cgr_m3_mmsm3" in l and r("cgr_m3_mmsm3") < -0.3:
            out.append((w, "CGR dropping fast (banking signal)", f"CGR {r('cgr_m3_mmsm3'):+.0%}", "Compare Pwf with dew point; consider gas cycling/solvent screening", "medium"))
        if "wgr_m3_mmsm3" in l and r("wgr_m3_mmsm3") > 0.5:
            out.append((w, "Water-gas ratio rising", f"WGR {r('wgr_m3_mmsm3'):+.0%}", "Check salinity (formation vs condensed water), liquid-loading margin", "medium"))
        if l.gas_sm3d.isna().sum() > 2:
            out.append((w, "Data gaps in recent tests", f"{int(l.gas_sm3d.isna().sum())}/6 missing", "Fix data capture", "low"))
    df = pd.DataFrame(out, columns=["well", "observation", "evidence", "proposed_action", "priority"])
    return df


def selftest() -> dict:
    f = DS.synth_fleet(6, 44, seed=1, noise=0.03)
    r = benchmark(list(f.values()), horizon=4, n_origins=2, use_torch=False)
    assert r.value is not None, r.messages
    s = r.value["summary"].set_index("model")
    assert s.loc["exp", "mae"] < s.loc["naive", "mae"] + 1e-9           # truth is exponential: exp must beat persistence
    assert r.value["best"] in ("exp", "arps", "hybrid Arps+ML", "ridge", "gbm"), r.value["best"]
    t, q, _ = DS.synth_decline(20, noise=0.01)
    p = pinn_decline(t, q, steps=300)
    return dict(best=r.value["best"], mae=float(s.mae.min()), pinn=p.status.value)
