"""Page registry: (key, title, 'module:function'). Imported lazily so one broken page never takes the app down."""
PAGES = [
    ("home", "0 · Data foundation", "dtp.ui.page_home:render"),
    ("mgmt", "1 · Managerial intelligence", "dtp.ui.page_mgmt:render"),
    ("lift", "2 · Artificial lift", "dtp.ui.page_lift:render"),
    ("gascond", "3 · Gas-condensate engineering", "dtp.ui.page_gascond:render"),
    ("network", "3b · Gathering network & facilities", "dtp.ui.page_network:render"),
    ("frac", "4 · Hydraulic fracturing", "dtp.ui.page_frac:render"),
    ("ccus", "5 · CCUS & CO2 utilisation", "dtp.ui.page_ccus:render"),
    ("ai", "6 · Advanced AI lab", "dtp.ui.page_ai:render"),
    ("hub", "7 · Engineering knowledge hub", "dtp.ui.page_hub:render"),
    ("gov", "8 · Governance & multi-asset", "dtp.ui.page_gov:render"),
]
