"""Artificial-lift toolbox: selection + liquid loading, ESP, SRP, gas lift, lift knowledge calculators."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..core.status import Result, Status
from .common import BLUE, GRAY, GREEN, ORANGE, PALETTE, RED


def _demo_switch(ctx, kind, label, key):
    has = ctx.has(kind)
    use = ctx.st.toggle(f"Use synthetic demo data ({label})", value=not has, key=key, help="Your uploaded data is used automatically when loaded.") if not has else False
    return has, use


# ============================================================================ selection
def _tab_selection(ctx):
    st, go = ctx.st, ctx.go
    from ..lift import selection as S
    ctx.section_intro("Screen lift methods for a well and check **liquid loading** of your gas wells (Turner/Coleman critical rate vs actual rate).",
                      "Inputs below; well_tests for loading.", "Method scores with exclusion reasons; per-test margin q / q_critical.")
    c = st.columns(5)
    q = c[0].number_input("Liquid rate m3/d", 1.0, 5000.0, 150.0)
    d = c[1].number_input("Pump depth m", 100.0, 6000.0, 2200.0)
    g = c[2].number_input("GOR Sm3/m3", 0.0, 5000.0, 120.0)
    sand = c[3].slider("Sand 1-5", 1, 5, 2)
    dev = c[4].slider("Deviation 1-5", 1, 5, 2)
    tab = S.screen(q, d, g, sand, dev)
    ctx.table(tab)
    ok = tab[tab.score > 0] if "score" in tab else tab
    if len(ok):
        fig = go.Figure(go.Bar(x=ok.iloc[:, 0] if ok.columns[0] != "score" else ok.index, y=ok["score"], marker_color=BLUE))
        fig.update_layout(title="Method score (0-1)")
        ctx.plot(fig, 300, key="sel_bar")
    st.subheader("Liquid loading on your gas wells")
    wt = ctx.canon("well_tests")
    if wt is None:
        st.info("Load well tests to run the liquid-loading check.")
        return
    ctx.assume_banner(["tubing_id_in", "gas_sg"])
    adj = st.slider("Turner adjustment factor (1.0 Turner, 1.2 Coleman-like)", 0.8, 1.5, 1.2, key="ll_adj")
    ll = ctx.memo(("ll", len(wt), adj, ctx.cfg.gas_sg), lambda: S.liquid_loading(wt, ctx.cfg, 40.0, adj))
    last = ll.sort_values("date").groupby("well").tail(1)
    ctx.table(last[["well", "date", "whp_bara", "gas_sm3d", "q_crit_sm3d", "margin", "loading_risk", "liquid"]])
    fig = go.Figure()
    for i, w in enumerate(sorted(ll.well.unique())):
        g_ = ll[ll.well == w]
        fig.add_trace(go.Scatter(x=g_.date, y=g_.margin, mode="lines+markers", name=w, marker=dict(size=4), line=dict(color=PALETTE[i % 10], width=1)))
    fig.add_hline(y=1, line_dash="dash", line_color=RED, annotation_text="critical")
    fig.update_layout(title="q / q_critical (below 1 = liquid-loading risk)", yaxis_title="margin", yaxis_type="log")
    ctx.plot(fig, 380, key="ll_fig")
    n_below = int((last.margin < 1).sum())
    st.caption(f"{n_below} of {len(last)} wells below critical at the last test (wellhead conditions, 40 °C assumed). Evaluated at the wellhead - the conservative point; "
               "tubing ID is a configuration assumption unless you set it per well.")


# ============================================================================ ESP
def _esp_data(ctx):
    from ..lift import esp
    ds = ctx.canon("esp_ts")
    if ds is not None:
        return ds.set_index("time") if "time" in ds.columns else ds, None, "uploaded"
    mode = ctx.st.selectbox("Demo failure mode", ["motor", "gas", "scale"], key="esp_mode")
    raw, ref, truth = ctx.memo(("espsim", mode), lambda: esp.simulate_esp_timeseries(mode=mode))
    return raw, truth, "demo"


def _tab_esp(ctx):
    st, go = ctx.st, ctx.go
    from ..lift import esp, esp_extra as X
    ctx.section_intro("ESP surveillance, health, run-life, setpoint optimisation and gas handling.",
                      "esp_ts (hourly time series), esp_fleet (run-life table) - or demo data.", "Alarms with lead time, diagnostic hypotheses, survival model, frequency scenarios.")
    sub = st.tabs(["Pump & performance map", "Surveillance (PCA)", "Diagnostics", "Run-life survival", "Frequency optimisation", "Gas handling"])
    with sub[0]:
        c = st.columns(4)
        s = esp.ESPSystem(p_res=c[0].number_input("Pr bara", 20.0, 800.0, 250.0), pi_index=c[1].number_input("PI m3/d/bar", 0.1, 50.0, 4.0),
                          pump_depth=c[2].number_input("Pump depth m TVD", 300.0, 5000.0, 2500.0), stages=int(c[3].number_input("Stages", 20, 600, 270)),
                          p_wh=c[0].number_input("WHP bara", 1.0, 100.0, 15.0), motor_kw=c[1].number_input("Motor kW", 20.0, 700.0, 180.0))
        st.session_state["_esp_sys"] = s
        pm = esp.performance_map(s)
        fig = ctx.make_subplots(rows=1, cols=3, subplot_titles=("Head (m) vs q", "Efficiency", "Shaft kW"))
        for i, cv in enumerate(pm["curves"]):
            for k, y in enumerate((cv["head"], cv["eff"], cv["shaft_kw"]), 1):
                fig.add_trace(go.Scatter(x=cv["q"], y=y, name=f"{cv['freq']} Hz", legendgroup=str(i), showlegend=k == 1, line=dict(color=PALETTE[i % 10])), row=1, col=k)
        fig.add_trace(go.Scatter(x=pm["system"]["q"], y=pm["system"]["head"], name="System", line=dict(color="black", dash="dash")), row=1, col=1)
        if pm["ops"]:
            fig.add_trace(go.Scatter(x=[o["q"] for o in pm["ops"]], y=[o["head"] for o in pm["ops"]], mode="markers", name="Operating pts", marker=dict(size=9, color="black")), row=1, col=1)
        ctx.plot(fig, 400, key="esp_map")
        op = s.operating_point(float(st.slider("Frequency Hz", 30.0, 70.0, 50.0, 0.5, key="esp_f")))
        if op:
            ctx.metrics([("Rate m3/d", f"{op['q']:.0f}"), ("Intake bara", f"{op['p_intake']:.1f}"), ("Motor load", f"{op['load']:.0%}"), ("Thrust ratio", f"{op['thrust_ratio']:.2f}"), ("kW", f"{op['elec_kw']:.0f}")])
        else:
            st.warning("Pump cannot lift at this frequency.")
        st.caption("Curve coefficients are generic placeholders - load the vendor curve in the *Pump curve fit* tool of the knowledge hub for real work. UNVALIDATED.")
    raw, truth, src = _esp_data(ctx)
    if raw is None or len(raw) < 300:
        for t in sub[1:5]:
            t.info("Needs an ESP time series (>= ~300 hourly rows).")
    else:
        qc = ctx.memo(("espqc", src, len(raw), float(raw.iloc[:, 0].sum()) if raw.shape[1] else 0), lambda: esp.qc_pipeline(raw))
        clean, steady = qc.clean, pd.Series(qc.steady, index=qc.clean.index)
        with sub[1]:
            X_ = X.make_features(clean)
            n = len(X_)
            ntr = st.slider("Healthy training window (days)", 10, max(11, n // 24 // 2), min(30, n // 24 // 3), key="pca_tr")
            ncal = min(20 * 24, n // 6)
            tr, ca = X_.iloc[:ntr * 24][steady.iloc[:ntr * 24]], X_.iloc[ntr * 24:ntr * 24 + ncal][steady.iloc[ntr * 24:ntr * 24 + ncal]]
            if len(tr) < 100 or len(ca) < 50:
                st.warning("Not enough steady-state hours in the healthy windows.")
            else:
                mon = X.PCAMonitor().fit(tr, ca)
                sc = mon.score(X_)
                al = mon.alarms(sc, steady)
                fig = ctx.make_subplots(rows=2, cols=1, shared_xaxes=True, subplot_titles=("Hotelling T2", "SPE"))
                fig.add_trace(go.Scatter(x=sc.index, y=sc["T2"], line=dict(color=BLUE, width=1), name="T2"), row=1, col=1)
                fig.add_trace(go.Scatter(x=sc.index, y=sc["SPE"], line=dict(color=ORANGE, width=1), name="SPE"), row=2, col=1)
                fig.add_hline(y=mon.t2_lim, line_dash="dash", line_color=RED, row=1, col=1)
                fig.add_hline(y=mon.spe_lim, line_dash="dash", line_color=RED, row=2, col=1)
                if al.any():
                    t0 = al.idxmax()
                    fig.add_vline(x=t0, line_color=RED)
                ctx.plot(fig, 420, key="pca_fig")
                if al.any():
                    msg = f"First persistent alarm: **{al.idxmax():%Y-%m-%d %H:%M}**"
                    if truth:
                        msg += f" - {(truth['fail_idx'] - int(np.argmax(al.values))) / 24:.1f} days before the simulated failure."
                    st.success(msg)
                    t0 = np.argmax(al.values)
                    st.bar_chart(mon.contributions(X_.iloc[max(0, t0 - 48):t0 + 48]).rename("contribution %"))
                else:
                    st.info("No persistent alarm.")
                st.caption("Thresholds from held-out healthy data; alarm = 18 of 24 steady hours outside limits. UNVALIDATED - tune on your own failures.")
        with sub[2]:
            r = X.diagnose(clean, st.session_state.get("_esp_sys", esp.ESPSystem()))
            ctx.status(r)
            if r.value:
                st.metric("Health score (0-100)", f"{r.value['score']:.0f}")
                ctx.table(r.value["table"] if len(r.value["table"]) else pd.DataFrame({"finding": ["No rule triggered"]}))
                ctx.table(pd.Series(r.value["deltas"]).rename("last 7 d vs previous 30 d").to_frame().T)
            wr = X.wear_track(clean, st.session_state.get("_esp_sys", esp.ESPSystem()))
            if len(wr):
                f = go.Figure(go.Scatter(x=wr.time, y=wr.wear, mode="lines+markers"))
                f.update_layout(title="Fitted head multiplier ('wear') per week", yaxis_title="1.0 = new")
                ctx.plot(f, 280, key="wear_fig")
    with sub[3]:
        fleet = ctx.canon("esp_fleet")
        if fleet is None:
            fleet = esp.demo_fleet(300)
            st.caption("Demo fleet (synthetic).")
        cov = [c for c in ["gvf", "water_cut", "freq_c", "starts"] if c in fleet.columns]
        res = X.fit_weibull(fleet, "run_days", "failed", cov)
        ctx.status(res)
        if res.value:
            ctx.table(res.value["table"].reset_index())
            km = X.kaplan_meier(fleet.run_days.values, fleet.failed.values)
            f = go.Figure(go.Scatter(x=km.t, y=km.S, line_shape="hv", name="Kaplan-Meier"))
            f.update_layout(title="Fleet survival", xaxis_title="run days", yaxis_title="S(t)")
            ctx.plot(f, 300, key="km")
            row = pd.DataFrame([{c: st.number_input(c, value=float(fleet[c].median()), key=f"sv_{c}") for c in cov}])
            pf = X.failure_probability(res, row, 0.0, 180.0)[0]
            st.metric("P(failure within 180 days) for this profile", f"{pf:.0%}")
    with sub[4]:
        s = st.session_state.get("_esp_sys", esp.ESPSystem())
        c = st.columns(4)
        eco = X.Economics(water_cut=c[0].slider("Water cut", 0.0, 0.95, 0.35), oil_value=c[1].number_input("Oil value $/m3", 0.0, 2000.0, 300.0),
                          water_cost=c[2].number_input("Water cost $/m3", 0.0, 50.0, 3.0), power_cost=c[3].number_input("Power $/kWh", 0.0, 1.0, 0.05))
        lim = X.Limits(p_intake_min=c[0].number_input("Min intake bara", 5.0, 300.0, 60.0), load_max=c[1].slider("Max motor load", 0.5, 1.0, 0.95))
        sw = X.frequency_sweep(s, eco, lim, 1.0)
        f = ctx.make_subplots(rows=1, cols=2, subplot_titles=("Rate m3/d", "Value $/d (feasible = solid)"))
        f.add_trace(go.Scatter(x=sw.freq, y=sw.q, line=dict(color=BLUE)), row=1, col=1)
        f.add_trace(go.Scatter(x=sw.freq, y=sw.value, mode="lines+markers", marker=dict(color=np.where(sw.feasible, GREEN, RED))), row=1, col=2)
        ctx.plot(f, 320, key="fsweep")
        o = X.optimise_frequency(s, eco, lim)
        ctx.status(o)
        if o.value["op"]:
            st.metric("Suggested setpoint scenario (Hz)", f"{o.value['freq']:.1f}", f"{o.value['value']:,.0f} $/d")
        ctx.table(sw)
    with sub[5]:
        c = st.columns(5)
        r = X.gas_handling(c[0].number_input("Intake bara", 5.0, 400.0, 60.0), c[1].number_input("T C", 20.0, 200.0, 90.0), c[2].number_input("Liquid m3/d", 1.0, 3000.0, 300.0),
                           c[3].slider("WC", 0.0, 0.95, 0.3), c[4].number_input("GOR Sm3/m3", 0.0, 3000.0, 120.0))
        ctx.metrics([("Free-gas fraction", f"{r['gvf']:.0%}"), ("Class", r["cls"].split(" (")[0]), ("Head multiplier", f"{r['head_multiplier']:.2f}"), ("Rs", f"{r['rs']:.0f}")])
        st.caption("Standing Rs/Bo + DAK Bg. UNVALIDATED; rule-of-thumb classes.")


# ============================================================================ SRP
def _tab_srp(ctx):
    st, go = ctx.st, ctx.go
    from ..lift import srp
    ctx.section_intro("Rod-pump card diagnosis (wave equation), design grid, POC, trend flags.", "srp_cards (position in, load lbf), srp_ts.", "Pump card + class, feasible designs, anomaly flags.")
    sub = st.tabs(["Dynamometer cards", "Design", "Pump-off control", "Trends"])
    with sub[0]:
        cards = ctx.canon("srp_cards")
        truth = None
        if cards is None:
            cards, truth = ctx.memo("srp_demo", lambda: srp.demo_cards(4))
            st.caption("Demo cards (synthetic). Units assumed inches / lbf.")
        cid = "card_id" if "card_id" in cards.columns else None
        keys = sorted(cards[cid].unique()) if cid else sorted(cards.well.unique())
        k = st.selectbox("Card", keys)
        c = cards[cards[cid] == k] if cid else cards[cards.well == k]
        d = st.columns(3)
        depth = d[0].number_input("Pump depth m", 300.0, 4000.0, float((truth or {}).get(k, {}).get("depth", 1800.0)))
        spm = d[1].number_input("SPM", 1.0, 15.0, float((truth or {}).get(k, {}).get("spm", 6.0)))
        sg = d[2].number_input("Fluid SG", 0.6, 1.2, 0.85)
        rs = srp.default_string(depth)
        res = srp.analyse_surface_card(c.position.values * srp.INCH, c.load.values * srp.LBF, spm, rs, sg)
        ctx.status(res)
        if res.value:
            v = res.value
            f = ctx.make_subplots(rows=1, cols=2, subplot_titles=("Surface card", "Pump card (wave equation)"))
            f.add_trace(go.Scatter(x=v["surface"][0], y=v["surface"][1] / 1e3, fill="toself", line=dict(color=BLUE)), row=1, col=1)
            f.add_trace(go.Scatter(x=v["pump"][0], y=v["pump"][1] / 1e3, fill="toself", line=dict(color=ORANGE)), row=1, col=2)
            f.update_xaxes(title_text="position m"); f.update_yaxes(title_text="load kN", col=1)
            ctx.plot(f, 360, key="card")
            st.success(f"Class: **{v.get('rule_class', v.get('label', '?'))}**" + (f" (truth: {truth[k]['kind']})" if truth and k in truth else ""))
            st.json({kk: (vv if not hasattr(vv, 'tolist') else None) for kk, vv in v.items() if isinstance(vv, (str, float, int))})
    with sub[1]:
        c = st.columns(4)
        x = srp.SRPInputs(pump_depth_m=c[0].number_input("Pump depth m", 300.0, 4000.0, 1800.0, key="sd"), sg_fluid=c[1].number_input("SG", 0.6, 1.2, 0.85, key="ssg"),
                          pip_bara=c[2].number_input("PIP bara", 1.0, 100.0, 15.0), whp_bara=c[3].number_input("WHP bara", 1.0, 50.0, 5.0))
        ipr = srp.IPR(c[0].number_input("Pr bara", 10.0, 500.0, 120.0), c[1].number_input("PI m3/d/bar", 0.05, 30.0, 1.5))
        tbl = ctx.memo(("srpd", str(x.__dict__), str(ipr.__dict__)), lambda: srp.design_table(x, ipr))
        obj = st.radio("Objective", ["max_rate", "min_energy"], horizontal=True)
        best = srp.optimise_design(tbl, obj)
        st.write(f"{int(tbl.feasible.sum())} of {len(tbl)} combinations feasible.")
        ctx.table(best[["dp_in", "stroke_in", "spm", "q_prod_m3d", "fill_est", "PPRL_kN", "MPRL_kN", "torque_kNm", "rod_pct", "kWh_per_m3"]] if len(best) else tbl.head())
        f = go.Figure(go.Scatter(x=tbl.PPRL_kN, y=tbl.q_prod_m3d, mode="markers", marker=dict(color=np.where(tbl.feasible, GREEN, GRAY), size=5)))
        f.update_layout(title="Rate vs PPRL (green = feasible)", xaxis_title="PPRL kN", yaxis_title="m3/d")
        ctx.plot(f, 320, key="srp_sc")
        st.caption("Mills geometry loads, API-style screening - UNVALIDATED; check against the unit's rating and rod data.")
    with sub[2]:
        c = st.columns(4)
        q_in = c[0].number_input("Inflow m3/d", 1.0, 500.0, 20.0)
        q_p = c[1].number_input("Pump capacity m3/d", 1.0, 1000.0, 40.0)
        thr = c[2].slider("Fillage threshold", 0.3, 0.95, 0.7)
        idle = c[3].number_input("Idle min", 5.0, 600.0, 30.0)
        poc = srp.poc_simulation(q_in, q_p, thr, idle)
        st.json({k: (round(v, 3) if isinstance(v, float) else v) for k, v in poc.items() if isinstance(v, (int, float))} if isinstance(poc, dict) else {})
    with sub[3]:
        ts = ctx.canon("srp_ts")
        if ts is None:
            ts = srp.demo_ts()
            st.caption("Demo trends (synthetic).")
        w = st.selectbox("Well", sorted(ts.well.unique()), key="srp_w")
        g = ts[ts.well == w].sort_values("date")
        fl = srp.trend_flags(g.set_index("date")) if "date" in g else srp.trend_flags(g)
        cols = [c for c in ("fillage", "pprl", "mprl", "power_kw") if c in g.columns]
        f = ctx.make_subplots(rows=len(cols), cols=1, shared_xaxes=True, subplot_titles=cols)
        for i, c_ in enumerate(cols, 1):
            f.add_trace(go.Scatter(x=g.date, y=g[c_], line=dict(color=BLUE)), row=i, col=1)
        ctx.plot(f, 140 * len(cols) + 80, key="srp_tr")
        ctx.table(fl.reset_index().tail(15) if len(fl) else pd.DataFrame())


# ============================================================================ gas lift
def _tab_gl(ctx):
    st, go = ctx.st, ctx.go
    from ..lift import gaslift as G
    ctx.section_intro("Gas-lift performance curves, optimal allocation of limited lift gas, valve spacing, orifice sizing and heading detection.",
                      "gaslift_ts or the demo field.", "GLPC with optimum and bootstrap range, allocation vs equal split.")
    sub = st.tabs(["Performance curves & allocation", "Valve spacing & orifice", "Instability"])
    with sub[0]:
        gl = ctx.canon("gaslift_ts")
        if gl is not None and "qliq" in gl.columns:
            curves, src = {}, "uploaded"
            for w, g in gl.dropna(subset=["qinj", "qliq"]).groupby("well"):
                if len(g) >= 6:
                    curves[w] = G.fit_glpc(g.qinj.values, g.qliq.values)
        else:
            field = ctx.memo("gl_field", lambda: G.demo_field(5))
            curves = ctx.memo("gl_curves", lambda: {w: G.fit_glpc(**{k: v for k, v in zip(("q_inj", "q_liq"), G.glpc(p).values.T)}) for w, p in field.items()})
            st.caption("Demo field (synthetic) - physics GLPC from the drift-flux traverse.")
        if not curves:
            st.info("No well has >= 6 injection/rate points.")
        else:
            f = go.Figure()
            for i, (w, c) in enumerate(curves.items()):
                x = np.linspace(0, 2 * c["x_opt"], 40)
                f.add_trace(go.Scatter(x=x, y=c["a"] + c["b"] * x / 1e5 - c["c"] * (x / 1e5) ** 2, name=w, line=dict(color=PALETTE[i % 10])))
                f.add_trace(go.Scatter(x=[c["x_opt"]], y=[c["q_opt"]], mode="markers", marker=dict(size=9, color=PALETTE[i % 10]), showlegend=False))
            f.update_layout(xaxis_title="Injection Sm3/d", yaxis_title="Liquid m3/d")
            ctx.plot(f, 380, key="glpc")
            tot = st.number_input("Total available lift gas Sm3/d", 1e4, 1e8, float(sum(c["x_opt"] for c in curves.values()) * 0.6), step=1e4)
            al = G.allocate({w: c for w, c in curves.items()}, tot)
            ctx.status(al)
            ctx.table(al.value["table"])
    with sub[1]:
        c = st.columns(4)
        vs = G.valve_spacing(c[0].number_input("Kick-off pressure bara", 20.0, 250.0, 80.0), c[1].number_input("WHP bara", 1.0, 80.0, 15.0), c[2].number_input("Kill gradient bar/m", 0.05, 0.15, 0.10),
                             c[3].number_input("Flowing gradient bar/m", 0.01, 0.10, 0.05))
        ctx.table(vs)
        c = st.columns(3)
        q = G.orifice_sm3d(c[0].number_input("Port mm", 2.0, 30.0, 6.4), c[1].number_input("Upstream bara", 5.0, 250.0, 80.0), c[2].number_input("Downstream bara", 1.0, 200.0, 50.0))
        st.metric("Gas through port (Sm3/d)", f"{q:,.0f}")
    with sub[2]:
        gl = ctx.canon("gaslift_ts")
        p = None
        if gl is not None and "tubing_p" in gl.columns and gl.tubing_p.notna().sum() > 60:
            p = gl.sort_values("date").tubing_p.dropna().values
        else:
            t = np.arange(600)
            p = 30 + 2.5 * np.sin(2 * np.pi * t / 40) + np.random.default_rng(0).normal(0, 0.3, 600)
            st.caption("Synthetic 1-min tubing pressure with 40-min heading.")
        r = G.instability(p)
        ctx.metrics([("Period min", f"{r['period_min']:.0f}"), ("Rel. amplitude", f"{r['rel_amplitude']:.1%}"), ("Heading", "YES" if r["heading"] else "no")])


# ============================================================================ knowledge calculators
def _tab_calc(ctx):
    st = ctx.st
    from ..gascond.pvt import GasPVT
    ctx.section_intro("Quick artificial-lift calculators.", "typed values", "numbers with the formula named")
    c = st.columns(3)
    with c[0]:
        st.markdown("**Pump hydraulic power**")
        q, h, rho = st.number_input("q m3/d", 1.0, 5000.0, 300.0, key="cq"), st.number_input("Head m", 1.0, 6000.0, 1800.0, key="ch"), st.number_input("rho kg/m3", 600.0, 1200.0, 850.0, key="cr")
        st.metric("kW", f"{q / 86400 * rho * 9.81 * h / 1e3:.1f}")
    with c[1]:
        st.markdown("**Fluid gradient → pressure**")
        g = st.number_input("rho kg/m3", 600.0, 1300.0, 850.0, key="gr") * 9.81 / 1e5
        dz = st.number_input("column m", 1.0, 5000.0, 1000.0)
        st.metric("bar", f"{g * dz:.1f}", f"{g:.4f} bar/m")
    with c[2]:
        st.markdown("**Turner critical rate**")
        from ..lift.selection import critical_rate_sm3d
        p, d = st.number_input("P bara", 2.0, 400.0, 40.0), st.number_input("ID in", 1.0, 8.0, 2.992)
        st.metric("Sm3/d", f"{critical_rate_sm3d(p, 40.0, d, GasPVT(ctx.cfg.gas_sg)):,.0f}")


def render(ctx):
    st = ctx.st
    st.header("2 · Artificial-lift toolbox")
    tabs = st.tabs(["Selection & liquid loading", "ESP", "SRP (rod pump)", "Gas lift", "Calculators"])
    for t, fn in zip(tabs, (_tab_selection, _tab_esp, _tab_srp, _tab_gl, _tab_calc)):
        with t:
            try:
                fn(ctx)
            except Exception as e:                                     # noqa: BLE001
                st.error(f"FAIL - {type(e).__name__}: {e}")
