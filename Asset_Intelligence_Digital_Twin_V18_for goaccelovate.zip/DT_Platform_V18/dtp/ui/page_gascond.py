"""Gas-condensate engineering page (works directly on the well_tests dataset)."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..core.status import Result, Status
from ..gascond import banking, deliverability as D, dewpoint, forecast as F, water
from ..gascond.pvt import GasPVT
from .common import BLUE, GRAY, ORANGE, PALETTE, RED


def render(ctx):
    st, go = ctx.st, ctx.go
    st.header("3 · Gas-condensate engineering")
    ctx.section_intro("Well-by-well engineering on your **well tests**: field overview, PVT, deliverability, condensate banking, water, forecast.",
                      "well_tests (well, date, WHP, gas, condensate, water, salinity); asset configuration (gas gravity, CO2 %, depth, tubing, Pr).",
                      "Trends, back-pressure fits, banking traffic lights, forecasts with ranges, ranked well hypotheses - each with a visible status.")
    wt = ctx.need("well_tests", "Needs the well-test table.")
    if wt is None:
        return
    cfg = ctx.cfg
    ctx.assume_banner(["gas_sg", "t_res_c", "p_res_init_bara", "p_res_now_bara", "datum_tvd_m", "tubing_id_in"])
    wells = sorted(wt.well.unique())
    tabs = st.tabs(["Field overview", "PVT & dew point", "Deliverability", "Condensate banking", "Water & salinity", "Forecast & backtest", "Well ranking"])

    with tabs[0]:
        ctx.metrics([("Wells", str(len(wells))), ("Tests", f"{len(wt):,}"), ("Period", f"{wt.date.min().year}-{wt.date.max().year}"),
                     ("Last gas (all wells, latest test each)", f"{wt.sort_values('date').groupby('well').gas_sm3d.last().sum()/1e6:.2f} MMSm3/d"),
                     ("CO2 in that gas @ %.1f %%" % cfg.co2_pct, f"{wt.sort_values('date').groupby('well').gas_sm3d.last().sum()*cfg.co2_pct/100*1.872/1e3:.0f} t/d")])
        st.caption("Latest-test sum is NOT allocated production: tests are sparse snapshots.")
        sel = st.multiselect("Wells", wells, default=wells, key="gc_wells")
        fig = ctx.make_subplots(rows=2, cols=2, shared_xaxes=True, subplot_titles=("WHP (bara)", "Gas rate (MMSm3/d)", "CGR (m3/MMSm3)", "WGR (m3/MMSm3)"))
        for i, w in enumerate(sel):
            g = wt[wt.well == w]
            c = PALETTE[i % 10]
            for (r, k), col, sc in (((1, 1), "whp_bara", 1), ((1, 2), "gas_sm3d", 1e6), ((2, 1), "cgr_m3_mmsm3", 1), ((2, 2), "wgr_m3_mmsm3", 1)):
                fig.add_trace(go.Scatter(x=g.date, y=g[col] / sc, mode="lines+markers", name=w, legendgroup=w, showlegend=(r, k) == (1, 1),
                                         marker=dict(size=4), line=dict(color=c, width=1)), row=r, col=k)
        fig.update_yaxes(range=[0, None], row=2, col=1)
        ctx.plot(fig, 560, key="gc_ov")
        sc = go.Figure()
        for i, w in enumerate(sel):
            g = wt[wt.well == w]
            sc.add_trace(go.Scatter(x=g.whp_bara, y=g.cgr_m3_mmsm3, mode="markers", name=w, marker=dict(color=PALETTE[i % 10], size=6)))
        sc.update_layout(title="CGR vs WHP (condensate drop-out signal)", xaxis_title="WHP bara", yaxis_title="CGR m3/MMSm3")
        ctx.plot(sc, 360, key="gc_cgr")
        summ = wt.sort_values("date").groupby("well").agg(first=("date", "min"), last=("date", "max"), n_tests=("date", "size"), whp_last=("whp_bara", "last"),
                                                           gas_last=("gas_sm3d", "last"), cgr_last=("cgr_m3_mmsm3", "last"), wgr_last=("wgr_m3_mmsm3", "last"))
        ctx.table(summ.reset_index())
        cov = wt.assign(year=wt.date.dt.year).pivot_table(index="well", columns="year", values="gas_sm3d", aggfunc="count").fillna(0)
        hm = go.Figure(go.Heatmap(z=cov.values, x=cov.columns, y=cov.index, colorscale="Blues", showscale=False))
        hm.update_layout(title="Test coverage (tests per well-year)")
        ctx.plot(hm, 300, key="gc_cov")

    pvt = GasPVT.from_cfg(cfg)
    with tabs[1]:
        t = st.number_input("Temperature (C)", value=float(cfg.t_res_c), key="gc_pvt_t")
        p = np.linspace(5, 400, 80)
        fig = ctx.make_subplots(rows=1, cols=4, subplot_titles=("Z", "Viscosity cP", "Bg rm3/Sm3", "Density kg/m3"))
        for k, (y, c) in enumerate([(pvt.z(p, t), BLUE), (pvt.mu(p, t), ORANGE), (pvt.bg(p, t), GRAY), (pvt.rho(p, t), RED)], 1):
            fig.add_trace(go.Scatter(x=p, y=y, line=dict(color=c), showlegend=False), row=1, col=k)
        fig.update_xaxes(title_text="bara")
        ctx.plot(fig, 330, key="gc_pvt")
        st.caption(f"Sutton pseudo-criticals + Wichert-Aziz for CO2 ({cfg.co2_pct}%), DAK Z, Lee-Gonzalez-Eakin viscosity. Screening-grade; replace by lab EOS.")
        lab = {}
        with st.expander("Lab dew-point override (bara)"):
            for w in wells:
                v = st.number_input(w, value=0.0, key=f"gc_lab_{w}")
                if v > 0:
                    lab[w] = v
        dres = dewpoint.estimate(wt, cfg, lab)
        ctx.status(dres)
        ctx.table(dres.value.round(1))
        ctx.download_df("Download dew-point table", dres.value, "dewpoint.csv", key="gc_dl_dew")
    pd_map = dict(zip(dres.value.well, dres.value.pd_used_bara))

    with tabs[2]:
        mode = st.radio("Reservoir pressure source", ["pz", "const", "implied"], index=2, horizontal=True, key="gc_prmode",
                        format_func=lambda m: {"pz": "p/z-style (from configured initial & current Pr)", "const": "constant", "implied": "implied by each test"}[m])
        pr_const = st.number_input("Constant Pr (bara)", value=float(cfg.p_res_now_bara), key="gc_prconst") if mode == "const" else None
        res = ctx.memo(("deliv", len(wt), mode, pr_const, cfg.p_res_now_bara, cfg.p_res_init_bara, cfg.gas_sg, cfg.co2_pct, cfg.datum_tvd_m, cfg.tubing_id_in),
                       lambda: D.analyse(wt, cfg, pr_mode=mode, pr_const=pr_const))
        ctx.status(res)
        if res.value is not None and len(res.value):
            df = res.value
            ctx.table(df.round(3))
            ctx.download_df("Download deliverability", df, "deliverability.csv", key="gc_dl_del")
            ok = df[df.ok.fillna(False)] if "ok" in df else df
            if len(ok) and "aof_mmsm3d" in ok:
                fig = go.Figure()
                for i, w in enumerate(sorted(ok.well.unique())):
                    o = ok[ok.well == w]
                    fig.add_trace(go.Scatter(x=o.date, y=o.aof_mmsm3d, mode="lines+markers", name=w, line=dict(color=PALETTE[i % 10]),
                                             error_y=dict(type="data", symmetric=False, array=(o.aof_p10 - o.aof_mmsm3d).clip(lower=0), arrayminus=(o.aof_mmsm3d - o.aof_p90).clip(lower=0))))
                fig.update_layout(title="AOF per valid multi-rate test (MMSm3/d, bootstrap range)", yaxis_title="MMSm3/d")
                ctx.plot(fig, 360, key="gc_aof")
        st.markdown("**Nodal: rate vs wellhead pressure** (benefit of lowering WHP / compression)")
        w = st.selectbox("Well", wells, key="gc_nodal_w")
        r = D.fit_whp_rate(wt[wt.well == w])
        if r["ok"]:
            st.caption(f"Empirical WHP trend: WHP = {r['a']:.1f} + {r['b']:.1f}·q (q in MMSm3/d, R² {r['r2']:.2f}); choke slope dq/dWHP = {r['dq_dwhp_choke']:.3f} MMSm3/d per bar.")
        else:
            st.info("Fewer than 4 test dates in the last 8 years for this well.")

    with tabs[3]:
        bres = ctx.memo(("bank", len(wt), tuple(sorted(pd_map.items())), cfg.p_res_now_bara),
                        lambda: banking.screen(wt, cfg, pd_map))
        ctx.status(bres)
        icon = {"green": "🟢", "amber": "🟠", "red": "🔴", "grey": "⚪"}
        b = bres.value.copy()
        b.insert(1, "", b.light.map(icon))
        ctx.table(b.drop(columns="light"))
        ctx.download_df("Download banking screen", bres.value, "banking.csv", key="gc_dl_bank")

    with tabs[4]:
        wres = water.analyse(wt, cfg)
        ctx.status(wres)
        ctx.table(wres.value.round(3))
        fig = go.Figure()
        for i, w in enumerate(wells):
            g = wt[wt.well == w]
            fig.add_trace(go.Scatter(x=g.date, y=g.salinity_mgl / 1000, mode="markers", name=w, marker=dict(color=PALETTE[i % 10])))
        fig.update_layout(title="Salinity (g/L)", yaxis_type="log")
        ctx.plot(fig, 340, key="gc_sal")

    with tabs[5]:
        yrs = st.slider("Horizon (years)", 3, 30, 15, key="gc_yrs")
        qe = st.number_input("Economic limit (Sm3/d per well)", value=100000.0, key="gc_qe")
        ff = ctx.memo(("ff", len(wt), yrs, qe), lambda: F.field_forecast(wt, cfg, yrs, q_econ=qe))
        if ff.empty:
            st.error("🔴 FAIL - no well has enough test dates for a forecast.")
        else:
            tot = ff.groupby("date")[["gas_p10", "gas_p50", "gas_p90"]].sum() / 1e6
            fig = go.Figure()
            hist = wt.groupby(["date", "well"]).gas_sm3d.mean().unstack().interpolate().ffill().sum(axis=1) / 1e6
            fig.add_trace(go.Scatter(x=tot.index, y=tot.gas_p90, line=dict(width=0), showlegend=False))
            fig.add_trace(go.Scatter(x=tot.index, y=tot.gas_p10, fill="tonexty", fillcolor="rgba(42,111,219,0.15)", line=dict(width=0), name="P10-P90 (low-high)"))
            fig.add_trace(go.Scatter(x=tot.index, y=tot.gas_p50, line=dict(color=BLUE, width=3), name="P50"))
            fig.add_trace(go.Scatter(x=hist.index, y=hist.values, line=dict(color=GRAY), name="tests (interpolated, sum of wells)"))
            fig.update_layout(title="Field gas forecast, MMSm3/d (sum of per-well forecasts; ranges NOT additive across wells)", yaxis_title="MMSm3/d")
            ctx.plot(fig, 420, key="gc_ff")
            ctx.download_df("Download forecast (monthly, per well)", ff, "field_forecast.csv", key="gc_dl_ff")
            st.session_state["field_forecast"] = ff
        bt = F.backtest(wt)
        ctx.status(bt)
        if bt.value is not None:
            ctx.table(bt.value.round(3))

    with tabs[6]:
        rows = []
        bl = bres.value.set_index("well")
        wr = wres.value.set_index("well")
        for w in wells:
            g = wt[wt.well == w].sort_values("date")
            r = D.fit_whp_rate(g)
            hyp = []
            if bl.loc[w, "light"] in ("red", "amber"):
                hyp.append("banking study (PTA / lab PVT)")
            if wr.loc[w, "water_zero_recent"]:
                hyp.append("confirm water measurement")
            if len(g) and g.date.max() < wt.date.max() - pd.Timedelta(days=730):
                hyp.append("re-test (no test for >2 y)")
            if np.isfinite(r.get("dq_dwhp_choke", np.nan)) and r["dq_dwhp_choke"] < -0.005:
                hyp.append("compression / lower WHP gives rate")
            rows.append(dict(well=w, banking=bl.loc[w, "light"], last_test=g.date.max().date(), whp_last=g.whp_bara.iloc[-1], hypotheses="; ".join(hyp) or "-"))
        st.caption("Hypotheses for engineering review - not recommendations.")
        ctx.table(pd.DataFrame(rows))
