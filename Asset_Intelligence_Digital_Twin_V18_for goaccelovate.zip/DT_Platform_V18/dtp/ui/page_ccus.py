"""CCUS page: CO2 quantity from gas production x CO2 % (user input), capture, transport, utilisation beyond EOR, storage, MRV, economics."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..ccus import accounting, capture, co2budget as B, economics as E, transport as T
from ..ccus.stream import CO2Stream
from .common import BLUE, GRAY, GREEN, ORANGE, RED


def _stream(ctx) -> CO2Stream | None:
    st, cfg = ctx.st, ctx.cfg
    wt = ctx.canon("well_tests")
    c = st.columns(5)
    pct = c[0].number_input("CO2 in the gas (mol %)", 0.0, 100.0, float(cfg.co2_pct), 0.1, key="ccus_pct",
                            help="Your value (e.g. 2 %). Applied to all wells unless you override below.")
    if abs(pct - cfg.co2_pct) > 1e-9:
        cfg.co2_pct = pct
        cfg.mark("co2_pct")
    life = c[1].number_input("Lifetime (years)", 1, 40, 15, key="ccus_life")
    pin = c[2].number_input("Plant inlet pressure (bara)", 1.0, 400.0, 30.0, key="ccus_pin")
    tin = c[3].number_input("Temperature (C)", 0.0, 150.0, 40.0, key="ccus_tin")
    h2s = c[4].number_input("H2S (ppm)", 0.0, 1e5, float(cfg.h2s_ppm), key="ccus_h2s")
    src_opts = ["Latest well tests", "Gas-condensate forecast", "Manual gas rate"] if wt is not None else ["Manual gas rate"]
    src = st.radio("Gas rate source", src_opts, horizontal=True, key="ccus_src")
    cap_t = st.slider("Share of contained CO2 you want to capture (%)", 10, 100, 100, key="ccus_cap")
    if src == "Manual gas rate":
        gas = st.number_input("Gas rate (MMSm3/d)", 0.0, 100.0, 1.0, 0.1, key="ccus_gas") * 1e6
        return B.build_stream(gas, pct, pin, tin, h2s, life, capture_target_pct=cap_t, cfg=cfg)
    ntest = st.slider("Average the last N test days per well", 1, 5, 1, key="ccus_n")
    rates = B.latest_rates(wt, ntest)
    ov = {}
    with st.expander("Per-well CO2 % override (measured wells)"):
        for w in rates.well:
            v = st.number_input(w, 0.0, 100.0, pct, 0.1, key=f"ccus_ov_{w}")
            if abs(v - pct) > 1e-9:
                ov[w] = v
    tab = B.per_well_table(rates, pct, ov, B.fit_decline(wt), cfg)
    profile = None
    if src == "Gas-condensate forecast":
        try:
            prof = B.field_forecast_profile(wt, {**ov}, pct, int(life), cfg)
            profile = prof[["year", "t_per_year"]] if isinstance(prof, pd.DataFrame) and "t_per_year" in prof else None
        except Exception:                                       # noqa: BLE001
            profile = None
        if profile is None:
            st.warning("Forecast not available - using per-well exponential decline fitted on the tests.")
    stream = B.stream_from_table(tab, pin, tin, h2s, life, cap_t, "forecast" if profile is not None else "well_tests", cfg, profile)
    st.session_state["ccus_tab"] = tab
    return stream


def render(ctx):
    st, go = ctx.st, ctx.go
    st.header("5 · CCUS & CO2 utilisation")
    ctx.section_intro("Enter the **CO2 percentage** of your gas: the platform computes tonnes of CO2, then screens **capture, transport, utilisation (not only EOR), storage and MRV**.",
                      "well_tests gas rates (or a manual rate) x CO2 mol %; reservoir data from the asset configuration.",
                      "CO2 t/d, t/yr and lifetime; technology screening; ranked uses and a portfolio; storage capacity; economics and net CO2 avoided.")
    ctx.assume_banner(["co2_pct"], "(this is YOUR input, not a measurement)")
    stream = _stream(ctx)
    if stream is None or stream.t_per_day <= 0:
        st.warning("Enter a gas rate and CO2 % above.")
        return
    st.session_state["co2_stream"] = stream
    cap = capture.screen(stream.pressure_bara, stream.mol_frac, stream.t_per_day, stream.h2s_ppm)
    best = cap.value.iloc[0] if cap.value is not None else None
    ctx.metrics([("CO2 in gas", f"{stream.t_per_day:,.1f} t/d"), ("Per year", f"{stream.t_per_year/1e3:,.1f} kt/yr"), ("Lifetime", f"{stream.mt_total:.2f} Mt"),
                 ("CO2 Sm3/d", f"{stream.gas_sm3d*stream.mol_frac:,.0f}"), ("Partial pressure", f"{B.partial_pressure(stream.mol_frac, stream.pressure_bara):.2f} bar")])
    tabs = st.tabs(["CO2 inventory", "Capture", "Conditioning & transport", "Utilisation menu", "EOR / EGR", "Storage", "MRV", "Economics & accounting"])

    with tabs[0]:
        tab = st.session_state.get("ccus_tab")
        if tab is not None:
            ctx.table(tab[["well", "gas_sm3d", "co2_pct", "co2_sm3d", "co2_t_d", "co2_t_yr", "decline_per_yr", "decline_assumed"]].round(2))
            ctx.download_df("Download CO2 per well", tab, "co2_per_well.csv", key="ccus_dl_tab")
            u = B.uncertainty(tab, int(stream.lifetime_years), cfg=ctx.cfg)
            ctx.status(u)
            if isinstance(u.value, dict):
                st.json({k: (round(v, 3) if isinstance(v, float) else v) for k, v in u.value.items()})
        prof = stream.profile
        if prof is not None:
            f = go.Figure(go.Bar(x=prof.year, y=prof.t_per_year / 1e3, marker_color=BLUE))
            f.update_layout(title="CO2 contained in the gas per year (kt)", xaxis_title="year", yaxis_title="kt/yr")
            ctx.plot(f, 320, key="ccus_prof")
        wt = ctx.canon("well_tests")
        if wt is not None:
            h = B.history(wt, {}, ctx.cfg.co2_pct, ctx.cfg)
            if len(h):
                tot = h.groupby("date").co2_t_d.sum().cumsum() / 1e3
                f = go.Figure(go.Scatter(x=tot.index, y=tot.values, line=dict(color=ORANGE)))
                f.update_layout(title="CO2 produced to date (kt) - reconstructed from sparse tests x your CO2 %", yaxis_title="kt")
                ctx.plot(f, 300, key="ccus_hist")
        spec = st.number_input("Sales-gas CO2 spec (mol %)", 0.0, 10.0, 2.0, 0.1, key="ccus_spec")
        g = B.spec_gap(stream.mol_frac, spec, stream.gas_sm3d, 1.0, ctx.cfg)
        (st.warning if g["exceeds_spec"] else st.info)(g["msg"])
        ctx.metrics([("Must remove for spec", f"{g['must_remove_t_d']:,.1f} t/d"), ("Could capture", f"{g['can_capture_t_d']:,.1f} t/d"), ("Voluntary", f"{g['optional_t_d']:,.1f} t/d")])
        c = st.columns(2)
        fuel = c[0].number_input("Fuel gas (Sm3/d)", 0.0, 1e8, 0.0, key="ccus_fuel")
        flare = c[1].number_input("Flare (Sm3/d)", 0.0, 1e8, 0.0, key="ccus_flare")
        if fuel + flare > 0:
            ctx.table(B.extra_sources(fuel, flare))

    with tabs[1]:
        ctx.status(cap)
        if cap.value is not None:
            ctx.table(cap.value[["tech", "score", "fit", "s_pco2", "s_y", "s_flow", "s_h2s"] + [c for c in cap.value.columns if c in ("purity_pct", "recov")]].round(2))
            pick = st.selectbox("Technology for the balance", list(cap.value.tech), key="ccus_tech")
            row = cap.value[cap.value.tech == pick].iloc[0]
            bal = capture.balance(stream, row, cfg=ctx.cfg)
            ctx.status(bal)
            if bal.value:
                f = bal.value["full"]
                ctx.metrics([("Captured", f"{f['co2_t_d']:,.1f} t/d"), ("Process CO2", f"{f['process_co2_per_t']:.2f} t/t"), ("Energy penalty", f"{f['energy_penalty_pct']:.1f} % of gas"),
                             ("CAPEX (placeholder)", f"{f['capex_usd']/1e6:,.1f} M$")])
                st.session_state["ccus_bal"] = bal.value

    with tabs[2]:
        c = st.columns(4)
        pout = c[0].number_input("Delivery pressure (bara)", 80.0, 300.0, 150.0, key="ccus_pout")
        L = c[1].number_input("Pipeline length (km)", 0.1, 1000.0, 50.0, key="ccus_L")
        dn = c[2].number_input("Pipe diameter (in)", 1.0, 40.0, 6.0, key="ccus_dn")
        tg = c[3].number_input("Ground temp (C)", 0.0, 60.0, 25.0, key="ccus_tg")
        t_cap = stream.t_per_day * stream.capture_target_pct / 100
        comp = T.compression(t_cap, max(stream.pressure_bara * 0.4, 1.5), pout)
        ctx.status(comp)
        if comp.value:
            ctx.metrics([("Compression + pump power", f"{comp.value['kw']:,.0f} kW"), ("Specific energy", f"{comp.value['kwh_per_t']:.0f} kWh/t"), ("Stages", str(comp.value["stages"]))])
            ctx.table(comp.value["table"].round(2))
        pl = T.pipeline_dp(t_cap, dn, L, pout, tg)
        ctx.status(pl)
        if pl.value:
            f = go.Figure(go.Scatter(x=pl.value["profile"].km, y=pl.value["profile"].p_bara, line=dict(color=BLUE)))
            f.add_hline(y=pl.value["psat"], line_dash="dash", annotation_text="saturation")
            f.update_layout(title=f"Pipeline pressure, dP {pl.value['dp_bar']:.1f} bar", xaxis_title="km", yaxis_title="bara")
            ctx.plot(f, 320, key="ccus_pl")
        ctx.table(T.diameter_options(t_cap, L, pout, 90.0, tg).round(2))
        ctx.table(T.road_ship_cost(t_cap * 365.25, L).round(1))
        st.caption("Alternatives for small streams (10-100 t/d) are often road/rail liquid CO2; costs are placeholders.")

    from . import ccus_tabs_b as TB
    with tabs[3]:
        ctx.guard("utilisation", TB.render_utilisation, ctx, stream)
    with tabs[4]:
        ctx.guard("EOR/EGR", TB.render_eor_egr, ctx, stream)
    with tabs[5]:
        ctx.guard("storage", TB.render_storage, ctx, stream)
    with tabs[6]:
        ctx.guard("MRV", TB.render_mrv, ctx, stream)

    with tabs[7]:
        st.markdown("**Economics (all inputs are yours)**")
        c = st.columns(5)
        capex = c[0].number_input("CAPEX (M$)", 0.0, 5000.0, float((st.session_state.get("ccus_bal") or {}).get("full", {}).get("capex_usd", 2e7)) / 1e6 + 3.0, key="ccus_capex") * 1e6
        opex = c[1].number_input("Fixed OPEX (M$/yr)", 0.0, 500.0, capex * 0.05 / 1e6, key="ccus_opex") * 1e6
        var = c[2].number_input("Variable OPEX ($/t)", 0.0, 500.0, 5.0, key="ccus_var")
        rev = c[3].number_input("Product revenue ($/t)", -100.0, 1000.0, 0.0, key="ccus_rev")
        cp = c[4].number_input("Carbon price ($/t)", 0.0, 500.0, float(ctx.cfg.carbon_price_usd_per_t), key="ccus_cp")
        t = (stream.profile.t_per_year.values * stream.capture_target_pct / 100) if stream.profile is not None else np.full(int(stream.lifetime_years), stream.t_per_year)
        base = dict(capex=capex, opex_fixed_yr=opex, opex_var_per_t=var, revenue_per_t=rev, t_per_year=t, discount=ctx.cfg.discount_rate, carbon_price=cp)
        r = E.cashflow_npv(**base)
        be = E.breakeven_carbon_price(**{k: v for k, v in base.items() if k != "carbon_price"})
        ctx.metrics([("NPV", f"{r['npv']/1e6:,.1f} M$"), ("Levelised cost of CO2 captured", f"{r['lcoc']:,.0f} $/t"), ("Breakeven carbon price", f"{be:,.0f} $/t"), ("Payback year", str(r["payback_year"]))])
        torn = E.tornado(base)
        f = go.Figure()
        f.add_trace(go.Bar(y=torn.parameter, x=torn.npv_low / 1e6, orientation="h", name="-30 %"))
        f.add_trace(go.Bar(y=torn.parameter, x=torn.npv_high / 1e6, orientation="h", name="+30 %"))
        f.update_layout(barmode="overlay", title="NPV sensitivity (M$)")
        ctx.plot(f, 320, key="ccus_torn")
        mc = E.monte_carlo(base)
        st.caption(f"Monte-Carlo NPV: P10 {mc.P10/1e6:,.1f} / P50 {mc.P50/1e6:,.1f} / P90 {mc.P90/1e6:,.1f} M$; P(NPV>0) = {mc.prob_positive:.0%}")
        ctx.download_df("Download cash flow", r["cashflow"], "ccus_cashflow.csv", key="ccus_dl_cf")
        st.markdown("**Net CO2 balance**")
        cap_t = stream.t_per_year * stream.capture_target_pct / 100
        proc = float((st.session_state.get("ccus_bal") or {}).get("full", {}).get("process_co2_t_d", 0.0)) * 365.25
        use = st.selectbox("Where does the captured CO2 go?", ["permanent geological", "long-lived product (>100 y)", "medium (10-100 y)", "short-lived (<1 y, re-emits)"], key="ccus_use")
        leak = st.slider("Leakage (% of stored)", 0.0, 5.0, 0.5, 0.1, key="ccus_leak")
        acc = accounting.balance(stream.t_per_year, cap_t, proc, cap_t * 0.02, leak, [dict(name="main use", t=cap_t, permanence=use)])
        ctx.metrics([("Captured", f"{cap_t/1e3:,.1f} kt/yr"), ("Net avoided", f"{acc['net_avoided']/1e3:,.1f} kt/yr"), ("Credit value", f"{acc['net_avoided']*cp/1e6:,.1f} M$/yr")])
        f = go.Figure(go.Waterfall(x=acc["table"].item, y=acc["table"].t_co2 / 1e3, measure=["absolute"] + ["relative"] * (len(acc["table"]) - 1)))
        f.update_layout(title="CO2 waterfall (kt/yr)")
        ctx.plot(f, 360, key="ccus_wf")
        st.caption(acc["note"])
