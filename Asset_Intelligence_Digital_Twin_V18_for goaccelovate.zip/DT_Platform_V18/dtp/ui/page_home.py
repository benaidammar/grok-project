"""Data foundation: upload -> detect kind -> confirm mapping and units -> QC -> asset configuration -> templates."""
from __future__ import annotations
import json

import pandas as pd

from ..core import qc as QC, schema as S, units as U
from ..core.config import AssetConfig
from ..core.registry import log_event
from .bootstrap import SAMPLES, ingest_dataset, load_sample


def _upload_tab(ctx):
    st = ctx.st
    cfg, ds = ctx.cfg, ctx.datasets
    st.markdown("Upload your own tables (csv / xlsx). The platform detects what each file is, proposes the column mapping and units, and you **confirm** before anything is used. "
                "Semicolon or comma separators, decimal commas, French/English headers and DMS coordinates are handled.")
    files = st.file_uploader("Drop files here", type=["csv", "txt", "xlsx", "xls"], accept_multiple_files=True, key="up_files")
    for i, f in enumerate(files or []):
        with st.expander(f"📄 {f.name}", expanded=True):
            sheet = None
            try:
                from ..core.ingest import sniff_sheets
                sh = sniff_sheets(f)
                if len(sh) > 1:
                    sheet = st.selectbox("Sheet", sh, key=f"sh{i}")
                f.seek(0)
            except Exception:                                      # noqa: BLE001
                pass
            dayfirst = st.checkbox("Dates are day-first (31/12/2025)", True, key=f"df{i}")
            try:
                raw, rep = S_read(f, sheet, dayfirst)
            except Exception as e:                                 # noqa: BLE001
                st.error(f"Could not read the file: {e}")
                continue
            st.caption(f"{rep.n_rows:,} rows × {rep.n_cols} columns · encoding {rep.encoding} · separator '{rep.sep}'")
            ctx.table(raw.head(8))
            rank = S.detect_kind(raw)
            st.write("Detected: " + ", ".join(f"**{S.KINDS[k].title}** ({s:.2f})" for k, s in rank[:3]))
            kind = st.selectbox("This file is", [k for k, _ in rank], format_func=lambda k: S.KINDS[k].title, key=f"kind{i}")
            mp = S.suggest_mapping(raw, kind)
            k = S.KINDS[kind]
            opts = [None] + list(raw.columns)
            cs = st.columns(3)
            new = {}
            for j, c in enumerate(k.required + k.optional):
                new[c] = cs[j % 3].selectbox(f"{c}{' *' if c in k.required else ''}", opts, index=opts.index(mp[c]) if mp.get(c) in opts else 0, key=f"mp{i}_{c}")
            u = None
            if kind == "well_tests":
                g, why = S.guess_units(raw, new)
                cu = st.columns(4)
                u = S.UnitChoice(pressure=cu[0].selectbox("Pressure unit", U.PRESSURE_UNITS, index=U.PRESSURE_UNITS.index(g.pressure) if g.pressure in U.PRESSURE_UNITS else 0, key=f"up{i}"),
                                 datum=cu[1].selectbox("Pressure datum", ["gauge", "absolute"], key=f"ud{i}"),
                                 gas=cu[2].selectbox("Gas unit", U.GAS_UNITS, index=U.GAS_UNITS.index(g.gas) if g.gas in U.GAS_UNITS else 0, key=f"ug{i}"),
                                 liquid=cu[3].selectbox("Liquid unit", U.LIQ_UNITS, key=f"ul{i}"), dayfirst=dayfirst)
                st.caption("Unit guess: " + "; ".join(why) + ". **Check pressure datum (barg vs bara) - it matters.**")
            if st.button("Load as " + k.title, key=f"load{i}", type="primary"):
                d = ingest_dataset(kind, f, f.name, cfg, new, u, sheet=sheet, dayfirst=dayfirst)
                ds[kind] = d
                log_event("data", "load", dataset=kind, file=f.name, rows=len(raw), ok=d.canon is not None)
                st.success(f"Loaded {len(d.canon):,} rows." if d.canon is not None else "Could not normalise - see notes below.")
                for n in d.notes:
                    st.caption("• " + n)
                st.rerun() if d.canon is not None else None
    st.divider()
    c = st.columns(3)
    if c[0].button("Load Field sample (rates.csv + Network_field.csv)"):
        for k in SAMPLES:
            load_sample(st, k)
        cfg.asset_name, cfg.country = "Field cluster (sample)", "Algeria"
        st.rerun()
    if c[1].button("Clear all datasets"):
        ds.clear()
        st.rerun()


def S_read(f, sheet, dayfirst):
    from ..core.ingest import read_table
    f.seek(0)
    return read_table(f, sheet=sheet, dayfirst=dayfirst, name=f.name)


def _loaded_tab(ctx):
    st = ctx.st
    if not ctx.datasets:
        st.info("No dataset loaded yet. Use *Upload* or *Load Field sample*.")
        return
    rows = [dict(kind=S.KINDS[k].title, file=d.name, source=d.source, rows=len(d.canon) if d.canon is not None else 0, ok="yes" if d.canon is not None else "NO") for k, d in ctx.datasets.items()]
    ctx.table(pd.DataFrame(rows))
    k = st.selectbox("Inspect", list(ctx.datasets), format_func=lambda k: S.KINDS[k].title)
    d = ctx.datasets[k]
    for n in d.notes:
        st.caption("• " + n)
    if d.canon is not None:
        t1, t2, t3 = st.tabs(["Canonical data", "QC", "Mapping"])
        with t1:
            ctx.table(d.canon.head(200))
            ctx.download_df("Download canonical CSV", d.canon, f"{k}_canonical.csv", key=f"dlc_{k}")
        with t2:
            if d.qc is not None and len(d.qc):
                st.write(QC.qc_summary(d.qc))
                ctx.table(d.qc)
                ctx.download_df("Download QC issues", d.qc, f"{k}_qc.csv", key=f"dlq_{k}")
            else:
                st.success("No QC issues.")
        with t3:
            ctx.table(pd.DataFrame(dict(canonical=list(d.mapping), source_column=[d.mapping[c] for c in d.mapping])))
            st.json(vars(d.units) if d.units else {})


def _config_tab(ctx):
    st, cfg = ctx.st, ctx.cfg
    st.markdown("Values you change here are marked as **user-set**; everything else stays flagged as an *assumption* on every page that uses it.")
    c = st.columns(4)
    def num(col, label, key, lo, hi, step=None, fmt=None):
        v = col.number_input(label, lo, hi, float(getattr(cfg, key)), step=step, key=f"cfg_{key}", format=fmt)
        if abs(v - getattr(cfg, key)) > 1e-12:
            setattr(cfg, key, float(v)); cfg.mark(key)
    cfg.asset_name = c[0].text_input("Asset name", cfg.asset_name)
    cfg.country = c[1].text_input("Country", cfg.country)
    num(c[2], "Gas gravity (air=1)", "gas_sg", 0.55, 1.2, 0.01)
    num(c[3], "CO2 in produced gas (mol %)", "co2_pct", 0.0, 100.0, 0.1)
    c = st.columns(4)
    num(c[0], "H2S (ppm)", "h2s_ppm", 0.0, 1e6, 10.0)
    num(c[1], "N2 (mol %)", "n2_pct", 0.0, 50.0, 0.1)
    num(c[2], "Reservoir T (°C)", "t_res_c", 20.0, 250.0, 1.0)
    num(c[3], "Datum TVD (m)", "datum_tvd_m", 100.0, 8000.0, 50.0)
    c = st.columns(4)
    num(c[0], "Initial Pr (bara)", "p_res_init_bara", 5.0, 1000.0, 5.0)
    num(c[1], "Current Pr (bara)", "p_res_now_bara", 5.0, 1000.0, 5.0)
    num(c[2], "Tubing ID (in)", "tubing_id_in", 1.0, 9.0, 0.1)
    num(c[3], "Condensate density (kg/m3)", "cond_density_kgm3", 600.0, 900.0, 5.0)
    c = st.columns(4)
    num(c[0], "Gas price ($/kSm3)", "gas_price_usd_per_ksm3", 0.0, 2000.0, 5.0)
    num(c[1], "Condensate price ($/m3)", "cond_price_usd_per_m3", 0.0, 3000.0, 10.0)
    num(c[2], "Carbon price ($/t)", "carbon_price_usd_per_t", 0.0, 500.0, 5.0)
    num(c[3], "Discount rate", "discount_rate", 0.0, 0.5, 0.01)
    wells = ctx.wells()
    if wells:
        st.markdown("**Per-well overrides** (leave blank to use field values)")
        t = cfg.well_table(wells)
        t["lift"] = t["lift"].astype(str)
        ed = st.data_editor(t, key="cfg_wells", disabled=["well"], hide_index=True)
        for (_, r), (_, r0) in zip(ed.iterrows(), t.iterrows()):
            for k in ("lift", "tvd_m", "tubing_id_in", "p_res_bara", "t_res_c"):
                if str(r[k]) != str(r0[k]) and not pd.isna(r[k]):
                    cfg.wells.setdefault(r["well"], {})[k] = r[k]
    cc = st.columns(3)
    cc[0].download_button("Download asset config (JSON)", cfg.to_json(), f"{cfg.asset_name.replace(' ', '_')}_config.json", "application/json")
    up = cc[1].file_uploader("Load config JSON", type=["json"], key="cfg_up")
    if up is not None and st.button("Apply uploaded config"):
        new = AssetConfig.from_json(up.getvalue().decode("utf-8"))
        st.session_state["cfg"] = new
        st.rerun()
    st.caption(f"Still on defaults: {', '.join(cfg.assumed('gas_sg', 'co2_pct', 't_res_c', 'p_res_init_bara', 'p_res_now_bara', 'datum_tvd_m', 'tubing_id_in')) or 'none'}")


def render(ctx):
    st = ctx.st
    st.header("0 · Data foundation")
    st.markdown("**Your data → the same platform for every field.** Upload, confirm, and every other page works on it.")
    cov = [(S.KINDS[k].title, "✅ loaded" if ctx.has(k) else "—") for k in S.KINDS]
    with st.expander("Dataset status", expanded=not ctx.datasets):
        ctx.table(pd.DataFrame(cov, columns=["dataset", "status"]))
    tabs = st.tabs(["Upload", "Loaded datasets & QC", "Asset configuration", "Templates"])
    with tabs[0]:
        _upload_tab(ctx)
    with tabs[1]:
        _loaded_tab(ctx)
    with tabs[2]:
        _config_tab(ctx)
    with tabs[3]:
        st.caption("Download an empty template for each dataset (semicolon-separated).")
        kinds = list(S.KINDS)
        for r in range(0, len(kinds), 4):
            ctx.template_buttons(kinds[r:r + 4])
