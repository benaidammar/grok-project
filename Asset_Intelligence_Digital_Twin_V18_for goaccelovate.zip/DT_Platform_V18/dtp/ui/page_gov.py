"""Governance & multi-asset: audit log, model registry and approvals, platform health, asset portfolio."""
from __future__ import annotations
import importlib

import pandas as pd

from ..core import deps
from ..core.registry import approve_model, list_models, read_log


def render(ctx):
    st = ctx.st
    st.header("8 · Governance & multi-asset")
    tabs = st.tabs(["Model registry", "Audit log", "Multi-asset", "Platform health"])
    with tabs[0]:
        m = list_models()
        if m.empty:
            st.info("No registered models yet (register from the AI lab after a benchmark).")
        else:
            ctx.table(m)
            c = st.columns(4)
            mid = c[0].selectbox("Model", sorted(m.model_id.unique()))
            ver = c[1].number_input("Version", 1, int(m[m.model_id == mid].version.max()), 1)
            by = c[2].text_input("Approved by (name, role)")
            if c[3].button("Approve") and by:
                approve_model(mid, int(ver), by)
                st.success("Approved and logged.")
        st.caption("Approval means a named engineer reviewed data window, metrics and limitations. It does not make a model validated for closed-loop use.")
    with tabs[1]:
        lg = read_log(500)
        if len(lg):
            ctx.table(lg)
            ctx.download_df("Download audit log", lg, "audit_log.csv", key="dl_audit")
        else:
            st.info("Audit log is empty.")
    with tabs[2]:
        st.markdown("One configuration file per field; the same code serves all assets. Export this asset's configuration and import it on another instance, or keep one folder per asset.")
        st.download_button("Export asset configuration", ctx.cfg.to_json(), "asset_config.json", "application/json")
        rows = [dict(asset=ctx.cfg.asset_name, wells=len(ctx.wells()), datasets=", ".join(ctx.datasets) or "-", co2_pct=ctx.cfg.co2_pct)]
        ctx.table(pd.DataFrame(rows))
        st.caption("Roll-out checklist: clone config → load data → revalidate models on the new asset (backtest) → approve → train users. Models trained on one reservoir are not assumed valid on another.")
    with tabs[3]:
        rows = []
        for k, v in {**deps.CORE, **deps.OPTIONAL}.items():
            rows.append(dict(package=v, role="core" if k in deps.CORE else "optional (fallback exists)", installed="yes" if deps.has(k) else "no"))
        ctx.table(pd.DataFrame(rows))
        ok = 0
        from .pages import PAGES
        for _, _, spec in PAGES:
            try:
                importlib.import_module(spec.split(":")[0]); ok += 1
            except Exception:                                      # noqa: BLE001
                pass
        st.metric("Pages importable", f"{ok}/{len(PAGES)}")
