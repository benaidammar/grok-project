"""CCUS tabs: utilisation menu, EOR/EGR, storage, MRV. Each renders inside an open tab; `stream` is a CO2Stream."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..ccus import eor, mrv, storage, utilization as U
from ..ccus import co2props as P
from ..gascond.pvt import GasPVT
from .common import BLUE, GRAY, GREEN, ORANGE


def render_utilisation(ctx, stream):
    st, go = ctx.st, ctx.go
    tpy = stream.t_per_year
    st.markdown(f"**Your stream: {stream.t_per_day:,.1f} t/d = {tpy/1e3:,.1f} kt/yr** ({stream.mol_frac*100:.2f} % CO2 in {stream.gas_sm3d/1e6:.2f} MMSm3/d). "
                "EOR is only one use: below, every pathway is sized against this stream.")
    st.caption("All value / capacity / energy columns are INDICATIVE PLACEHOLDERS - edit the table (double-click cells) with local quotes.")
    cat = ctx.memo(("ccb_cat",), U.catalogue)
    cat = st.data_editor(cat, key="ccb_cat_edit", num_rows="fixed", width="stretch") if hasattr(st, "data_editor") else cat
    purity = st.slider("CO2 purity available after capture/conditioning (%)", 80.0, 99.99, 98.0, key="ccb_purity")
    w = {k: st.slider(k, 0.0, 1.0, v, 0.05, key=f"ccb_w_{k}") for k, v in dict(climate=0.3, scale=0.25, maturity=0.15, economics=0.15, logistics=0.1, inputs=0.05).items()}
    crit = U.criteria_table(cat, tpy, purity)
    rk = U.topsis(crit, w)
    show = rk[["rank", "pathway", "category", "topsis", "scale", "trl", "permanence", "purity_ok"]]
    ctx.table(show.round(2))
    fig = go.Figure(go.Bar(x=rk.topsis[::-1], y=rk.pathway[::-1], orientation="h", marker_color=[GREEN if o else GRAY for o in rk.purity_ok[::-1]]))
    fig.update_layout(title="Multi-criteria closeness (green = purity OK; grey = fails purity)", height=620)
    ctx.plot(fig, 620, key="ccb_topsis")
    st.markdown("**Portfolio allocation** - split the stream across pathways")
    obj = st.radio("Objective", ["value", "climate"], horizontal=True, key="ccb_obj")
    no_in = st.checkbox("Exclude pathways needing external H2/NH3 etc.", value=True, key="ccb_noin")
    a = U.allocate(cat, tpy, purity, obj, exclude_inputs=no_in)
    ctx.status(a)
    if a.value:
        ctx.table(a.value["table"].round(1))
        ctx.metrics([("Allocated value", f"{a.value['total_value']:,.0f} USD/yr"), ("Avoided CO2", f"{a.value['total_avoided']:,.0f} t/yr"), ("Unallocated", f"{a.value['unallocated_tpy']:,.0f} t/yr")])
        ctx.table(U.sensitivity(cat, tpy, purity, obj, exclude_inputs=no_in).round(0))
    st.markdown("**Chemical routes: mass balance**")
    route = st.selectbox("Route", list(U.CHEM), key="ccb_route")
    mb = U.mass_balance(route, st.number_input("CO2 into route (t/yr)", value=float(min(tpy, 20000)), key="ccb_mb_t"))
    ctx.status(mb)
    if mb.value:
        st.json({k: (round(v, 2) if isinstance(v, float) else v) for k, v in mb.value.items()} if isinstance(mb.value, dict) else str(mb.value))


def render_eor_egr(ctx, stream):
    st, go = ctx.st, ctx.go
    st.info("Your fields are gas-condensate: oil EOR needs an OIL reservoir within reach. Enter a candidate oil field, or use the gas/condensate recovery screen below.")
    c = st.columns(4)
    api = c[0].number_input("Oil API", value=38.0, key="ccb_api")
    vis = c[1].number_input("Viscosity cP", value=1.2, key="ccb_vis")
    depth = c[2].number_input("Depth m", value=2600.0, key="ccb_dep")
    tc = c[3].number_input("Temp C", value=95.0, key="ccb_t")
    c = st.columns(4)
    pr = c[0].number_input("Pr bara", value=220.0, key="ccb_pr")
    so = c[1].number_input("Remaining So %", value=35.0, key="ccb_so")
    k = c[2].number_input("k mD", value=50.0, key="ccb_k")
    mw = c[3].number_input("MW C5+", value=180.0, key="ccb_mw")
    r = eor.screen(api, vis, depth, tc, pr, so, k, mw)
    ctx.status(r)
    ctx.table(r.value["table"])
    inc = eor.incremental_oil(stream.t_per_year)
    ctx.table(inc.round(2))
    st.caption(f"Incremental oil with {stream.t_per_year/1e3:,.0f} kt/yr CO2 (utilisation factor 4-10 Mscf/stb: literature range).")
    st.markdown("**Enhanced gas / condensate recovery - voidage replacement**")
    pvt = GasPVT.from_cfg(ctx.cfg)
    pr2 = st.number_input("Gas-field Pr (bara)", value=float(ctx.cfg.p_res_now_bara), key="ccb_pr_gas")
    bg = float(pvt.bg(pr2, ctx.cfg.t_res_c))
    e = eor.egr_voidage(stream.gas_sm3d, 0.0, pr2, ctx.cfg.t_res_c, bg, stream.t_per_day)
    ctx.metrics([("Voidage", f"{e['voidage_rm3d']:,.0f} rm3/d"), ("CO2 needed for full replacement", f"{e['co2_needed_t_d']:,.0f} t/d"), ("Achievable VRR", f"{e['vrr']:.2f}")])
    st.caption(e["note"])


def render_storage(ctx, stream):
    st, go = ctx.st, ctx.go
    pvt = GasPVT.from_cfg(ctx.cfg)
    need_mt = stream.mt_total
    st.markdown(f"CO2 to place over {stream.lifetime_years:.0f} years: **{need_mt:.2f} Mt** (all of it, if everything were captured).")
    t1, t2, t3 = st.tabs(["Depleted gas field", "Saline aquifer", "Injectivity & Hall plot"])
    with t1:
        wt = ctx.canon("well_tests")
        gp_def = 0.0
        if wt is not None:
            from ..gascond.deliverability import field_cum_gas
            try:
                gp_def = float(field_cum_gas(wt).iloc[-1]) / 1e9
            except Exception:                                   # noqa: BLE001
                pass
        gp = st.number_input("Cumulative gas produced from the reservoir (GSm3)", value=gp_def if gp_def > 0 else 5.0, key="ccb_gp",
                             help="Default = trapezoid over the well tests: LOWER BOUND of true cumulative.")
        pr = st.number_input("Final reservoir pressure (bara)", value=float(ctx.cfg.p_res_now_bara * 0.6), key="ccb_prf")
        e = st.slider("Efficiency", 0.3, 0.95, 0.7, key="ccb_eff")
        r = storage.depleted_field(gp * 1e9, pr, ctx.cfg.t_res_c, pvt, e)
        ctx.status(r)
        ctx.metrics([("Capacity", f"{r.value['mt']:.1f} Mt"), ("Years of this stream", f"{r.value['mt'] / max(stream.t_per_year / 1e6, 1e-9):.0f}"), ("CO2 density", f"{r.value['rho_co2']:.0f} kg/m3")])
    with t2:
        c = st.columns(4)
        A = c[0].number_input("Area km2", value=100.0, key="ccb_A")
        h = c[1].number_input("Net thickness m", value=40.0, key="ccb_h")
        phi = c[2].number_input("Porosity", value=0.15, key="ccb_phi")
        p = c[3].number_input("Pressure bara", value=200.0, key="ccb_pa")
        r = storage.saline(A, h, phi, ctx.cfg.t_res_c * 0.7, p)
        ctx.status(r)
        ctx.metrics([("P10", f"{r.value['P10']:.0f} Mt"), ("P50", f"{r.value['P50']:.0f} Mt"), ("P90", f"{r.value['P90']:.0f} Mt")])
    with t3:
        c = st.columns(4)
        k = c[0].number_input("k mD", value=100.0, key="ccb_ik")
        h = c[1].number_input("h m", value=30.0, key="ccb_ih")
        pr = c[2].number_input("Pr bara", value=150.0, key="ccb_ipr")
        dep = c[3].number_input("Depth m", value=2000.0, key="ccb_idep")
        inj = storage.injectivity(k, h, pr, dep, 70.0)
        ctx.metrics([("Max pressure (90 % frac)", f"{inj['p_max']:.0f} bara"), ("Max rate / well", f"{inj['q_t_per_day']:,.0f} t/d"), ("Wells needed", f"{np.ceil(stream.t_per_day / max(inj['q_t_per_day'], 1e-9)):.0f}")])
        up = st.file_uploader("Injection history CSV (time days, pwf, pres, q_t_d) for a Hall plot", type="csv", key="ccb_hall")
        if up is not None:
            from ..core.ingest import read_table
            d, _ = read_table(up)
            try:
                h_ = storage.hall_plot(d)
                f = go.Figure(go.Scatter(x=h_.Wi, y=h_.H, mode="lines"))
                f.update_layout(xaxis_title="cumulative injection (t)", yaxis_title="Hall integral", title="Hall plot: slope up = injectivity loss")
                ctx.plot(f, 320, key="ccb_hallplot")
            except Exception as ex:                             # noqa: BLE001
                st.error(f"Hall plot failed: {ex}")
    st.markdown("**Storage security checklist**")
    st.data_editor(storage.checklist(), key="ccb_chk", width="stretch") if hasattr(st, "data_editor") else ctx.table(storage.checklist())
    st.caption("Precedent: In Salah (Algeria) injected CO2 into the aquifer leg of a gas field from 2004 and suspended injection in 2011 over caprock-integrity questions - verify details against current literature.")


def render_mrv(ctx, stream):
    st, go = ctx.st, ctx.go
    risk = st.radio("Risk level", ["low", "medium", "high"], index=1, horizontal=True, key="ccb_risk")
    ctx.table(mrv.plan(risk))
    up = st.file_uploader("Injection data (time, pressure, rate) or use demo", type="csv", key="ccb_mrv_up")
    if up is not None:
        from ..core.ingest import read_table
        df, _ = read_table(up)
    else:
        df = mrv.demo_injection()
        st.caption("Demo data: a slow leak starts at sample 260.")
    d = mrv.detect_anomaly(df)
    f = ctx.make_subplots(rows=2, cols=1, shared_xaxes=True)
    f.add_trace(go.Scatter(y=d.pressure, name="pressure"), row=1, col=1)
    f.add_trace(go.Scatter(y=d.pressure[d.flag], x=d.index[d.flag], mode="markers", name="flag", marker=dict(color="red")), row=1, col=1)
    f.add_trace(go.Scatter(y=d.z, name="z (P/q)"), row=2, col=1)
    ctx.plot(f, 460, key="ccb_mrv")
    st.caption(f"{int(d.flag.sum())} flagged samples. Flags are triggers for investigation, not leak confirmation.")
    c = st.columns(3)
    inj = c[0].number_input("Injected (t)", value=100000.0, key="ccb_mi")
    sto = c[1].number_input("Stored / accounted (t)", value=99000.0, key="ccb_ms")
    unc = c[2].number_input("Meter uncertainty %", value=2.0, key="ccb_mu")
    r = mrv.reconcile(inj, sto, 0.0, unc)
    (st.success if r["within_uncertainty"] else st.error)(f"Unexplained {r['unexplained_t']:,.0f} t vs meter uncertainty ±{r['meter_uncertainty_t']:,.0f} t")
    with st.expander("Carbon-credit eligibility explainer"):
        for n in mrv.CREDIT_NOTES:
            st.write("• " + n)
