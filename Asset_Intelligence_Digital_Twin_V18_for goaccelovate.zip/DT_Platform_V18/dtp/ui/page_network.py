"""Page 3b - gathering network & facilities (Field sample or a synthetic 20-well tree).  All physics lives in dtp.gascond.network / netopt.

FINDINGS_PLACEHOLDER
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core import qc as QC
from ..gascond import netopt
from ..gascond import network as N
from ..gascond.pvt import GasPVT
from .common import BLUE, GRAY, GREEN, ORANGE, RED

K = "net_"
BASES = {"As stated in file": "stated", "Straight-line x tortuosity": "straight", "Max of both": "max"}


def _map(ctx, model: N.NetModel, edges: pd.DataFrame, col: str, label: str):
    """UTM plan view; segments coloured by `col` (dP/km or velocity ratio)."""
    import plotly.colors as pc
    go = ctx.go
    fig = go.Figure()
    vals = edges[col].astype(float)
    lo, hi = float(vals.min()), float(vals.max())
    nd = model.nodes.set_index("site")
    for c, r in edges.iterrows():
        a, b = nd.loc[c], nd.loc[r["to"]]
        t = 0.0 if hi <= lo else (r[col] - lo) / (hi - lo)
        fig.add_trace(go.Scatter(x=[a["x"], b["x"]], y=[a["y"], b["y"]], mode="lines", showlegend=False, hoverinfo="text",
                                 line=dict(width=2 + 1.2 * float(r["diameter_in"]) ** 0.7 / 2, color=pc.sample_colorscale("Turbo", [0.1 + 0.8 * t])[0]),
                                 text=f"{c} -> {r['to']}<br>{r['diameter_in']:.0f} in, {r['length_m']:.0f} m<br>{label}: {r[col]:.2f}<br>v = {r['velocity_ms']:.1f} m/s"))
    sym = {"well": "circle", "manifold": "square", "facility": "diamond"}
    for idn, g in nd.reset_index().groupby("identity"):
        fig.add_trace(go.Scatter(x=g["x"], y=g["y"], mode="markers+text", text=g["site"], textposition="top center", name=idn,
                                 marker=dict(size=9 if idn == "well" else 13, symbol=sym.get(idn, "circle"), color="#222", line=dict(width=1, color="white"))))
    fig.add_trace(go.Scatter(x=[None], y=[None], mode="markers", showlegend=False, hoverinfo="skip",
                             marker=dict(colorscale="Turbo", cmin=lo, cmax=hi, color=[lo], colorbar=dict(title=label, len=0.6), showscale=True)))
    fig.update_layout(title=f"Plan view (UTM m), segments coloured by {label}", yaxis=dict(scaleanchor="x", title="Northing m"), xaxis_title="Easting m")
    ctx.plot(fig, 520, key=K + "map")


def _inputs(ctx, demo: bool):
    """-> (nodes, curves, ratios, qc_issues)."""
    if demo:
        nodes, curves, ratios = ctx.memo(("net_demo",), N.demo_network)
        return nodes, curves, ratios, QC.qc_network(nodes)
    nodes, tests = ctx.canon("network"), ctx.canon("well_tests")
    ratios = ctx.memo(("net_ratios", len(tests), float(tests["gas_sm3d"].sum())), lambda: N.well_ratios(tests))
    curves = ctx.memo(("net_curves", len(tests), float(tests["gas_sm3d"].sum())), lambda: N.fit_all_curves(tests))
    return nodes, curves, ratios, QC.qc_network(nodes)


def render(ctx):
    st, cfg = ctx.st, ctx.cfg
    st.header("3b · Gathering network & facilities")
    ctx.section_intro("Tree hydraulics from wells through manifolds to the facility: required wellhead pressures, deliverable rates, bottlenecks, upsizing, "
                      "facility-pressure / compression scenarios, rate allocation and Monte-Carlo on the uncertain data.",
                      "Network (nodes, UTM, lengths, diameters) + well tests (rates, WHP, CGR / WGR) + prices & gas properties from the asset configuration.",
                      "Per-segment dP, velocity vs erosional, bottleneck ranking, upsizing NPV, rate vs facility pressure, optimised allocation, P10/P50/P90 rate.")
    ctx.template_buttons(["network"])
    have = ctx.has("network") and ctx.has("well_tests")
    demo = st.toggle("Use demo network (synthetic 20-well tree)", value=not have, key=K + "demo")
    if not have and not demo:
        ctx.need("network", "This page needs the network and well tests.")
        return
    nodes, curves, ratios, qci = _inputs(ctx, demo)
    errs = int((qci["severity"] == "error").sum()) if len(qci) else 0

    # ---- data quality up front -----------------------------------------------------------------------
    st.subheader("Network data quality")
    if len(qci):
        (st.error if errs else st.warning)(f"{errs} error(s), {int((qci['severity'] == 'warning').sum())} warning(s) in the network data - "
                                           "flowline lengths that are impossible or suspect change the hydraulics. Choose the length basis below.")
        ctx.table(qci)
        ctx.download_df("Download QC issues (CSV)", qci, "network_qc.csv", K + "dlqc")
    else:
        st.success("No network data issues found.")

    # ---- controls ----------------------------------------------------------------------------------------
    c = st.columns(4)
    basis_lbl = c[0].selectbox("Length basis", list(BASES), index=0, key=K + "basis",
                               help="'Straight-line x tortuosity' replaces every flowline length by the UTM distance x tortuosity; 'max' keeps the larger of stated and that.")
    tort = c[1].slider("Tortuosity factor", 1.0, 2.0, 1.25, 0.05, key=K + "tort")
    t_c = c[2].number_input("Flowing temperature, degC", 5.0, 150.0, 35.0, 1.0, key=K + "t")
    rough = c[3].number_input("Roughness, mm", 0.005, 1.0, 0.0457, 0.005, format="%.4f", key=K + "rough")
    c = st.columns(4)
    c_ero = c[0].number_input("Erosional C (API RP 14E)", 50.0, 200.0, 100.0, 10.0, key=K + "cero", help="100 continuous service; up to 125-150 clean/intermittent.")
    wet = c[1].checkbox("Wet-gas multiplier (screening)", True, key=K + "wet")
    v_lim = c[2].slider("Velocity limit, fraction of erosional", 0.3, 1.0, 0.8, 0.05, key=K + "vlim")
    basis = BASES[basis_lbl]
    pvt = GasPVT.from_cfg(cfg)
    ctx.assume_banner(["gas_sg", "co2_pct", "gas_price_usd_per_ksm3", "cond_price_usd_per_m3", "discount_rate"], "(gas properties and prices drive every result here)")
    mk = lambda **kw: N.NetModel(nodes, pvt, ratios, basis, tort, t_c=t_c, rough_mm=rough, c_ero=c_ero, cond_density=cfg.cond_density(),
                                 water_density=1000 * cfg.water_sg, wet_gas=wet, **kw)
    model = mk()
    gp = ("net_model", demo, basis, tort, t_c, rough, c_ero, wet, cfg.gas_sg, cfg.co2_pct, len(nodes))
    if model.edges["length_m"].isna().any() or model.edges["diameter_in"].isna().any():
        st.error("Missing length / diameter on some segments - fix the network data.")
        return
    pf_cal = ctx.memo(gp + ("pcal",), model.calibrate_p_fac) if not demo else 55.0
    pf_default = float(round(pf_cal, 1)) if np.isfinite(pf_cal) else 60.0
    pf = c[3].number_input("Facility inlet pressure, bara", 5.0, 300.0, pf_default, 1.0, key=K + f"pf_{demo}",
                           help="Default = value that reproduces the latest tested WHPs at the latest tested rates (calibrated on the chosen length basis; assumes test WHP = flowline inlet)." if not demo else "")
    prices = dict(gas=cfg.gas_price_usd_per_ksm3, cond=cfg.cond_price_usd_per_m3)

    res = N.deliverability_result(model, curves, pf, cfg, errs)
    ctx.status(res)
    if not res.ok:
        return
    sol = res.value
    e = sol.edges
    qtot = sum(sol.q.values())
    imax = e["v_ratio"].idxmax()
    ctx.metrics([("Deliverable gas, MMSm3/d", f"{qtot / 1e6:.2f}"), ("Max dP/km, bar", f"{e['dp_bar_per_km'].max():.2f} ({e['dp_bar_per_km'].idxmax()})"),
                 ("Max v / v_erosional", f"{e['v_ratio'].max():.2f} ({imax})"), ("Facility inlet, bara", f"{pf:.1f}")])

    # visible effect of the length basis
    cmp_rows = []
    for lbl, b in BASES.items():
        m2 = N.NetModel(nodes, pvt, ratios, b, tort, t_c=t_c, rough_mm=rough, c_ero=c_ero, wet_gas=wet)
        s2 = m2.deliverability(curves, pf)
        cmp_rows.append(dict(length_basis=lbl, total_flowline_km=m2.edges["length_m"].sum() / 1000, deliverable_MMsm3d=sum(s2.q.values()) / 1e6,
                             max_dp_per_km=s2.edges["dp_bar_per_km"].max(), max_v_ratio=s2.edges["v_ratio"].max(), binding_segment=s2.edges["dp_bar"].idxmax()))
    cmp_df = pd.DataFrame(cmp_rows)
    with st.expander("How much does the length basis matter?", expanded=bool(errs)):
        ctx.table(cmp_df.style.format({c: "{:.2f}" for c in cmp_df.columns if c not in ("length_basis", "binding_segment")}))

    tabs = st.tabs(["Map & hydraulics", "Solve both ways", "Bottlenecks", "Upsizing", "Facility pressure / compression", "Rate allocation", "Monte-Carlo"])

    with tabs[0]:
        met = st.radio("Colour by", ["dP per km (bar/km)", "Velocity / erosional"], horizontal=True, key=K + "col")
        ee = e.assign(vr=e["v_ratio"])
        _map(ctx, model, ee, "dp_bar_per_km" if met.startswith("dP") else "vr", "dP/km" if met.startswith("dP") else "v/ve")
        show = e[["to", "length_m", "diameter_in", "q_sm3d", "p_up_bara", "p_down_bara", "dp_bar", "dp_bar_per_km", "velocity_ms", "v_erosional_ms", "v_ratio",
                  "friction", "wet_multiplier", "holdup_risk"]].round(3)
        ctx.table(show)
        ctx.download_df("Download segment results (CSV)", show.reset_index(), "network_segments.csv", K + "dlseg")
        st.caption("Velocity is evaluated at the downstream (lowest-pressure, highest-velocity) end. holdup_risk = gas velocity < 3 m/s (liquid loading in the flowline). "
                   "Wet-gas multiplier: SCREENING (Chisholm), no liquid holdup.")
        if (e["v_ratio"] > v_lim).any():
            st.warning("Segments above the velocity limit: " + ", ".join(e.index[e["v_ratio"] > v_lim]))

    with tabs[1]:
        a, b = st.columns(2)
        a.markdown("**A. Fixed facility pressure + rates -> required wellhead pressures**")
        base_q = pd.DataFrame({"well": model.wells, "q_sm3d": [float(ratios.get(w, {}).get("q", sol.q.get(w, 0.0))) for w in model.wells]})
        ed = a.data_editor(base_q, key=K + "qed", hide_index=True, disabled=["well"])
        sb = model.solve_back(dict(zip(ed["well"], ed["q_sm3d"])), pf)
        rq = pd.DataFrame({"well": model.wells, "q_sm3d": ed["q_sm3d"].values, "required_whp_bara": [float(sb.node_p[w]) for w in model.wells],
                           "tested_whp_bara": [ratios.get(w, {}).get("whp", np.nan) for w in model.wells]})
        rq["whp_gap_bar"] = rq["required_whp_bara"] - rq["tested_whp_bara"]
        a.dataframe(rq.round(2), hide_index=True)
        ctx.download_df("Download required WHP (CSV)", rq, "required_whp.csv", K + "dlreq")
        a.caption("Positive gap = the network needs more WHP than was tested at that rate (facility pressure set too low for the tested rates).")
        b.markdown("**B. WHP-rate curves + facility pressure -> flowing rates**")
        dq = pd.DataFrame({"well": list(sol.q), "q_sm3d": list(sol.q.values()), "whp_bara": [float(sol.node_p[w]) for w in sol.q],
                           "curve": [curves[w].quality for w in sol.q], "last_test_q": [curves[w].q_last for w in sol.q]})
        b.dataframe(dq.round(1), hide_index=True)
        ctx.download_df("Download deliverable rates (CSV)", dq, "deliverable_rates.csv", K + "dldq")
        fig = ctx.go.Figure()
        for i, w in enumerate(list(curves)[:12]):
            pr = np.linspace(1.0, curves[w].ps, 60)
            fig.add_trace(ctx.go.Scatter(x=curves[w].q(pr) / 1e6, y=pr, mode="lines", name=w, line=dict(width=1.5)))
            if w in sol.q:
                fig.add_trace(ctx.go.Scatter(x=[sol.q[w] / 1e6], y=[sol.node_p[w]], mode="markers", showlegend=False, marker=dict(color="black", size=7)))
        fig.update_layout(title="Well WHP-rate curves (black dots = network operating points)", xaxis_title="MMSm3/d", yaxis_title="WHP, bara")
        ctx.plot(fig, 380, key=K + "curves")
        weak = [w for w, cv in curves.items() if cv.quality.startswith("single")]
        if weak:
            st.warning("Single-point (assumed Ps) curves - rates for these wells are less certain: " + ", ".join(weak))

    with tabs[2]:
        if st.button("Rank bottlenecks (marginal gain of upsizing)", key=K + "bnbtn"):
            st.session_state[K + "bn"] = ctx.guard("bottlenecks", lambda: ctx.memo(gp + ("bn", pf), lambda: N.bottleneck_table(model, curves, pf)))
        bn = st.session_state.get(K + "bn")
        if bn is not None:
            v = bn[["dp_bar", "dp_bar_per_km", "velocity_ms", "v_ratio", "share_of_total_dp_%", "gain_next_size_sm3d", "gain_half_dp_sm3d", "rank"]].round(3)
            ctx.table(v)
            ctx.download_df("Download bottleneck ranking (CSV)", v.reset_index(), "bottlenecks.csv", K + "dlbn")
            fig = ctx.go.Figure(ctx.go.Bar(x=bn.index, y=bn["gain_next_size_sm3d"] / 1e3, marker_color=BLUE))
            fig.update_layout(title="Gain in network deliverability if the segment is one nominal size larger", yaxis_title="kSm3/d")
            ctx.plot(fig, 320, key=K + "bnfig")
            st.caption("Ranked by gain when the segment's dP is halved. A high dP/km on a short spur matters less than a modest dP/km on the trunk that carries every well.")

    with tabs[3]:
        st.markdown("**Installed cost per metre by nominal size - PLACEHOLDER numbers, replace with your own.**")
        cap_df = st.data_editor(pd.DataFrame({"nps_in": list(N.CAPEX_PER_M), "usd_per_m": list(N.CAPEX_PER_M.values())}), key=K + "capex", hide_index=True)
        cc = st.columns(3)
        hor = cc[0].slider("Horizon, years", 3, 25, 10, key=K + "hor")
        dec = cc[1].slider("Annual decline", 0.0, 0.3, 0.10, 0.01, key=K + "dec")
        cc[2].caption(f"Prices from asset config: gas {prices['gas']:.0f} USD/kSm3, condensate {prices['cond']:.0f} USD/m3, discount {cfg.discount_rate:.0%}.")
        if st.button("Run upsizing study (replace vs parallel loop)", key=K + "upbtn"):
            cap = {int(a_): float(b_) for a_, b_ in zip(cap_df["nps_in"], cap_df["usd_per_m"])}
            st.session_state[K + "up"] = ctx.guard("upsizing", lambda: N.upsizing_study(model, curves, pf, prices, cap, hor, dec, cfg.discount_rate, max_steps=2))
        up = st.session_state.get(K + "up")
        if up is not None and len(up):
            ctx.table(up.round(2).head(40))
            ctx.download_df("Download upsizing study (CSV)", up, "upsizing.csv", K + "dlup")
            st.caption("dQ from the full network solve. NPV = discounted revenue (declining) minus placeholder capex; screening only - the decision requires engineering review and MoC.")

    with tabs[4]:
        cc = st.columns(3)
        span = cc[0].slider("Facility pressure span below reference, bar", 10, int(max(11, pf - 5)), int(min(40, pf - 5)), key=K + "span")
        eta = cc[1].slider("Compressor isentropic efficiency", 0.5, 0.9, 0.75, 0.01, key=K + "eta")
        pw = cc[2].number_input("Energy cost, USD/kWh (placeholder)", 0.0, 1.0, 0.05, 0.01, key=K + "kwh")
        pl = np.linspace(pf - span, pf + 5, 12)
        rv = N.rate_vs_facility_pressure(model, curves, pl)
        cs = N.compression_study(model, curves, pf, np.linspace(pf - span, pf, 8)[::-1], eta, pw)
        fig = ctx.make_subplots(specs=[[dict(secondary_y=True)]])
        fig.add_trace(ctx.go.Scatter(x=rv["p_fac_bara"], y=rv["gas_sm3d"] / 1e6, name="Deliverable gas", line=dict(color=BLUE)), secondary_y=False)
        fig.add_trace(ctx.go.Scatter(x=cs["p_suction_bara"], y=cs["power_kw"] / 1e3, name="Compressor power (to reference pressure)", line=dict(color=ORANGE, dash="dot")), secondary_y=True)
        fig.update_xaxes(title="Facility (UTG) inlet pressure, bara")
        fig.update_yaxes(title="MMSm3/d", secondary_y=False)
        fig.update_yaxes(title="MW", secondary_y=True)
        ctx.plot(fig, 400, key=K + "comp")
        out = cs.round(2)
        ctx.table(out)
        ctx.download_df("Download compression scenarios (CSV)", cs, "compression.csv", K + "dlcomp")
        st.caption("Single-stage isentropic power (k = 1.27, real-gas Z at suction), no staging / aftercooling / driver limits - screening. "
                   "Wet-gas condensate / water at lower pressure is not re-flashed.")

    with tabs[5]:
        st.markdown("**Maximise value by allocating well rates (choke settings) under velocity, minimum-WHP and facility limits.**")
        cc = st.columns(3)
        whp_min = cc[0].number_input("Minimum flowing WHP, bara", 1.0, 200.0, float(max(10.0, round(pf * 0.25))), 1.0, key=K + "whpmin")
        cap_on = cc[1].checkbox("Facility gas capacity limit", True, key=K + "capon")
        cap_val = cc[2].number_input("Capacity, MMSm3/d", 0.1, 100.0, float(round(0.85 * qtot / 1e6, 2)), 0.1, key=K + "cap", disabled=not cap_on)
        if st.button("Optimise (SLSQP)", key=K + "optbtn"):
            st.session_state[K + "opt"] = ctx.guard("optimisation", lambda: netopt.optimise_rates(model, curves, pf, prices, whp_min, v_lim, cap_val * 1e6 if cap_on else None))
        opt = st.session_state.get(K + "opt")
        if opt is not None:
            ctx.status(opt)
            if opt.ok:
                m_ = opt.meta
                ctx.metrics([("Value base, kUSD/d", f"{m_['value_base_usd_d'] / 1e3:.1f}"), ("Value optimised, kUSD/d", f"{m_['value_opt_usd_d'] / 1e3:.1f}"),
                             ("Max v/ve", f"{m_['max_v_ratio']:.2f}")])
                ctx.table(opt.value.round(2))
                ctx.download_df("Download allocation (CSV)", opt.value, "rate_allocation.csv", K + "dlopt")
                st.warning("Suggestion only. Any choke or rate change **requires engineering review and MoC**; this is not a closed-loop setpoint.")

    with tabs[6]:
        n_mc = st.slider("Samples", 30, 300, 100, 10, key=K + "nmc")
        st.caption("Sampled: tortuosity 1.0-1.5 applied to flagged (impossible / suspect) lengths, +-10% on other lengths, roughness 0.02-0.25 mm (log-uniform), gas SG +-0.03.")
        if st.button("Run Monte-Carlo", key=K + "mcbtn"):
            st.session_state[K + "mc"] = ctx.guard("Monte-Carlo", lambda: ctx.memo(gp + ("mc", pf, n_mc), lambda: N.monte_carlo(nodes, pvt, curves, ratios, pf, n_mc, 0, t_c, c_ero)))
        mc = st.session_state.get(K + "mc")
        if mc:
            ctx.metrics([("P10, MMSm3/d", f"{mc['p10'] / 1e6:.3f}"), ("P50", f"{mc['p50'] / 1e6:.3f}"), ("P90", f"{mc['p90'] / 1e6:.3f}"),
                         ("Stated-length base", f"{mc['q_base_stated'] / 1e6:.3f}")])
            fig = ctx.go.Figure(ctx.go.Histogram(x=mc["q_samples"] / 1e6, nbinsx=25, marker_color=GRAY))
            for k_, col in (("p10", RED), ("p50", GREEN), ("p90", BLUE)):
                fig.add_vline(x=mc[k_] / 1e6, line_color=col, annotation_text=k_.upper())
            fig.update_layout(title="Deliverable network rate (screening ranges, not a reservoir uncertainty)", xaxis_title="MMSm3/d")
            ctx.plot(fig, 340, key=K + "mcfig")
            pr = pd.DataFrame({"P(highest dP)": mc["top_dp_prob"], "P(v > 0.5 ve)": mc["v_gt_half_ero_prob"]}).round(2)
            ctx.table(pr)
            ctx.download_df("Download Monte-Carlo probabilities (CSV)", pr.reset_index(), "mc_bottlenecks.csv", K + "dlmc")
            st.caption("Flagged segments: " + (", ".join(mc["flagged"]) or "none"))
