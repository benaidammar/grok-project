"""Managerial intelligence: actual vs target vs forecast, gap bridge, root causes, budget, opportunities."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..core.status import Status
from ..gascond import forecast as F
from ..mgmt import manage as M
from .common import BLUE, GRAY, GREEN, ORANGE, RED


def render(ctx):
    st, go = ctx.st, ctx.go
    st.header("1 · Managerial intelligence")
    ctx.section_intro("Where are we vs target and forecast, why is there a gap, which wells drive it, what does it cost and which actions pay.",
                      "well_tests and/or production_daily; targets, downtime, budget (optional).",
                      "Actual / target / forecast chart, gap waterfall, well bridge with root-cause hints, budget variance, ranked opportunities.")
    wt, pdv = ctx.canon("well_tests"), ctx.canon("production_daily")
    act = M.monthly_actual(wt, pdv)
    ctx.status(act)
    if act.value is None:
        return
    m = act.value
    tabs = st.tabs(["Actual · target · forecast", "Gap & root cause", "Budget CAPEX/OPEX", "Opportunity register", "Executive summary"])
    gas = m["gas"].dropna()
    with tabs[0]:
        pct = st.slider("If no targets uploaded: target as % of trailing 12-month peak", 0.5, 1.2, 0.9, 0.05)
        tgt, why = M.target_series(gas.index, ctx.canon("targets"), gas, pct)
        fc = None
        if wt is not None:
            yrs = st.slider("Forecast horizon (years)", 1, 15, 5)
            ff = ctx.memo(("ff", len(wt), yrs), lambda: F.field_forecast(wt, ctx.cfg, years=yrs))
            if len(ff):
                fc = ff.groupby("date")[["gas_p10", "gas_p50", "gas_p90"]].sum()
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=gas.index, y=gas / 1e6, name="Actual", line=dict(color=BLUE)))
        fig.add_trace(go.Scatter(x=tgt.index, y=tgt / 1e6, name="Target", line=dict(color=ORANGE, dash="dash")))
        if fc is not None:
            fig.add_trace(go.Scatter(x=fc.index, y=fc.gas_p90 / 1e6, line=dict(width=0), showlegend=False))
            fig.add_trace(go.Scatter(x=fc.index, y=fc.gas_p10 / 1e6, fill="tonexty", fillcolor="rgba(46,160,67,.15)", line=dict(width=0), name="P10-P90"))
            fig.add_trace(go.Scatter(x=fc.index, y=fc.gas_p50 / 1e6, name="Forecast P50", line=dict(color=GREEN)))
        fig.update_layout(yaxis_title="MMSm3/d", title=f"Field gas - target: {why}")
        ctx.plot(fig, 440, key="mg_main")
        cum = gas.sum() * 30.4 / 1e9
        ctx.metrics([("Latest month", f"{gas.iloc[-1] / 1e6:.2f} MMSm3/d"), ("vs target", f"{(gas.iloc[-1] / tgt.iloc[-1] - 1):+.0%}"), ("Cumulative (period)", f"{cum:.2f} GSm3"),
                     ("12-month change", f"{(gas.iloc[-1] / gas.iloc[-13] - 1):+.0%}" if len(gas) > 13 else "n/a")])
        if "ASSUMED" in why:
            st.warning("Target is a placeholder rule. Upload `targets` for a real gap analysis.")
    with tabs[1]:
        dt = ctx.canon("downtime")
        loss = M.downtime_loss(dt, gas.index)
        i = st.slider("Month to analyse", 0, len(gas) - 1, len(gas) - 1, key="mg_i")
        ref = st.slider("Decline reference (months back)", 1, max(2, min(36, len(gas) - 1)), min(12, len(gas) - 1))
        j = max(0, i - ref)
        decline = max(gas.iloc[j] - gas.iloc[i], 0)
        wb = M.gap_bridge(gas.iloc[i], tgt.iloc[i] if len(tgt) > i else gas.iloc[i], float(loss.iloc[i]), decline)
        f = go.Figure(go.Waterfall(x=wb.step, y=wb.value / 1e6, measure=["absolute", "relative", "relative", "relative", "total"]))
        f.update_layout(title=f"Target → actual, {gas.index[i]:%b %Y} (MMSm3/d)")
        ctx.plot(f, 340, key="mg_gap")
        if dt is None:
            st.caption("No downtime data: the whole non-decline gap shows as 'other / unexplained'.")
        if wt is not None:
            a, b = gas.index[j], gas.index[i]
            wbr = M.well_bridge(wt, a, b)
            if len(wbr):
                f = go.Figure(go.Bar(x=wbr.well, y=wbr.delta / 1e6, marker_color=np.where(wbr.delta < 0, RED, GREEN)))
                f.update_layout(title=f"Per-well change in last-known rate, {a:%Y-%m} → {b:%Y-%m} (MMSm3/d)")
                ctx.plot(f, 320, key="mg_wb")
                ctx.table(wbr)
                w = st.selectbox("Root-cause hints for", list(wbr.well))
                for h in M.root_cause_hints(wt, w):
                    st.write("• " + h)
                st.caption("Hints are rule-based trend flags (UNVALIDATED); confirm with well surveillance before acting.")
    with tabs[2]:
        b = ctx.canon("budget")
        if b is None:
            st.info("No budget loaded - using an editable illustrative table. Load `budget` (period, category, budget, actual) on the Data foundation page.")
            b = pd.DataFrame(dict(period=pd.date_range("2026-01-01", periods=12, freq="MS").repeat(2), category=["Workover", "Chemicals"] * 12, type=["CAPEX", "OPEX"] * 12,
                                  budget=[400e3, 120e3] * 12, actual=[380e3, 135e3] * 6 + [np.nan] * 12))
            b = st.data_editor(b, num_rows="dynamic", key="mg_bud")
        v = M.budget_variance(b)
        s = v.groupby("type")[["budget", "actual"]].sum()
        ctx.table(s.assign(variance=s.actual - s.budget).reset_index())
        g = v.groupby(["period", "type"])[["budget", "actual"]].sum().reset_index()
        f = go.Figure()
        for t_, c in (("CAPEX", BLUE), ("OPEX", ORANGE)):
            x = g[g.type == t_]
            f.add_trace(go.Bar(x=x.period, y=x.budget, name=f"{t_} budget", marker_color=c, opacity=.45))
            f.add_trace(go.Scatter(x=x.period, y=x.actual, name=f"{t_} actual", mode="lines+markers", line=dict(color=c)))
        ctx.plot(f, 340, key="mg_bud_f")
    with tabs[3]:
        st.caption("Editable register - the numbers below are ILLUSTRATIVE placeholders; replace with your project estimates.")
        reg = pd.DataFrame(dict(name=["Compression / lower WHP", "Acid / de-scaling", "Gas-lift conversion", "Water shut-off"], gain_boed=[1500.0, 400.0, 600.0, 300.0],
                                capex_usd=[8e6, 0.6e6, 2.5e6, 1.2e6], opex_usd_yr=[0.5e6, 0.05e6, 0.2e6, 0.05e6], decline_pct_yr=[15.0, 35.0, 20.0, 30.0]))
        reg = st.data_editor(reg, num_rows="dynamic", key="mg_reg")
        c = st.columns(3)
        price = c[0].number_input("Value $/boe", 5.0, 200.0, 45.0)
        disc = c[1].slider("Discount rate", 0.0, 0.3, 0.10)
        yrs = c[2].slider("Horizon years", 1, 15, 5, key="mg_oy")
        rk = M.rank_opportunities(reg.dropna(), price, disc, yrs)
        ctx.table(rk)
        f = go.Figure(go.Bar(x=rk.name, y=rk.npv_usd / 1e6, marker_color=BLUE))
        f.update_layout(title="NPV ($M)")
        ctx.plot(f, 300, key="mg_npv")
    with tabs[4]:
        lines = [f"Latest month gas: {gas.iloc[-1] / 1e6:.2f} MMSm3/d ({act.status.value}).", f"Target basis: {why}."]
        if "cond" in m and m.cond.notna().any():
            lines.append(f"Condensate: {m.cond.dropna().iloc[-1]:.0f} m3/d.")
        if fc is not None and len(fc):
            lines.append(f"Forecast P50 at +{yrs} y: {fc.gas_p50.iloc[-1] / 1e6:.2f} MMSm3/d (P10-P90 {fc.gas_p10.iloc[-1] / 1e6:.2f}-{fc.gas_p90.iloc[-1] / 1e6:.2f}).")
        lines.append("All volumes from tests are interpolated unless production_daily is loaded.")
        st.markdown("\n".join("- " + l for l in lines))
        st.download_button("Download summary (txt)", "\n".join(lines), "executive_summary.txt")
