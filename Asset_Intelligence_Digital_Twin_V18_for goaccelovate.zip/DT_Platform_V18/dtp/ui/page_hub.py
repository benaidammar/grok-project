"""Engineering knowledge hub: 100+ structured topics, search, learning paths, calculators, glossary, roadmap."""
from __future__ import annotations
import pandas as pd

from ..hub import calculators as C, engine as E

GLOSSARY = {
    "AOF": "Absolute open flow: rate at pwf = 1 bar from a back-pressure fit; extrapolated, treat with care.", "BHP/WHP": "Bottomhole / wellhead flowing pressure.", "CGR": "Condensate-gas ratio, m3 condensate per MMSm3 gas.",
    "WGR": "Water-gas ratio, m3/MMSm3.", "Pd": "Dew-point pressure.", "Pr": "Average reservoir pressure.", "GIIP": "Gas initially in place.", "EUR": "Estimated ultimate recovery.", "BEP": "Best efficiency point of a pump.",
    "VSD": "Variable speed drive.", "GVF": "Gas volume fraction at pump intake.", "PPRL/MPRL": "Peak / minimum polished-rod load.", "GLPC": "Gas-lift performance curve.", "FcD": "Dimensionless fracture conductivity.",
    "ISIP": "Instantaneous shut-in pressure.", "DFIT": "Diagnostic fracture injection test.", "MMP": "Minimum miscibility pressure.", "MRV": "Monitoring, reporting, verification.", "LCOC": "Levelised cost of CO2 captured.",
    "CCUS": "Carbon capture, utilisation and storage.", "TOPSIS": "Multi-criteria ranking by closeness to the ideal solution.", "UNVALIDATED": "Platform status: model not yet validated on this asset's data.", "MoC": "Management of change.",
    "Sm3": "Standard cubic metre (15 °C, 1 atm).", "PSS": "Pseudo-steady state.", "PINN": "Physics-informed neural network.", "T2/SPE": "Hotelling statistic / squared prediction error from PCA.", "AFT": "Accelerated failure time (survival model).",
}


def _topic_view(ctx, t):
    st = ctx.st
    st.markdown(f"#### {t['title']}  \n`{t['domain']}` · `{t['level']}` · {t['maturity']}")
    st.write(t["summary"])
    c = st.columns(2)
    c[0].markdown("**Why it matters**  \n" + t["why_it_matters"])
    c[1].markdown(f"**When to use**  \n{t['when_to_use']}  \n**When NOT to use**  \n{t['when_NOT_to_use']}")
    for e in t["key_equations"]:
        st.latex(e["latex"])
        if e["variables"]:
            st.caption(f"{e['name']}: {e['variables']}")
    for key, lab in (("workflow_steps", "Workflow"), ("inputs_needed", "Inputs"), ("outputs", "Outputs"), ("assumptions_limits", "Assumptions & limits"),
                     ("common_pitfalls", "Common pitfalls"), ("validation_checks", "Validation checks")):
        if t[key]:
            with st.expander(lab):
                for x in t[key]:
                    st.write("• " + x)
    if t["python_entry_points"]:
        st.caption("Code: " + ", ".join(f"`{x}`" for x in t["python_entry_points"]))
    if t["platform_tool"]:
        st.caption("Platform tool: **" + t["platform_tool"] + "**")
    if t["references"]:
        st.caption("References: " + " | ".join(t["references"]))
    if t["related"]:
        st.caption("Related: " + ", ".join(t["related"]))
    st.download_button("Download topic (.md)", E.to_markdown(t), f"{t['id']}.md", key=f"dl_{t['id']}")


def render(ctx):
    st = ctx.st
    st.header("7 · Engineering knowledge hub")
    topics = E.load_all_topics()
    st.caption(f"{len(topics)} structured topics across {len(E.domains())} domains - each with equations, workflow, limits, pitfalls, validation checks, code entry points and references.")
    tabs = st.tabs(["Search & browse", "Learning paths", "Calculators", "Glossary", "Roadmap & concept map", "Library export"])
    with tabs[0]:
        c = st.columns([3, 1, 1])
        q = c[0].text_input("Search (e.g. 'liquid loading', 'CO2 quantity', 'survival')", key="hub_q")
        dom = c[1].selectbox("Domain", ["all"] + E.domains())
        lvl = c[2].selectbox("Level", ["all"] + E.LEVELS)
        hits = E.search(q, None if dom == "all" else dom, None if lvl == "all" else lvl) if q else [t for t in sorted(topics, key=lambda t: (t["domain"], t["title"]))
                                                                                                    if (dom == "all" or t["domain"] == dom) and (lvl == "all" or t["level"] == lvl)]
        st.write(f"{len(hits)} topics")
        if hits:
            lab = {f"{t['domain']} · {t['title']} ({t['level']})": t for t in hits}
            pick = st.selectbox("Open topic", list(lab), key="hub_pick")
            _topic_view(ctx, lab[pick])
            with st.expander("All matching topics"):
                ctx.table(pd.DataFrame([dict(domain=t["domain"], title=t["title"], level=t["level"], summary=t["summary"]) for t in hits]))
    with tabs[1]:
        p = st.selectbox("Learning path", list(E.LEARNING_PATHS))
        for i, tid in enumerate(E.LEARNING_PATHS[p], 1):
            t = E.topic_by_id(tid)
            if t:
                with st.expander(f"{i}. {t['title']}"):
                    st.write(t["summary"])
                    if t["workflow_steps"]:
                        st.caption("Steps: " + " → ".join(t["workflow_steps"]))
    with tabs[2]:
        st.subheader("CO2 quantity from gas rate and CO2 %")
        c = st.columns(4)
        gas = c[0].number_input("Gas rate Sm3/d", 0.0, 1e9, 1e6, step=1e5, format="%.0f")
        pct = c[1].number_input("CO2 mol %", 0.0, 100.0, float(ctx.cfg.co2_pct))
        yrs = c[2].number_input("Years", 0.0, 60.0, 15.0)
        r = C.co2_from_gas(gas, pct, yrs)
        ctx.metrics([("CO2 t/d", f"{r['t_per_day']:.1f}"), ("CO2 t/yr", f"{r['t_per_year']:,.0f}"), (f"Over {yrs:g} y", f"{r['over_years_Mt']:.2f} Mt"), ("CO2 Sm3/d", f"{r['co2_sm3d']:,.0f}")])
        st.caption("Uses ρ(CO2, std) = 1.872 kg/Sm3. The same number drives the CCUS page; there you can also pick capture and utilisation options.")
        st.subheader("Pressure conversion")
        c = st.columns(4)
        v = c[0].number_input("Value", 0.0, 1e6, 100.0)
        a = c[1].selectbox("From", ["bara", "barg", "psia", "psig", "kPa", "MPa"])
        b = c[2].selectbox("To", ["bara", "barg", "psia", "psig", "kPa", "MPa"], index=2)
        c[3].metric("Result", f"{C.pressure_convert(v, a, b):.3f} {b}")
        st.subheader("Hydrostatic gradient")
        c = st.columns(3)
        rho = c[0].number_input("Density kg/m3", 1.0, 1500.0, 850.0)
        h = c[1].number_input("Height m", 0.0, 8000.0, 1000.0)
        c[2].metric("Pressure", f"{C.gradient_to_pressure(rho, h):.1f} bar")
    with tabs[3]:
        f = st.text_input("Filter glossary", key="gl_q").lower()
        ctx.table(pd.DataFrame([(k, v) for k, v in GLOSSARY.items() if f in k.lower() or f in v.lower()], columns=["term", "meaning"]))
    with tabs[4]:
        ctx.table(pd.DataFrame(E.ROADMAP, columns=["version", "theme", "content", "status"]))
        ctx.table(pd.DataFrame(E.PHASES, columns=["phase", "name", "where"]))
        try:
            import networkx as nx
            G = E.concept_graph()
            st.caption(f"Concept graph: {G.number_of_nodes()} topics, {G.number_of_edges()} links. Most connected: " +
                       ", ".join(f"{n} ({d})" for n, d in sorted(G.degree, key=lambda x: -x[1])[:6]))
        except Exception:                                              # noqa: BLE001
            pass
    with tabs[5]:
        st.download_button("Download the whole library (.md)", E.library_markdown(), "dtp_knowledge_library.md")
        ctx.table(E.library_df())
