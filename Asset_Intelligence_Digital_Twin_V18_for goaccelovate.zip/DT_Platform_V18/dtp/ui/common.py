"""Shared UI helpers.  Every page is `def render(ctx)` and receives a Ctx."""
from __future__ import annotations
import io
from dataclasses import dataclass, field
from typing import Any, Callable

import pandas as pd

from ..core.config import AssetConfig
from ..core.status import ICON, Result, Status

BLUE, ORANGE, GRAY, RED, GREEN, PURPLE, TEAL = "#2a6fdb", "#d9822b", "#8a8f98", "#c0392b", "#2e9e5b", "#7b5ea7", "#1b9aaa"
PALETTE = [BLUE, ORANGE, GREEN, RED, PURPLE, TEAL, "#b5651d", "#e377c2", "#7f7f7f", "#bcbd22"]


@dataclass
class Dataset:
    kind: str
    name: str
    raw: pd.DataFrame
    mapping: dict
    canon: pd.DataFrame | None
    report: Any = None
    units: Any = None
    qc: pd.DataFrame | None = None
    source: str = "upload"          # upload | sample | demo
    notes: list = field(default_factory=list)


class Ctx:
    """Passed to every page. Holds the datasets, the asset configuration and small UI helpers."""

    def __init__(self, st, cfg: AssetConfig, datasets: dict[str, Dataset]):
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots
        self.st, self.cfg, self.datasets = st, cfg, datasets
        self.go, self.make_subplots = go, make_subplots

    # ---- data access ------------------------------------------------------------------
    def has(self, kind: str) -> bool:
        d = self.datasets.get(kind)
        return d is not None and d.canon is not None and len(d.canon) > 0

    def canon(self, kind: str) -> pd.DataFrame | None:
        return self.datasets[kind].canon if self.has(kind) else None

    def dataset(self, kind: str) -> Dataset | None:
        return self.datasets.get(kind)

    def need(self, kind: str, hint: str = "") -> pd.DataFrame | None:
        """Return the canonical frame or show an info box and return None."""
        df = self.canon(kind)
        if df is None:
            from ..core.schema import KINDS
            self.st.info(f"**{KINDS[kind].title}** not loaded. {hint} Load it on the **Data foundation** page "
                         f"(upload, or *Load Field sample*), or use the demo-data switch on this page when it offers one.")
        return df

    def wells(self) -> list:
        w = self.canon("well_tests")
        if w is not None:
            return sorted(w["well"].unique())
        n = self.canon("network")
        if n is not None:
            return sorted(n.loc[n["identity"] == "well", "site"])
        return []

    # ---- memo / logging -------------------------------------------------------------------
    def memo(self, key, compute: Callable):
        store = self.st.session_state.setdefault("_memo", {})
        if key not in store:
            if len(store) > 40:
                store.clear()
            store[key] = compute()
        return store[key]

    def log(self, module: str, action: str, **kw):
        from ..core.registry import log_event
        log_event(module, action, **kw)

    # ---- rendering ---------------------------------------------------------------------------
    def status(self, res: Result, show_assumptions: bool = True):
        """Visible status line + messages + assumptions. A FAIL result must never be shown as numbers."""
        box = {Status.OK: self.st.success, Status.WARN: self.st.warning, Status.FAIL: self.st.error,
               Status.UNVALIDATED: self.st.warning}[res.status]
        box(f"{res.badge()} - {res.name}" + (f": {res.messages[0]}" if res.messages and res.status == Status.FAIL else ""))
        extra = res.messages[1:] if res.status == Status.FAIL else res.messages
        for m in extra:
            self.st.caption("• " + m)
        if show_assumptions and res.assumptions:
            with self.st.expander(f"Assumptions used ({len(res.assumptions)}) - replace them with your data", expanded=False):
                for a in res.assumptions:
                    self.st.write("• " + str(a))

    def assume_banner(self, keys: list, label: str = ""):
        miss = self.cfg.assumed(*keys)
        if miss:
            self.st.caption(f"⚠️ Still on default values in the asset configuration: **{', '.join(miss)}** {label} - "
                            f"edit them in *Data foundation → Asset configuration*.")

    def plot(self, fig, h: int = 420, key: str | None = None):
        fig.update_layout(template="plotly_white", height=h, margin=dict(l=10, r=10, t=45, b=10),
                          legend=dict(orientation="h", y=1.1, x=0))
        try:
            self.st.plotly_chart(fig, width="stretch", key=key)
        except TypeError:
            self.st.plotly_chart(fig, use_container_width=True, key=key)

    def table(self, df: pd.DataFrame, **kw):
        try:
            self.st.dataframe(df, width="stretch", **kw)
        except TypeError:
            self.st.dataframe(df, use_container_width=True, **kw)

    def download_df(self, label: str, df: pd.DataFrame, filename: str, key: str | None = None):
        self.st.download_button(label, df.to_csv(index=False).encode("utf-8"), file_name=filename, mime="text/csv",
                                key=key or f"dl_{filename}_{label}")

    def metrics(self, items: list, cols: int | None = None):
        """items = [(label, value_str, delta_or_None), ...]"""
        cs = self.st.columns(cols or len(items))
        for c, it in zip(cs, items):
            c.metric(it[0], it[1], it[2] if len(it) > 2 else None)

    def template_buttons(self, kinds: list):
        from ..core.schema import KINDS, template
        cs = self.st.columns(len(kinds))
        for c, k in zip(cs, kinds):
            c.download_button(f"Template: {KINDS[k].title}", template(k).to_csv(index=False, sep=";").encode("utf-8"),
                              file_name=f"template_{k}.csv", mime="text/csv", key=f"tpl_{k}_{id(self)}")

    def section_intro(self, what: str, needs: str, outputs: str):
        self.st.markdown(what)
        c = self.st.columns(2)
        c[0].caption("**Data it uses:** " + needs)
        c[1].caption("**What you get:** " + outputs)

    def guard(self, name: str, fn: Callable, *a, **kw):
        """Run fn; on exception show a FAIL box instead of crashing the page. Returns fn's value or None."""
        try:
            return fn(*a, **kw)
        except Exception as exc:            # noqa: BLE001
            self.st.error(f"🔴 FAIL - {name}: {type(exc).__name__}: {exc}")
            with self.st.expander("Technical details"):
                import traceback
                self.st.code(traceback.format_exc())
            return None
