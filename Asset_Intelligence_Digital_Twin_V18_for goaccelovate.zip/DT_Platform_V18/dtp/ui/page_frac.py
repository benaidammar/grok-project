"""Hydraulic fracturing: screening -> geomechanics -> design -> treatment monitoring -> flowback / evaluation."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..frac import analysis as A, design as D, geomech as G
from .common import BLUE, GRAY, GREEN, ORANGE, RED


def _tab_screen(ctx):
    st, go = ctx.st, ctx.go
    ctx.section_intro("Rank wells for stimulation from test-based productivity and volumes.", "well_tests + Pr in the asset configuration.", "Candidate ranking (screening).")
    wt = ctx.need("well_tests", "")
    if wt is None:
        return
    ctx.assume_banner(["p_res_now_bara"])
    d = A.screen_candidates(wt, ctx.cfg)
    ctx.table(d)
    f = go.Figure(go.Bar(x=d.well, y=d.score, marker_color=BLUE))
    f.update_layout(title="Candidate score 0-100 (low productivity proxy + high cum)")
    ctx.plot(f, 300, key="fr_sc")
    st.caption("Proxy only: PIg = q/(Pr²-WHP²) depends on the assumed Pr. A low value can equally mean damage, loading or depletion - screen with well tests and logs first. UNVALIDATED.")


def _tab_geomech(ctx):
    st, go = ctx.st, ctx.go
    ctx.section_intro("Stress profile from logs: overburden, pore pressure, sh_min, brittleness, barrier contrast.", "log table (depth_m, e_gpa, nu, optional rho_b, pp_bar) - or demo.", "Profile plot + frac-quality score.")
    up = st.file_uploader("Log CSV (depth_m, e_gpa, nu, rho_b, pp_bar)", type=["csv"], key="fr_log")
    if up is not None:
        from ..core.ingest import read_table
        log = read_table(up)
        log = log.value if hasattr(log, "value") else log
    else:
        z = np.arange(3000.0, 3120.0, 2.0)
        rng = np.random.default_rng(0)
        shale = (np.sin(z / 9) > 0.4)
        log = pd.DataFrame(dict(depth_m=z, e_gpa=np.where(shale, 28.0, 45.0) + rng.normal(0, 1, len(z)), nu=np.where(shale, 0.30, 0.20) + rng.normal(0, .005, len(z)),
                                rho_b=np.where(shale, 2550.0, 2450.0), porosity=np.where(shale, 0.04, 0.10), perm_md=np.where(shale, 1e-4, 0.05)))
        st.caption("Demo log (synthetic).")
    r = G.stress_profile(log)
    ctx.status(r)
    if r.value is not None:
        v = r.value
        f = ctx.make_subplots(rows=1, cols=3, shared_yaxes=True, subplot_titles=("Stress (bar)", "E static GPa / nu", "Brittleness"))
        for c, col in (("sv_bar", GRAY), ("sh_bar", RED), ("pp_bar", BLUE)):
            f.add_trace(go.Scatter(x=v[c], y=v.depth_m, name=c, line=dict(color=col)), row=1, col=1)
        f.add_trace(go.Scatter(x=v.e_static_gpa, y=v.depth_m, name="E_static", line=dict(color=ORANGE)), row=1, col=2)
        f.add_trace(go.Scatter(x=v.bi, y=v.depth_m, name="BI", line=dict(color=GREEN)), row=1, col=3)
        f.update_yaxes(autorange="reversed")
        ctx.plot(f, 460, key="fr_gm")
        v = v.assign(quality=G.quality_score(v))
        if "porosity" in v:
            ctx.table(v[["depth_m", "sh_bar", "bi", "quality"]].sort_values("quality", ascending=False).head(10))
        st.caption("Uncalibrated until tied to DFIT/minifrac closure pressure.")


def _tab_design(ctx):
    st, go = ctx.st, ctx.go
    ctx.section_intro("Fracture geometry (PKN/KGD/Radial + Carter leak-off), conductivity (FcD), productivity ratio, pump schedule and constrained DOE optimisation.",
                      "typed inputs.", "Geometry, JR, risk flags, pump schedule, optimum + Pareto.")
    c = st.columns(5)
    base = D.FracInputs(q_m3min=c[0].number_input("Rate m3/min", 1.0, 30.0, 8.0), t_min=c[1].number_input("Pump time min", 10.0, 300.0, 60.0), h_m=c[2].number_input("Height m", 5.0, 200.0, 40.0),
                        e_gpa=c[3].number_input("E GPa", 5.0, 80.0, 30.0), nu=c[4].number_input("nu", 0.1, 0.4, 0.22), mu_cp=c[0].number_input("Fluid cP", 1.0, 500.0, 30.0),
                        geometry=c[1].selectbox("Geometry", ["PKN", "KGD", "Radial"]))
    res_in = dict(k_md=c[2].number_input("k mD", 1e-4, 100.0, 0.05, format="%.4f"), closure_bar=c[3].number_input("Closure bar", 50.0, 1000.0, 450.0), p_net_max_bar=c[4].number_input("Max net bar", 5.0, 300.0, 80.0),
                  d_prop_mm=0.6)
    mass = c[0].number_input("Proppant kg", 1e3, 5e5, 50000.0)
    o = D.evaluate(dict(prop_kg=mass), base, res_in)
    ctx.metrics([("Frac half-length m", f"{o['L_m']:.0f}"), ("Propped xf m", f"{o['xf_prop_m']:.0f}"), ("w_avg mm", f"{o['w_avg_mm']:.1f}"), ("Net pressure bar", f"{o['p_net_bar']:.0f}"),
                 ("Fluid efficiency", f"{o['eta']:.0%}"), ("FcD", f"{o['FcD']:.1f}"), ("JR", f"{o['JR']:.2f}")])
    if not o["p_net_ok"]: st.error("Net pressure exceeds the limit (barrier breach risk).")
    if o["width_ratio"] < 1: st.warning("Width < 3 grain diameters: bridging / screen-out risk.")
    sch = D.pump_schedule(base.q_m3min, base.t_min, o["eta"], mass)
    if sch.value is not None:
        ctx.table(sch.value)
    st.subheader("Constrained optimisation (DOE + surrogate check)")
    if st.button("Run optimisation", key="fr_opt"):
        b = dict(prop_kg=(20000, 150000), q_m3min=(4, 14), t_min=(40, 120), mu_cp=(5, 60))
        r = D.optimise(base, res_in, b, n=400)
        ctx.status(r)
        if r.value and r.value.get("best") is not None:
            st.write(r.value["best"][["prop_kg", "q_m3min", "t_min", "mu_cp", "L_m", "JR", "net_usd"]].to_frame().T)
            p = r.value["pareto"]
            f = go.Figure(go.Scatter(x=p.prop_kg, y=p.JR, mode="lines+markers"))
            f.update_layout(title="Pareto: proppant mass vs JR", xaxis_title="kg", yaxis_title="JR")
            ctx.plot(f, 300, key="fr_par")
    st.caption("SCREENING only; use a validated 3D simulator, offset calibration and MoC before execution.")


def _tab_treat(ctx):
    st, go = ctx.st, ctx.go
    ctx.section_intro("Treatment-pressure diagnostics: ISIP, closure, Nolte-Smith regime and stage statistics.", "frac_ts (time, pressure, rate), frac_stage - or demo.", "Regime flag + plots.")
    ts = ctx.canon("frac_ts")
    if ts is None:
        mode = st.radio("Demo treatment", ["normal", "screenout"], horizontal=True)
        ts = A.synth_treatment(mode=mode)
        st.caption("Demo (synthetic).")
    cl = st.number_input("Closure pressure bar (0 = estimate)", 0.0, 1500.0, 380.0)
    r = A.treatment_diagnostics(ts, cl or None)
    ctx.status(r)
    if r.value:
        v = r.value
        ctx.metrics([("ISIP bar", f"{v['isip']:.0f}"), ("Net pressure bar", f"{v.get('net_pressure_end', np.nan):.0f}"), ("Nolte slope", f"{v.get('nolte_slope', np.nan):.2f}"), ("Avg HHP kW", f"{v['hhp_kw']:,.0f}")])
        st.info(f"Regime: {v.get('regime', 'n/a')}")
    f = ctx.make_subplots(rows=1, cols=1, specs=[[{"secondary_y": True}]])
    f.add_trace(go.Scatter(x=ts.time, y=ts.pressure, name="Pressure bar", line=dict(color=RED)), secondary_y=False)
    f.add_trace(go.Scatter(x=ts.time, y=ts.rate, name="Rate m3/min", line=dict(color=BLUE)), secondary_y=True)
    ctx.plot(f, 360, key="fr_ts")
    sg = ctx.canon("frac_stage")
    if sg is not None:
        ctx.table(A.stage_stats(sg))


def _tab_flow(ctx):
    st, go = ctx.st, ctx.go
    ctx.section_intro("Flowback clean-up and load recovery.", "daily gas/water after the job (production_daily or demo).", "Clean-up day, load recovery.")
    pdv = ctx.canon("production_daily")
    if pdv is not None and {"gas", "water"} <= set(pdv.columns) and st.toggle("Use production_daily (first 60 days)", False):
        d = pdv.groupby("date")[["gas", "water"]].sum().reset_index().rename(columns={"gas": "gas_sm3d", "water": "water_m3d"}).head(60)
    else:
        d = A.synth_flowback()
        st.caption("Demo flowback (synthetic).")
    load = st.number_input("Fluid pumped m3 (load)", 10.0, 1e5, 3000.0)
    r = A.flowback_eval(d, load)
    ctx.status(r)
    t = r.value["table"]
    f = ctx.make_subplots(rows=1, cols=1, specs=[[{"secondary_y": True}]])
    f.add_trace(go.Scatter(x=t.date, y=t.gas_sm3d / 1e3, name="Gas kSm3/d", line=dict(color=ORANGE)), secondary_y=False)
    f.add_trace(go.Scatter(x=t.date, y=t.water_m3d, name="Water m3/d", line=dict(color=BLUE)), secondary_y=True)
    ctx.plot(f, 340, key="fr_fb")
    ctx.metrics([("Load recovered", f"{r.value['load_rec_pct']:.0f} %"), ("Clean-up day", str(r.value["cleanup_day"]))])


def render(ctx):
    st = ctx.st
    st.header("4 · Hydraulic fracturing")
    tabs = st.tabs(["Screening", "Geomechanics", "Design & optimisation", "Treatment monitoring", "Flowback & evaluation"])
    for t, fn in zip(tabs, (_tab_screen, _tab_geomech, _tab_design, _tab_treat, _tab_flow)):
        with t:
            try:
                fn(ctx)
            except Exception as e:                                     # noqa: BLE001
                st.error(f"FAIL - {type(e).__name__}: {e}")
