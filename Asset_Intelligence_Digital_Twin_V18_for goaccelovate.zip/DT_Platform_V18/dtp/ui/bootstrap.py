"""Session state, dataset ingestion and Ctx construction (used by app.py and by the test runner)."""
from __future__ import annotations
from pathlib import Path

import pandas as pd

from ..core import qc as QC
from ..core import schema as S
from ..core.config import AssetConfig
from ..core.ingest import read_table
from .common import Ctx, Dataset

ROOT = Path(__file__).resolve().parents[2]
SAMPLE_DIR = ROOT / "sample_data"
SAMPLES = {"well_tests": "rates.csv", "network": "Network_field.csv"}


def ingest_dataset(kind: str, source, name: str, cfg: AssetConfig, mapping: dict | None = None, units: S.UnitChoice | None = None,
                   sheet=None, dayfirst: bool = True, tag: str = "upload") -> Dataset:
    raw, rep = read_table(source, sheet=sheet, dayfirst=dayfirst, name=name)
    mp = mapping or S.suggest_mapping(raw, kind)
    notes = list(rep.notes)
    canon, qc, u = None, None, units
    try:
        if kind == "well_tests":
            if u is None:
                u, why = S.guess_units(raw, mp)
                notes += why
            canon = S.normalize_well_tests(raw, mp, u)
            qc = QC.qc_well_tests(canon)
        elif kind == "network":
            u = u or S.UnitChoice()
            canon, n2 = S.normalize_network(raw, mp, u)
            notes += n2
            qc = QC.qc_network(canon)
        else:
            canon = S.normalize_generic(raw, mp)
            u = u or S.UnitChoice()
            missing = [c for c in S.KINDS[kind].required if mp.get(c) is None]
            if missing:
                notes.append("Required columns not matched: " + ", ".join(missing))
                canon = None
    except Exception as exc:                                  # noqa: BLE001
        notes.append(f"Normalisation failed: {type(exc).__name__}: {exc}")
        canon = None
    cfg.units[kind] = vars(u) if u is not None else {}
    return Dataset(kind=kind, name=name, raw=raw, mapping=mp, canon=canon, report=rep, units=u, qc=qc, source=tag, notes=notes)


def get_state(st) -> tuple[AssetConfig, dict]:
    if "cfg" not in st.session_state:
        st.session_state["cfg"] = AssetConfig()
    if "datasets" not in st.session_state:
        st.session_state["datasets"] = {}
    return st.session_state["cfg"], st.session_state["datasets"]


def load_sample(st, kind: str) -> Dataset:
    cfg, ds = get_state(st)
    f = SAMPLE_DIR / SAMPLES[kind]
    ds[kind] = ingest_dataset(kind, f, f.name, cfg, tag="sample")
    return ds[kind]


def autoload_sample(st):
    """Used by tests / DTP_AUTOLOAD_SAMPLE=1: preload the Field sample."""
    cfg, ds = get_state(st)
    if not st.session_state.get("_sample_loaded"):
        for k in SAMPLES:
            if k not in ds:
                load_sample(st, k)
        cfg.asset_name = "Field cluster (sample)"
        cfg.country = "Algeria"
        st.session_state["_sample_loaded"] = True


def build_ctx(st) -> Ctx:
    import os
    cfg, ds = get_state(st)
    if os.environ.get("DTP_AUTOLOAD_SAMPLE") == "1":
        autoload_sample(st)
    return Ctx(st, cfg, ds)
