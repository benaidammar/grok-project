"""Advanced AI lab - benchmark first, complexity only when it wins."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..ai import datasets as DS, lab
from ..core.registry import log_event, register_model
from .common import BLUE, GRAY, GREEN, ORANGE, RED


def _grids(wt, var="gas_sm3d"):
    org = DS.global_origin(wt)
    out = []
    for w, s in DS.raw_by_well(wt, var, 6).items():
        g = DS.to_grid(s, org, 6, well=w)
        if g is not None:
            out.append(g)
    return out


def render(ctx):
    st, go = ctx.st, ctx.go
    st.header("6 · Advanced AI lab")
    st.info("Handbook rule: advanced AI is selected **only after benchmarking** against simple physical baselines. Every model here is UNVALIDATED until you approve it in *Governance*; "
            "agents only **propose** actions - nothing is executed or sent to control systems.")
    wt = ctx.canon("well_tests")
    tabs = st.tabs(["Benchmark", "Hybrid & PINN", "Graph (network)", "Surveillance agent", "Method guide"])
    with tabs[0]:
        src = "your well tests" if wt is not None else "synthetic fleet"
        use = st.radio("Data", [src, "synthetic fleet (known truth)"], horizontal=True) if wt is not None else "synthetic fleet (known truth)"
        grids = _grids(wt) if use == "your well tests" else list(DS.synth_fleet(8, 44, kind=st.selectbox("Truth", ["exp", "arps"])).values())
        c = st.columns(3)
        h = c[0].slider("Horizon (semi-annual cells)", 1, 8, 4)
        no = c[1].slider("Rolling origins", 1, 5, 3)
        tor = c[2].toggle("Include small torch MLP", False)
        st.caption(f"{len(grids)} wells on a 6-month grid. Interpolated gap cells are not counted as observations.")
        if st.button("Run benchmark", key="ai_bm") or st.session_state.get("_ai_bm_done") == use:
            r = ctx.memo(("bm", use, h, no, tor, len(grids)), lambda: lab.benchmark(grids, h, no, tor))
            st.session_state["_ai_bm_done"] = use
            ctx.status(r)
            if r.value:
                s = r.value["summary"]
                ctx.table(s)
                f = go.Figure(go.Bar(x=s.model, y=s.skill_vs_naive_pct, marker_color=[GREEN if v > 0 else RED for v in s.skill_vs_naive_pct]))
                f.update_layout(title="Skill vs persistence (%) - positive = better", yaxis_title="%")
                ctx.plot(f, 320, key="ai_sk")
                st.success(f"Best on this data: **{r.value['best']}**; typical 90 % error band ≈ ±{lab.conformal_interval(r.value['detail'], r.value['best']):.0%} of level.")
                if st.button("Register best model in the model registry (UNVALIDATED)"):
                    register_model(f"rate_forecast_{r.value['best']}", "well-rate forecasting", f"{use}", ["rate lags"], {"mae_scaled": float(s.mae.min())}, "benchmark-only")
                    st.write("Registered.")
    with tabs[1]:
        t, q, tr = DS.synth_decline(14, d=0.35, b=0.5, noise=0.03)
        cut = st.slider("Use only the first N points for fitting", 6, len(t), 9)
        p = lab.pinn_decline(t[:cut], q[:cut], steps=st.select_slider("PINN training steps", [300, 800, 1500], 800))
        ctx.status(p)
        f = go.Figure()
        f.add_trace(go.Scatter(x=t[:cut], y=q[:cut], mode="markers", name="fit data", marker_color=BLUE))
        f.add_trace(go.Scatter(x=t[cut:], y=q[cut:], mode="markers", name="held-out", marker=dict(color=GRAY, symbol="x")))
        tt = np.linspace(0, t.max() * 1.2, 80)
        f.add_trace(go.Scatter(x=tt, y=DS.arps(tt, tr["qi"], tr["d"], tr["b"]), name="truth", line=dict(color="black", dash="dot")))
        g = DS.Grid("x", np.round(t[:cut] * 10).astype(int), q[:cut], np.ones(cut, bool))
        ar = lab._arps_fit(g)
        if ar is not None:
            (d, b), tg, q0 = ar
            f.add_trace(go.Scatter(x=tt, y=q0 * (1 + b * d * tt * 10) ** (-1 / b), name="Arps fit", line=dict(color=ORANGE)))
        if p.value:
            f.add_trace(go.Scatter(x=p.value["t"], y=p.value["q"], name="PINN", line=dict(color=GREEN)))
            st.caption(f"PINN learned D={p.value['D']:.2f}, b={p.value['b']:.2f} (true d={tr['d']}, b={tr['b']}).")
        ctx.plot(f, 380, key="ai_pinn")
        st.caption("Synthetic data with known truth - the point is to compare fairly before trusting a physics-informed net on real wells.")
    with tabs[2]:
        net = ctx.canon("network")
        if net is None:
            st.info("Load the network dataset for the graph demo.")
        else:
            adj = {}
            for _, r in net.dropna(subset=["to_node"]).iterrows():
                adj.setdefault(r.site, []).append(r.to_node); adj.setdefault(r.to_node, []).append(r.site)
            vals = {}
            if wt is not None:
                last = wt.sort_values("date").groupby("well").tail(1).set_index("well")
                vals = {w: float(last.loc[w, "whp_bara"]) for w in last.index if w in adj}
            st.write(f"Graph: {len(adj)} nodes, {sum(len(v) for v in adj.values()) // 2} edges. Wells with a WHP and node match: {len(vals)}.")
            if vals:
                sm = lab.graph_smooth(adj, vals, st.slider("Hops", 1, 4, 2), 0.5)
                ctx.table(pd.DataFrame(dict(well=list(vals), whp=list(vals.values()), neighbour_smoothed=[sm[w] for w in vals])))
                st.caption("Message-passing step of a GNN without learned weights: neighbour-aware features. A trained GNN needs far more labelled network states than a typical field provides; start from this feature and benchmark.")
    with tabs[3]:
        if wt is None:
            st.info("Needs well tests.")
        else:
            ag = lab.surveillance_agent(wt, ctx.cfg)
            st.write(f"{len(ag)} proposals (rule-based). Approve or reject - decisions are logged.")
            ctx.table(ag)
            if len(ag):
                i = st.number_input("Proposal #", 0, len(ag) - 1, 0)
                c = st.columns(2)
                if c[0].button("Approve (log only)"):
                    log_event("ai_agent", "proposal approved", **ag.iloc[int(i)].to_dict()); st.success("Logged. Execution stays with the field team.")
                if c[1].button("Reject"):
                    log_event("ai_agent", "proposal rejected", **ag.iloc[int(i)].to_dict()); st.info("Logged.")
    with tabs[4]:
        ctx.table(pd.DataFrame(dict(method=["Arps / exponential", "Ridge / GBM on lags", "Hybrid physics + ML", "PINN", "Transformer / LSTM", "GNN", "RL / agents"],
                                    when=["always first - sparse data, explainable", "many wells, regular sampling", "physics right on average, residual structure", "very sparse data with trusted ODE",
                                          "dense high-frequency sensors (ESP, SCADA)", "many connected nodes with states", "only in simulators with human approval"],
                                    data_needed=["5+ points", "10s of wells", "10s of wells", "5+ points + ODE choice", "100k+ samples", "100s of snapshots", "simulator"],
                                    risk=["low", "overfit", "moderate", "optimisation instability", "overfit, opaque", "data hungry", "safety"])))
