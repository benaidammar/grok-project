"""Managerial intelligence: production actual vs target vs forecast, gap decomposition, well-level root-cause bridge, budget variance, opportunity ranking."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..core.status import Result, Status
from ..gascond import forecast as F


def monthly_actual(wt: pd.DataFrame | None, pdaily: pd.DataFrame | None) -> Result:
    """Field monthly mean rates. production_daily (measured) is preferred; otherwise reconstructed from well tests (interpolated -> NOT allocated production)."""
    if pdaily is not None and len(pdaily):
        d = pdaily.copy()
        for c in ("gas", "cond", "water", "oil"):
            if c not in d:
                d[c] = np.nan
        if "well" in d:
            d = d.groupby("date")[["oil", "gas", "cond", "water"]].sum(min_count=1).reset_index()
        m = d.set_index("date")[["gas", "cond", "water", "oil"]].resample("MS").mean()
        return Result("Actual production (daily data)", m, Status.OK)
    if wt is None or wt.empty:
        return Result("Actual production", None, Status.FAIL, ["no production_daily and no well tests"])
    d = F.reconstruct_daily(wt)
    m = d.groupby("date")[["gas_sm3d", "cond_m3d", "water_m3d"]].sum(min_count=1)
    m = m.rename(columns={"gas_sm3d": "gas", "cond_m3d": "cond", "water_m3d": "water"}).resample("MS").mean()
    res = Result("Actual production (reconstructed from tests)", m, Status.UNVALIDATED,
                 ["Interpolated between sparse well tests: shows trend, NOT allocated/fiscal production. Load production_daily for measured values."])
    return res


def target_series(index, targets: pd.DataFrame | None, actual: pd.Series, pct_of_peak: float = 0.9) -> tuple[pd.Series, str]:
    if targets is not None and "target_gas" in targets and targets.target_gas.notna().any():
        t = targets.groupby("date").target_gas.sum().resample("MS").mean().reindex(index).interpolate(limit_direction="both")
        return t, "uploaded targets"
    peak = actual.rolling(12, min_periods=3).max().bfill()
    return peak * pct_of_peak, f"ASSUMED: {pct_of_peak:.0%} of trailing 12-month peak"


def downtime_loss(dt: pd.DataFrame | None, index) -> pd.Series:
    """Lost volume per month [Sm3/d-equivalent monthly mean] = sum(lost_rate x overlap days)/days in month."""
    out = pd.Series(0.0, index=index)
    if dt is None or dt.empty or "lost_rate" not in dt:
        return out
    for _, r in dt.dropna(subset=["start", "end"]).iterrows():
        for m in index:
            a, b = max(r.start, m), min(r.end, m + pd.offsets.MonthBegin(1))
            if b > a:
                out[m] += float(r.get("lost_rate", 0) or 0) * (b - a).days / m.days_in_month
    return out


def gap_bridge(actual: float, target: float, downtime: float, decline: float) -> pd.DataFrame:
    """Target -> actual waterfall. downtime = measured losses; decline = natural decline since reference (supplied); remainder = unexplained/other."""
    gap = target - actual
    other = gap - downtime - decline
    return pd.DataFrame({"step": ["Target", "Downtime / curtailment", "Natural decline", "Other / unexplained", "Actual"],
                         "value": [target, -downtime, -decline, -other, actual]})


def well_bridge(wt: pd.DataFrame, start, end, col="gas_sm3d", window_days=120) -> pd.DataFrame:
    """Change in last-known rate per well between two dates (median of tests within +-window). Waterfall by well + category."""
    rows = []
    for w, g in wt.groupby("well"):
        a = g[(g.date >= pd.Timestamp(start) - pd.Timedelta(days=window_days)) & (g.date <= pd.Timestamp(start) + pd.Timedelta(days=window_days))][col].median()
        b = g[(g.date >= pd.Timestamp(end) - pd.Timedelta(days=window_days)) & (g.date <= pd.Timestamp(end) + pd.Timedelta(days=window_days))][col].median()
        if np.isfinite(a) and np.isfinite(b):
            rows.append(dict(well=w, start=a, end=b, delta=b - a))
        elif np.isfinite(a):
            rows.append(dict(well=w, start=a, end=0.0, delta=-a))
        elif np.isfinite(b):
            rows.append(dict(well=w, start=0.0, end=b, delta=b))
    d = pd.DataFrame(rows)
    if d.empty:
        return d
    d["driver"] = np.where(d.start == 0, "new well / restart", np.where(d.end == 0, "shut-in / no recent test", np.where(d.delta < 0, "decline / loss", "gain")))
    return d.sort_values("delta")


def root_cause_hints(wt: pd.DataFrame, well: str) -> list[str]:
    g = wt[wt.well == well].sort_values("date").tail(6)
    h = []
    if len(g) < 3:
        return ["too few recent tests"]
    d = lambda c: g[c].iloc[-1] / g[c].iloc[0] - 1 if g[c].iloc[0] else np.nan
    if d("whp_bara") < -0.15: h.append(f"WHP down {d('whp_bara'):.0%}: reservoir depletion or back-pressure change")
    if "cgr_m3_mmsm3" in g and d("cgr_m3_mmsm3") < -0.25: h.append(f"CGR down {d('cgr_m3_mmsm3'):.0%}: condensate drop-out / banking risk")
    if "wgr_m3_mmsm3" in g and d("wgr_m3_mmsm3") > 0.5: h.append(f"WGR up {d('wgr_m3_mmsm3'):.0%}: water production growing (loading / water breakthrough)")
    if d("gas_sm3d") < -0.2 and abs(d("whp_bara")) < 0.05: h.append("rate down at constant WHP: skin / productivity loss, restriction or choke change")
    return h or ["no strong trend flag in the last 6 tests"]


def budget_variance(b: pd.DataFrame) -> pd.DataFrame:
    d = b.copy()
    d["period"] = pd.to_datetime(d["period"], errors="coerce")
    if "type" not in d:
        d["type"] = "OPEX"
    for c in ("actual", "forecast", "commitment"):
        if c not in d:
            d[c] = np.nan
    d["variance"] = d.actual - d.budget
    d["variance_pct"] = 100 * d.variance / d.budget.replace(0, np.nan)
    return d


def rank_opportunities(df: pd.DataFrame, oil_price_per_boe=60.0, disc=0.10, years=5) -> pd.DataFrame:
    """df columns: name, gain_boed, capex_usd, opex_usd_yr, decline_pct_yr. NPV of incremental barrels (simple exponential)."""
    d = df.copy()
    r = []
    for _, x in d.iterrows():
        t = np.arange(1, years + 1)
        q = x.gain_boed * (1 - x.decline_pct_yr / 100) ** (t - 1)
        cf = q * 365 * oil_price_per_boe - x.opex_usd_yr
        npv = -x.capex_usd + (cf / (1 + disc) ** t).sum()
        r.append((npv, npv / max(x.capex_usd, 1.0), x.capex_usd / max(x.gain_boed, 1e-9)))
    d["npv_usd"], d["pi"], d["usd_per_boed"] = zip(*r) if r else ([], [], [])
    return d.sort_values("npv_usd", ascending=False)


def selftest() -> dict:
    idx = pd.date_range("2020-01-01", periods=24, freq="MS")
    a = pd.Series(np.linspace(100, 70, 24), index=idx)
    t, why = target_series(idx, None, a)
    assert (t >= a * 0.89).all() and "ASSUMED" in why
    gb = gap_bridge(70, 90, 5, 10)
    assert abs(gb.value.iloc[1:4].sum() - (70 - 90)) < 1e-9
    wt = pd.DataFrame(dict(well=["A"] * 4 + ["B"] * 4, date=list(pd.date_range("2020", periods=4, freq="YS")) * 2, gas_sm3d=[10, 8, 6, 5, 4, 4, 5, 6.0], whp_bara=1.0))
    wb = well_bridge(wt, "2020-01-01", "2023-01-01", window_days=30)
    assert abs(wb.delta.sum() - (5 + 6 - 10 - 4)) < 1e-9
    op = rank_opportunities(pd.DataFrame(dict(name=["x"], gain_boed=[100.0], capex_usd=[1e6], opex_usd_yr=[1e5], decline_pct_yr=[20.0])))
    assert op.npv_usd.iloc[0] > 0
    return dict(npv=float(op.npv_usd.iloc[0]))
