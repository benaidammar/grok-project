"""ESP analysis on top of esp.py: PCA health monitor, run-life survival (lifelines or built-in Weibull), constrained frequency optimisation,
rule-based diagnostics + health score, gas handling, energy KPIs, Kaplan-Meier. Port of the V12 esp_twin ideas with fallbacks."""
from __future__ import annotations
from dataclasses import dataclass, replace

import numpy as np
import pandas as pd
from scipy.optimize import minimize, minimize_scalar
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from ..core.deps import try_import
from ..core.status import Result, Status
from ..gascond.pvt import GasPVT
from .esp import ESPSystem

lifelines = try_import("lifelines")
MONITOR_FEATURES = ["freq", "pintake", "dP", "tmotor", "current"]


def make_features(clean: pd.DataFrame) -> pd.DataFrame:
    x = clean.copy()
    x["dP"] = x["pdisch"] - x["pintake"]
    return x[MONITOR_FEATURES]


class PCAMonitor:
    """Hotelling T2 + SPE trained on a healthy period (thresholds from held-out healthy data)."""

    def __init__(self, var=0.95, quantile=0.995, margin=1.1):
        self.var, self.quantile, self.margin = var, quantile, margin

    def fit(self, X_train, X_calib):
        self.scaler = StandardScaler().fit(X_train)
        self.pca = PCA(n_components=self.var).fit(self.scaler.transform(X_train))
        s = self.score(X_calib)
        self.t2_lim, self.spe_lim = self.margin * s["T2"].quantile(self.quantile), self.margin * s["SPE"].quantile(self.quantile)
        return self

    def score(self, X):
        Z = self.scaler.transform(X)
        T = self.pca.transform(Z)
        return pd.DataFrame({"T2": (T ** 2 / self.pca.explained_variance_).sum(1), "SPE": ((Z - self.pca.inverse_transform(T)) ** 2).sum(1)}, index=X.index)

    def alarms(self, scores, steady=None, window=24, min_hits=18):
        hit = ((scores["T2"] > self.t2_lim) | (scores["SPE"] > self.spe_lim)).astype(float)
        if steady is not None:
            hit = hit.where(steady, 0.0)
        return hit.rolling(window).sum() >= min_hits

    def contributions(self, X):
        Z = self.scaler.transform(X)
        r = (Z - self.pca.inverse_transform(self.pca.transform(Z))) ** 2
        c = pd.Series(r.mean(0), index=X.columns)
        return 100 * c / c.sum()


# ---------------------------------------------------------------- survival
def fit_weibull(df: pd.DataFrame, dur: str, ev: str, covs: list[str]) -> Result:
    """Weibull AFT: lifelines if available, otherwise scipy MLE (log-time = b0 + b.x + sigma*eps). Returns coefficients table (time ratio) and rho."""
    d = df[[dur, ev] + covs].dropna()
    d = d[d[dur] > 0]
    if len(d) < 20 or d[ev].sum() < 6:
        return Result("Run-life survival", None, Status.FAIL, ["fewer than 20 runs / 6 failures: not enough to fit"])
    if lifelines is not None:
        aft = lifelines.WeibullAFTFitter(penalizer=1e-3).fit(d, dur, ev)
        tab = aft.summary.loc["lambda_"][["coef", "exp(coef)", "p"]].rename(columns={"exp(coef)": "time_ratio"})
        rho = float(np.exp(aft.params_.loc[("rho_", "Intercept")]))
        res = Result("Run-life survival (Weibull AFT, lifelines)", dict(table=tab, rho=rho, model=aft, data=d), Status.OK)
        res.value["predict_sf"] = lambda X, times: aft.predict_survival_function(X, times=times)
        return res
    X = np.column_stack([np.ones(len(d))] + [d[c].values for c in covs])
    t, e = d[dur].values, d[ev].values

    def nll(p):
        b, lns = p[:-1], p[-1]
        s = np.exp(lns)
        z = (np.log(t) - X @ b) / s
        return -(e * (z - lns - np.log(t)) - np.exp(z)).sum()
    r = minimize(nll, np.r_[np.log(t.mean()), np.zeros(len(covs)), 0.0], method="BFGS")
    b, s = r.x[:-1], float(np.exp(r.x[-1]))
    tab = pd.DataFrame({"coef": b, "time_ratio": np.exp(b)}, index=["Intercept"] + covs)

    def sf(Xn, times):
        xm = np.column_stack([np.ones(len(Xn))] + [Xn[c].values for c in covs])
        return pd.DataFrame(np.exp(-np.exp((np.log(np.asarray(times)[:, None]) - (xm @ b)[None, :]) / s)))
    return Result("Run-life survival (Weibull AFT, built-in MLE)", dict(table=tab, rho=1 / s, predict_sf=sf, data=d), Status.OK,
                  ["lifelines not installed: built-in maximum-likelihood fit (no p-values)."])


def kaplan_meier(t, e):
    d = pd.DataFrame(dict(t=t, e=e)).sort_values("t")
    n, s, rows = len(d), 1.0, [(0.0, 1.0)]
    for tt, g in d.groupby("t"):
        deaths = g.e.sum()
        s *= 1 - deaths / n
        n -= len(g)
        rows.append((tt, s))
    return pd.DataFrame(rows, columns=["t", "S"])


def failure_probability(res: Result, X: pd.DataFrame, age=0.0, horizon=180.0) -> np.ndarray:
    sf = res.value["predict_sf"](X, [max(age, 1e-6), age + horizon])
    return (1 - sf.iloc[1] / sf.iloc[0].clip(lower=1e-12)).values


# ---------------------------------------------------------------- optimisation
@dataclass
class Limits:
    f_min: float = 35.0
    f_max: float = 65.0
    p_intake_min: float = 60.0
    load_max: float = 0.95
    thrust_lo: float = 0.60
    thrust_hi: float = 1.15
    t_motor_max: float = 150.0


@dataclass
class Economics:
    water_cut: float = 0.35
    oil_value: float = 300.0
    water_cost: float = 3.0
    power_cost: float = 0.05


def violations(op, lim: Limits) -> dict:
    if op is None:
        return {"cannot_lift": 1.0}
    v = {"p_intake": (lim.p_intake_min - op["p_intake"]) / lim.p_intake_min, "motor_load": (op["load"] - lim.load_max) / lim.load_max,
         "downthrust": (lim.thrust_lo - op["thrust_ratio"]) / lim.thrust_lo, "upthrust": (op["thrust_ratio"] - lim.thrust_hi) / lim.thrust_hi,
         "t_motor": (op["t_motor"] - lim.t_motor_max) / lim.t_motor_max}
    return {k: x for k, x in v.items() if x > 0}


def daily_value(op, eco: Economics) -> float:
    return op["q"] * (1 - eco.water_cut) * eco.oil_value - op["q"] * eco.water_cut * eco.water_cost - op["elec_kw"] * 24 * eco.power_cost


def frequency_sweep(system: ESPSystem, eco: Economics, lim: Limits, step=0.5) -> pd.DataFrame:
    rows = []
    for f in np.arange(lim.f_min, lim.f_max + 1e-9, step):
        op = system.operating_point(f)
        v = violations(op, lim)
        rows.append(dict(freq=f, q=op["q"] if op else np.nan, p_intake=op["p_intake"] if op else np.nan, load=op["load"] if op else np.nan, elec_kw=op["elec_kw"] if op else np.nan,
                         kwh_per_m3=op["elec_kw"] * 24 / op["q"] if op else np.nan, value=daily_value(op, eco) if op else np.nan, feasible=not v, binding=",".join(v)))
    return pd.DataFrame(rows)


def optimise_frequency(system: ESPSystem, eco=Economics(), lim=Limits(), seed=0) -> Result:
    """Optuna TPE if installed, else bounded scalar search on the penalised value; always cross-checked against a 0.1 Hz grid."""
    pen = lambda f: (lambda op: -1e7 if op is None else daily_value(op, eco) - 1e7 * sum(violations(op, lim).values()))(system.operating_point(f))
    optuna = try_import("optuna")
    if optuna is not None:
        optuna.logging.set_verbosity(optuna.logging.WARNING)
        st = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=seed))
        st.optimize(lambda t: pen(t.suggest_float("f", lim.f_min, lim.f_max)), n_trials=60)
        f = st.best_params["f"]
    else:
        f = minimize_scalar(lambda x: -pen(x), bounds=(lim.f_min, lim.f_max), method="bounded").x
    grid = frequency_sweep(system, eco, lim, 0.1)
    gb = grid[grid.feasible].sort_values("value").tail(1)
    op = system.operating_point(f)
    v = violations(op, lim)
    res = Result("ESP frequency optimisation", dict(freq=f, op=op, value=daily_value(op, eco) if op else np.nan, violations=v, grid=grid, grid_best=gb), Status.UNVALIDATED)
    if v:
        res.warn("optimum violates: " + ", ".join(v))
    res.messages.append("Setpoint scenario for engineering review / MoC; vendor curves and motor/cable limits remain authoritative.")
    return res


# ---------------------------------------------------------------- gas handling
def gas_handling(pi_bara: float, t_c: float, q_liq_m3d: float, wc: float, gor: float, api=35.0, gas_sg=0.7, sep_eff=0.0) -> dict:
    """Free-gas fraction at the intake (Standing Rs/Bo, gas Bg from DAK). Rule-of-thumb classes: <10 % ok, 10-30 % gas-handler, >30 % separator/not ESP."""
    from .gaslift import _oil_pvt
    rs, bo, _ = _oil_pvt(pi_bara, t_c, api, gas_sg, gor)
    qo, qw = q_liq_m3d * (1 - wc), q_liq_m3d * wc
    free_std = qo * max(gor - rs, 0.0) * (1 - sep_eff)
    qg = free_std * float(GasPVT(gas_sg).bg(pi_bara, t_c))
    ql = qo * bo + qw
    gvf = qg / (qg + ql) if qg + ql > 0 else 0.0
    cls = "OK (<10 %)" if gvf < 0.10 else "gas handler / AGH advisable (10-30 %)" if gvf < 0.30 else "separator needed or ESP not suitable (>30 %)"
    return dict(gvf=gvf, q_gas_rm3d=qg, q_liq_rm3d=ql, rs=rs, bo=bo, cls=cls, head_multiplier=float(np.clip(1 - 1.8 * max(gvf - 0.05, 0), 0.3, 1)))


# ---------------------------------------------------------------- diagnostics
def diagnose(clean: pd.DataFrame, base: ESPSystem, days: int = 7) -> Result:
    """Rule-based: compare the last `days` with the previous 30 days (same well). Each finding carries evidence and a confidence (low/medium/high)."""
    n = days * 24
    if len(clean) < n * 3:
        return Result("ESP diagnostics", None, Status.FAIL, ["not enough history (need > 3x the diagnostic window)"])
    a, b = clean.iloc[-n:], clean.iloc[-n - 30 * 24:-n]
    pct = lambda c: 100 * (a[c].mean() / b[c].mean() - 1) if b[c].mean() else 0.0
    dP_a, dP_b = (a.pdisch - a.pintake).mean(), (b.pdisch - b.pintake).mean()
    d = dict(amp=pct("current"), tmot=a.tmotor.mean() - b.tmotor.mean(), pin=pct("pintake"), dp=100 * (dP_a / dP_b - 1) if dP_b else 0.0,
             amp_cv=a.current.std() / max(a.current.mean(), 1e-9), pin_cv=a.pintake.std() / max(a.pintake.mean(), 1e-9))
    f = []
    if d["amp_cv"] > 0.04 and d["pin_cv"] > 0.03:
        f.append(("Gas interference / slugging", "high" if d["amp_cv"] > 0.08 else "medium", f"current CV {d['amp_cv']:.1%}, intake CV {d['pin_cv']:.1%}"))
    if d["amp"] < -8 and d["dp"] < -8:
        f.append(("Underload / gas lock / low inflow", "medium", f"current {d['amp']:+.0f} %, dP {d['dp']:+.0f} %"))
    if d["amp"] > 6 and d["tmot"] > 5:
        f.append(("Overload / scale / sand / emulsion", "medium", f"current {d['amp']:+.0f} %, motor T {d['tmot']:+.1f} C"))
    if d["dp"] < -6 and d["amp"] > -3:
        f.append(("Head loss: wear, tubing leak or scale", "medium", f"dP {d['dp']:+.0f} % at steady current"))
    if d["pin"] < -10:
        f.append(("Falling intake pressure: inflow decline / low submergence", "medium", f"intake {d['pin']:+.0f} %"))
    if a.current.nunique() < 3 or a.pintake.nunique() < 3:
        f.append(("Sensor frozen / comms issue", "high", "constant readings"))
    score = 100.0
    for _, conf, _e in f:
        score -= {"high": 30, "medium": 15, "low": 5}[conf]
    score = float(np.clip(score - min(abs(d["tmot"]), 20) * 0.5, 0, 100))
    df = pd.DataFrame(f, columns=["finding", "confidence", "evidence"]) if f else pd.DataFrame(columns=["finding", "confidence", "evidence"])
    res = Result("ESP diagnostics", dict(table=df, score=score, deltas=d), Status.UNVALIDATED)
    res.messages.append("Rule-based hypotheses from sensor trends; confirm with well tests, vendor data and workover history before acting.")
    return res


def wear_track(clean: pd.DataFrame, base: ESPSystem, step_days=7) -> pd.DataFrame:
    """Fit the head multiplier `wear` per weekly window so that the model reproduces the measured discharge - intake pressure at the measured frequency
    (hybrid physics+residual: wear = the physics model's unexplained head degradation)."""
    rows = []
    for i in range(0, len(clean) - step_days * 24, step_days * 24):
        w = clean.iloc[i:i + step_days * 24]
        f = float(w.freq.mean())
        dp = float((w.pdisch - w.pintake).mean())

        def err(wear):
            op = replace(base, wear=wear).operating_point(f)
            return 1e9 if op is None else (op["p_discharge"] - op["p_intake"] - dp) ** 2
        r = minimize_scalar(err, bounds=(0.5, 1.15), method="bounded")
        rows.append(dict(time=w.index[0], wear=float(r.x), freq=f))
    return pd.DataFrame(rows)


def selftest() -> dict:
    from .esp import simulate_esp_timeseries, qc_pipeline
    raw, ref, truth = simulate_esp_timeseries()
    qc = qc_pipeline(raw)
    X = make_features(qc.clean)
    ok = qc.steady
    d = lambda a, b: slice(a * 24, b * 24)
    mon = PCAMonitor().fit(X.iloc[d(0, 30)][ok[d(0, 30)]], X.iloc[d(30, 50)][ok[d(30, 50)]])
    al = mon.alarms(mon.score(X), steady=ok)
    assert al.any() and al.values.argmax() < truth["fail_idx"], "no alarm before failure"
    fleet = __import__("dtp.lift.esp", fromlist=["x"]).simulate_fleet(400)
    r = fit_weibull(fleet, "run_days", "failed", ["gvf", "water_cut", "freq_c", "starts"])
    assert r.status == Status.OK and abs(r.value["table"].loc["gvf", "coef"] + 4.0) < 1.5, r.value["table"]
    s = ESPSystem()
    o = optimise_frequency(s)
    gb = o.value["grid_best"].iloc[0]
    assert abs(o.value["value"] - gb.value) / abs(gb.value) < 0.02
    g = gas_handling(60, 90, 300, 0.3, 120)
    assert 0 <= g["gvf"] < 1
    return dict(lead_days=(truth["fail_idx"] - al.values.argmax()) / 24, gvf=g["gvf"], f_opt=o.value["freq"])
