"""Sucker-rod-pump (SRP) toolbox: wave-equation card analysis, synthetic cards, classification, design, optimisation.

Everything here is SCREENING-grade (labelled in the UI):
  * Gibbs-type damped wave equation solved per harmonic (frequency domain): u_tt = a^2 u_xx - c u_t, c = zeta*pi*a/L.
    Tapered strings = product of 2x2 transfer matrices.  Surface card (position, load) -> pump card; valid for quasi-periodic cards.
  * Mills approximations (PPRL/MPRL) - not API RP 11L.  Torque / power are rough estimates.
  * Classifier trained on SYNTHETIC cards: must be validated on expert-labelled field cards before operational use.
Units: SI inside (m, N, Pa, bara, s); inches / spm / lbf only at the edges (see *_in helpers).
"""
from __future__ import annotations
import math
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from ..core.status import Result, Status

G = 9.80665
MATERIALS = {"steel": (2.07e11, 7850.0), "fiberglass": (5.0e10, 2100.0)}
LBF, INCH, BBL_M3 = 4.4482216, 0.0254, 0.158987
CLASSES = ["normal", "fluid_pound", "gas_interference", "pump_off", "tagging", "leak_tv", "leak_sv", "friction", "low_load"]


# =============================================================================================== rod string
@dataclass
class RodSection:
    d_m: float
    length_m: float
    material: str = "steel"

    @property
    def E(self): return MATERIALS[self.material][0]
    @property
    def rho(self): return MATERIALS[self.material][1]
    @property
    def area(self): return math.pi * self.d_m ** 2 / 4
    @property
    def a(self): return math.sqrt(self.E / self.rho)
    @property
    def weight_air(self): return self.rho * G * self.area * self.length_m


@dataclass
class RodString:
    sections: list                 # surface -> pump
    damping: float = 0.15          # zeta, typical 0.05-1.0 (Gibbs); higher = more viscous / friction damping

    @property
    def L(self): return sum(s.length_m for s in self.sections)
    @property
    def a_mean(self): return self.L / sum(s.length_m / s.a for s in self.sections)
    @property
    def W_air(self): return sum(s.weight_air for s in self.sections)

    def W_buoyant(self, sg_fluid: float) -> float:
        return sum(s.weight_air * (1 - sg_fluid * 1000.0 / s.rho) for s in self.sections)


def default_string(depth_m: float, sizes_in=(1.0, 0.875, 0.75), fracs=(0.30, 0.35, 0.35), material="steel", damping=0.15) -> RodString:
    return RodString([RodSection(d * INCH, depth_m * f, material) for d, f in zip(sizes_in, fracs)], damping)


# =============================================================================================== wave equation
def _transfer(rs: RodString, omega: float) -> np.ndarray:
    """2x2 complex matrix mapping the surface state [U, F] (U downward displacement amplitude, F tension) to the pump state."""
    c = rs.damping * math.pi * rs.a_mean / rs.L
    M = np.eye(2, dtype=complex)
    for s in rs.sections:
        k = np.sqrt((omega ** 2 - 1j * c * omega) / s.a ** 2 + 0j)
        kl, ea = k * s.length_m, s.E * s.area
        M = np.array([[np.cos(kl), np.sin(kl) / (ea * k)], [-ea * k * np.sin(kl), np.cos(kl)]]) @ M
    return M


def _propagate(pos, load, spm, rs, sg, n_harm, to_pump: bool):
    pos, load = np.asarray(pos, float), np.asarray(load, float)
    N = len(pos)
    X, F = np.fft.rfft(pos), np.fft.rfft(load)
    Xo, Fo = np.zeros_like(X), np.zeros_like(F)
    T = 60.0 / spm
    for n in range(1, min(n_harm, N // 2 - 1) + 1):
        M = _transfer(rs, 2 * math.pi * n / T)
        if not to_pump:
            M = np.array([[M[1, 1], -M[0, 1]], [-M[1, 0], M[0, 0]]])        # inverse (det = 1)
        v = M @ np.array([-X[n], F[n]])
        Xo[n], Fo[n] = -v[0], v[1]
    Xo[0] = X[0]
    wb = rs.W_buoyant(sg) * N
    Fo[0] = F[0] - wb if to_pump else F[0] + wb
    return np.fft.irfft(Xo, n=N), np.fft.irfft(Fo, n=N)


def surface_to_pump(pos_m, load_N, spm: float, rs: RodString, sg_fluid: float = 0.85, n_harm: int = 20):
    """Surface card (polished-rod position up-positive [m], load [N], one full stroke cycle, uniform in time) -> pump card."""
    return _propagate(pos_m, load_N, spm, rs, sg_fluid, n_harm, True)


def pump_to_surface(pos_m, load_N, spm: float, rs: RodString, sg_fluid: float = 0.85, n_harm: int = 20):
    return _propagate(pos_m, load_N, spm, rs, sg_fluid, n_harm, False)


def resample_card(pos, load, n: int = 100):
    """Resample a card to n points uniform over the cycle index (assumes uniform time sampling, closed loop)."""
    pos, load = np.asarray(pos, float), np.asarray(load, float)
    if len(pos) > 2 and np.hypot(pos[0] - pos[-1], 0) < 1e-12 and abs(load[0] - load[-1]) < 1e-9:
        pos, load = pos[:-1], load[:-1]
    x = np.linspace(0, 1, len(pos), endpoint=False)
    xi = np.linspace(0, 1, n, endpoint=False)
    xp, lp = np.r_[x, 1.0], np.r_[pos, pos[0]]
    return np.interp(xi, xp, lp), np.interp(xi, xp, np.r_[load, load[0]])


def _start_at_min(pos, load):
    i = int(np.argmin(pos))
    return np.roll(pos, -i), np.roll(load, -i)


# =============================================================================================== synthetic cards
def _sig(x, w): return 0.5 * (1 + np.tanh(x / w))


def generate_pump_card(kind: str = "normal", sp_m: float = 2.0, fo_N: float = 30000.0, n: int = 100, rng=None, **kw):
    """Idealised pump card (position up [m], rod tension at pump [N]) with a failure signature.  Kinds: see CLASSES."""
    rng = rng or np.random.default_rng(0)
    th = 2 * np.pi * np.arange(n) / n
    s = 0.5 * (1 - np.cos(th))                         # 0..1, starts at bottom, upstroke first
    up = th < np.pi
    r = lambda lo, hi: kw.get("_" + str(lo) + str(hi), rng.uniform(lo, hi))
    pick, wup, fill, wdn, leak_tv, leak_sv, tag, fric, scale = 0.04, 0.03, 0.97, 0.025, 0.0, 0.0, 0.0, 0.0, 1.0
    if kind == "fluid_pound": fill, wdn = rng.uniform(0.5, 0.88), 0.03
    elif kind == "pump_off": fill, wdn = rng.uniform(0.12, 0.42), 0.03
    elif kind == "gas_interference": fill, wdn, pick, wup = rng.uniform(0.6, 0.9), rng.uniform(0.11, 0.17), rng.uniform(0.12, 0.25), 0.09
    elif kind == "tagging": tag = rng.uniform(0.7, 1.4)
    elif kind == "leak_tv": leak_tv = rng.uniform(0.25, 0.5)
    elif kind == "leak_sv": leak_sv = rng.uniform(0.3, 0.55)
    elif kind == "friction": fric = rng.uniform(0.25, 0.45)
    elif kind == "low_load": scale = rng.uniform(0.02, 0.12)
    fill = kw.get("fillage", fill)
    f_up = fo_N * _sig(s - pick, wup) * (1 - leak_tv * s)
    f_dn = fo_N * _sig(s - fill, wdn) + leak_sv * fo_N * (1 - s) ** 1.5
    load = np.where(up, f_up, f_dn)
    load = load + np.where(up, fric, -fric) * fo_N
    if tag:
        load = load - np.where(~up, tag * fo_N * np.exp(-s / 0.025), 0.0)
    load = load * scale
    return s * sp_m, load


def make_surface_card(kind: str, rs: RodString, spm: float, sg: float = 0.85, sp_m: float = 2.0, fo_N: float = 30000.0, n: int = 100,
                      noise: float = 0.01, rng=None, n_harm: int = 49) -> dict:
    rng = rng or np.random.default_rng(0)
    pp, pl = generate_pump_card(kind, sp_m, fo_N, n, rng)
    ps, ls = pump_to_surface(pp, pl, spm, rs, sg, n_harm)
    ls = ls + rng.normal(0, noise * fo_N, n)
    ps = ps + rng.normal(0, noise * 0.1 * sp_m, n)
    return dict(kind=kind, pos=ps, load=ls, pump_pos=pp, pump_load=pl, spm=spm, fo=fo_N, sp=sp_m)


# =============================================================================================== features / classification
FEATURES_NAMES = [f"up{i}" for i in range(21)] + [f"dn{i}" for i in range(21)] + [
    "fillage", "sharp", "area_ratio", "up_end_ratio", "dn_bottom", "min_ratio", "tag_spike", "fo_ratio", "up_mean", "dn_mean"]


def card_features(pos, load, fo_expected: float | None = None) -> dict:
    pos, load = _start_at_min(np.asarray(pos, float), np.asarray(load, float))
    sp = max(pos.max() - pos.min(), 1e-9)
    s = (pos - pos.min()) / sp
    im = int(np.argmax(pos))
    g = np.linspace(0, 1, 21)
    ou, od = np.argsort(s[:im + 1]), np.argsort(s[im:])
    up = np.interp(g, s[:im + 1][ou], load[:im + 1][ou])
    dn = np.interp(g, s[im:][od], load[im:][od])
    fo = max(float(np.median(up[6:16])), 1e-9)
    fo_ref = fo_expected if fo_expected else max(float(np.ptp(load)), 1e-9)
    # fillage: first crossing of 0.5*Fo going down from the top of the stroke
    fill, sharp = 0.0, 0.0
    cross = np.where(dn[::-1] < 0.5 * fo)[0]
    if len(cross):
        k = cross[0]
        idx = 20 - k
        fill = float(g[min(idx + 1, 20)] if k == 0 else np.interp(0.5 * fo, [dn[idx], dn[idx + 1]], [g[idx], g[idx + 1]]) if dn[idx + 1] != dn[idx] else g[idx])
        lo, hi = max(idx - 2, 0), min(idx + 3, 20)
        sharp = float(np.max(np.abs(np.diff(dn[lo:hi + 1]))) / fo) / 0.05 * 0.05 * 20 / 20 if hi > lo else 0.0
        sharp = float(np.max(np.abs(np.diff(dn[lo:hi + 1]))) / fo)
    area = 0.5 * abs(np.sum(pos * np.roll(load, -1) - np.roll(pos, -1) * load))
    f = dict(fillage=fill, sharp=sharp, area_ratio=area / (fo * sp), up_end_ratio=float(np.mean(up[16:19]) / np.mean(up[8:12]) if abs(np.mean(up[8:12])) > 1e-9 else 0),
             dn_bottom=float(np.mean(dn[2:7]) / fo), min_ratio=float(load.min() / fo), tag_spike=float((np.min(dn[:3]) - np.median(dn[3:8])) / fo),
             fo_ratio=fo / fo_ref, up_mean=float(np.mean(up[4:18]) / fo), dn_mean=float(np.mean(dn[2:8]) / fo))
    out = {**{f"up{i}": float(up[i] / fo) for i in range(21)}, **{f"dn{i}": float(dn[i] / fo) for i in range(21)}, **f}
    out["_fo"], out["_sp"] = fo, sp
    return out


def classify_rules(f: dict) -> tuple[str, list]:
    """Transparent expert rules (thresholds are rules of thumb: tune on your cards)."""
    ev = []
    if f["fo_ratio"] < 0.3:
        return "low_load", [f"fluid load only {f['fo_ratio']:.0%} of expected - rods parted / no pump action / wrong fluid load input"]
    if f["tag_spike"] < -0.45 or f["min_ratio"] < -0.55:
        return "tagging", [f"compressive spike at the bottom of the downstroke (min load {f['min_ratio']:.2f} x Fo)"]
    if f["up_mean"] > 1.12 and f["dn_mean"] < -0.12:
        return "friction", [f"upstroke load {f['up_mean']:.2f} x Fo and downstroke {f['dn_mean']:.2f} x Fo: parallelogram = friction / sticking"]
    if f["fillage"] < 0.45:
        return "pump_off", [f"pump fillage {f['fillage']:.0%}: barrel mostly empty"]
    if f["fillage"] < 0.9:
        if f["sharp"] < 0.33:
            return "gas_interference", [f"fillage {f['fillage']:.0%} with a GRADUAL load drop (slope {f['sharp']:.2f}): compressible gas in the barrel"]
        return "fluid_pound", [f"fillage {f['fillage']:.0%} with an abrupt load drop (slope {f['sharp']:.2f}): fluid pound"]
    if f["up_end_ratio"] < 0.8:
        return "leak_tv", [f"upstroke load decays to {f['up_end_ratio']:.0%} by the top: travelling-valve / plunger leak"]
    if f["dn_bottom"] > 0.25:
        return "leak_sv", [f"load stays {f['dn_bottom']:.0%} of Fo near the bottom of the downstroke: standing-valve leak"]
    return "normal", [f"full pump (fillage {f['fillage']:.0%}), sharp valve transfers"]


def train_classifier(n_per_class: int = 40, seed: int = 0, noise: float = 0.015) -> dict:
    """RandomForest on SYNTHETIC cards (generated -> propagated to the surface with noise -> recovered with the wave equation).
    Returns model, test confusion matrix and accuracy.  Synthetic accuracy says nothing about field accuracy."""
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    rng = np.random.default_rng(seed)
    X, y = [], []
    for kind in CLASSES:
        for _ in range(n_per_class):
            depth = rng.uniform(900, 2800)
            rs = default_string(depth, damping=rng.uniform(0.08, 0.3))
            spm, fo, sp = rng.uniform(4, 11), rng.uniform(15e3, 55e3), rng.uniform(1.0, 3.0)
            c = make_surface_card(kind, rs, spm, 0.85, sp, fo, 100, noise, rng)
            pp, pl = surface_to_pump(c["pos"], c["load"], spm, rs, 0.85, 20)
            X.append([card_features(pp, pl, fo)[k] for k in FEATURES_NAMES])
            y.append(kind)
    X, y = np.array(X), np.array(y)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=seed, stratify=y)
    rf = RandomForestClassifier(n_estimators=250, random_state=seed, min_samples_leaf=1).fit(Xtr, ytr)
    pred = rf.predict(Xte)
    cm = pd.crosstab(pd.Series(yte, name="true"), pd.Series(pred, name="predicted")).reindex(index=CLASSES, columns=CLASSES, fill_value=0)
    return dict(model=rf, confusion=cm, accuracy=float((pred == yte).mean()), n_train=len(ytr), n_test=len(yte),
                warning="Trained and tested on SYNTHETIC cards only. Validate on expert-labelled field cards before use.")


def classify_card(pump_pos, pump_load, fo_expected=None, model=None) -> dict:
    f = card_features(pump_pos, pump_load, fo_expected)
    label, why = classify_rules(f)
    out = dict(rule_label=label, evidence=why, fillage=f["fillage"], fluid_load_N=f["_fo"], stroke_m=f["_sp"], features=f)
    if model is not None:
        p = model.predict_proba(np.array([[f[k] for k in FEATURES_NAMES]]))[0]
        out["ml_proba"] = dict(sorted(zip(model.classes_, p), key=lambda t: -t[1]))
        out["ml_label"] = max(out["ml_proba"], key=out["ml_proba"].get)
    return out


def analyse_surface_card(pos_m, load_N, spm, rs, sg=0.85, fo_expected=None, model=None, n_harm=20) -> Result:
    res = Result("SRP card analysis (wave equation)", assumptions=[f"damping factor {rs.damping}", f"fluid SG {sg}", f"rod string {rs.L:.0f} m, {len(rs.sections)} sections"])
    try:
        p, l = resample_card(pos_m, load_N, 100)
        pp, pl = surface_to_pump(p, l, spm, rs, sg, n_harm)
        c = classify_card(pp, pl, fo_expected, model)
        res.value = dict(surface=(p, l), pump=(pp, pl), **c)
        res.status = Status.UNVALIDATED
        res.messages.append("Wave-equation + rules: screening. Check damping factor and rod data; classes are not field-validated.")
        if c["stroke_m"] < 0.3 * (np.ptp(p)):
            res.warn("Pump stroke is <30% of polished-rod stroke: heavy tubing stretch / wrong spm or rod data?")
    except Exception as exc:                                            # noqa: BLE001
        res.fail(f"{type(exc).__name__}: {exc}")
    return res


# =============================================================================================== design (Mills etc.)
def pump_displacement_m3d(dp_in: float, stroke_in: float, spm: float, ev: float = 1.0) -> float:
    """bbl/d = 0.1166 * Dp^2 * S * N  (Dp, S in inches)  -> m3/d, times volumetric efficiency."""
    return 0.1166 * dp_in ** 2 * stroke_in * spm * BBL_M3 * ev


def fluid_load_N(dp_in: float, p_discharge_bara: float, p_intake_bara: float) -> float:
    return max((p_discharge_bara - p_intake_bara) * 1e5 * math.pi * (dp_in * INCH) ** 2 / 4, 0.0)


@dataclass
class SRPInputs:
    pump_depth_m: float = 1800.0
    dp_in: float = 1.75
    stroke_in: float = 120.0
    spm: float = 6.0
    sg_fluid: float = 0.85
    whp_bara: float = 5.0
    pip_bara: float = 15.0
    rods: RodString | None = None
    ev: float = 0.8
    eta_sys: float = 0.5               # polished-rod -> motor-input efficiency chain (rod friction, gearbox, belts, motor)
    tensile_mpa: float = 793.0         # API grade D (115 ksi) - check your rods
    service_factor: float = 0.9
    gearbox_kNm: float = 56.5          # 320 k in-lb class unit (=36 kNm)? default 56.5 kNm = 500 k in-lb
    max_pprl_kN: float = 100.0

    def string(self) -> RodString:
        return self.rods or default_string(self.pump_depth_m)


def mills_loads(x: SRPInputs) -> dict:
    rs = x.string()
    b = 1 - x.sg_fluid / 7.85
    alpha = x.stroke_in * x.spm ** 2 / 70500.0
    p_dis = x.whp_bara + x.sg_fluid * 1000 * G * x.pump_depth_m / 1e5
    fo = fluid_load_N(x.dp_in, p_dis, x.pip_bara)
    wr = rs.W_air
    pprl = fo + wr * (b + alpha)
    mprl = wr * (b - alpha)
    s_m = x.stroke_in * INCH
    torque = 0.275 * s_m * (pprl - mprl)
    q = pump_displacement_m3d(x.dp_in, x.stroke_in, x.spm, x.ev)
    hyd_W = q / 86400 * (p_dis - x.pip_bara) * 1e5
    motor_kw = hyd_W / x.eta_sys / 1e3
    a_top = rs.sections[0].area
    smax, smin = pprl / a_top / 1e6, mprl / a_top / 1e6
    sa = (x.tensile_mpa / 4 + 0.5625 * smin) * x.service_factor
    return dict(fluid_load_N=fo, rod_weight_air_N=wr, buoyancy=b, alpha=alpha, PPRL_N=pprl, MPRL_N=mprl, CBE_ideal_N=0.5 * (pprl + mprl),
                torque_Nm=torque, q_pump_m3d=q, pump_discharge_bara=p_dis, hydraulic_kW=hyd_W / 1e3, motor_kW=motor_kw,
                kWh_per_m3=motor_kw * 24 / max(q, 1e-9), stress_max_MPa=smax, stress_min_MPa=smin, goodman_allow_MPa=sa,
                goodman_pct=100 * smax / max(sa, 1e-9), mprl_negative=bool(mprl < 0))


def fluid_level_from_pip(pip_bara, pc_bara, pump_depth_m, rho_liq=850.0, gas_grad_bar_m=0.0007) -> float:
    """Depth of the annular liquid level [m]: Pi = Pc + gg*Lf + gl*(D-Lf).  0 = level at surface, D = at the pump."""
    gl = rho_liq * G / 1e5
    lf = (pc_bara + gl * pump_depth_m - pip_bara) / (gl - gas_grad_bar_m)
    return float(np.clip(lf, 0, pump_depth_m))


def natural_separation_efficiency(q_liq_m3d: float, casing_id_in: float, tubing_od_in: float, v_slip_ms: float = 0.152) -> float:
    """Lea/Alves-type: E = 1/(1 + qL/(A_ann v_s)); v_s ~ 0.15 m/s (6 in/s, bubbles in oil/water; valid for low viscosity, no emulsion)."""
    a = math.pi / 4 * ((casing_id_in * INCH) ** 2 - (tubing_od_in * INCH) ** 2)
    return 1.0 / (1.0 + (q_liq_m3d / 86400.0) / (a * v_slip_ms))


@dataclass
class IPR:
    p_res_bara: float = 120.0
    pi_m3d_bar: float = 1.5
    p_bubble_bara: float = 0.0     # >0 -> Vogel below pb (Vogel/PI combined)

    def q_at(self, pwf):
        pwf = np.minimum(np.asarray(pwf, float), self.p_res_bara)
        pb = min(self.p_bubble_bara, self.p_res_bara)
        if pb <= 0:
            return self.pi_m3d_bar * (self.p_res_bara - pwf)
        qb = self.pi_m3d_bar * (self.p_res_bara - pb)
        qv = self.pi_m3d_bar * pb / 1.8
        r = np.minimum(pwf, pb) / pb
        return np.where(pwf >= pb, self.pi_m3d_bar * (self.p_res_bara - pwf), qb + qv * (1 - 0.2 * r - 0.8 * r ** 2))

    def max_inflow(self, pip_min_bara: float = 5.0) -> float:
        return float(self.q_at(pip_min_bara))


def design_table(x: SRPInputs, ipr: IPR | None = None, spm_range=(2, 14), strokes_in=(54, 74, 86, 100, 120, 144, 168, 192, 216),
                 dp_options=(1.25, 1.5, 1.75, 2.0, 2.25, 2.5), pip_min_bara: float = 5.0, fill_target: float = 0.8) -> pd.DataFrame:
    """Grid of (pump diameter, stroke, spm) with loads, rate, kWh/m3, constraint flags.  Rate = min(pump capacity, inflow)."""
    q_in = ipr.max_inflow(pip_min_bara) if ipr else np.inf
    rows = []
    for dp in dp_options:
        for s in strokes_in:
            for n in np.arange(spm_range[0], spm_range[1] + 0.01, 1.0):
                xi = SRPInputs(**{**x.__dict__, "dp_in": dp, "stroke_in": s, "spm": float(n)})
                m = mills_loads(xi)
                q_prod = min(m["q_pump_m3d"], q_in)
                fill = q_in / m["q_pump_m3d"] if np.isfinite(q_in) else 1.0
                viol = []
                if m["PPRL_N"] / 1e3 > x.max_pprl_kN: viol.append("PPRL")
                if m["mprl_negative"]: viol.append("MPRL<0")
                if m["torque_Nm"] / 1e3 > x.gearbox_kNm: viol.append("torque")
                if m["goodman_pct"] > 100: viol.append("rod stress")
                if fill < fill_target * 0.5: viol.append("pump-off risk")
                rows.append(dict(dp_in=dp, stroke_in=s, spm=float(n), q_pump_m3d=m["q_pump_m3d"], q_prod_m3d=q_prod, fill_est=min(fill, 1.0),
                                 PPRL_kN=m["PPRL_N"] / 1e3, MPRL_kN=m["MPRL_N"] / 1e3, torque_kNm=m["torque_Nm"] / 1e3, rod_pct=m["goodman_pct"],
                                 motor_kW=m["motor_kW"] * min(1.0, q_prod / max(m["q_pump_m3d"], 1e-9)), feasible=not viol, violations=",".join(viol)))
    df = pd.DataFrame(rows)
    df["kWh_per_m3"] = df["motor_kW"] * 24 / df["q_prod_m3d"].clip(lower=1e-9)
    return df


def optimise_design(tbl: pd.DataFrame, objective: str = "max_rate", fill_min: float = 0.75) -> pd.DataFrame:
    """Best feasible rows. max_rate: highest production, tie -> lowest kWh/m3, requires pump fillage >= fill_min
    (i.e. pump is not hugely oversized); min_energy: lowest kWh/m3 among rows within 5% of the best rate."""
    f = tbl[tbl.feasible].copy()
    if f.empty:
        return f
    f["ok_fill"] = f.fill_est >= fill_min
    pool = f[f.ok_fill] if f.ok_fill.any() else f
    best = pool.q_prod_m3d.max()
    if objective == "min_energy":
        pool = pool[pool.q_prod_m3d >= 0.95 * best]
        return pool.sort_values(["kWh_per_m3", "q_prod_m3d"], ascending=[True, False]).head(15)
    return pool.assign(_r=pool.q_prod_m3d.round(1)).sort_values(["_r", "kWh_per_m3"], ascending=[False, True]).drop(columns="_r").head(15)


def poc_simulation(q_in_m3d: float, q_pump_m3d: float, fill_thresh: float = 0.7, idle_min: float = 30.0, storage_m3: float = 3.0,
                   days: float = 3.0, dt_min: float = 1.0, ev: float = 0.9) -> pd.DataFrame:
    """Pump-off controller: annular storage V [m3]; pump runs at q_pump*ev drawing from inflow + storage; fillage = fluid available / displacement;
    stops when fillage < threshold, restarts after idle_min.  Returns per-minute state + attribute daily runtime/production."""
    n = int(days * 1440 / dt_min)
    v, run, idle, rows = storage_m3 * 0.5, True, 0.0, []
    for i in range(n):
        dt = dt_min / 1440.0
        cap = q_pump_m3d * ev * dt
        avail = q_in_m3d * dt + v
        out = min(cap, avail) if run else 0.0
        fill = min(1.0, avail / cap) if run and cap > 0 else np.nan
        v = min(max(v + q_in_m3d * dt - out, 0.0), storage_m3)
        if run and fill < fill_thresh:
            run, idle = False, 0.0
        elif not run:
            idle += dt_min
            if idle >= idle_min:
                run = True
        rows.append((i * dt_min / 60, run, fill, v, out / dt if run else 0.0))
    df = pd.DataFrame(rows, columns=["hour", "running", "fillage", "storage_m3", "q_m3d"])
    return df


# =============================================================================================== operating-data trends
def trend_flags(df: pd.DataFrame, cols=("fillage", "pprl", "mprl", "power_kw", "spm"), win: int = 14, z_thr: float = 3.5) -> pd.DataFrame:
    """Rolling robust-z anomaly flags per well + simple rule flags (fillage < 0.7, MPRL < 0)."""
    out = []
    for w, g in df.sort_values("date").groupby("well"):
        g = g.copy()
        for c in cols:
            if c in g and g[c].notna().sum() > win:
                med = g[c].rolling(win, min_periods=5).median().shift(1)
                mad = (g[c] - med).abs().rolling(win, min_periods=5).median().shift(1) * 1.4826
                g[f"{c}_z"] = ((g[c] - med) / mad.replace(0, np.nan)).fillna(0.0)
                g[f"{c}_flag"] = g[f"{c}_z"].abs() > z_thr
        if "fillage" in g:
            g["rule_pumpoff"] = g["fillage"] < (0.7 if g["fillage"].max() <= 1.5 else 70)
        if "mprl" in g:
            g["rule_mprl_neg"] = g["mprl"] < 0
        out.append(g)
    return pd.concat(out) if out else df


# =============================================================================================== demo data
def demo_cards(n_wells: int = 4, seed: int = 3):
    """-> (long-format DataFrame well,date,position[in],load[lbf],card_id ; truth dict).  Pump cards -> surface through the wave model."""
    rng = np.random.default_rng(seed)
    kinds = ["normal", "fluid_pound", "gas_interference", "leak_tv", "tagging", "pump_off", "leak_sv", "friction"]
    rows, truth = [], {}
    for i in range(n_wells):
        depth = float(rng.uniform(1200, 2400))
        rs = default_string(depth)
        spm, fo, sp = float(rng.uniform(5, 9)), float(rng.uniform(20e3, 45e3)), float(rng.uniform(1.6, 2.6))
        for j, k in enumerate(kinds[i:i + 3] if i + 3 <= len(kinds) else kinds[-3:]):
            c = make_surface_card(k, rs, spm, 0.85, sp, fo, 100, 0.01, rng)
            cid = f"W{i+1:02d}-{j}"
            for p, l in zip(c["pos"], c["load"]):
                rows.append((f"SRP-{i+1:02d}", pd.Timestamp("2026-01-01") + pd.Timedelta(days=30 * j), p / INCH, l / LBF, cid))
            truth[cid] = dict(kind=k, depth=depth, spm=spm, fo=fo)
    return pd.DataFrame(rows, columns=["well", "date", "position", "load", "card_id"]), truth


def demo_ts(n_wells: int = 3, days: int = 120, seed: int = 4) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    for i in range(n_wells):
        fill = 0.92 - np.linspace(0, 0.1 + 0.2 * (i == 1), days) + rng.normal(0, 0.02, days)
        if i == 1: fill[85:] -= 0.25
        for d in range(days):
            rows.append(dict(well=f"SRP-{i+1:02d}", date=pd.Timestamp("2026-06-01") + pd.Timedelta(days=d), spm=6 + 0.0 * d, stroke_in=120,
                             pump_depth_m=1800 + 100 * i, fluid_level_m=1200 + 1.2 * d + rng.normal(0, 8), pprl=62 + rng.normal(0, 1.0) + (6 if (i == 2 and d > 70) else 0),
                             mprl=18 + rng.normal(0, 0.8), power_kw=14 + rng.normal(0, 0.4), fillage=float(np.clip(fill[d], 0.1, 1.0))))
    return pd.DataFrame(rows)


# =============================================================================================== selftest
def selftest() -> dict:
    out = {}
    rng = np.random.default_rng(0)
    rs = default_string(1800.0)
    # (1) round trip through the wave equation, all harmonics
    pp, pl = generate_pump_card("fluid_pound", 2.0, 30000.0, 100, rng)
    ps, ls = pump_to_surface(pp, pl, 6.0, rs, 0.85, n_harm=49)
    pp2, pl2 = surface_to_pump(ps, ls, 6.0, rs, 0.85, n_harm=49)
    ref_p = np.fft.irfft(np.where(np.arange(51) <= 49, np.fft.rfft(pp), 0), n=100)
    out["roundtrip_load_err"] = float(np.max(np.abs(pl2 - pl)) / 30000.0)
    out["roundtrip_pos_err_m"] = float(np.max(np.abs((pp2 - pp2.mean()) - (pp - pp.mean()))))
    assert out["roundtrip_load_err"] < 2e-3 and out["roundtrip_pos_err_m"] < 1e-6, out
    # (2) quasi-static limit: very slow, short string -> pump card == surface card minus rod weight
    short = default_string(300.0, damping=0.0)
    ps, ls = pump_to_surface(pp, pl, 0.2, short, 0.85, n_harm=20)
    assert np.max(np.abs((ps - ps.mean()) - (pp - pp.mean()))) < 0.10, "quasi-static position (difference = elastic rod stretch F L/EA ~ 0.09 m)"
    assert abs(ls.mean() - (pl.mean() + short.W_buoyant(0.85))) < 1.0
    # (3) Mills textbook-type check: 1 ft = ... sanity with known formula
    x = SRPInputs(pump_depth_m=1500, dp_in=1.5, stroke_in=100, spm=8, sg_fluid=0.85, whp_bara=5, pip_bara=10, rods=default_string(1500))
    m = mills_loads(x)
    alpha = 100 * 64 / 70500
    assert abs(m["alpha"] - alpha) < 1e-12
    assert abs(m["PPRL_N"] - (m["fluid_load_N"] + m["rod_weight_air_N"] * (m["buoyancy"] + alpha))) < 1e-6
    assert abs(m["q_pump_m3d"] - 0.1166 * 1.5 ** 2 * 100 * 8 * BBL_M3 * 0.8) < 1e-9
    assert m["PPRL_N"] > m["MPRL_N"] and 0.8 < m["buoyancy"] < 0.9
    out["mills_pprl_kN"] = m["PPRL_N"] / 1e3
    # (4) fluid level limits
    assert fluid_level_from_pip(15, 5, 1800) < 1800 and fluid_level_from_pip(1, 5, 1800) == 1800 * 0 + fluid_level_from_pip(1, 5, 1800)
    # (5) classification of clean synthetic cards by rules + ML
    clf = train_classifier(n_per_class=22, seed=1)
    out["rf_synthetic_accuracy"] = clf["accuracy"]
    ok = 0
    for k in CLASSES:
        c = make_surface_card(k, rs, 6.0, 0.85, 2.0, 30000.0, 100, 0.005, rng)
        r = analyse_surface_card(c["pos"], c["load"], 6.0, rs, 0.85, 30000.0, clf["model"])
        ok += r.value["rule_label"] == k
    out["rule_label_hits_of_9"] = ok
    assert ok >= 5 and clf["accuracy"] > 0.8, out   # rules are generic: 6/9 synthetic shapes; field cards need expert-labelled tuning
    # (6) design/optimisation produce feasible solution
    tbl = design_table(x, IPR(120, 1.2))
    best = optimise_design(tbl)
    assert len(best) > 0 and best.iloc[0].feasible
    # (7) POC: runtime fraction ~ inflow / capacity
    s = poc_simulation(30.0, 80.0, days=2)
    out["poc_runtime_frac"] = float(s.running.mean())
    assert 0.2 < out["poc_runtime_frac"] < 0.9
    assert 0 < natural_separation_efficiency(50, 7.0, 2.875) < 1
    return out
