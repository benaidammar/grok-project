"""Lift-method screening (textbook rules of thumb - verify) and gas-well liquid-loading analysis (Turner / Coleman)."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..gascond.pvt import GasPVT

METHODS = {  # feasible envelopes: rate m3/d (lo,hi), depth m (lo,hi), max GLR tolerance 'gas', sand tolerance, deviation tolerance, power/gas need, CAPEX, OPEX (1 low .. 5 high)
    "Natural flow / velocity string": dict(q=(0, 800), d=(0, 5000), gas=5, sand=4, dev=5, capex=1, opex=1),
    "Plunger lift": dict(q=(0, 60), d=(0, 4500), gas=5, sand=2, dev=3, capex=1, opex=1),
    "Foam / surfactant": dict(q=(0, 100), d=(0, 4500), gas=5, sand=4, dev=5, capex=1, opex=2),
    "Gas lift": dict(q=(20, 8000), d=(300, 4500), gas=5, sand=4, dev=5, capex=3, opex=2),
    "ESP": dict(q=(40, 12000), d=(300, 4000), gas=2, sand=1, dev=4, capex=4, opex=4),
    "Sucker rod pump": dict(q=(1, 400), d=(100, 3000), gas=2, sand=2, dev=2, capex=2, opex=3),
    "PCP": dict(q=(1, 400), d=(100, 1800), gas=2, sand=5, dev=3, capex=2, opex=3),
    "Jet pump": dict(q=(20, 2000), d=(300, 4500), gas=3, sand=4, dev=5, capex=3, opex=4),
    "Compression / lower WHP": dict(q=(0, 1e5), d=(0, 6000), gas=5, sand=5, dev=5, capex=4, opex=3),
}


def screen(q_liq, depth, gor_sm3m3, sand=2, dev=2, gas_available=True, power_available=True, weights=None) -> pd.DataFrame:
    """Score 0-1 per method; excluded methods carry the reason. Inputs: sand/dev 1(low)..5(severe)."""
    w = dict(fit=0.5, capex=0.2, opex=0.3, **(weights or {}))
    rows = []
    for m, e in METHODS.items():
        why = []
        if not e["q"][0] <= q_liq <= e["q"][1]:
            why.append(f"rate outside {e['q'][0]}-{e['q'][1]} m3/d")
        if not e["d"][0] <= depth <= e["d"][1]:
            why.append(f"depth outside {e['d'][0]}-{e['d'][1]} m")
        if gor_sm3m3 > 300 and e["gas"] < 3:
            why.append("high GOR: poor gas handling")
        if sand >= 4 and e["sand"] <= 2:
            why.append("sand intolerant")
        if dev >= 4 and e["dev"] <= 2:
            why.append("deviation intolerant")
        if m == "Gas lift" and not gas_available:
            why.append("no lift gas")
        if m in ("ESP", "PCP") and not power_available:
            why.append("no power")
        fit = 0.0 if why else 1.0
        score = w["fit"] * fit + w["capex"] * (5 - e["capex"]) / 4 * fit + w["opex"] * (5 - e["opex"]) / 4 * fit
        rows.append(dict(method=m, score=score, feasible=not why, exclusion="; ".join(why)))
    return pd.DataFrame(rows).sort_values("score", ascending=False).reset_index(drop=True)


def turner_velocity(p_bara, t_c, pvt: GasPVT, liquid="water", adj=1.2):
    """Critical gas velocity [m/s] for droplet removal: v = adj * 5.46 sigma^.25 (rho_l-rho_g)^.25 / rho_g^.5 (SI; adj 1.2 Turner, 1.0 Coleman-like).
    (Field-unit Turner constants converted and checked; sigma N/m.) water: sigma 0.06, rho 1050; condensate: sigma 0.02, rho 700."""
    sig, rl = (0.06, 1050.0) if liquid == "water" else (0.02, 700.0)
    rg = pvt.rho(p_bara, t_c)
    return adj * 5.46 * sig ** 0.25 * (rl - rg) ** 0.25 / np.sqrt(rg)


def critical_rate_sm3d(p_bara, t_c, d_in, pvt: GasPVT, liquid="water", adj=1.2):
    area = np.pi * (d_in * 0.0254) ** 2 / 4
    v = turner_velocity(p_bara, t_c, pvt, liquid, adj)
    return v * area * 86400.0 / pvt.bg(p_bara, t_c)


def liquid_loading(wt: pd.DataFrame, cfg, t_wh_c=40.0, adj=1.2) -> pd.DataFrame:
    """Per test: actual rate vs critical rate at the wellhead (conservative location). margin = q/qc (<1 = below critical -> loading risk)."""
    pvt = GasPVT.from_cfg(cfg)
    d = wt.dropna(subset=["whp_bara", "gas_sm3d"]).copy()
    d["tubing_id_in"] = [cfg.well(w, "tubing_id_in") for w in d.well]
    liq = np.where(d.water_m3d.fillna(0) > 0, "water", "condensate")
    qc = np.array([critical_rate_sm3d(p, t_wh_c, di, pvt, l, adj) for p, di, l in zip(d.whp_bara, d.tubing_id_in, liq)])
    d["liquid"], d["q_crit_sm3d"] = liq, qc
    d["margin"] = d.gas_sm3d / qc
    d["loading_risk"] = pd.cut(d.margin, [0, 1, 1.3, 1e9], labels=["BELOW critical", "marginal", "ok"])
    return d


def selftest() -> dict:
    pvt = GasPVT(0.7)
    v = turner_velocity(27.6, 40.0, pvt, "water", 1.0)            # ~400 psia: unadjusted Turner ~3.4 m/s (SI constant derived from field form)
    assert 2.8 < v < 4.3, v
    s = screen(150, 2000, 80)
    assert s.iloc[0].feasible and not screen(5000, 2000, 80).set_index("method").loc["Plunger lift", "feasible"]
    wt = pd.DataFrame(dict(well="A", whp_bara=[100.0, 60.0], gas_sm3d=[1e6, 2e5], water_m3d=[5.0, 5.0]))
    class C:  # minimal cfg
        gas_sg, co2_pct, h2s_ppm, n2_pct, t_std_c, p_std_bar = 0.7, 2.0, 0.0, 0.0, 15.0, 1.01325
        def well(self, w, k, d=None): return 4.0
    ll = liquid_loading(wt, C())
    assert ll.margin.iloc[0] > ll.margin.iloc[1]
    return dict(v_turner_27bar=v)
