"""Gas lift: drift-flux vertical traverse with injection (screening), nodal GLPC, curve fit, multi-well allocation, stability, valve spacing, orifice."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.optimize import brentq, minimize

from ..core.status import Result, Status
from ..gascond.pvt import GasPVT

G = 9.80665


def _oil_pvt(p_bar, t_c, api, gas_sg, rs_total_sm3m3):
    """Standing correlations (field units internally). -> Rs [Sm3/Sm3], Bo [rm3/Sm3], rho_oil [kg/m3 in situ]."""
    p = p_bar * 14.5038
    t = t_c * 1.8 + 32
    yg = 0.00091 * t - 0.0125 * api
    rs = min(gas_sg * ((p / 18.2 + 1.4) * 10 ** yg) ** 1.2048, rs_total_sm3m3 * 5.615)       # scf/stb
    bo = 0.9759 + 0.00012 * (rs * (gas_sg / (141.5 / (api + 131.5))) ** 0.5 + 1.25 * t) ** 1.2
    rho_o_std = 141.5 / (api + 131.5) * 999.0
    rho = (rho_o_std + 1.2217 * rs / 5.615 * gas_sg) / bo
    return rs / 5.615, bo, rho


_ZG = {}


def _zfun(gas_sg: float):
    """Bilinear Z(p,T) lookup built once per gas gravity from the DAK solver (screening speed-up; error < 1e-3)."""
    key = round(float(gas_sg), 4)
    if key not in _ZG:
        from scipy.interpolate import RegularGridInterpolator
        ps, ts = np.linspace(1.0, 700.0, 140), np.linspace(10.0, 200.0, 20)
        P, T = np.meshgrid(ps, ts, indexing="ij")
        z = GasPVT(gas_sg).z(P.ravel(), T.ravel()).reshape(P.shape)
        _ZG[key] = RegularGridInterpolator((ps, ts), z, bounds_error=False, fill_value=None)
    f = _ZG[key]
    return lambda p, t: float(f([[min(max(p, 1.0), 700.0), min(max(t, 10.0), 200.0)]])[0])


def traverse(p_top, depth_m, d_in, q_liq_m3d, wc, gor, q_inj_sm3d, inj_depth, api=35.0, gas_sg=0.7, t_top=40.0, t_bot=100.0, rough_mm=0.046, n=80, sigma=0.03) -> float:
    """Pressure at depth_m [bara] from tubing head pressure, marching down. Gas = formation (GOR) + injected below/above inj_depth. Drift-flux (C0 1.2)."""
    pvt = GasPVT(gas_sg)
    zf = _zfun(gas_sg)
    mw = pvt.mol_weight()
    d = d_in * 0.0254
    area = np.pi * d * d / 4
    qo, qw = q_liq_m3d * (1 - wc), q_liq_m3d * wc
    dz = depth_m / n
    p = p_top
    for i in range(n):
        z_mid = (i + 0.5) * dz
        t = t_top + (t_bot - t_top) * z_mid / depth_m
        rs, bo, rho_o = _oil_pvt(p, t, api, gas_sg, gor)
        gas_free = qo * max(gor - rs, 0.0) + (q_inj_sm3d if z_mid < inj_depth else 0.0)
        zz = zf(p, t)
        bg = zz * (t + 273.15) * 1.01325 / (p * 288.15)
        qg, ql = gas_free * bg / 86400.0, (qo * bo + qw) / 86400.0
        rho_l = (qo * bo * rho_o + qw * 1050.0) / max(qo * bo + qw, 1e-9)
        rho_g = p * 1e5 * mw * 1e-3 / (zz * 8.314462 * (t + 273.15))
        vsg, vsl = qg / area, ql / area
        vm = vsg + vsl
        vd = 1.53 * (G * sigma * (rho_l - rho_g) / rho_l ** 2) ** 0.25
        alpha = min(vsg / (1.2 * vm + vd), 0.98) if vm > 0 else 0.0
        rho_m = alpha * rho_g + (1 - alpha) * rho_l
        mu_m = 1e-3 * (1 - alpha) * 1.5 + alpha * 1.5e-5
        re = max(rho_m * vm * d / mu_m, 3000)
        f = 1.0 / (-1.8 * np.log10(6.9 / re + (rough_mm * 1e-3 / d / 3.7) ** 1.11)) ** 2
        p += (rho_m * G + f * rho_m * vm * vm / (2 * d)) * dz / 1e5
    return p


def ipr_pwf(q, pr, pi, pb=0.0):
    """Pwf for a rate: linear above pb, Vogel below. q in m3/d, pi m3/d/bar."""
    if pb <= 0 or pb >= pr:
        return max(pr - q / pi, 1.0)
    qb = pi * (pr - pb)
    qmax = qb + pi * pb / 1.8
    if q <= qb:
        return pr - q / pi
    r = (-0.2 + np.sqrt(0.04 + 3.2 * (1 - (q - qb) / (qmax - qb)))) / 1.6 if q < qmax else 0.0
    return max(pb * r, 1.0)


def glpc(well: dict, inj_rates=None, n=14) -> pd.DataFrame:
    """Gas-lift performance curve: for each injection rate, the liquid rate where inflow (IPR) = outflow (traverse). well keys: pr, pi, pb, whp, depth, d_in, wc, gor, inj_depth, api, gas_sg."""
    inj = np.asarray(inj_rates if inj_rates is not None else np.linspace(0, 1.5e5, n), float)
    rows = []
    for qi in inj:
        f = lambda q: traverse(well["whp"], well["depth"], well["d_in"], q, well["wc"], well["gor"], qi, well["inj_depth"], well.get("api", 35), well.get("gas_sg", 0.7)) - ipr_pwf(q, well["pr"], well["pi"], well.get("pb", 0))
        qmax = well["pi"] * well["pr"] * 0.999
        try:
            q = brentq(f, 0.5, qmax) if f(0.5) < 0 else 0.0
        except ValueError:
            q = 0.0
        rows.append(dict(q_inj_sm3d=qi, q_liq_m3d=q))
    return pd.DataFrame(rows)


def fit_glpc(q_inj, q_liq, n_boot=100, seed=0) -> dict:
    """Concave quadratic q = a + b x - c x^2 (c>=0) with bootstrap; optimum x* = b/2c."""
    x, y = np.asarray(q_inj, float) / 1e5, np.asarray(q_liq, float)
    rng = np.random.default_rng(seed)

    def fit(xx, yy):
        A = np.column_stack([np.ones_like(xx), xx, -xx ** 2])
        co, *_ = np.linalg.lstsq(A, yy, rcond=None)
        co[2] = max(co[2], 1e-9)
        return co
    co = fit(x, y)
    opt = [fit(x[i], y[i])[1] / (2 * fit(x[i], y[i])[2]) for i in (rng.integers(0, len(x), len(x)) for _ in range(n_boot)) if len(set(i)) > 3]
    return dict(a=co[0], b=co[1], c=co[2], x_opt=co[1] / (2 * co[2]) * 1e5, q_opt=co[0] + co[1] ** 2 / (4 * co[2]),
                x_opt_p10=float(np.percentile(opt, 10)) * 1e5 if opt else np.nan, x_opt_p90=float(np.percentile(opt, 90)) * 1e5 if opt else np.nan)


def allocate(curves: dict, total_gas: float, current: dict | None = None) -> Result:
    """curves {well: dict(a,b,c)} on x = q_inj/1e5. Maximise sum q_i s.t. sum x_i <= total (SLSQP) vs equal split vs current."""
    names = list(curves)
    q = lambda x: sum(curves[w]["a"] + curves[w]["b"] * xi - curves[w]["c"] * xi ** 2 for w, xi in zip(names, x))
    T = total_gas / 1e5
    x0 = np.full(len(names), T / len(names))
    r = minimize(lambda x: -q(x), x0, bounds=[(0, None)] * len(names), constraints=[{"type": "ineq", "fun": lambda x: T - x.sum()}], method="SLSQP")
    opt = r.x
    rows = [dict(well=w, optimal=opt[i] * 1e5, equal=x0[i] * 1e5, current=(current or {}).get(w, np.nan)) for i, w in enumerate(names)]
    out = dict(table=pd.DataFrame(rows), q_opt=-r.fun, q_equal=q(x0), q_current=q(np.array([(current or {}).get(w, 0) / 1e5 for w in names])) if current else np.nan)
    res = Result("Gas allocation", out, Status.UNVALIDATED)
    res.messages.append(f"Optimal {out['q_opt']:.0f} vs equal split {out['q_equal']:.0f} m3/d liquid ({100*(out['q_opt']/max(out['q_equal'],1e-9)-1):+.1f} %). Requires engineering review and MoC.")
    return res


def instability(p: np.ndarray, dt_min: float = 1.0) -> dict:
    """Dominant oscillation period (FFT) and relative amplitude of a casing / tubing pressure trace. Heading flag: period 5-180 min and amplitude > 4 % of mean."""
    x = np.asarray(p, float)
    x = x[np.isfinite(x)]
    xd = x - np.polyval(np.polyfit(np.arange(len(x)), x, 1), np.arange(len(x)))
    sp = np.abs(np.fft.rfft(xd * np.hanning(len(xd))))
    fr = np.fft.rfftfreq(len(xd), dt_min)
    k = 1 + int(np.argmax(sp[1:]))
    period = 1 / fr[k]
    amp = float(np.ptp(xd) / max(abs(x.mean()), 1e-9))
    return dict(period_min=float(period), rel_amplitude=amp, heading=bool(5 <= period <= 180 and amp > 0.04))


def valve_spacing(p_ko, p_wh, g_kill, g_flow, g_gas=0.0007, n_max=8, drop=0.7, depth_max=4000.0) -> pd.DataFrame:
    """Constant surface-pressure-drop spacing (bar, bar/m). D1=(Pko-Pwh)/Gu; D(i+1)=(Pko_i - Pwh - Gf Di + Gu Di)/(Gu - Gg)."""
    d, rows = (p_ko - p_wh) / g_kill, []
    rows.append(dict(valve=1, depth_m=d, p_ko=p_ko))
    for i in range(1, n_max):
        pk = p_ko - drop * i
        d = (pk - p_wh - g_flow * d + g_kill * d) / (g_kill - g_gas)
        if d > depth_max or d - rows[-1]["depth_m"] < 30.0:      # spacing converged: deeper valves cannot be reached with this pressure margin
            break
        rows.append(dict(valve=i + 1, depth_m=d, p_ko=pk))
    return pd.DataFrame(rows)


def orifice_sm3d(d_port_mm, p_up_bara, p_dn_bara, t_c=60.0, gas_sg=0.7, cd=0.84, k=1.28) -> float:
    """Gas through a port (isentropic nozzle, critical or subcritical) -> Sm3/d."""
    pvt = GasPVT(gas_sg)
    z = float(pvt.z(p_up_bara, t_c))
    rho_up = float(pvt.rho(p_up_bara, t_c))
    r = max(p_dn_bara / p_up_bara, 1e-6)
    rc = (2 / (k + 1)) ** (k / (k - 1))
    A = np.pi * (d_port_mm * 1e-3) ** 2 / 4
    if r <= rc:
        m = cd * A * np.sqrt(k * rho_up * p_up_bara * 1e5 * (2 / (k + 1)) ** ((k + 1) / (k - 1)))
    else:
        m = cd * A * np.sqrt(2 * rho_up * p_up_bara * 1e5 * k / (k - 1) * (r ** (2 / k) - r ** ((k + 1) / k)))
    return float(m / pvt.sm3_per_day_to_kg_per_s(1.0))


def demo_field(n=5, seed=0) -> dict:
    rng = np.random.default_rng(seed)
    return {f"GL-{i+1}": dict(pr=200 + rng.uniform(-20, 20), pi=rng.uniform(3, 9), pb=0.0, whp=15.0, depth=2300 + rng.uniform(-200, 200), d_in=2.992, wc=rng.uniform(0.2, 0.7),
                              gor=rng.uniform(60, 150), inj_depth=2000.0, api=34.0, gas_sg=0.7) for i in range(n)}


def selftest() -> dict:
    w = demo_field(1)["GL-1"]
    c = glpc(w, n=8)
    assert c.q_liq_m3d.iloc[1:].max() > c.q_liq_m3d.iloc[0], "gas lift must help"
    fit = fit_glpc(c.q_inj_sm3d, c.q_liq_m3d)
    assert fit["c"] > 0 and fit["x_opt"] > 0
    curves = {k: fit_glpc(*glpc(v, n=8).T.values) for k, v in demo_field(3).items()}
    r = allocate(curves, 2.0e5)
    assert r.value["q_opt"] >= r.value["q_equal"] - 1e-6
    t = np.arange(600.0)
    ins = instability(100 + 6 * np.sin(2 * np.pi * t / 40) + np.random.default_rng(0).normal(0, 0.3, 600))
    assert abs(ins["period_min"] - 40) < 3 and ins["heading"]
    vs = valve_spacing(80, 15, 0.1, 0.05)
    assert vs.depth_m.is_monotonic_increasing
    assert 1e4 < orifice_sm3d(6, 80, 40) < 1e7
    return dict(x_opt=fit["x_opt"], gain_pct=100 * (r.value["q_opt"] / r.value["q_equal"] - 1), period=ins["period_min"])
