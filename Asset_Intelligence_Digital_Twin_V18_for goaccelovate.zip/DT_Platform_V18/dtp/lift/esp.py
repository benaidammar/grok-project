"""ESP toolbox (V18) - port and extension of the V12 esp_twin.py.  Logic only (no streamlit).

Parts
  1 physics core        ESPSystem (IPR linear/Vogel + system curve + pump curve by affinity laws), generic catalogue, curve fitting
  2 synthetic data      simulate_esp_timeseries (modes motor|gas|scale), demo_multiwell, demo_fleet
  3 data QC             qc_pipeline (frozen / IsolationForest spikes / gap fill / change points / Savitzky-Golay)
  4 gas handling        Standing black-oil, intake GVF, head degradation, separator efficiency
  5 diagnostics         rules engine + health score;   wear tracking (physics inversion + residual)
  6 PCA monitor         Hotelling T2 + SPE
  7 reliability         Weibull AFT (lifelines or built-in MLE), Cox (lifelines), Kaplan-Meier, MTBF, Pareto, bootstrap
  8 optimisation/energy frequency optimisation (Optuna or scipy), sweeps, energy KPIs, sizing wizard
Units: bar(a), m3/d, m, kW, A, degC, Hz.  All outputs are decision SUPPORT for engineering review / management of change.
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass, replace

import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import brentq, minimize, minimize_scalar
from scipy.signal import savgol_filter
from sklearn.decomposition import PCA
from sklearn.ensemble import IsolationForest
from sklearn.impute import KNNImputer
from sklearn.preprocessing import StandardScaler

from ..core.deps import try_import
from ..core.status import Result, Status, failed

rpt = try_import("ruptures")
_lifelines = try_import("lifelines")
_optuna = try_import("optuna")
if _optuna is not None:
    _optuna.logging.set_verbosity(_optuna.logging.WARNING)
warnings.filterwarnings("ignore", category=FutureWarning)

G = 9.81
CHANNELS = ["pintake", "pdisch", "tmotor", "current", "thp"]
MONITOR_FEATURES = ["freq", "pintake", "dP", "tmotor", "current"]
STD_MOTOR_KW = [30, 45, 60, 75, 90, 112, 135, 150, 180, 225, 260, 300, 375, 450, 600]
BBL_PER_M3 = 6.28981


# =============================================================================
# 1. PHYSICS CORE
# =============================================================================
@dataclass
class ESPSystem:
    """Well + ESP model. Replace the numbers with your well data / vendor curves."""
    p_res: float = 250.0          # bar
    pi_index: float = 4.0         # m3/d/bar
    pb: float = 0.0               # bubble point, bar; 0 or >= p_res -> linear IPR, else Vogel below pb
    p_wh: float = 15.0
    pump_depth: float = 2500.0    # m TVD
    rho: float = 850.0            # kg/m3 mean fluid density in tubing
    fric_k: float = 1.0e-4
    fric_n: float = 1.8
    t_bh: float = 105.0
    stages: int = 270
    f0: float = 50.0
    h_coef: tuple = (9.5, -0.0012, -7.5e-6)     # head per stage = a0 + a1 q + a2 q^2 (q at f0, m3/d)
    q_bep0: float = 700.0
    eta_max: float = 0.68
    eta_width: float = 0.65       # efficiency parabola half-width as fraction of q_bep
    motor_eff: float = 0.90
    motor_kw: float = 180.0
    wear: float = 1.0
    volts0: float = 2400.0
    pf: float = 0.85

    # --- IPR ----------------------------------------------------------------
    def _vogel(self):
        if 0 < self.pb < self.p_res:
            qb = self.pi_index * (self.p_res - self.pb)
            return qb, qb + self.pi_index * self.pb / 1.8
        return None

    def q_max(self) -> float:
        v = self._vogel()
        return v[1] if v else self.p_res * self.pi_index

    def p_intake_of_q(self, q):
        q = np.asarray(q, dtype=float)
        lin = self.p_res - q / self.pi_index
        v = self._vogel()
        if v is None:
            return lin
        qb, qmax = v
        x = np.clip((q - qb) / (qmax - qb), 0, 1)
        return np.where(q <= qb, lin, 0.125 * self.pb * (-1 + np.sqrt(81 - 80 * x)))

    def q_of_p_intake(self, p):
        p = np.asarray(p, dtype=float)
        lin = (self.p_res - p) * self.pi_index
        v = self._vogel()
        if v is None:
            return np.maximum(lin, 0)
        qb, qmax = v
        r = np.clip(p / self.pb, 0, 1)
        return np.maximum(np.where(p >= self.pb, lin, qb + (qmax - qb) * (1 - 0.2 * r - 0.8 * r * r)), 0)

    # --- curves -----------------------------------------------------------------
    def pump_head(self, q, f):
        qe = np.asarray(q, dtype=float) * self.f0 / f
        a0, a1, a2 = self.h_coef
        return np.maximum((a0 + a1 * qe + a2 * qe ** 2) * self.stages * (f / self.f0) ** 2 * self.wear, 0.0)

    def required_head(self, q, p_wh=None):
        p_wh = self.p_wh if p_wh is None else p_wh
        q = np.asarray(q, dtype=float)
        p_dis = p_wh + self.rho * G * self.pump_depth / 1e5 + self.fric_k * q ** self.fric_n
        return (p_dis - self.p_intake_of_q(q)) * 1e5 / (self.rho * G)

    def efficiency(self, q, f):
        qe = np.asarray(q, dtype=float) * self.f0 / f
        return self.eta_max * np.maximum(0.05, 1 - ((qe - self.q_bep0) / (self.eta_width * self.q_bep0)) ** 2)

    def shaft_kw(self, q, f):
        q = np.asarray(q, dtype=float)
        return q / 86400.0 * self.rho * G * self.pump_head(q, f) / 1000.0 / self.efficiency(q, f)

    def bep_q(self, f):
        return self.q_bep0 * f / self.f0

    def operating_point(self, f: float, p_wh: float | None = None) -> dict | None:
        p_wh_ = self.p_wh if p_wh is None else p_wh
        fun = lambda q: float(self.pump_head(q, f)) - float(self.required_head(q, p_wh_))
        if fun(1e-3) <= 0:
            return None
        hi = 0.999 * self.q_max()
        limited = False
        if fun(hi) > 0:                       # pump stronger than the IPR can feed: drawdown limited
            q, limited = hi, True
        else:
            q = brentq(fun, 1e-3, hi)
        head = float(self.pump_head(q, f))
        p_in = float(self.p_intake_of_q(q))
        eta = float(self.efficiency(q, f))
        hyd_kw = q / 86400.0 * self.rho * G * head / 1000.0
        shaft = hyd_kw / eta
        elec = shaft / self.motor_eff
        load = shaft / self.motor_kw
        volts = self.volts0 * f / self.f0
        return dict(freq=f, p_wh=p_wh_, q=q, p_intake=p_in, p_discharge=p_in + self.rho * G * head / 1e5, head=head, eta=eta,
                    hyd_kw=hyd_kw, shaft_kw=shaft, elec_kw=elec, load=load, current=elec * 1000.0 / (np.sqrt(3) * volts * self.pf),
                    t_motor=self.t_bh + 38.0 * load ** 2, thrust_ratio=q / (self.q_bep0 * f / self.f0), drawdown_limited=limited)


def current_from_power(system: ESPSystem, elec_kw, f):
    return np.asarray(elec_kw, float) * 1000.0 / (np.sqrt(3) * system.volts0 * np.asarray(f, float) / system.f0 * system.pf)


# ---- generic catalogue (PLACEHOLDERS - not vendor data) --------------------------------------------------
CATALOGUE = {
    "GENERIC-400 (placeholder, not vendor data)": dict(h0=7.0, q_bep0=400.0, eta_max=0.62, max_stages=450),
    "GENERIC-700 (placeholder, not vendor data)": dict(h0=9.5, q_bep0=700.0, eta_max=0.68, max_stages=400),
    "GENERIC-1200 (placeholder, not vendor data)": dict(h0=12.5, q_bep0=1200.0, eta_max=0.70, max_stages=350),
}


def system_from_series(name: str, base: ESPSystem, stages: int | None = None) -> ESPSystem:
    c = CATALOGUE[name]
    qb, h0 = c["q_bep0"], c["h0"]
    return replace(base, h_coef=(h0, -0.0884 * h0 / qb, -0.3868 * h0 / qb ** 2), q_bep0=qb, eta_max=c["eta_max"], stages=stages or base.stages)


def fit_pump_curve(curve: pd.DataFrame) -> Result:
    """Vendor curve at rated Hz: columns q (m3/d), head_stage (m), eff (0-1 or %) [, bhp_stage]. Quadratic head fit,
    BEP = max efficiency, parabolic efficiency width fitted by least squares."""
    res = Result("Pump curve fit")
    try:
        d = curve.rename(columns=str.lower).dropna(subset=["q", "head_stage"]).sort_values("q")
        if len(d) < 4:
            return failed("Pump curve fit", "Need at least 4 curve points")
        a2, a1, a0 = np.polyfit(d["q"], d["head_stage"], 2)
        pred = np.polyval([a2, a1, a0], d["q"])
        r2 = 1 - ((d["head_stage"] - pred) ** 2).sum() / max(((d["head_stage"] - d["head_stage"].mean()) ** 2).sum(), 1e-12)
        out = dict(h_coef=(a0, a1, a2), r2_head=float(r2))
        if "eff" in d:
            e = d["eff"].astype(float)
            e = e / 100 if e.max() > 1.5 else e
            i = int(np.argmax(e.values))
            qb, em = float(d["q"].iloc[i]), float(e.iloc[i])
            w = minimize_scalar(lambda w: float(((em * np.maximum(0.05, 1 - ((d["q"] - qb) / (w * qb)) ** 2) - e) ** 2).sum()), bounds=(0.2, 2.0), method="bounded").x
            out.update(q_bep0=qb, eta_max=em, eta_width=float(w))
        res.value = out
        if r2 < 0.98:
            res.warn(f"Quadratic head fit R2={r2:.3f}: curve is not well described by a parabola")
        res.status = res.status if res.status != Status.OK else Status.OK
    except Exception as exc:                                      # noqa: BLE001
        return failed("Pump curve fit", f"{type(exc).__name__}: {exc}")
    return res


def performance_map(system: ESPSystem, freqs=(35, 40, 45, 50, 55, 60), n=120, band=(0.75, 1.20)) -> dict:
    """Curves for plotting: per frequency head/eff/power vs q, recommended operating window [band*BEP(f)], system curve, operating points."""
    out = {"curves": [], "system": None, "ops": []}
    qmax = system.q_max() * 0.98
    qs = np.linspace(1, min(qmax, 2.2 * system.q_bep0 * max(freqs) / system.f0), n)
    for f in freqs:
        out["curves"].append(dict(freq=f, q=qs, head=system.pump_head(qs, f), eff=system.efficiency(qs, f) * (qs > 0),
                                  shaft_kw=system.shaft_kw(qs, f), window=(band[0] * system.bep_q(f), band[1] * system.bep_q(f)),
                                  bep=system.bep_q(f)))
        op = system.operating_point(f)
        if op:
            out["ops"].append(op)
    out["system"] = dict(q=qs, head=system.required_head(qs))
    return out


# =============================================================================
# 2. SYNTHETIC DATA
# =============================================================================
def _ar1(n: int, sigma, phi: float, rng) -> np.ndarray:
    sigma = np.broadcast_to(np.asarray(sigma, dtype=float), (n,))
    e = rng.normal(size=n)
    x = np.zeros(n)
    for i in range(1, n):
        x[i] = phi * x[i - 1] + np.sqrt(1 - phi ** 2) * sigma[i] * e[i]
    return x


NOISE_SIGMA = dict(freq=0.03, pintake=0.35, pdisch=0.6, tmotor=0.5, current=0.4, thp=0.15)


def _op_table(base: ESPSystem, f_true: np.ndarray, wear: np.ndarray) -> dict:
    """Operating points for every hour; solved on a (frequency x wear) grid then interpolated (fast, smooth)."""
    keys = ["p_intake", "p_discharge", "t_motor", "current", "q"]
    out = {k: np.full(len(f_true), np.nan) for k in keys}
    wg = np.linspace(wear.min() - 1e-3, wear.max() + 1e-3, 14)
    for f in np.unique(np.round(f_true, 3)):
        m = np.isclose(f_true, f, atol=1e-3)
        vals = {k: [] for k in keys}
        for w in wg:
            op = replace(base, wear=float(w)).operating_point(float(f))
            for k in keys:
                vals[k].append(np.nan if op is None else op[k])
        for k in keys:
            out[k][m] = np.interp(wear[m], wg, vals[k])
    return out


def simulate_esp_timeseries(days: int = 150, seed: int = 1, system: ESPSystem | None = None, onset_days: int = 20,
                            freq_schedule: dict | None = None, mode: str = "motor"):
    """Hourly ESP data ending in a failure. mode: 'motor' (hot motor + unstable current, V12), 'gas' (gas interference:
    falling, unstable current and noisy intake), 'scale' (head loss + rising current/temperature).
    Returns (raw, ref, truth)."""
    rng = np.random.default_rng(seed)
    base = system or ESPSystem()
    n = days * 24
    idx = pd.date_range("2026-01-01", periods=n, freq="h")
    sched = freq_schedule or {0: 50, 18: 52, 40: 48, 63: 50, 90: 53, 112: 51}
    f_true = np.empty(n)
    for d, f in sorted(sched.items()):
        f_true[d * 24:] = f
    t0 = n - onset_days * 24
    ramp = np.clip((np.arange(n) - t0) / (n - t0), 0, 1)
    wear = 1 - 0.03 * np.arange(n) / n - 0.12 * ramp ** 2
    if mode == "gas":
        wear = wear - 0.05 * ramp ** 2
    elif mode == "scale":
        wear = 1 - 0.03 * np.arange(n) / n - 0.10 * ramp
    op = _op_table(base, f_true, wear)
    cols = dict(pintake=op["p_intake"], pdisch=op["p_discharge"], tmotor=op["t_motor"].copy(), current=op["current"].copy(), q_true=op["q"])
    cur_noise, pin_noise = 1 + 6 * ramp ** 2, 1 + 4 * ramp ** 2
    if mode == "motor":
        cols["tmotor"] += 20 * ramp ** 2
        cols["current"] *= 1 + 0.06 * ramp ** 2
    elif mode == "gas":
        cols["current"] *= 1 - 0.10 * ramp ** 2
        cur_noise, pin_noise = 1 + 12 * ramp ** 2, 1 + 9 * ramp ** 2
    elif mode == "scale":
        cols["current"] *= 1 + 0.08 * ramp
        cols["tmotor"] += 8 * ramp
    ref = pd.DataFrame(index=idx)
    ref["freq"] = f_true + _ar1(n, NOISE_SIGMA["freq"], 0.3, rng)
    ref["pintake"] = cols["pintake"] + _ar1(n, NOISE_SIGMA["pintake"] * pin_noise, 0.7, rng)
    ref["pdisch"] = cols["pdisch"] + _ar1(n, NOISE_SIGMA["pdisch"], 0.7, rng)
    ref["tmotor"] = cols["tmotor"] + _ar1(n, NOISE_SIGMA["tmotor"], 0.7, rng)
    ref["current"] = cols["current"] + _ar1(n, NOISE_SIGMA["current"] * cur_noise, 0.7, rng)
    ref["thp"] = base.p_wh + _ar1(n, NOISE_SIGMA["thp"], 0.7, rng)
    ref["q_true"] = cols["q_true"]
    raw = ref.copy()
    spikes = pd.DataFrame(False, index=idx, columns=CHANNELS)
    frozen, gaps = spikes.copy(), spikes.copy()
    for c in CHANNELS:
        m = rng.random(n) < 0.006
        spikes[c] = m
        sign = rng.choice([-1, 1], size=n)
        raw.loc[m, c] = ref.loc[m, c] + (sign * rng.uniform(7, 12, size=n) * NOISE_SIGMA[c])[m]
    for c, d0, hrs in [("pintake", 30, 36), ("tmotor", 80, 24)]:
        s = d0 * 24
        frozen.iloc[s:s + hrs, frozen.columns.get_loc(c)] = True
        raw.iloc[s:s + hrs, raw.columns.get_loc(c)] = raw.iloc[s, raw.columns.get_loc(c)]
    s = 55 * 24
    for c in ["pintake", "pdisch"]:
        gaps.iloc[s:s + 10, gaps.columns.get_loc(c)] = True
    for c in CHANNELS:
        gaps[c] |= rng.random(n) < 0.015
    spikes &= ~(frozen | gaps)
    for c in CHANNELS:
        raw.loc[gaps[c], c] = np.nan
    truth = dict(spikes=spikes, frozen=frozen, gaps=gaps, onset_idx=t0, fail_idx=n - 1, wear=wear, mode=mode,
                 freq_steps=[d * 24 for d in sorted(sched) if d > 0])
    return raw, ref, truth


def demo_multiwell(days: int = 150, seed: int = 1) -> pd.DataFrame:
    """3 wells with different failure modes + 1 healthy well (no onset): long-format frame with a 'well' column."""
    spec = [("ESP-A1 (motor overheating)", "motor", 20, 1), ("ESP-B2 (gas interference)", "gas", 20, 2),
            ("ESP-C3 (scale / head loss)", "scale", 25, 3)]
    frames = []
    for name, mode, onset, k in spec:
        raw, _, _ = simulate_esp_timeseries(days=days, seed=seed + k, onset_days=onset, mode=mode,
                                            system=ESPSystem(pi_index=3.5 + 0.5 * k, p_res=240 + 10 * k))
        raw = raw.drop(columns=["q_true"])
        raw.insert(0, "well", name)
        frames.append(raw.rename_axis("time").reset_index())
    return pd.concat(frames, ignore_index=True)


TRUE_AFT = dict(intercept=6.6, gvf=-4.0, water_cut=-0.6, freq_c=-0.25, starts=-0.08, rho=1.5)


def simulate_fleet(n: int = 500, seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    d = pd.DataFrame({"gvf": rng.uniform(0.0, 0.30, n), "water_cut": rng.uniform(0.05, 0.85, n),
                      "freq_c": (rng.uniform(40, 62, n) - 50) / 5.0, "starts": rng.poisson(3, n).astype(float)})
    t = TRUE_AFT
    lam = np.exp(t["intercept"] + t["gvf"] * d.gvf + t["water_cut"] * d.water_cut + t["freq_c"] * d.freq_c + t["starts"] * d.starts)
    life = lam * (-np.log(rng.uniform(size=n))) ** (1 / t["rho"])
    cens = rng.uniform(200, 1500, n)
    d["run_days"] = np.minimum(life, cens)
    d["failed"] = (life <= cens).astype(int)
    return d


def demo_fleet(n: int = 300, seed: int = 0) -> pd.DataFrame:
    d = simulate_fleet(n, seed)
    mode = np.where(d.gvf > 0.18, "gas interference", np.where(d.starts > 4, "electrical / start stress",
                    np.where(d.water_cut > 0.6, "scale / corrosion", "wear / sand")))
    d["failure_mode"] = np.where(d.failed == 1, mode, "")
    d.insert(0, "well", [f"RUN-{i:03d}" for i in range(len(d))])
    return d


# =============================================================================
# 3. DATA QC
# =============================================================================
def _pelt_l2(x: np.ndarray, pen: float, min_size: int) -> list[int]:
    """Pure-numpy PELT (Killick 2012), squared-error cost. Returns segment start indices."""
    n = len(x)
    c1 = np.concatenate([[0.0], np.cumsum(x)])
    c2 = np.concatenate([[0.0], np.cumsum(x * x)])

    def cost(s, e):
        m = e - s
        return (c2[e] - c2[s]) - (c1[e] - c1[s]) ** 2 / m

    F = np.full(n + 1, np.inf)
    F[0] = -pen
    last = np.zeros(n + 1, dtype=int)
    cand = [0]
    for t in range(min_size, n + 1):
        taus = np.array([s for s in cand if t - s >= min_size])
        if taus.size == 0:
            continue
        vals = F[taus] + cost(taus, t) + pen
        k = int(np.argmin(vals))
        F[t], last[t] = vals[k], taus[k]
        cand = [s for s, v in zip(taus, vals) if v - pen <= F[t]]
        if t - min_size + 1 <= n:
            cand.append(t - min_size + 1)
    bk, t = [], n
    while t > 0:
        t = last[t]
        if t > 0:
            bk.append(int(t))
    return sorted(bk)


def detect_change_points(freq: np.ndarray, pen: float = 0.5, min_size: int = 3) -> list[int]:
    x = np.asarray(freq, dtype=float)
    if rpt is not None:
        bkps = rpt.Pelt(model="l2", min_size=min_size, jump=1).fit(x.reshape(-1, 1)).predict(pen=pen)
        return [b for b in bkps if b < len(x)]
    if len(x) > 800:                                   # pure-python PELT is O(n^2)-ish: run on block medians, map indices back
        k = int(np.ceil(len(x) / 600))
        m = len(x) // k
        xb = np.median(x[:m * k].reshape(m, k), axis=1)
        return [int(b * k) for b in _pelt_l2(xb, pen, max(1, int(np.ceil(min_size / k))))]
    return _pelt_l2(x, pen, min_size)


@dataclass
class QCResult:
    clean: pd.DataFrame
    spikes: pd.DataFrame
    frozen: pd.DataFrame
    filled: pd.DataFrame
    change_points: list
    steady: np.ndarray


def qc_pipeline(raw: pd.DataFrame, contamination: float = 0.04, hampel_win: int = 5, z_thr: float = 6.0, frozen_run: int = 8,
                short_gap: int = 3, sg_window: int = 7, sg_order: int = 2, cp_pen: float = 0.5, settle_hours: int = 6,
                seed: int = 0, channels: list | None = None) -> QCResult:
    CH = list(channels or CHANNELS)
    df = raw.copy()
    df["freq"] = df["freq"].interpolate(limit_area="inside").bfill().ffill()
    n = len(df)
    frozen = pd.DataFrame(False, index=df.index, columns=CH)
    for c in CH:
        s = df[c].dropna()
        same = s.diff().eq(0)
        run = same.groupby((~same).cumsum()).transform("sum")
        frozen.loc[s.index, c] = (run >= frozen_run - 1).values
    df[CH] = df[CH].mask(frozen)
    med = df[CH].rolling(hampel_win, center=True, min_periods=3).median()
    res = df[CH] - med
    sig = 1.4826 * res.abs().rolling(168, center=True, min_periods=24).median()
    sig = sig.bfill().ffill().clip(lower=1e-6)
    z = res / sig
    zf = z.fillna(0.0)
    iso = IsolationForest(n_estimators=200, contamination=contamination, random_state=seed).fit(zf)
    row_flag = iso.predict(zf) == -1
    spikes = (z.abs() > z_thr) & pd.DataFrame(np.repeat(row_flag[:, None], len(CH), 1), index=df.index, columns=CH)
    df[CH] = df[CH].mask(spikes)
    missing = df[CH].isna()
    for c in CH:
        isn = df[c].isna()
        runlen = isn.groupby((~isn).cumsum()).transform("sum")
        interp = df[c].interpolate(limit_area="inside")
        short = isn & (runlen <= short_gap)
        df.loc[short, c] = interp[short]
    if df[CH].isna().any().any():
        cols = CH + ["freq"]
        scaler = StandardScaler().fit(df[cols])
        arr = KNNImputer(n_neighbors=5, weights="distance").fit_transform(scaler.transform(df[cols]))
        df[cols] = scaler.inverse_transform(arr)
    cps = detect_change_points(df["freq"].values, pen=cp_pen)
    bounds = [0] + cps + [n]
    for s, e in zip(bounds[:-1], bounds[1:]):
        if e - s >= sg_window:
            for c in CH:
                j = df.columns.get_loc(c)
                df.iloc[s:e, j] = savgol_filter(df.iloc[s:e, j].values, sg_window, sg_order)
    steady = np.ones(n, dtype=bool)
    for cp in cps:
        steady[cp:cp + settle_hours] = False
    return QCResult(df, spikes, frozen, missing, cps, steady)


def _num(s: pd.Series) -> pd.Series:
    if not pd.api.types.is_numeric_dtype(s):
        s = s.astype(str).str.replace(",", ".", regex=False).str.replace(r"[^0-9eE+\-.]", "", regex=True)
    return pd.to_numeric(s, errors="coerce")


def prepare_timeseries(src: pd.DataFrame, mapping: dict, rule: str = "1h", dayfirst: bool = True) -> Result:
    """Mapped upload -> time-indexed numeric frame (resampled to `rule` if finer). mapping: key -> column (time,freq,pintake,pdisch,tmotor,current[,thp])."""
    res = Result("ESP time-series preparation")
    try:
        t = src[mapping["time"]]
        t = t if pd.api.types.is_datetime64_any_dtype(t) else pd.to_datetime(t, errors="coerce", dayfirst=dayfirst)
        df = pd.DataFrame({"time": t})
        for k in ["freq", "pintake", "pdisch", "tmotor", "current", "thp"]:
            if mapping.get(k):
                df[k] = _num(src[mapping[k]])
        df = df.dropna(subset=["time"]).drop_duplicates("time").sort_values("time").set_index("time")
        step = df.index.to_series().diff().median() if len(df) > 1 else pd.NaT
        if pd.notna(step) and step <= pd.Timedelta(rule):
            df = df.resample(rule).mean()
        elif pd.notna(step):
            res.warn(f"Data sampled every {step}, coarser than {rule}: not resampled; cleaning filters assume ~hourly data.")
        if len(df) < 300 or df["freq"].notna().sum() < 100:
            return failed("ESP time-series preparation", f"Not enough usable rows ({len(df)}); need >= ~300 with frequency values")
        res.value = df
        res.meta = dict(rows=len(df), step=str(step))
    except Exception as exc:                                    # noqa: BLE001
        return failed("ESP time-series preparation", f"{type(exc).__name__}: {exc}")
    return res
