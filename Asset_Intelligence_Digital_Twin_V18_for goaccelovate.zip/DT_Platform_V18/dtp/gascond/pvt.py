"""Gas PVT for wet/dry gas with CO2 / H2S / N2 (screening-grade correlations; replace with lab EOS when available).

  pseudo-criticals   Sutton (1985) from gas gravity, Wichert-Aziz (1972) correction for CO2/H2S,
                     Standing-Katz style N2 shift ignored (small)  -> flagged in .notes
  Z factor           Dranchuk & Abou-Kassem (1975), valid Ppr 0.2-30, Tpr 1.0-3.0 (out-of-range is flagged)
  viscosity          Lee-Gonzalez-Eakin (1966)
Units in/out: p [bara], T [degC], rho [kg/m3], mu [cP], Bg [rm3/Sm3], m(p) [bar^2/cP].
"""
from __future__ import annotations
from dataclasses import dataclass, field

import numpy as np

R_SI = 8.314462618
M_AIR = 28.9647
_A = dict(A1=0.3265, A2=-1.0700, A3=-0.5339, A4=0.01569, A5=-0.05165, A6=0.5475, A7=-0.7361,
          A8=0.1844, A9=0.1056, A10=0.6134, A11=0.7210)


@dataclass
class GasPVT:
    gas_sg: float = 0.70           # air = 1 (wet-gas / well-stream gravity if you only have that)
    co2_pct: float = 0.0           # mol %
    h2s_ppm: float = 0.0
    n2_pct: float = 0.0
    t_std_c: float = 15.0
    p_std_bar: float = 1.01325
    notes: list = field(default_factory=list)

    # ---- pseudo-critical properties -------------------------------------------------
    def pseudo_critical(self) -> tuple[float, float]:
        """-> (Tpc [K], Ppc [bara]) after Wichert-Aziz."""
        g = self.gas_sg
        tpc = 169.2 + 349.5 * g - 74.0 * g * g                      # degR
        ppc = 756.8 - 131.0 * g - 3.6 * g * g                       # psia
        a = self.co2_pct / 100.0 + self.h2s_ppm / 1e6               # y_CO2 + y_H2S
        b = self.h2s_ppm / 1e6
        if a > 0:
            eps = 120.0 * (a ** 0.9 - a ** 1.6) + 15.0 * (b ** 0.5 - b ** 4)
            tpc_c = tpc - eps
            ppc = ppc * tpc_c / (tpc + b * (1 - b) * eps)
            tpc = tpc_c
        return tpc / 1.8, ppc * 0.0689475729

    def mol_weight(self) -> float:
        return M_AIR * self.gas_sg

    # ---- Z factor ---------------------------------------------------------------------
    def z(self, p_bara, t_c):
        p = np.atleast_1d(np.asarray(p_bara, dtype=float))
        t = np.broadcast_to(np.asarray(t_c, dtype=float), p.shape)
        tpc, ppc = self.pseudo_critical()
        ppr, tpr = np.maximum(p, 0.05) / ppc, (t + 273.15) / tpc
        a = _A
        rho = 0.27 * ppr / tpr                                       # first guess (Z=1)
        for _ in range(60):
            r2 = rho * rho
            z = (1 + (a["A1"] + a["A2"] / tpr + a["A3"] / tpr ** 3 + a["A4"] / tpr ** 4 + a["A5"] / tpr ** 5) * rho
                 + (a["A6"] + a["A7"] / tpr + a["A8"] / tpr ** 2) * r2
                 - a["A9"] * (a["A7"] / tpr + a["A8"] / tpr ** 2) * rho ** 5
                 + a["A10"] * (1 + a["A11"] * r2) * (r2 / tpr ** 3) * np.exp(-a["A11"] * r2))
            f = 0.27 * ppr / (z * tpr) - rho
            h = 1e-6
            r2h = (rho + h) ** 2
            zh = (1 + (a["A1"] + a["A2"] / tpr + a["A3"] / tpr ** 3 + a["A4"] / tpr ** 4 + a["A5"] / tpr ** 5) * (rho + h)
                  + (a["A6"] + a["A7"] / tpr + a["A8"] / tpr ** 2) * r2h
                  - a["A9"] * (a["A7"] / tpr + a["A8"] / tpr ** 2) * (rho + h) ** 5
                  + a["A10"] * (1 + a["A11"] * r2h) * (r2h / tpr ** 3) * np.exp(-a["A11"] * r2h))
            fh = 0.27 * ppr / (zh * tpr) - (rho + h)
            d = (fh - f) / h
            step = np.where(np.abs(d) > 1e-12, f / d, 0.0)
            rho = np.clip(rho - step, 1e-6, 3.0)
            if np.max(np.abs(step)) < 1e-10:
                break
        zf = 0.27 * ppr / (rho * tpr)
        return zf if np.ndim(p_bara) else float(zf[0])

    def in_range(self, p_bara, t_c) -> bool:
        tpc, ppc = self.pseudo_critical()
        ppr = np.asarray(p_bara, float) / ppc
        tpr = (np.asarray(t_c, float) + 273.15) / tpc
        return bool(np.all((ppr >= 0.2) & (ppr <= 30) & (tpr >= 1.0) & (tpr <= 3.0)))

    # ---- derived properties ---------------------------------------------------------------
    def rho(self, p_bara, t_c):
        """kg/m3 at P,T."""
        p, t = np.asarray(p_bara, float), np.asarray(t_c, float)
        return p * 1e5 * self.mol_weight() * 1e-3 / (self.z(p, t) * R_SI * (t + 273.15))

    def bg(self, p_bara, t_c):
        """rm3/Sm3."""
        p, t = np.asarray(p_bara, float), np.asarray(t_c, float)
        return self.z(p, t) * (t + 273.15) * self.p_std_bar / (p * (self.t_std_c + 273.15))

    def mu(self, p_bara, t_c):
        """cP, Lee-Gonzalez-Eakin."""
        p, t = np.asarray(p_bara, float), np.asarray(t_c, float)
        m = self.mol_weight()
        tr = (t + 273.15) * 1.8
        rho_gcc = self.rho(p, t) / 1000.0
        k = (9.379 + 0.01607 * m) * tr ** 1.5 / (209.2 + 19.26 * m + tr)
        x = 3.448 + 986.4 / tr + 0.01009 * m
        y = 2.447 - 0.2224 * x
        return 1e-4 * k * np.exp(x * rho_gcc ** y)

    def compressibility(self, p_bara, t_c):
        """1/bar, cg = 1/p - (1/z) dz/dp (numeric)."""
        p = np.asarray(p_bara, float)
        dp = np.maximum(p * 1e-3, 1e-3)
        dz = (self.z(p + dp, t_c) - self.z(p - dp, t_c)) / (2 * dp)
        return 1.0 / p - dz / self.z(p, t_c)

    def pseudo_pressure(self, p_bara, t_c, p_ref: float = 1.0, n: int = 400):
        """m(p) = 2 * integral_{p_ref}^{p} p/(mu z) dp  [bar^2/cP]; vectorised on a log-spaced grid."""
        p = np.atleast_1d(np.asarray(p_bara, float))
        grid = np.unique(np.concatenate([np.linspace(p_ref, max(p.max(), p_ref + 1) * 1.001, n), p]))
        f = grid / (self.mu(grid, t_c) * self.z(grid, t_c))
        cum = np.concatenate([[0.0], np.cumsum(0.5 * (f[1:] + f[:-1]) * np.diff(grid))]) * 2.0
        out = np.interp(p, grid, cum)
        return out if np.ndim(p_bara) else float(out[0])

    def sm3_per_day_to_kg_per_s(self, q_sm3d):
        rho_std = self.p_std_bar * 1e5 * self.mol_weight() * 1e-3 / (R_SI * (self.t_std_c + 273.15))   # kg/Sm3 (Z~1)
        return np.asarray(q_sm3d, float) * rho_std / 86400.0

    @classmethod
    def from_cfg(cls, cfg) -> "GasPVT":
        return cls(gas_sg=cfg.gas_sg, co2_pct=cfg.co2_pct, h2s_ppm=cfg.h2s_ppm, n2_pct=cfg.n2_pct, t_std_c=cfg.t_std_c, p_std_bar=cfg.p_std_bar)


def bottomhole_from_wellhead(pvt: GasPVT, whp_bara, t_wh_c, t_bh_c, tvd_m, q_sm3d=0.0, id_in=4.0, rough_mm=0.0457, md_m=None):
    """Gas column, average temperature and Z (iterated), analytical solution of
        d(p^2)/dz = 2 a p^2 + 2 b      a = M g/(Z R T) * TVD/MD ,  b = f G^2 Z R T /(2 d M)
        p_bh^2 = p_wh^2 e^{2aL} + (b/a)(e^{2aL}-1)
    q = 0 gives the static column.  Screening-grade (dry-gas, single phase): liquids in the tubing add weight and friction.
    -> bara (array if whp is array)."""
    p_wh = np.atleast_1d(np.asarray(whp_bara, float))
    q = np.broadcast_to(np.asarray(q_sm3d, float), p_wh.shape)
    md = float(md_m or tvd_m)
    t_avg = 0.5 * (t_wh_c + t_bh_c) + 273.15
    m_kg = pvt.mol_weight() * 1e-3
    d = id_in * 0.0254
    area = np.pi * d * d / 4
    p_bh = p_wh * 1.1
    for _ in range(30):
        p_avg = 0.5 * (p_wh + p_bh)
        z = pvt.z(p_avg, t_avg - 273.15)
        a_l = m_kg * 9.80665 * tvd_m / (z * R_SI * t_avg)                  # a*L (dimensionless)
        g_flux = pvt.sm3_per_day_to_kg_per_s(q) / area                      # kg/m2/s
        mu = pvt.mu(p_avg, t_avg - 273.15) * 1e-3                           # Pa s
        re_ = np.maximum(g_flux * d / mu, 5e3)
        f = 1.0 / (-1.8 * np.log10(6.9 / re_ + (rough_mm * 1e-3 / d / 3.7) ** 1.11)) ** 2     # Darcy-Haaland
        b_over_a = f * g_flux ** 2 * z ** 2 * R_SI ** 2 * t_avg ** 2 / (2 * d * m_kg ** 2 * 9.80665) * (md / tvd_m)   # Pa^2
        e2 = np.exp(2 * a_l)
        p2 = (p_wh * 1e5) ** 2 * e2 + b_over_a * (e2 - 1)
        new = np.sqrt(p2) / 1e5
        if np.max(np.abs(new - p_bh)) < 1e-5:
            p_bh = new
            break
        p_bh = new
    return p_bh if np.ndim(whp_bara) else float(p_bh[0])
