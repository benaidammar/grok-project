"""Well / field forecasts from sparse tests: Arps + modified hyperbolic, bootstrap ranges, rolling-origin backtest.
Percentile naming: *_p10 = LOW case (10th percentile of the distribution), *_p90 = HIGH case. Tests are sparse, so every
daily series here is an interpolation (uncertainty grows with distance to the nearest test)."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

from ..core.status import Result, Status

YR = 365.25


def reconstruct_daily(wt: pd.DataFrame, freq: str = "D") -> pd.DataFrame:
    """Daily gas/cond/water/whp per well by linear interpolation between test dates (no extrapolation past first/last test).
    Column gap_days = distance to the nearest test (uncertainty proxy)."""
    out = []
    for w, g in wt.groupby("well"):
        d = g.groupby("date")[["gas_sm3d", "cond_m3d", "water_m3d", "whp_bara"]].mean().sort_index()
        idx = pd.date_range(d.index.min(), d.index.max(), freq=freq)
        r = d.reindex(idx.union(d.index)).interpolate("time").reindex(idx)
        tests = pd.Series(1, index=d.index).reindex(idx).notna().values
        pos = np.where(tests)[0]
        gap = np.abs(np.arange(len(idx))[:, None] - pos[None, :]).min(axis=1) if len(pos) else np.zeros(len(idx))
        r["gap_days"], r["well"] = gap, w
        out.append(r.rename_axis("date").reset_index())
    return pd.concat(out, ignore_index=True) if out else pd.DataFrame()


def arps(t, qi, d, b):
    """q(t) = qi (1 + b d t)^(-1/b); t [years], d nominal [1/yr]."""
    b = np.maximum(b, 1e-4)
    return qi * (1 + b * d * t) ** (-1 / b)


def modified_hyperbolic(t, qi, d, b, d_lim=0.05):
    """Hyperbolic until the instantaneous decline falls to d_lim [1/yr], then exponential."""
    b = max(b, 1e-4)
    t_sw = (d / d_lim - 1) / (b * d) if d > d_lim else 0.0
    t = np.asarray(t, float)
    q_sw = qi * (1 + b * d * t_sw) ** (-1 / b)
    with np.errstate(all='ignore'):
        return np.where(t < t_sw, qi * (1 + b * d * np.minimum(t, t_sw)) ** (-1 / b), q_sw * np.exp(-d_lim * (t - t_sw)))


def fit_arps(t, q, b_max: float = 1.0):
    """Least squares in log space. -> (qi, d, b) or None."""
    t, q = np.asarray(t, float), np.asarray(q, float)
    m = np.isfinite(t) & np.isfinite(q) & (q > 0)
    if m.sum() < 4:
        return None
    t, q = t[m], q[m]
    f = lambda tt, lqi, d, b: np.log(arps(tt, np.exp(lqi), d, b))
    best = None
    for b0 in (0.0, 0.5, 1.0):
        try:
            p, _ = curve_fit(f, t, np.log(q), p0=[np.log(q[0]), 0.15, b0], bounds=([np.log(q.min()) - 2, 1e-4, 0.0], [np.log(q.max()) + 2, 3.0, b_max]), maxfev=4000)
            sse = np.sum((f(t, *p) - np.log(q)) ** 2)
            if best is None or sse < best[0]:
                best = (sse, p)
        except Exception:                                       # noqa: BLE001
            pass
    return None if best is None else (float(np.exp(best[1][0])), float(best[1][1]), float(best[1][2]))


def _series(g: pd.DataFrame, years_back: float):
    d = g.groupby("date").gas_sm3d.mean().sort_index()
    d = d[d.index >= d.index.max() - pd.Timedelta(days=YR * years_back)]
    t = (d.index - d.index[0]).days.values / YR
    return d, t


def well_forecast(g: pd.DataFrame, years: float = 15, years_back: float = 10, d_lim: float = 0.05, q_econ: float = 1e5, n_boot: int = 40, seed: int = 0):
    """-> dict(ok, t0, q0, params, table(DataFrame t_years, p10, p50, p90), eur_p50 [Sm3 over horizon], msg)."""
    d, t = _series(g, years_back)
    fit = fit_arps(t, d.values)
    if fit is None or len(d) < 5:
        return dict(ok=False, msg="fewer than 5 usable test dates in window")
    qi, dd, b = fit
    res = np.log(d.values) - np.log(arps(t, qi, dd, b))
    rng = np.random.default_rng(seed)
    grid = np.arange(0, years * 12 + 1) / 12.0
    t_last = t[-1]
    curves = []
    for _ in range(n_boot):
        yb = np.exp(np.log(arps(t, qi, dd, b)) + rng.choice(res, len(res)))
        fb = fit_arps(t, yb)
        if fb:
            curves.append(modified_hyperbolic(t_last + grid, fb[0], fb[1], fb[2], d_lim))
    base = modified_hyperbolic(t_last + grid, qi, dd, b, d_lim)
    C = np.array(curves) if curves else base[None, :]
    tab = pd.DataFrame(dict(t_years=grid, p10=np.percentile(C, 10, 0), p50=base, p90=np.percentile(C, 90, 0)))
    for c in ("p10", "p50", "p90"):
        tab[c] = np.where(tab[c] < q_econ, 0.0, tab[c])
    eur = float(np.trapezoid(tab.p50.values, grid * YR))
    return dict(ok=True, t0=d.index[-1], q0=float(d.values[-1]), params=dict(qi=qi, d=dd, b=b), table=tab, eur_p50=eur, resid_sd=float(res.std()),
                msg="" if res.std() < 0.25 else f"scatter {res.std():.0%}: wide ranges")


def field_forecast(wt: pd.DataFrame, cfg, years: float = 15, whp_abandon: float | None = None, q_econ: float = 1e5, years_back: float = 10) -> pd.DataFrame:
    """Monthly forecast per well: date, well, gas_p10/p50/p90 [Sm3/d], cond_p50, water_p50 [m3/d].
    Condensate and water follow the gas via the LAST-3-TEST CGR / WGR (constant ratio: an assumption)."""
    rows = []
    for w, g in wt.groupby("well"):
        f = well_forecast(g, years, years_back, q_econ=q_econ)
        if not f["ok"]:
            continue
        last = g.sort_values("date").tail(3)
        cgr = float(np.nanmedian(last.cgr_m3_mmsm3)) if last.cgr_m3_mmsm3.notna().any() else 0.0
        wgr = float(np.nanmedian(last.wgr_m3_mmsm3)) if last.wgr_m3_mmsm3.notna().any() else 0.0
        tab = f["table"]
        dates = f["t0"] + pd.to_timedelta(tab.t_years * YR, unit="D")
        rows.append(pd.DataFrame(dict(date=dates, well=w, gas_p10=tab.p10, gas_p50=tab.p50, gas_p90=tab.p90,
                                      cond_p50=tab.p50 / 1e6 * cgr, water_p50=tab.p50 / 1e6 * wgr)))
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


def backtest(wt: pd.DataFrame, holdout_frac: float = 0.3, years_back: float = 10) -> Result:
    """Fit on the first (1-holdout) of each well's test dates, predict the held-out tests; compare with a naive last-value forecast."""
    rows = []
    for w, g in wt.groupby("well"):
        d = g.groupby("date").gas_sm3d.mean().sort_index()
        if len(d) < 10:
            continue
        k = int(len(d) * (1 - holdout_frac))
        tr, te = d.iloc[:k], d.iloc[k:]
        tr = tr[tr.index >= tr.index.max() - pd.Timedelta(days=YR * years_back)]
        t0 = tr.index[0]
        fit = fit_arps((tr.index - t0).days.values / YR, tr.values)
        if fit is None:
            continue
        pred = modified_hyperbolic((te.index - t0).days.values / YR, *fit)
        naive = np.full(len(te), tr.values[-1])
        rows.append(dict(well=w, n_test=len(te), arps_mape=float(np.mean(np.abs(pred / te.values - 1))), naive_mape=float(np.mean(np.abs(naive / te.values - 1))),
                         arps_bias=float(np.mean(pred / te.values - 1)), naive_bias=float(np.mean(naive / te.values - 1))))
    df = pd.DataFrame(rows)
    res = Result("Rolling backtest (single origin)", df, Status.UNVALIDATED)
    if df.empty:
        return res.fail("not enough tests per well")
    win = int((df.arps_mape < df.naive_mape).sum())
    res.messages.append(f"Arps beats naive last-value on {win}/{len(df)} wells (MAPE {df.arps_mape.mean():.0%} vs {df.naive_mape.mean():.0%}).")
    if win < len(df) / 2:
        res.warn("Decline-curve forecast is NOT clearly better than 'last value': rates here are WHP-driven (operating decisions), treat long forecasts with caution.")
    return res


def selftest() -> dict:
    t = np.linspace(0, 8, 30)
    q = arps(t, 1e6, 0.2, 0.5) * np.exp(np.random.default_rng(1).normal(0, 0.02, 30))
    qi, d, b = fit_arps(t, q)
    assert abs(qi / 1e6 - 1) < 0.08 and abs(d - 0.2) < 0.08, (qi, d, b)
    dates = pd.date_range("2010-01-01", periods=30, freq="120D")
    wt = pd.DataFrame(dict(well="A", date=dates, gas_sm3d=q, cond_m3d=q / 1e6 * 50, water_m3d=5.0, whp_bara=100.0, cgr_m3_mmsm3=50.0, wgr_m3_mmsm3=5.0))
    f = well_forecast(wt, 5)
    assert f["ok"] and (f["table"].p10 <= f["table"].p90 + 1e-6).all()
    assert not field_forecast(wt, None, 5).empty
    return dict(qi=qi, d=d, b=b, eur=f["eur_p50"])
