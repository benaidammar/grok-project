"""Condensate-banking SCREEN (never concluded from rate decline alone). Three independent indicators per well:
 1 flowing BHP below the dew pressure (needs a dew-point estimate and WHP->BHP conversion)
 2 CGR falling with pressure (liquid drop-out in the reservoir / near wellbore)
 3 productivity index q/(Pr^2-Pwf^2) falling by more than the pressure alone explains
Output = traffic light + what would confirm it (PTA, compositional simulation, PVT lab)."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

from ..core.status import Result, Status
from . import deliverability as D


def screen(wt: pd.DataFrame, cfg, pd_bara: dict) -> Result:
    rows = []
    for w, g in wt.groupby("well"):
        g = g.dropna(subset=["whp_bara", "gas_sm3d"]).sort_values("date")
        if len(g) < 8:
            rows.append(dict(well=w, light="grey", score=np.nan, evidence="fewer than 8 tests: inconclusive", confirm="more tests"))
            continue
        pwf = D.whp_to_bhp(cfg, w, g.whp_bara.values, g.gas_sm3d.values)
        pr = D.pr_series(wt, cfg, w, "pz", None, None, g.date.values)
        pdw = pd_bara.get(w, np.nan)
        ev, pts = [], 0
        below = float(np.mean(pwf < pdw)) if np.isfinite(pdw) else np.nan
        if np.isfinite(below):
            ev.append(f"BHP below dew point in {below:.0%} of tests (Pd {pdw:.0f} bara, screening)")
            pts += 2 if below > 0.8 else 1 if below > 0.3 else 0
        c = g.cgr_m3_mmsm3.replace([np.inf, -np.inf], np.nan)
        m = c.notna() & (c > 0)
        if m.sum() >= 8:
            rho, p = spearmanr(g.whp_bara[m], c[m])
            ev.append(f"CGR vs WHP Spearman {rho:+.2f} (p={p:.2g}); CGR first/last third {c[m].iloc[:m.sum()//3].median():.0f} -> {c[m].iloc[-(m.sum()//3):].median():.0f} m3/MMSm3")
            pts += 1 if (rho > 0.5 and p < 0.05) else 0
        dp2 = np.maximum(pr ** 2 - pwf ** 2, 1.0)
        pi = g.gas_sm3d.values / dp2
        k = max(3, len(pi) // 4)
        ratio = float(np.median(pi[-k:]) / np.median(pi[:k]))
        ev.append(f"productivity index last/first quarter = {ratio:.2f} (Pr from p/z assumption)")
        pts += 2 if ratio < 0.5 else 1 if ratio < 0.75 else 0
        light = "red" if pts >= 4 else "amber" if pts >= 2 else "green"
        rows.append(dict(well=w, light=light, score=pts, evidence=" | ".join(ev),
                         confirm="PTA / build-up with derivative (skin & two-region composite), lab CCE/CVD, compositional model" if pts >= 2 else "routine monitoring"))
    df = pd.DataFrame(rows)
    res = Result("Condensate banking screen", df, Status.UNVALIDATED,
                 assumptions=[f"{k} (default)" for k in cfg.assumed("p_res_init_bara", "p_res_now_bara", "gas_sg", "t_res_c")])
    res.messages.append("Screening indicators only: a falling PI also results from depletion, water, scale or Pr error. Confirm before any treatment decision.")
    return res


def selftest() -> dict:
    return dict(ok=True)
