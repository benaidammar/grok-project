"""Gathering-network hydraulics (wells -> manifolds -> facility), screening grade, no streamlit.

Physics
  * segment: steady isothermal gas flow, momentum balance on p^2 with gravity + Darcy friction (Haaland):
        d(p^2)/dx = -2 a' p^2 - 2 b ,  a'L = M g dz /(Z R T),  b = f G^2 Z R T /(2 D M)
        p_down^2 = p_up^2 E - bL F ,  E = exp(-2aL),  F = (1-E)/(aL)      (F -> 2 when aL -> 0)
    Z and mu from GasPVT (pre-tabulated on a pressure grid -> FastGas).
  * wet gas (condensate + water): Chisholm / Lockhart-Martinelli multiplier on the gas-only friction,
        phi2 = 1 + 20 X + X^2 ,  X = (m_l/m_g) sqrt(rho_g/rho_l)         (SCREENING, no holdup / hydrostatic term)
  * erosional velocity API RP 14E: ve = C / sqrt(rho_m)   (C = 100 continuous service, up to 150 intermittent / clean)
  * well deliverability (WHP-rate): q = C (Ps^2 - p^2)^n  fitted locally on the latest tests of each well
Network: tree (every node has one downstream node, as in the file schema).  Loops: model a loop as a parallel line
(equivalent diameter, see `equivalent_diameter`).  Units: bara, degC, Sm3/d, m, kg/m3.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from ..core.status import Result, Status
from .pvt import R_SI, GasPVT

G0 = 9.80665
STD_NPS = [2, 3, 4, 6, 8, 10, 12, 14, 16, 18, 20, 24, 30, 36, 42]
# PLACEHOLDER installed cost, USD per metre of line by nominal inch (pipe + coating + lay + tie-ins).  Replace with your own rates.
CAPEX_PER_M = {2: 90, 3: 120, 4: 160, 6: 230, 8: 320, 10: 410, 12: 500, 14: 580, 16: 670, 18: 760, 20: 850, 24: 1030, 30: 1300, 36: 1600, 42: 1900}
STD_CONDITION_MOLAR_VOL = None   # set lazily from PVT std conditions


# =============================================================================
# fast gas properties
# =============================================================================
class FastGas:
    """z, mu, rho, bg on a pressure grid at fixed T (microsecond lookups)."""

    def __init__(self, pvt: GasPVT, t_c: float, pmax: float = 700.0):
        self.pvt, self.t_c = pvt, t_c
        self.p = np.linspace(0.5, pmax, 1400)
        self._z = np.asarray(pvt.z(self.p, t_c), float)
        self._mu = np.asarray(pvt.mu(self.p, t_c), float)
        self.M = pvt.mol_weight() * 1e-3
        self.tk = t_c + 273.15
        self.rho_std = pvt.p_std_bar * 1e5 * self.M / (R_SI * (pvt.t_std_c + 273.15))
        self.vm_std = R_SI * (pvt.t_std_c + 273.15) / (pvt.p_std_bar * 1e5)      # m3/mol at std

    def z(self, p):
        return np.interp(p, self.p, self._z)

    def mu(self, p):             # Pa s
        return np.interp(p, self.p, self._mu) * 1e-3

    def rho(self, p):
        return p * 1e5 * self.M / (self.z(p) * R_SI * self.tk)

    def bg(self, p):
        return self.z(p) * self.tk * self.pvt.p_std_bar / (p * (self.pvt.t_std_c + 273.15))


def haaland(re, rel_rough):
    re = max(re, 2300.0)
    return 1.0 / (-1.8 * math.log10((rel_rough / 3.7) ** 1.11 + 6.9 / re)) ** 2


def erosional_velocity(rho_mix, c: float = 100.0):
    """API RP 14E, SI: ve [m/s] = 1.2193 * C / sqrt(rho [kg/m3])  (C=100 in lb/ft3 / ft/s units)."""
    return 0.3048 * c * math.sqrt(16.01846) / math.sqrt(rho_mix)


def equivalent_diameter(d_existing_in: float, d_new_in: float) -> float:
    """Parallel loop: equal dp -> q ~ D^2.5 ,  D_eq^2.5 = D1^2.5 + D2^2.5."""
    return (d_existing_in ** 2.5 + d_new_in ** 2.5) ** (1 / 2.5)


# =============================================================================
# well curves from tests
# =============================================================================
def well_ratios(tests: pd.DataFrame, window_days: int = 365) -> dict:
    """Per well: latest-test rate / WHP; CGR and WGR (m3 / million Sm3) = median of the valid values in the last `window_days` (0 if none)."""
    out = {}
    for w, g in tests.groupby("well"):
        g = g.dropna(subset=["gas_sm3d"])
        if g.empty:
            continue
        last = g[g["date"] == g["date"].max()]
        rec = g[g["date"] >= g["date"].max() - pd.Timedelta(days=window_days)]
        med = lambda c: float(rec[c].dropna().median()) if rec[c].notna().any() else 0.0
        out[w] = dict(q=float(last["gas_sm3d"].median()), whp=float(last["whp_bara"].median()), date=g["date"].max(),
                      cgr=med("cgr_m3_mmsm3"), wgr=med("wgr_m3_mmsm3"))
    return out


@dataclass
class WellCurve:
    well: str
    C: float
    n: float
    ps: float            # shut-in-like wellhead pressure of the model (bara)
    quality: str
    n_pts: int = 0
    rmse_log: float = float("nan")
    q_last: float = float("nan")
    whp_last: float = float("nan")

    def q(self, p):
        p = np.asarray(p, float)
        v = np.maximum(self.ps ** 2 - p ** 2, 0.0)
        return self.C * v ** self.n

    def p_at(self, q):
        """Maximum wellhead pressure at which the well can deliver q."""
        q = np.asarray(q, float)
        return np.sqrt(np.maximum(self.ps ** 2 - (np.maximum(q, 0) / self.C) ** (1 / self.n), 0.0))


def fit_well_curve(df: pd.DataFrame, well: str = "", ps_factor: float = 1.25, n_fixed: float = 0.9,
                   window_days: int = 365, min_spread: float = 0.04) -> WellCurve | None:
    """Local backpressure fit q = C (Ps^2 - p^2)^n on the tests of the last `window_days`.
       >=3 points with WHP spread >= 4%: fit (C, Ps) with n fixed (n fitted if >=6 pts);  otherwise a single test point with Ps = ps_factor x WHP (ASSUMED)."""
    from scipy.optimize import least_squares
    d = df.dropna(subset=["whp_bara", "gas_sm3d"])
    d = d[(d["gas_sm3d"] > 0) & (d["whp_bara"] > 1)]
    if d.empty:
        return None
    last = d["date"].max()
    w = d[d["date"] >= last - pd.Timedelta(days=window_days)]
    pmax = float(w["whp_bara"].max())
    spread = (pmax - float(w["whp_bara"].min())) / pmax
    q_last = float(w[w["date"] == w["date"].max()]["gas_sm3d"].median())
    whp_last = float(w[w["date"] == w["date"].max()]["whp_bara"].median())

    def single(tag):
        ps = ps_factor * whp_last
        c = q_last / (ps ** 2 - whp_last ** 2) ** n_fixed
        return WellCurve(well, c, n_fixed, ps, tag, len(w), float("nan"), q_last, whp_last)

    if len(w) >= 3 and spread >= min_spread:
        p, q = w["whp_bara"].values, w["gas_sm3d"].values
        free_n = len(w) >= 6

        def model(x):
            ps = pmax * (1 + math.exp(x[1]))
            n = x[2] if free_n else n_fixed
            return np.log(np.exp(x[0]) * np.maximum(ps ** 2 - p ** 2, 1e-9) ** n) - np.log(q)

        c0 = math.log(q.mean() / (1.5 * pmax ** 2) ** n_fixed)
        x0 = [c0, math.log(0.4), n_fixed] if free_n else [c0, math.log(0.4)]
        lb, ub = ([-60, -4.0, 0.5], [60, math.log(2.0), 1.0]) if free_n else ([-60, -4.0], [60, math.log(2.0)])
        try:
            s = least_squares(model, x0, bounds=(lb, ub))
            rm = float(np.sqrt(np.mean(s.fun ** 2)))
            ps = pmax * (1 + math.exp(s.x[1]))
            n = float(s.x[2]) if free_n else n_fixed
            at_bound = s.x[1] < -3.9 or s.x[1] > math.log(2.0) - 0.02
            if rm < 0.15 and not at_bound:
                return WellCurve(well, math.exp(s.x[0]), n, ps, "multi-rate fit" + (" (n fitted)" if free_n else f" (n={n_fixed} fixed)"),
                                 len(w), rm, q_last, whp_last)
        except Exception:                                     # noqa: BLE001
            pass
        return single("single-point (multi-rate fit rejected: poor fit / Ps at bound)")
    return single("single-point (Ps ASSUMED = factor x WHP)")


def fit_all_curves(tests: pd.DataFrame, **kw) -> dict:
    out = {}
    for w, g in tests.groupby("well"):
        c = fit_well_curve(g, w, **kw)
        if c is not None:
            out[w] = c
    return out


# =============================================================================
# network model
# =============================================================================
def edge_lengths(nodes: pd.DataFrame, basis: str = "stated", tort: float = 1.25) -> pd.DataFrame:
    """Per non-facility node: stated length, straight line to the downstream node, length used.
       basis: 'stated' | 'straight' (straight x tort) | 'max' (max(stated, straight x tort))."""
    idx = nodes.set_index("site")
    rows = []
    for _, r in nodes.iterrows():
        if r["identity"] == "facility" or r["to_node"] not in idx.index:
            continue
        d = idx.loc[r["to_node"]]
        sl = math.hypot(r["x"] - d["x"], r["y"] - d["y"]) if np.all(np.isfinite([r["x"], r["y"], d["x"], d["y"]])) else float("nan")
        st = float(r["length_m"]) if np.isfinite(r["length_m"]) else float("nan")
        ratio = st / sl if np.isfinite(sl) and sl > 0 and np.isfinite(st) else float("nan")
        flag = ("SHORTER than straight line (impossible)" if ratio < 0.95 else ("> 3x straight line (suspicious)" if ratio > 3 else "")) if np.isfinite(ratio) else ""
        if basis == "stated" or not np.isfinite(sl):
            used = st
        elif basis == "straight":
            used = sl * tort
        else:
            used = max(st, sl * tort) if np.isfinite(st) else sl * tort
        dz = (d["elevation_m"] if np.isfinite(d["elevation_m"]) else 0.0) - (r["elevation_m"] if np.isfinite(r["elevation_m"]) else 0.0)
        rows.append(dict(edge=r["site"], to=r["to_node"], identity=r["identity"], stated_m=st, straight_m=sl, ratio=ratio, flag=flag,
                         length_m=used, diameter_in=float(r["diameter_in"]), dz_m=float(dz)))
    return pd.DataFrame(rows).set_index("edge")


def build_graph(nodes: pd.DataFrame, length_basis: str = "stated", tort: float = 1.25):
    """networkx DiGraph child -> parent. Node attrs: identity, x, y, elevation; edge attrs: length_m, diameter_in, stated_m, straight_m."""
    import networkx as nx
    G = nx.DiGraph()
    for _, r in nodes.iterrows():
        G.add_node(r["site"], identity=r["identity"], x=r["x"], y=r["y"], elevation=r["elevation_m"])
    el = edge_lengths(nodes, length_basis, tort)
    for c, r in el.iterrows():
        G.add_edge(c, r["to"], length_m=r["length_m"], diameter_in=r["diameter_in"], stated_m=r["stated_m"], straight_m=r["straight_m"], dz_m=r["dz_m"])
    return G


def validate_graph(G) -> list:
    import networkx as nx
    msgs = []
    fac = [n for n, d in G.nodes(data=True) if d["identity"] == "facility"]
    if not fac:
        msgs.append("no facility node")
    if not nx.is_directed_acyclic_graph(G):
        msgs.append("network has a loop (cycle)")
    for n in G.nodes:
        if n not in fac and G.out_degree(n) != 1:
            msgs.append(f"{n}: out-degree {G.out_degree(n)} (must be 1)")
    return msgs


def gnn_tables(G, q: dict | None = None, pressures: pd.Series | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """(nodes, edges) feature tables ready for a GNN / ML (x, y, elevation, type one-hot, rate, pressure; edge length, diameter, dz)."""
    rows = []
    for n, d in G.nodes(data=True):
        rows.append(dict(node=n, type=d["identity"], x=d["x"], y=d["y"], elevation=d["elevation"], q_sm3d=(q or {}).get(n, 0.0),
                         p_bara=(pressures.get(n, np.nan) if pressures is not None else np.nan)))
    nd = pd.DataFrame(rows)
    for t in ("well", "manifold", "facility"):
        nd[f"is_{t}"] = (nd["type"] == t).astype(int)
    ed = pd.DataFrame([dict(src=u, dst=v, **{k: a[k] for k in ("length_m", "diameter_in", "dz_m")}) for u, v, a in G.edges(data=True)])
    return nd, ed


@dataclass
class NetSolution:
    node_p: pd.Series
    edges: pd.DataFrame
    ok: bool = True
    messages: list = field(default_factory=list)
    q: dict = field(default_factory=dict)
    compressors: pd.DataFrame | None = None


class NetModel:
    def __init__(self, nodes: pd.DataFrame, pvt: GasPVT, ratios: dict | None = None, basis: str = "stated", tort: float = 1.25,
                 t_c: float = 35.0, rough_mm: float = 0.0457, c_ero: float = 100.0, cond_density: float = 765.0,
                 water_density: float = 1050.0, wet_gas: bool = True, length_override: dict | None = None,
                 diameter_override: dict | None = None):
        self.nodes, self.pvt, self.ratios = nodes.copy(), pvt, ratios or {}
        self.basis, self.tort, self.t_c, self.rough_mm, self.c_ero = basis, tort, t_c, rough_mm, c_ero
        self.cond_density, self.water_density, self.wet_gas = cond_density, water_density, wet_gas
        self.gas = FastGas(pvt, t_c)
        self.edges = edge_lengths(self.nodes, basis, tort)
        for k, v in (length_override or {}).items():
            self.edges.loc[k, "length_m"] = v
        for k, v in (diameter_override or {}).items():
            self.edges.loc[k, "diameter_in"] = v
        self.facility = [r["site"] for _, r in self.nodes.iterrows() if r["identity"] == "facility"]
        self.wells = [r["site"] for _, r in self.nodes.iterrows() if r["identity"] == "well"]
        # order: from the facility outward (children after parents)
        children: dict = {}
        for c, r in self.edges.iterrows():
            children.setdefault(r["to"], []).append(c)
        self.order, queue = [], list(self.facility)
        while queue:
            n = queue.pop(0)
            for c in children.get(n, []):
                self.order.append(c)
                queue.append(c)
        self.sub_wells = {c: [c] if c in self.wells else [] for c in self.edges.index}
        for w in self.wells:                      # propagate wells downstream
            cur = w
            while cur in self.edges.index:
                if cur != w:
                    self.sub_wells[cur].append(w)
                cur = self.edges.loc[cur, "to"]
        self.dp_mult: dict = {}

    def copy(self, **changes) -> "NetModel":
        kw = dict(nodes=self.nodes, pvt=self.pvt, ratios=self.ratios, basis=self.basis, tort=self.tort, t_c=self.t_c, rough_mm=self.rough_mm,
                  c_ero=self.c_ero, cond_density=self.cond_density, water_density=self.water_density, wet_gas=self.wet_gas)
        m = NetModel(**{**kw, **{k: v for k, v in changes.items() if k in kw}})
        m.edges = self.edges.copy()
        m.dp_mult = dict(self.dp_mult)
        for k, v in changes.get("diameter", {}).items():
            m.edges.loc[k, "diameter_in"] = v
        for k, v in changes.get("dp_mult", {}).items():
            m.dp_mult[k] = v
        return m

    # ---- one segment ---------------------------------------------------------------------
    def _liquid(self, wells, q):
        cond = sum(q.get(w, 0.0) * self.ratios.get(w, {}).get("cgr", 0.0) / 1e6 for w in wells)
        wat = sum(q.get(w, 0.0) * self.ratios.get(w, {}).get("wgr", 0.0) / 1e6 for w in wells)
        ml = (cond * self.cond_density + wat * self.water_density) / 86400.0
        rho_l = (cond * self.cond_density + wat * self.water_density) / (cond + wat) if cond + wat > 0 else self.cond_density
        return cond, wat, ml, rho_l

    def _march(self, p_a, qg, ml, rho_l, L, d_m, dz, mult, forward: bool, n_sub: int | None = None):
        """Known pressure p_a at one end -> pressure at the other end. forward: p_a is the UPSTREAM pressure."""
        if qg <= 0 or L <= 0:
            return p_a, dict(f=0.0, phi2=1.0, z=float(self.gas.z(p_a)))
        gas = self.gas
        n_sub = n_sub or max(1, int(math.ceil(L / 2000.0)))
        ls, dzs = L / n_sub, dz / n_sub
        area = math.pi * d_m ** 2 / 4
        mg = gas.rho_std * qg / 86400.0
        gflux = mg / area
        info = {}
        p = p_a
        for _ in range(n_sub):
            pb = p
            for _it in range(4):
                pm = 0.5 * (p + pb)
                z, mu = float(gas.z(pm)), float(gas.mu(pm))
                re = gflux * d_m / mu
                f = haaland(re, self.rough_mm * 1e-3 / d_m)
                phi2 = 1.0
                if self.wet_gas and ml > 0:
                    xx = (ml / mg) * math.sqrt(float(gas.rho(pm)) / rho_l)
                    phi2 = 1 + 20 * xx + xx * xx
                b = f * phi2 * self.dp_mult_val(mult) * gflux ** 2 * z * R_SI * gas.tk / (2 * d_m * gas.M)          # Pa^2/m
                al = gas.M * G0 * dzs / (z * R_SI * gas.tk)
                e = math.exp(-2 * al)
                fch = (1 - e) / al if abs(al) > 1e-8 else 2.0
                if forward:
                    p2 = (p * 1e5) ** 2 * e - b * ls * fch
                    if p2 <= 0:
                        return float("nan"), dict(f=f, phi2=phi2, z=z, re=re)
                    pb_new = math.sqrt(p2) / 1e5
                else:
                    pb_new = math.sqrt(((p * 1e5) ** 2 + b * ls * fch) / e) / 1e5
                if abs(pb_new - pb) < 1e-7:
                    pb = pb_new
                    break
                pb = pb_new
            p = pb
            info = dict(f=f, phi2=phi2, z=z, re=re)
        return p, info

    @staticmethod
    def dp_mult_val(m):
        return m if m is not None else 1.0

    # ---- solve: facility pressure + rates -> pressures ----------------------------------------
    def solve_back(self, q: dict, p_fac: float | dict, boost: dict | None = None) -> NetSolution:
        """Fixed facility inlet pressure and well gas rates (Sm3/d) -> manifold / wellhead (flowline-inlet) pressures and segment metrics."""
        boost = boost or {}
        pf = p_fac if isinstance(p_fac, dict) else {f: p_fac for f in self.facility}
        node_p = {f: float(pf[f]) for f in self.facility}
        rows, msgs, ok = [], [], True
        comp = []
        for c in self.order:
            e = self.edges.loc[c]
            wells = self.sub_wells[c]
            qe = sum(q.get(w, 0.0) for w in wells)
            cond, wat, ml, rho_l = self._liquid(wells, q)
            d_m = e["diameter_in"] * 0.0254
            p_down = node_p[e["to"]]
            if not np.isfinite(e["length_m"]) or not np.isfinite(d_m):
                msgs.append(f"{c}: missing length/diameter")
                ok = False
                node_p[c] = float("nan")
                continue
            p_up, info = self._march(p_down, qe, ml, rho_l, e["length_m"], d_m, e["dz_m"], self.dp_mult.get(c), forward=False)
            area = math.pi * d_m ** 2 / 4
            qa = qe * float(self.gas.bg(p_down)) / 86400.0
            ql = (cond + wat) / 86400.0 * (1.0)
            u = (qa) / area
            rho_g = float(self.gas.rho(p_down))
            rho_m = (self.gas.rho_std * qe / 86400.0 + ml) / (qa + ql) if qe > 0 else rho_g
            ve = erosional_velocity(rho_m, self.c_ero)
            suct = p_up - boost.get(c, 0.0)
            node_p[c] = suct
            if c in boost and boost[c] > 0 and qe > 0:
                comp.append(dict(node=c, suction_bara=suct, discharge_bara=p_up, ratio=p_up / suct, q_sm3d=qe,
                                 power_kw=compressor_power(qe, suct, p_up, self.pvt, self.t_c)))
            rows.append(dict(edge=c, to=e["to"], identity=e["identity"], length_m=e["length_m"], diameter_in=e["diameter_in"], q_sm3d=qe,
                             cond_m3d=cond, water_m3d=wat, p_up_bara=p_up, p_down_bara=p_down, dp_bar=p_up - p_down,
                             dp_bar_per_km=(p_up - p_down) / (e["length_m"] / 1000.0), velocity_ms=u, v_erosional_ms=ve, v_ratio=u / ve,
                             reynolds=info.get("re", float("nan")), friction=info.get("f", float("nan")), wet_multiplier=info.get("phi2", 1.0),
                             holdup_risk=bool(qe > 0 and u < 3.0)))
        edges = pd.DataFrame(rows).set_index("edge") if rows else pd.DataFrame()
        sol = NetSolution(pd.Series(node_p, name="p_bara"), edges, ok and not any(np.isnan(list(node_p.values()))), msgs, dict(q),
                          pd.DataFrame(comp) if comp else None)
        return sol

    # ---- deliverability: well curves + facility pressure -> rates ----------------------------------
    def deliverability(self, curves: dict, p_fac: float | dict, active: list | None = None, boost: dict | None = None,
                       qcap: dict | None = None, tol: float = 1e-5, max_iter: int = 150) -> NetSolution:
        """Solve q_i = f_i(WHP_i(q)) with wells fully open (WHP = flowline-inlet pressure required by the network)."""
        act = [w for w in (active if active is not None else self.wells) if w in curves]
        pf0 = p_fac if not isinstance(p_fac, dict) else min(p_fac.values())
        q = {w: float(curves[w].q(pf0)) for w in act}
        if qcap:
            q = {w: min(v, qcap.get(w, v)) for w, v in q.items()}
        sol = self.solve_back(q, p_fac, boost)
        relax = 0.6
        for it in range(max_iter):
            qn = {}
            for w in act:
                pw = sol.node_p.get(w, float("nan"))
                v = 0.0 if not np.isfinite(pw) else float(curves[w].q(pw))
                if qcap:
                    v = min(v, qcap.get(w, v))
                qn[w] = v
            err = max((abs(qn[w] - q[w]) / max(q[w], 1.0) for w in act), default=0.0)
            q = {w: (1 - relax) * q[w] + relax * qn[w] for w in act}
            sol = self.solve_back(q, p_fac, boost)
            if err < tol:
                break
        else:
            sol.messages.append(f"deliverability iteration did not fully converge (err {err:.1e})")
        sol.q = q
        sol.messages.append(f"converged in {it + 1} iterations")
        return sol

    def calibrate_p_fac(self, bracket=(5.0, 200.0)) -> float:
        """Facility inlet pressure that reproduces the latest tested WHPs (mean error 0) at the latest tested rates; ASSUMES test WHP = flowline inlet."""
        from scipy.optimize import brentq
        q = {w: self.ratios[w]["q"] for w in self.wells if w in self.ratios}
        tw = {w: self.ratios[w]["whp"] for w in q}
        f = lambda p: float(np.mean([self.solve_back(q, p).node_p[w] - tw[w] for w in q]))
        lo, hi = bracket
        return float(brentq(f, lo, hi)) if f(lo) * f(hi) < 0 else float("nan")

    def total_value(self, q: dict, prices: dict | None = None) -> float:
        pr = prices or dict(gas=120.0, cond=520.0)
        g = sum(q.values())
        c = sum(q[w] * self.ratios.get(w, {}).get("cgr", 0.0) / 1e6 for w in q)
        return g / 1000.0 * pr["gas"] + c * pr["cond"]          # USD / day


# =============================================================================
# compression, bottlenecks, upsizing
# =============================================================================
def compressor_power(q_sm3d: float, p_suction: float, p_discharge: float, pvt: GasPVT, t_suction_c: float = 35.0,
                     eta: float = 0.75, k: float = 1.27) -> float:
    """Single-stage isentropic power [kW] with real-gas Z at suction (W = Z R T n k/(k-1) (r^((k-1)/k)-1)/eta). Staging not modelled."""
    if p_discharge <= p_suction or q_sm3d <= 0:
        return 0.0
    vm = R_SI * (pvt.t_std_c + 273.15) / (pvt.p_std_bar * 1e5)
    n_dot = q_sm3d / 86400.0 / vm
    z = float(pvt.z(p_suction, t_suction_c))
    r = p_discharge / p_suction
    return z * R_SI * (t_suction_c + 273.15) * n_dot * (k / (k - 1)) * (r ** ((k - 1) / k) - 1) / eta / 1000.0


def next_sizes(d_in: float, n: int = 3) -> list:
    return [s for s in STD_NPS if s > d_in + 0.01][:n]


def bottleneck_table(model: NetModel, curves: dict, p_fac: float, active: list | None = None) -> pd.DataFrame:
    """Rank segments: dp, dp/km, v/ve and the MARGINAL GAIN in network deliverability if the segment is one size larger / its dp halved."""
    base = model.deliverability(curves, p_fac, active)
    q0 = sum(base.q.values())
    e = base.edges.copy()
    gains, gains_half = [], []
    for c in e.index:
        nxt = next_sizes(model.edges.loc[c, "diameter_in"], 1)
        if nxt:
            s = model.copy(diameter={c: float(nxt[0])}).deliverability(curves, p_fac, active)
            gains.append(sum(s.q.values()) - q0)
        else:
            gains.append(0.0)
        s2 = model.copy(dp_mult={c: 0.5}).deliverability(curves, p_fac, active)
        gains_half.append(sum(s2.q.values()) - q0)
    e["gain_next_size_sm3d"] = gains
    e["gain_half_dp_sm3d"] = gains_half
    e["share_of_total_dp_%"] = 100 * e["dp_bar"] / max(e["dp_bar"].sum(), 1e-9)
    e["rank"] = e["gain_half_dp_sm3d"].rank(ascending=False, method="min")
    return e.sort_values("gain_half_dp_sm3d", ascending=False)


def rate_vs_facility_pressure(model: NetModel, curves: dict, p_list, active: list | None = None) -> pd.DataFrame:
    rows = []
    for p in p_list:
        s = model.deliverability(curves, float(p), active)
        rows.append(dict(p_fac_bara=float(p), gas_sm3d=sum(s.q.values()),
                         cond_m3d=sum(s.q[w] * model.ratios.get(w, {}).get("cgr", 0.0) / 1e6 for w in s.q)))
    return pd.DataFrame(rows)


def compression_study(model: NetModel, curves: dict, p_ref: float, p_suction_list, eta: float = 0.75, power_cost_usd_kwh: float = 0.05,
                      active: list | None = None) -> pd.DataFrame:
    """Facility compression: inlet (suction) pressure lowered from p_ref, gas recompressed to p_ref."""
    base = sum(model.deliverability(curves, p_ref, active).q.values())
    rows = []
    for ps in p_suction_list:
        s = model.deliverability(curves, float(ps), active)
        q = sum(s.q.values())
        kw = compressor_power(q, float(ps), p_ref, model.pvt, model.t_c, eta)
        gain = q - base
        usd_d = kw * 24 * power_cost_usd_kwh
        rows.append(dict(p_suction_bara=float(ps), gas_sm3d=q, gain_sm3d=gain, power_kw=kw, energy_usd_per_day=usd_d,
                         energy_usd_per_ksm3_total=usd_d / (q / 1000.0) if q > 0 else float("nan"),
                         energy_usd_per_ksm3_incremental=usd_d / (gain / 1000.0) if gain > 1 else float("nan")))
    return pd.DataFrame(rows)


def manifold_compression_study(model: NetModel, curves: dict, p_fac: float, manifold: str, boosts, active: list | None = None,
                               eta: float = 0.75, power_cost_usd_kwh: float = 0.05) -> pd.DataFrame:
    base = sum(model.deliverability(curves, p_fac, active).q.values())
    rows = []
    for b in boosts:
        s = model.deliverability(curves, p_fac, active, boost={manifold: float(b)})
        q = sum(s.q.values())
        kw = float(s.compressors["power_kw"].sum()) if s.compressors is not None else 0.0
        rows.append(dict(boost_bar=float(b), gas_sm3d=q, gain_sm3d=q - base, power_kw=kw,
                         energy_usd_per_ksm3_incremental=(kw * 24 * power_cost_usd_kwh) / ((q - base) / 1000.0) if q - base > 1 else float("nan")))
    return pd.DataFrame(rows)


def upsizing_study(model: NetModel, curves: dict, p_fac: float, prices: dict, capex: dict | None = None, horizon: int = 10,
                   decline: float = 0.10, disc: float = 0.10, active: list | None = None, max_steps: int = 3) -> pd.DataFrame:
    """For each segment and candidate size: replace vs parallel loop. dQ via the full network solve; NPV of gas+condensate revenue
       (revenue declines `decline`/yr, 10 yr default) minus capex. Capex table is a PLACEHOLDER."""
    capex = capex or CAPEX_PER_M
    base = model.deliverability(curves, p_fac, active)
    q0 = sum(base.q.values())
    c0 = sum(base.q[w] * model.ratios.get(w, {}).get("cgr", 0.0) / 1e6 for w in base.q)
    rows = []
    for c in model.edges.index:
        d0 = float(model.edges.loc[c, "diameter_in"])
        L = float(model.edges.loc[c, "length_m"])
        for nps in next_sizes(d0, max_steps):
            for mode in ("replace", "loop"):
                dnew = float(nps) if mode == "replace" else equivalent_diameter(d0, float(nps))
                s = model.copy(diameter={c: dnew}).deliverability(curves, p_fac, active)
                dq = sum(s.q.values()) - q0
                dc = sum(s.q[w] * model.ratios.get(w, {}).get("cgr", 0.0) / 1e6 for w in s.q) - c0
                cost = capex.get(int(nps), CAPEX_PER_M.get(int(nps), 800)) * L
                rev0 = 365 * (dq / 1000.0 * prices["gas"] + dc * prices["cond"])
                npv = -cost + sum(rev0 * (1 - decline) ** t / (1 + disc) ** (t + 1) for t in range(horizon))
                rows.append(dict(segment=c, to=model.edges.loc[c, "to"], length_m=L, from_in=d0, to_nps_in=nps, mode=mode,
                                 gain_gas_sm3d=dq, gain_cond_m3d=dc, capex_usd=cost, revenue_year1_usd=rev0, npv_usd=npv,
                                 payback_years=(cost / rev0 if rev0 > 0 else float("inf"))))
    out = pd.DataFrame(rows)
    return out.sort_values("npv_usd", ascending=False).reset_index(drop=True) if len(out) else out


# =============================================================================
# Monte-Carlo
# =============================================================================
def monte_carlo(nodes: pd.DataFrame, cfg_pvt: GasPVT, curves: dict, ratios: dict, p_fac: float, n: int = 150, seed: int = 0,
                tort_range=(1.0, 1.5), rough_range=(0.02, 0.25), sg_sd: float = 0.03, t_c: float = 35.0, c_ero: float = 100.0,
                flagged_use_straight: bool = True) -> dict:
    """Uncertain: roughness (log-uniform), gas SG (normal), tortuosity (uniform) applied to FLAGGED segments (stated length impossible / suspicious)
       and mild +-10% on the others. Returns P10/P50/P90 of network deliverable gas, segment-bottleneck probabilities, dQ vs the stated-length base case."""
    rng = np.random.default_rng(seed)
    base_m = NetModel(nodes, cfg_pvt, ratios, "stated", t_c=t_c, c_ero=c_ero)
    q_base = sum(base_m.deliverability(curves, p_fac).q.values())
    el = base_m.edges
    flagged = el.index[el["flag"] != ""].tolist()
    qs, top, v_hi = [], {c: 0 for c in el.index}, {c: 0 for c in el.index}
    for _ in range(n):
        t = rng.uniform(*tort_range)
        rough = float(np.exp(rng.uniform(np.log(rough_range[0]), np.log(rough_range[1]))))
        pv = GasPVT(max(0.55, rng.normal(cfg_pvt.gas_sg, sg_sd)), cfg_pvt.co2_pct, cfg_pvt.h2s_ppm, cfg_pvt.n2_pct, cfg_pvt.t_std_c, cfg_pvt.p_std_bar)
        ov = {}
        for c in el.index:
            if c in flagged and flagged_use_straight and np.isfinite(el.loc[c, "straight_m"]):
                ov[c] = el.loc[c, "straight_m"] * t
            else:
                ov[c] = el.loc[c, "length_m"] * rng.uniform(0.9, 1.1)
        m = NetModel(nodes, pv, ratios, "stated", t_c=t_c, rough_mm=rough, c_ero=c_ero, length_override=ov)
        s = m.deliverability(curves, p_fac)
        qs.append(sum(s.q.values()))
        if len(s.edges):
            top[s.edges["dp_bar"].idxmax()] += 1
            for c in s.edges.index[s.edges["v_ratio"] > 0.5]:
                v_hi[c] += 1
    qs = np.array(qs)
    return dict(q_samples=qs, p10=float(np.percentile(qs, 10)), p50=float(np.percentile(qs, 50)), p90=float(np.percentile(qs, 90)),
                q_base_stated=float(q_base), flagged=flagged, top_dp_prob=pd.Series(top) / n, v_gt_half_ero_prob=pd.Series(v_hi) / n)


def deliverability_result(model: NetModel, curves: dict, p_fac: float, cfg=None, qc_errors: int = 0, **kw) -> Result:
    """Standard Result wrapper: value = NetSolution. Never OK: hydraulics + wet-gas multiplier are screening models not benchmarked on the field."""
    res = Result("Network deliverability (screening hydraulics)", status=Status.UNVALIDATED, meta=dict(basis=model.basis, p_fac=p_fac))
    if not curves or not model.wells:
        return res.fail("no wells with a deliverability curve or no network wells")
    sol = model.deliverability(curves, p_fac, **kw)
    if not sol.ok:
        return res.fail("; ".join(sol.messages) or "network solve failed")
    res.value = sol
    res.messages += [m for m in sol.messages if "converge" in m or "iterations" in m]
    res.messages.append("Wet-gas multiplier (Chisholm / Lockhart-Martinelli) is a SCREENING correction: no holdup or hydrostatic liquid term; not benchmarked on field data.")
    if qc_errors:
        res.warn(f"{qc_errors} network data error(s) in the QC table (impossible flowline lengths): results depend on the chosen length basis ({model.basis}).")
    res.assumptions += [f"flowing temperature {model.t_c:.0f} degC (isothermal)", f"roughness {model.rough_mm} mm", f"erosional C = {model.c_ero:g}",
                        f"wells without multi-rate tests: Ps = 1.25 x WHP (ASSUMED)"]
    if cfg is not None:
        res.assumptions += [f"{k} (asset-config default)" for k in cfg.assumed("gas_sg", "co2_pct")]
    return res


# =============================================================================
# demo network
# =============================================================================
def demo_network(seed: int = 3):
    """Synthetic 20-well tree, 4 manifolds, 1 facility: returns (nodes_df, curves, ratios)."""
    rng = np.random.default_rng(seed)
    rows, curves, ratios = [], {}, {}
    fac = (0.0, 0.0)
    rows.append(dict(site="PLANT", identity="facility", to_node="facility", x=fac[0], y=fac[1], elevation_m=0.0, length_m=np.nan, diameter_in=np.nan, coord_src="demo"))
    rows.append(dict(site="HDR", identity="manifold", to_node="PLANT", x=-6000.0, y=1500.0, elevation_m=0.0, length_m=6500.0, diameter_in=24.0, coord_src="demo"))
    for m in range(4):
        mx, my = -6000 - 3500 * math.cos(m * 1.5 + .3) - 1500, 1500 + 3500 * math.sin(m * 1.5 + .3)
        rows.append(dict(site=f"MAN-{m + 1}", identity="manifold", to_node="HDR", x=mx, y=my, elevation_m=float(rng.integers(0, 20)),
                         length_m=math.hypot(mx + 6000, my - 1500) * 1.2, diameter_in=16.0, coord_src="demo"))
        for k in range(5):
            wid = f"W{m * 5 + k + 1:02d}"
            wx, wy = mx + rng.normal(0, 1500), my + rng.normal(0, 1500)
            sl = math.hypot(wx - mx, wy - my)
            rows.append(dict(site=wid, identity="well", to_node=f"MAN-{m + 1}", x=wx, y=wy, elevation_m=float(rng.integers(0, 40)),
                             length_m=sl * rng.uniform(1.1, 1.4), diameter_in=float(rng.choice([6, 8])), coord_src="demo"))
            ps = rng.uniform(150, 190)
            q_ref = rng.uniform(0.5e6, 1.3e6)
            n = 0.9
            c = q_ref / (ps ** 2 - 110 ** 2) ** n
            curves[wid] = WellCurve(wid, c, n, ps, "demo", 3, 0.0, q_ref, 110.0)
            ratios[wid] = dict(q=q_ref, whp=110.0, date=pd.Timestamp("2026-01-01"), cgr=float(rng.uniform(5, 60)), wgr=float(rng.uniform(5, 80)))
    return pd.DataFrame(rows), curves, ratios


# =============================================================================
def selftest() -> dict:
    from scipy.integrate import solve_ivp
    out = {}
    pvt = GasPVT(0.7, 2.0)
    # --- 1. single horizontal pipe vs numerical integration of the ODE with the same Z, mu --------------
    nodes = pd.DataFrame([dict(site="W", identity="well", to_node="F", x=0.0, y=0.0, elevation_m=0.0, length_m=8000.0, diameter_in=8.0),
                          dict(site="F", identity="facility", to_node="facility", x=8000.0, y=0.0, elevation_m=0.0, length_m=np.nan, diameter_in=np.nan)])
    m = NetModel(nodes, pvt, {}, "stated", t_c=30.0)
    q = 1.0e6
    sol = m.solve_back({"W": q}, 60.0)
    p_up = float(sol.node_p["W"])
    d = 8 * 0.0254
    area = math.pi * d * d / 4
    gflux = m.gas.rho_std * q / 86400 / area

    def rhs(x, y):
        p = y[0]
        z, mu = float(m.gas.z(p / 1e5)), float(m.gas.mu(p / 1e5))
        f = haaland(gflux * d / mu, m.rough_mm * 1e-3 / d)
        rho = p * m.gas.M / (z * R_SI * m.gas.tk)
        return [-f / (2 * d) * gflux ** 2 / rho]
    ref = solve_ivp(rhs, [0, 8000], [p_up * 1e5], rtol=1e-9, atol=1e-3).y[0, -1] / 1e5
    assert abs(ref - 60.0) < 0.05, (ref, "march vs ODE")
    out["pipe_vs_ode_bar_err"] = float(abs(ref - 60.0))
    # --- 2. erosional velocity hand calc --------------------------------------------------------------
    ve = erosional_velocity(100.0, 100.0)
    assert abs(ve - 12.2) < 0.1, ve                      # 100/sqrt(6.243 lb/ft3)=40.0 ft/s = 12.2 m/s
    out["ve_100kgm3_C100"] = ve
    # --- 3. mass balance + forward/backward consistency on the demo tree ------------------------------------
    nd, curves, ratios = demo_network()
    mm = NetModel(nd, pvt, ratios, "stated")
    s = mm.deliverability(curves, 55.0)
    assert s.ok and sum(s.q.values()) > 1e6
    fac_in = sum(s.edges.loc[s.edges["to"] == "PLANT", "q_sm3d"])
    assert abs(fac_in - sum(s.q.values())) < 1e-6 * fac_in, "mass balance"
    for c in mm.order:                                   # forward march recovers the downstream pressure
        e, r = mm.edges.loc[c], s.edges.loc[c]
        cond, wat, ml, rl = mm._liquid(mm.sub_wells[c], s.q)
        p_dn, _ = mm._march(r["p_up_bara"], r["q_sm3d"], ml, rl, e["length_m"], e["diameter_in"] * 0.0254, e["dz_m"], None, forward=True)
        assert abs(p_dn - r["p_down_bara"]) < 1e-4, (c, p_dn, r["p_down_bara"])
    # wells honour their curves
    for w in mm.wells:
        assert abs(float(curves[w].q(s.node_p[w])) - s.q[w]) < 1e-3 * max(s.q[w], 1) + 5, w
    out["demo_total_MMsm3d"] = sum(s.q.values()) / 1e6
    # --- 4. physics monotonicity ---------------------------------------------------------------------------------
    r = rate_vs_facility_pressure(mm, curves, [40, 55, 70])
    assert r["gas_sm3d"].is_monotonic_decreasing
    big = mm.copy(diameter={c: 2 * mm.edges.loc[c, "diameter_in"] for c in mm.edges.index}).deliverability(curves, 55.0)
    assert sum(big.q.values()) >= sum(s.q.values())
    # --- 5. well curve fit round trip ---------------------------------------------------------------------------------
    pp = np.array([100.0, 110.0, 120.0])
    true = WellCurve("t", 5e-3, 0.9, 150.0, "x")
    df = pd.DataFrame(dict(whp_bara=pp, gas_sm3d=true.q(pp), date=pd.Timestamp("2025-01-01")))
    fit = fit_well_curve(df, "t")
    assert fit.quality.startswith("multi-rate") and abs(fit.ps - 150) < 2, fit
    out["fit_ps"] = fit.ps
    # --- 6. compressor power sanity (10 MMSm3/d, 40->80 bar ~ 10-20 MW class) ------------------------------------------------
    kw = compressor_power(5e6, 40, 80, pvt)
    assert 5000 < kw < 15000, kw
    out["compressor_kw_5MMsm3d_40_80"] = kw
    from . import netopt
    out.update(netopt.selftest())
    return out
