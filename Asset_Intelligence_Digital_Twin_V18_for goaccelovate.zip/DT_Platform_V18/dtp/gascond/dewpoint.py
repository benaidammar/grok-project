"""Dew-point pressure SCREENING from surface CGR, gas gravity and temperature (no lab data needed).

Model (heuristic, NOT a published correlation and NOT lab-validated):
    Pd = [P0 + P1*ln(1 + CGR/CGR0)] * (1 + 0.5*(SG-0.70)) * exp(-0.002*(T-100))        [bara, T in degC, CGR in m3/MMSm3]
    P0=60, P1=105, CGR0=15 -> anchors ~90 bara @CGR 5, ~215 @50, ~310 @150 (T=100C, SG=0.70): typical lean-to-rich gas-condensate range.
Why not Nemeth-Kennedy: it needs a full molar composition + C7+ properties which the well-test data do not contain; inventing a
composition would give false precision.  A +-25 % band is returned.  Replace with the lab CCE/CVD dew point (`lab_pd_bara`) whenever
available - the lab value always overrides.  CGR must be the ORIGINAL (undepleted, above-dew) CGR: current CGR below dew is depleted
and under-predicts Pd, so `initial_cgr` uses the early plateau of each well.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..core.status import Result, Status

P0, P1, CGR0, BAND = 60.0, 105.0, 15.0, 0.25


def dew_pressure(cgr_m3_mmsm3, gas_sg: float = 0.70, t_c: float = 100.0):
    """Screening dew pressure [bara] (array-aware)."""
    c = np.maximum(np.asarray(cgr_m3_mmsm3, float), 0.0)
    return (P0 + P1 * np.log1p(c / CGR0)) * (1 + 0.5 * (gas_sg - 0.70)) * np.exp(-0.002 * (t_c - 100.0))


def initial_cgr(well_df: pd.DataFrame, n: int = 3) -> float:
    """Original CGR proxy = median of the first n valid (>0) CGR tests of the well."""
    c = well_df.sort_values("date")["cgr_m3_mmsm3"].dropna()
    c = c[c > 0].head(n)
    return float(c.median()) if len(c) else float("nan")


def estimate(well_tests: pd.DataFrame, cfg, lab_pd_bara: dict | None = None) -> Result:
    """Per-well dew pressure table. lab_pd_bara = {well: value} overrides the correlation."""
    lab_pd_bara = lab_pd_bara or {}
    rows = []
    for w, d in well_tests.groupby("well"):
        c0 = initial_cgr(d)
        t = cfg.well(w, "t_res_c")
        pd_c = float(dew_pressure(c0, cfg.gas_sg, t)) if np.isfinite(c0) else np.nan
        lab = lab_pd_bara.get(w)
        rows.append(dict(well=w, cgr_initial=c0, t_res_c=t, pd_screen_bara=pd_c, pd_low=pd_c * (1 - BAND), pd_high=pd_c * (1 + BAND),
                         pd_lab_bara=lab, pd_used_bara=lab if lab is not None else pd_c, source="LAB" if lab is not None else "screening"))
    df = pd.DataFrame(rows)
    res = Result("Dew-point estimate", df, Status.UNVALIDATED, assumptions=[f"{k} (default)" for k in cfg.assumed("gas_sg", "t_res_c")],
                 meta=dict(model="heuristic CGR/SG/T anchor correlation", band=BAND))
    n_lab = int(df.pd_lab_bara.notna().sum())
    res.messages.append(f"{len(df) - n_lab} wells on SCREENING dew point (+-{BAND:.0%}, not lab data); {n_lab} on lab value.")
    res.messages.append("Initial CGR from the first valid tests; if production started below the true dew point this under-predicts Pd.")
    return res


def selftest() -> dict:
    p = dew_pressure([0, 5, 50, 150, 400])
    assert np.all(np.diff(p) > 0), "Pd must rise with CGR"
    assert dew_pressure(50, 0.8) > dew_pressure(50, 0.7) > dew_pressure(50, 0.6)
    assert dew_pressure(50, 0.7, 140) < dew_pressure(50, 0.7, 90)
    d = pd.DataFrame(dict(well="A", date=pd.date_range("2000", periods=5, freq="YS"), cgr_m3_mmsm3=[100, 98, 99, 60, 10]))
    from ..core.config import AssetConfig
    r = estimate(d, AssetConfig(), {"A": 300.0})
    assert r.value.pd_used_bara[0] == 300.0 and r.status == Status.UNVALIDATED
    return {"pd@50": float(dew_pressure(50))}
