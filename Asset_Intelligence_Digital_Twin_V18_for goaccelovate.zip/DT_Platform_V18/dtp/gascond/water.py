"""Water & salinity screening: WGR trend, brine class, regime change, zero-water ambiguity, CO2 corrosion screen."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.stats import theilslopes

from ..core.status import Result, Status

SAL_CLASSES = [(5_000, "condensed / fresh water (< 5 g/L)"), (50_000, "mixed or diluted brine (5-50 g/L)"), (1e12, "formation brine (> 50 g/L)")]


def classify_salinity(mgl: float) -> str:
    if not np.isfinite(mgl):
        return "n/a"
    return next(lbl for lim, lbl in SAL_CLASSES if mgl < lim)


def change_points(y: np.ndarray, min_seg: int = 5, thr: float = 3.0, max_cp: int = 3) -> list[int]:
    """Binary segmentation on mean shift; accept a split if the t-like statistic exceeds thr."""
    y = np.asarray(y, float)
    cps = []

    def rec(a, b):
        if len(cps) >= max_cp or b - a < 2 * min_seg:
            return
        best, bi = 0, None
        sd = y[a:b].std() + 1e-9
        for i in range(a + min_seg, b - min_seg):
            s = abs(y[a:i].mean() - y[i:b].mean()) / (sd * np.sqrt(1 / (i - a) + 1 / (b - i)))
            if s > best:
                best, bi = s, i
        if bi is not None and best > thr:
            cps.append(bi)
            rec(a, bi)
            rec(bi, b)
    rec(0, len(y))
    return sorted(cps)


def corrosion_dewaard(p_co2_bar: float, t_c: float) -> float:
    """Uncorrected de Waard-Milliams (1991) CO2 corrosion rate [mm/y]: log10 V = 5.8 - 1710/T + 0.67 log10(pCO2). Upper-bound screening."""
    return float(10 ** (5.8 - 1710 / (t_c + 273.15) + 0.67 * np.log10(max(p_co2_bar, 1e-6))))


def analyse(wt: pd.DataFrame, cfg, t_wh_c: float = 40.0) -> Result:
    rows, cps = [], {}
    for w, g in wt.groupby("well"):
        g = g.sort_values("date")
        wgr = g.wgr_m3_mmsm3.fillna(0).values
        sal = g.salinity_mgl.dropna()
        sl = np.nan
        if len(g) >= 5:
            t = (g.date - g.date.iloc[0]).dt.days.values / 365.25
            sl = float(theilslopes(wgr, t)[0])
        recent = g.tail(4)
        zero_recent = bool((recent.water_m3d.fillna(0) == 0).all())
        zero_before = bool((g.water_m3d.fillna(0) > 0).iloc[:-4].any())
        cps[w] = [g.date.iloc[i] for i in change_points(np.log1p(wgr))]
        pco2 = g.whp_bara.iloc[-1] * cfg.co2_pct / 100.0
        rows.append(dict(well=w, wgr_last=float(wgr[-1]), wgr_trend_per_yr=sl, sal_last_mgl=float(sal.iloc[-1]) if len(sal) else np.nan,
                         sal_class=classify_salinity(float(sal.iloc[-1]) if len(sal) else np.nan),
                         water_zero_recent=zero_recent and zero_before, regime_changes=", ".join(str(d.date()) for d in cps[w]),
                         pCO2_bar=pco2, corr_mm_y_screen=corrosion_dewaard(pco2, t_wh_c)))
    df = pd.DataFrame(rows)
    res = Result("Water & salinity screen", df, Status.UNVALIDATED, meta=dict(change_points=cps),
                 assumptions=[f"{k} (default)" for k in cfg.assumed("co2_pct")] + [f"wellhead temperature {t_wh_c:.0f} C"])
    res.messages.append("Salinity classes and corrosion rates are rules of thumb; the de Waard-Milliams value is an uncorrected upper bound (no scale/oil wetting/inhibitor credit).")
    if df.water_zero_recent.any():
        res.warn("Wells with water recorded > 0 earlier and exactly 0 recently: confirm whether 'no water' or 'not measured'.")
    return res


def selftest() -> dict:
    y = np.r_[np.zeros(20), np.ones(20) * 3] + np.random.default_rng(0).normal(0, 0.1, 40)
    cp = change_points(y)
    assert cp and abs(cp[0] - 20) <= 2, cp
    assert 0.1 < corrosion_dewaard(2.0, 80) < 50
    return dict(cp=cp)
