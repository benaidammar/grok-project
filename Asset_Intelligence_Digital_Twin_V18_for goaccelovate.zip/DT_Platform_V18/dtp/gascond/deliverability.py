"""Back-pressure (Rawlins-Schellhardt) deliverability, WHP->BHP, Pr estimation, rate-WHP relation and nodal analysis.

    q = C (Pr^2 - Pwf^2)^n      n in [0.5, 1]   (Rawlins & Schellhardt 1936; empirical, dry-gas pseudo-steady, needs stabilised rates)
    Pwf from WHP: pvt.bottomhole_from_wellhead (single-phase gas column + friction; liquids ignored; wellhead T assumed).
    Pr:  'pz'  linear p/z decline between cfg.p_res_init_bara (zero field cum) and cfg.p_res_now_bara (cum to last test) - an ASSUMPTION
         'const' constant value; 'table' user table(well,date,pr_bara) interpolated; 'implied' per test: n=1 fit of Pwf^2 vs q, intercept=Pr^2.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.optimize import brentq
from scipy.stats import theilslopes

from ..core.status import Result, Status
from .pvt import GasPVT, bottomhole_from_wellhead

T_WH_C = 40.0                       # assumed flowing wellhead temperature
T_ATM_AOF = 1.01325                 # AOF reference Pwf [bara]


def _well_par(cfg, w):
    return cfg.well(w, "tvd_m"), cfg.well(w, "tubing_id_in"), cfg.well(w, "t_res_c")


def whp_to_bhp(cfg, w, whp, q) -> np.ndarray:
    tvd, idin, tres = _well_par(cfg, w)
    return np.asarray(bottomhole_from_wellhead(GasPVT.from_cfg(cfg), whp, T_WH_C, tres, tvd, q, idin), float)


def field_cum_gas(well_tests: pd.DataFrame) -> pd.Series:
    """Field cumulative gas [Sm3] on the test dates, rates linearly interpolated between tests of each well (continuous-flow assumption)."""
    g = well_tests.groupby(["well", "date"])["gas_sm3d"].mean().reset_index()
    grid = pd.date_range(g.date.min(), g.date.max(), freq="MS")
    tot = np.zeros(len(grid))
    x = grid.values.astype("datetime64[D]").astype(float)
    for _, d in g.groupby("well"):
        xd = d.date.values.astype("datetime64[D]").astype(float)
        tot += np.interp(x, xd, d.gas_sm3d.values, left=0.0, right=0.0)
    cum = np.concatenate([[0.0], np.cumsum(0.5 * (tot[1:] + tot[:-1]) * np.diff(x))])
    return pd.Series(cum, index=grid)


def pr_series(well_tests: pd.DataFrame, cfg, well: str, mode: str = "pz", pr_const: float | None = None, table: pd.DataFrame | None = None,
              dates=None) -> np.ndarray:
    """Reservoir pressure [bara] at `dates` (default: the well's test dates)."""
    d = well_tests[well_tests.well == well]
    dates = pd.DatetimeIndex(d.date if dates is None else dates)
    if mode == "const":
        return np.full(len(dates), pr_const if pr_const is not None else cfg.well(well, "p_res_bara"), float)
    if mode == "table" and table is not None:
        t = table[table.well == well].sort_values("date")
        return np.interp(dates.values.astype(float), t.date.values.astype(float), t.pr_bara.values)
    cum = field_cum_gas(well_tests)
    gp = np.interp(dates.values.astype(float), cum.index.values.astype(float), cum.values)
    pvt, tres = GasPVT.from_cfg(cfg), cfg.well(well, "t_res_c")
    pzi = cfg.p_res_init_bara / pvt.z(cfg.p_res_init_bara, tres)
    pzn = cfg.p_res_now_bara / pvt.z(cfg.p_res_now_bara, tres)
    pz = pzi + (pzn - pzi) * gp / max(cum.iloc[-1], 1.0)
    p = pz * 0 + cfg.p_res_now_bara
    for _ in range(20):
        p = pz * pvt.z(p, tres)
    return np.asarray(p, float)


def fit_rs(q, pwf, pr, n_fixed: float | None = None):
    """Log-log least squares: ln q = ln C + n ln(Pr^2-Pwf^2). -> dict(C, n, r2, span) or None if not fittable."""
    q, pwf = np.asarray(q, float), np.asarray(pwf, float)
    dp2 = pr ** 2 - pwf ** 2
    m = (q > 0) & (dp2 > 0)
    if m.sum() < 2:
        return None
    x, y = np.log(dp2[m]), np.log(q[m])
    if n_fixed is not None:
        n = n_fixed
    else:
        if np.ptp(x) < 1e-9:
            return None
        n = np.polyfit(x, y, 1)[0]
    lc = np.mean(y - n * x)
    res = y - (lc + n * x)
    r2 = 1 - np.sum(res ** 2) / max(np.sum((y - y.mean()) ** 2), 1e-12)
    return dict(C=float(np.exp(lc)), n=float(n), r2=float(r2), span=float(np.expm1(min(np.ptp(x), 50.0))), n_pts=int(m.sum()))


def implied_pr(q, pwf) -> float:
    """Pr from n=1 regression Pwf^2 = Pr^2 - q/C (multi-rate test, intercept at q=0). nan if slope not negative."""
    q, y = np.asarray(q, float), np.asarray(pwf, float) ** 2
    if len(q) < 2 or np.ptp(q) <= 0:
        return float("nan")
    s, b = np.polyfit(q, y, 1)
    return float(np.sqrt(b)) if s < 0 and b > 0 else float("nan")


def aof(C, n, pr) -> float:
    return C * (pr ** 2 - T_ATM_AOF ** 2) ** n


def multirate_tests(well_tests: pd.DataFrame, min_pts: int = 2):
    for (w, dt), d in well_tests[well_tests.n_pts_day >= min_pts].groupby(["well", "date"]):
        yield w, dt, d


def analyse(well_tests: pd.DataFrame, cfg, pr_mode: str = "pz", pr_const: float | None = None, pr_table: pd.DataFrame | None = None,
            n_boot: int = 60, seed: int = 0) -> Result:
    """Fit every multi-rate test. Columns: well,date,n_pts,pr_used,pr_implied,n,C,r2,aof_mmsm3d,aof_p10,aof_p90,flags,ok"""
    rng = np.random.default_rng(seed)
    rows = []
    ud = {w: g.date.unique() for w, g in well_tests.groupby("well")}
    prm = {w: dict(zip(pd.DatetimeIndex(ud[w]), pr_series(well_tests, cfg, w, "pz" if pr_mode == "implied" else pr_mode, pr_const, pr_table, ud[w])))
           for w in ud}
    for w, dt, d in multirate_tests(well_tests):
        q, whp = d.gas_sm3d.values, d.whp_bara.values
        pwf = whp_to_bhp(cfg, w, whp, q)
        pri = implied_pr(q, pwf)
        pr = pri if (pr_mode == "implied" and np.isfinite(pri)) else prm[w][dt]
        flags = []
        imp = pr_mode == "implied" and np.isfinite(pri)
        f = fit_rs(q, pwf, pr, n_fixed=1.0 if imp else None)
        row = dict(well=w, date=dt, n_pts=len(d), pr_used=pr, pr_implied=pri, pwf_mean=float(pwf.mean()), q_mean=float(q.mean()))
        if f is None:
            row.update(flags="not fittable (Pr<=Pwf or no rate contrast)", ok=False)
            rows.append(row)
            continue
        if len(d) < 3:
            flags.append("<3 points: n not determinable")
        if imp:
            flags.append("n fixed 1 (implied-Pr mode: n and Pr not independent)")
        elif not 0.5 <= f["n"] <= 1.0:
            flags.append(f"n={f['n']:.2f} outside 0.5-1")
        if f["span"] < 0.10:
            flags.append("rate contrast in (Pr2-Pwf2) <10%: ill-conditioned")
        if np.isfinite(pri) and abs(pri - pr) / pr > 0.15 and not imp:
            flags.append(f"Pr used {pr:.0f} vs implied {pri:.0f} bara disagree")
        if not np.isfinite(pri):
            flags.append("implied Pr n/a (rate rises with Pwf)")
        nn, ok = f["n"], not any(s.startswith(("n=", "<3", "rate contrast")) for s in flags)
        boots = []
        for _ in range(n_boot):
            i = rng.integers(0, len(d), len(d))
            fb = fit_rs(q[i], pwf[i], pr * rng.uniform(0.95, 1.05))
            if fb is not None:
                fb2 = fit_rs(q, pwf, pr, n_fixed=float(np.clip(fb["n"], 0.5, 1.0)))
                boots.append(aof(fb2["C"], fb2["n"], pr))
        nc = float(np.clip(nn, 0.5, 1.0))
        fc = fit_rs(q, pwf, pr, n_fixed=nc)
        row.update(n=nn, n_clip=nc, C=fc["C"], r2=f["r2"], aof_mmsm3d=aof(fc["C"], nc, pr) / 1e6,
                   aof_p10=np.percentile(boots, 90) / 1e6 if boots else np.nan, aof_p90=np.percentile(boots, 10) / 1e6 if boots else np.nan,
                   flags="; ".join(flags), ok=ok)
        rows.append(row)
    df = pd.DataFrame(rows)
    res = Result("Back-pressure deliverability", df, Status.UNVALIDATED, meta=dict(pr_mode=pr_mode, t_wh_c=T_WH_C))
    res.assumptions = [f"{k} (default)" for k in cfg.assumed("p_res_init_bara", "p_res_now_bara", "datum_tvd_m", "tubing_id_in", "t_res_c", "gas_sg")]
    res.assumptions.append(f"flowing wellhead temperature {T_WH_C:.0f} C")
    if pr_mode == "pz":
        res.assumptions.append("Pr(t): linear p/z between configured initial and current Pr vs field cumulative (not measured)")
    if df.empty:
        return res.fail("no multi-rate tests (same well+date, >=2 rates)")
    bad = int((~df.ok.fillna(False)).sum())
    res.warn(f"{bad}/{len(df)} tests flagged (n outside 0.5-1, <3 pts, ill-conditioned or Pr inconsistent): AOF numbers are indicative only.")
    return res


def fit_whp_rate(well_df: pd.DataFrame, window_years: float = 8.0) -> dict:
    """Empirical WHP-rate relations of one well, from the last `window_years` of tests (one point per date).
    trend:  whp = a + b*q   [bara, MMSm3/d] Theil-Sen over time (b>0: WHP falls with the depletion-driven rate decline)
    choke:  dq/dwhp [MMSm3/d per bar] pooled within-test slope of multi-rate tests (negative = rate up when WHP down)
    Empirical; both change as the reservoir depletes - never extrapolate far outside the stated ranges."""
    d = well_df.sort_values("date")
    d = d[d.date >= d.date.max() - pd.Timedelta(days=365.25 * window_years)]
    g = d.groupby("date").agg(whp=("whp_bara", "mean"), q=("gas_sm3d", "mean")).dropna()
    out = dict(ok=False, n=len(g), a=np.nan, b=np.nan, r2=np.nan, dq_dwhp_choke=np.nan, q_range=(np.nan, np.nan), whp_range=(np.nan, np.nan))
    if len(g) >= 4:
        q = g.q.values / 1e6
        b, a, _, _ = theilslopes(g.whp.values, q)
        pred = a + b * q
        r2 = 1 - np.sum((g.whp.values - pred) ** 2) / max(np.sum((g.whp.values - g.whp.mean()) ** 2), 1e-9)
        out.update(ok=True, a=float(a), b=float(b), r2=float(r2), q_range=(float(q.min()), float(q.max())),
                   whp_range=(float(g.whp.min()), float(g.whp.max())))
    mr = well_df[well_df.n_pts_day >= 2].copy()
    if len(mr):
        k = mr.groupby("date")
        dx, dy = (mr.whp_bara - k.whp_bara.transform("mean")).values, (mr.gas_sm3d - k.gas_sm3d.transform("mean")).values / 1e6
        if np.sum(dx ** 2) > 0:
            out["dq_dwhp_choke"] = float(np.sum(dx * dy) / np.sum(dx ** 2))
    return out


def q_at_whp(rel: dict, whp: float) -> float:
    """Invert the trend relation: rate [MMSm3/d] at a given WHP (nan if the relation is unusable / flat)."""
    return (whp - rel["a"]) / rel["b"] if rel.get("ok") and abs(rel["b"]) > 1e-9 else float("nan")


def nodal(cfg, well: str, C: float, n: float, pr: float, whp_list, q_max: float = 5e6) -> pd.DataFrame:
    """IPR (back-pressure) x tubing (WHP->BHP) intersection: rate [Sm3/d] for each WHP. n is clipped to 0.5-1."""
    n = float(np.clip(n, 0.5, 1.0))
    rows = []
    for whp in whp_list:
        f = lambda q: np.sqrt(max(pr ** 2 - (q / C) ** (1 / n), 0.0)) - float(whp_to_bhp(cfg, well, whp, q))
        qs = float(aof(C, n, pr))
        try:
            q = brentq(f, 1.0, min(qs * 0.999, q_max)) if f(1.0) > 0 and f(min(qs * 0.999, q_max)) < 0 else (0.0 if f(1.0) <= 0 else min(qs, q_max))
        except ValueError:
            q = np.nan
        rows.append(dict(whp_bara=float(whp), q_sm3d=q))
    df = pd.DataFrame(rows)
    df["gain_vs_first_sm3d"] = df.q_sm3d - df.q_sm3d.iloc[0]
    return df


def selftest() -> dict:
    from ..core.config import AssetConfig
    cfg = AssetConfig()
    C0, n0, pr = 2.0e-2, 0.82, 200.0
    pwf = np.array([150.0, 120.0, 90.0, 60.0])
    q = C0 * (pr ** 2 - pwf ** 2) ** n0
    f = fit_rs(q, pwf, pr)
    assert abs(f["n"] - n0) / n0 < 0.02 and abs(f["C"] - C0) / C0 < 0.02, f
    assert abs(implied_pr(q * 0 + np.array([1, 2, 3, 4.0]), np.sqrt(pr ** 2 - np.array([1, 2, 3, 4.0]) * 1000)) - np.sqrt(pr ** 2 - 1000 * 0)) < 1.0
    b1, b2 = whp_to_bhp(cfg, "X", 80.0, 0.0), whp_to_bhp(cfg, "X", 80.0, 1e6)
    assert b1 > 80 and b2 > b1, "static column > WHP and friction adds"
    nd = nodal(cfg, "X", 1e-2, 0.9, 250.0, [100.0, 80.0, 60.0])
    assert nd.q_sm3d.is_monotonic_increasing, nd
    rel = fit_whp_rate(pd.DataFrame(dict(date=pd.date_range("2015", periods=10, freq="YS"), whp_bara=np.linspace(150, 80, 10),
                                         gas_sm3d=np.linspace(1.2e6, 0.5e6, 10), n_pts_day=1)))
    assert rel["ok"] and abs(rel["b"] - 100.0) < 1.0, rel
    return {"n_rec": f["n"], "C_rec": f["C"], "nodal": nd.q_sm3d.round(0).tolist()}
