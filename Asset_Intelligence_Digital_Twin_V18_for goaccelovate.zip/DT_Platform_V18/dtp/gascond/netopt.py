"""Rate / choke allocation optimiser for the gathering tree (screening, no streamlit).

maximise  value(q) = sum_i q_i/1000 * P_gas + sum_i q_i CGR_i/1e6 * P_cond          [USD/d]
over well rates q_i (Sm3/d), subject to (SLSQP, variables scaled to MMSm3/d)
    * well capability   : WHP_i(q) <= p_at_i(q)      (the well curve can deliver q at the pressure the network demands; the gap is choke dP)
    * min flowing WHP   : WHP_i(q) >= whp_min        (separator / lift-off limit)
    * velocity          : u_e / u_erosional_e <= v_max for every segment
    * facility          : sum q <= facility capacity (optional)
WHP_i(q) comes from NetModel.solve_back (full tree hydraulics).  Local optimiser: result is a SCREENING suggestion and
REQUIRES ENGINEERING REVIEW AND MoC before any choke change; nothing here is closed-loop.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.optimize import minimize

from ..core.status import Result, Status


def _value(q: dict, ratios: dict, prices: dict) -> float:
    return sum(v / 1000.0 * prices["gas"] + v * ratios.get(w, {}).get("cgr", 0.0) / 1e6 * prices["cond"] for w, v in q.items())


def optimise_rates(model, curves: dict, p_fac: float, prices: dict, whp_min: float = 20.0, v_max: float = 0.8,
                   fac_cap_sm3d: float | None = None, active: list | None = None, maxiter: int = 60) -> Result:
    """Maximise value under velocity / min-WHP / capacity limits. value = DataFrame per well (base vs optimised rate, WHP, choke dP)."""
    res = Result("Rate / choke allocation (SLSQP, screening)", status=Status.UNVALIDATED)
    res.messages.append("Local optimum on a screening hydraulic model: requires engineering review and MoC before any choke change.")
    act = [w for w in (active if active is not None else model.wells) if w in curves]
    if not act:
        return res.fail("no wells with a deliverability curve")
    base = model.deliverability(curves, p_fac, act)
    scale = 1e6
    cache: dict = {}

    def solve(x):
        k = tuple(np.round(x, 9))
        if k not in cache:
            if len(cache) > 400:
                cache.clear()
            cache[k] = model.solve_back({w: float(v) * scale for w, v in zip(act, x)}, p_fac)
        return cache[k]

    def cons(x):
        s = solve(x)
        whp = np.array([s.node_p.get(w, np.nan) for w in act])
        whp = np.nan_to_num(whp, nan=1e3)
        cap = np.array([float(curves[w].p_at(v * scale)) for w, v in zip(act, x)])
        c = [cap - whp, whp - whp_min]
        if len(s.edges):
            c.append(v_max - s.edges["v_ratio"].values)
        if fac_cap_sm3d:
            c.append(np.array([(fac_cap_sm3d - x.sum() * scale) / scale]))
        return np.concatenate(c)

    obj_w = np.array([prices["gas"] / 1000.0 + model.ratios.get(w, {}).get("cgr", 0.0) / 1e6 * prices["cond"] for w in act]) * scale / 1e6
    x0 = np.array([base.q[w] for w in act]) / scale
    ub = np.array([float(curves[w].q(whp_min)) for w in act]) / scale
    r = minimize(lambda x: -float(obj_w @ x), x0, jac=lambda x: -obj_w, method="SLSQP", bounds=[(0, u) for u in ub],
                 constraints=[dict(type="ineq", fun=cons)], options=dict(maxiter=maxiter, ftol=1e-9))
    x = np.clip(r.x, 0, ub)
    viol = float(min(0.0, cons(x).min()))
    if viol < -0.5:                                  # mixed bar / ratio units: >0.5 breach = not credible
        res.warn(f"constraint violation {viol:.2f} after SLSQP ({r.message}): treat as infeasible, relax limits")
    s = solve(x)
    rows = []
    for w, xb, xo in zip(act, x0, x):
        pw = float(s.node_p.get(w, np.nan))
        rows.append(dict(well=w, q_base_sm3d=xb * scale, q_opt_sm3d=xo * scale, change_sm3d=(xo - xb) * scale, whp_required_bara=pw,
                         whp_capable_bara=float(curves[w].p_at(xo * scale)), choke_dp_bar=float(curves[w].p_at(xo * scale)) - pw))
    df = pd.DataFrame(rows)
    qb = {w: v for w, v in zip(act, x0 * scale)}
    qo = {w: v for w, v in zip(act, x * scale)}
    res.value = df
    res.meta = dict(value_base_usd_d=_value(qb, model.ratios, prices), value_opt_usd_d=_value(qo, model.ratios, prices), converged=bool(r.success),
                    max_v_ratio=float(s.edges["v_ratio"].max()) if len(s.edges) else float("nan"), worst_violation=viol, solver=str(r.message),
                    edges=s.edges)
    if not r.success:
        res.warn(f"SLSQP did not converge: {r.message}")
    return res


def selftest() -> dict:
    from .network import NetModel, demo_network
    from .pvt import GasPVT
    nd, curves, ratios = demo_network()
    keep = ["PLANT", "HDR", "MAN-1", "MAN-2"] + [f"W{i:02d}" for i in range(1, 11)]
    nd = nd[nd["site"].isin(keep)]
    m = NetModel(nd, GasPVT(0.7, 2.0), ratios, "stated")
    pr = dict(gas=120.0, cond=520.0)
    free = optimise_rates(m, curves, 55.0, pr, whp_min=10.0, v_max=10.0)
    assert free.ok and free.value["q_opt_sm3d"].sum() >= free.value["q_base_sm3d"].sum() * 0.98
    cap = 0.7 * free.value["q_base_sm3d"].sum()
    tight = optimise_rates(m, curves, 55.0, pr, whp_min=10.0, v_max=10.0, fac_cap_sm3d=cap)
    assert tight.value["q_opt_sm3d"].sum() <= cap * 1.001, "capacity limit"
    # capacity-limited optimum favours the high-value (CGR-rich) wells vs pro-rata cut
    d = tight.value.set_index("well")
    pro = sum(_value({w: d.loc[w, "q_base_sm3d"] * 0.7}, ratios, pr) for w in d.index)
    assert tight.meta["value_opt_usd_d"] >= pro * 0.999, (tight.meta["value_opt_usd_d"], pro)
    return dict(opt_free_gain_pct=100 * (free.meta["value_opt_usd_d"] / free.meta["value_base_usd_d"] - 1),
                opt_capped_vs_prorata_pct=100 * (tight.meta["value_opt_usd_d"] / pro - 1))
