"""Frac screening, treatment-pressure diagnostics (Nolte-Smith, ISIP, closure), stage statistics and flowback evaluation (screening level, UNVALIDATED)."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..core.status import Result, Status


def screen_candidates(wt: pd.DataFrame, cfg) -> pd.DataFrame:
    """Rank wells for stimulation. Productivity proxy PIg = q / (Pr^2 - WHP^2) at the last 3 tests (low = candidate); remaining volume proxy = cumulative from tests.
    Score = 0.5*rank(low PI) + 0.3*rank(cum) + 0.2*rank(low CGR drop). Needs Pr (config) - flagged as assumption."""
    rows = []
    for w, g in wt.sort_values("date").groupby("well"):
        l = g.tail(3)
        pr = cfg.well(w, "p_res_bara")
        den = (pr ** 2 - l.whp_bara ** 2).clip(lower=1.0)
        pi = float(np.nanmedian(l.gas_sm3d / den))
        dt = g.date.diff().dt.days.fillna(0).clip(upper=365)
        cum = float((g.gas_sm3d.fillna(0) * dt).sum() / 1e9)
        rows.append(dict(well=w, pi_proxy=pi, cum_gsm3=cum, last_gas_sm3d=float(l.gas_sm3d.iloc[-1]), whp_last=float(l.whp_bara.iloc[-1]), pr_used=pr))
    d = pd.DataFrame(rows)
    d["score"] = 100 * (0.6 * (1 - d.pi_proxy.rank(pct=True)) + 0.4 * d.cum_gsm3.rank(pct=True))
    return d.sort_values("score", ascending=False).reset_index(drop=True)


def synth_treatment(seed=0, duration_min=90, shutin_min=40, mode="normal") -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    t = np.arange(0, duration_min + shutin_min, 0.25)
    pump = t < duration_min
    rate = np.where(pump, 8.0 + rng.normal(0, 0.15, len(t)), 0.0)
    p_closure = 380.0
    pnet = 55 * (np.maximum(t, 1) / 10) ** (0.18 if mode == "normal" else 0.18)
    if mode == "screenout":
        pnet = pnet + np.where(t > 70, 4.0 * (t - 70), 0)
    p = np.where(pump, p_closure + pnet, 0)
    ts = np.maximum(t - duration_min, 0)
    p = np.where(pump, p, p_closure + 25 * np.exp(-ts / 12) + 10 / (1 + ts / 5))
    p = p + rng.normal(0, 1.0, len(t))
    pc = np.clip(np.where(pump, 90 + 600 * np.clip((t - 25) / 55, 0, 1), 0) / 600, 0, 1) * 600
    return pd.DataFrame(dict(time=pd.Timestamp("2026-03-01") + pd.to_timedelta(t, unit="min"), pressure=p, rate=rate, prop_conc=pc, well="DEMO-F1", stage=1))


def treatment_diagnostics(ts: pd.DataFrame, closure_bar: float | None = None) -> Result:
    d = ts.sort_values("time").copy()
    t = (d.time - d.time.iloc[0]).dt.total_seconds() / 60
    p, q = d.pressure.values, d.rate.values
    pumping = q > 0.2 * np.nanmax(q)
    if pumping.sum() < 20:
        return Result("Treatment diagnostics", None, Status.FAIL, ["fewer than 20 pumping points"])
    i_end = int(np.where(pumping)[0][-1])
    isip = float(np.median(p[max(i_end - 2, 0):i_end + 1]))
    sh = np.arange(i_end + 1, len(d))
    out = dict(isip=isip, pmax=float(np.nanmax(p)), pavg=float(np.nanmean(p[pumping])), q_avg=float(np.nanmean(q[pumping])), vol_m3=float(np.trapezoid(q[:i_end + 1], t[:i_end + 1])),
              hhp_kw=float(np.nanmean(p[pumping]) * 1e5 * np.nanmean(q[pumping]) / 60 / 1e3))
    # closure: first-order sqrt-time deviation on the shut-in decline (simplified G-function style)
    if len(sh) > 20:
        ts_ = t[sh] - t[i_end]
        x, y = np.sqrt(ts_), p[sh]
        k = max(8, len(x) // 6)
        slope = np.polyfit(x[:k], y[:k], 1)[0]
        resid = y - (np.polyval(np.polyfit(x[:k], y[:k], 1), x))
        dev = np.where(resid > 0.02 * abs(y[0]) * 0.1)[0]
        i_c = int(dev[0]) if len(dev) else None
        out["closure_est"] = float(y[i_c]) if i_c else np.nan
    else:
        out["closure_est"] = np.nan
    cl = closure_bar if closure_bar is not None else out["closure_est"]
    if np.isfinite(cl):
        out["net_pressure_end"] = isip - cl
    # Nolte-Smith slope of net pressure on log-log (pumping)
    if np.isfinite(cl):
        m = pumping & (t > 3) & (p - cl > 1)
        if m.sum() > 12:
            s = np.polyfit(np.log(t[m]), np.log(p[m] - cl), 1)[0]
            out["nolte_slope"] = float(s)
            out["regime"] = ("I (PKN-like confined growth, 0.1-0.25)" if 0.05 <= s < 0.3 else "II (stable height, ~0)" if -0.05 <= s < 0.05 else "III (restricted extension / screen-out, >=1)" if s >= 0.8
                             else "intermediate (0.3-0.8: height growth / restricted tip)" if s >= 0.3 else "IV (fall: uncontrolled height / fissure opening)")
    res = Result("Treatment diagnostics", out, Status.UNVALIDATED, assumptions=["closure from user value or sqrt-time deviation (simplified; run a DFIT / G-function in your frac software)"])
    res.messages.append("Nolte-Smith interpretation is qualitative; confirm with the frac simulator and offset data.")
    return res


def stage_stats(st: pd.DataFrame) -> pd.DataFrame:
    d = st.copy()
    L = (d.md_bot - d.md_top) if {"md_top", "md_bot"} <= set(d.columns) else pd.Series(np.nan, index=d.index)
    d["length_m"] = L
    if "proppant_t" in d: d["prop_t_per_m"] = d.proppant_t / L
    if "fluid_m3" in d: d["fluid_m3_per_m"] = d.fluid_m3 / L
    if {"isip_bar", "closure_bar"} <= set(d.columns): d["p_net_bar"] = d.isip_bar - d.closure_bar
    return d


def flowback_eval(df: pd.DataFrame, load_m3: float) -> Result:
    """df: date, gas_sm3d, water_m3d (daily). load recovery %, clean-up day (water-gas ratio stabilised), gas rate stabilised."""
    d = df.sort_values("date").copy()
    d["cum_water"] = d.water_m3d.fillna(0).cumsum()
    d["load_rec_pct"] = 100 * d.cum_water / max(load_m3, 1e-9)
    d["wgr"] = d.water_m3d / (d.gas_sm3d / 1e6).replace(0, np.nan)
    w = d.wgr.rolling(5).median()
    stab = np.where((w.pct_change().abs() < 0.05).rolling(3).sum() >= 3)[0]
    out = dict(table=d, cleanup_day=int(stab[0]) if len(stab) else None, load_rec_pct=float(d.load_rec_pct.iloc[-1]), q_gas_last=float(d.gas_sm3d.iloc[-1]))
    res = Result("Flowback evaluation", out, Status.UNVALIDATED)
    if out["cleanup_day"] is None:
        res.warn("WGR has not stabilised yet: clean-up not complete.")
    return res


def synth_flowback(days=40, seed=0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    t = np.arange(days)
    gas = 3e5 * (1 - np.exp(-t / 6)) * np.exp(-t / 400) * (1 + rng.normal(0, 0.03, days))
    wat = 90 * np.exp(-t / 9) + 6 + rng.normal(0, 1, days)
    return pd.DataFrame(dict(date=pd.Timestamp("2026-03-05") + pd.to_timedelta(t, unit="D"), gas_sm3d=gas, water_m3d=np.clip(wat, 0, None)))


def selftest() -> dict:
    ts = synth_treatment()
    r = treatment_diagnostics(ts, 380.0)
    assert r.value["isip"] > 380 and 0 < r.value["nolte_slope"] < 0.4, r.value
    so = treatment_diagnostics(synth_treatment(mode="screenout"), 380.0)
    assert so.value["nolte_slope"] > r.value["nolte_slope"]
    fb = flowback_eval(synth_flowback(), 3000)
    assert fb.value["cleanup_day"] is not None and fb.value["load_rec_pct"] > 0
    return dict(isip=r.value["isip"], slope=r.value["nolte_slope"], cleanup=fb.value["cleanup_day"])
