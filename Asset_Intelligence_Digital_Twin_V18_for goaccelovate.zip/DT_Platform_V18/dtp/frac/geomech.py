"""Frac geomechanics (screening grade). Stresses/pressures in bar, depth in m, E in GPa.
References: Eaton (1975) pore pressure; uniaxial-strain + Biot (Blanton & Olson) minimum stress; Rickman et al. (2008) brittleness."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ..core.status import Result, Status

G = 9.80665


def sigma_hmin(nu, sigma_v, pp, biot: float = 1.0, tectonic: float = 0.0):
    """sigma_h = nu/(1-nu) (sigma_v - alpha Pp) + alpha Pp + tectonic   (uniaxial strain, poro-elastic). bar."""
    nu = np.asarray(nu, float)
    return nu / (1 - nu) * (np.asarray(sigma_v, float) - biot * np.asarray(pp, float)) + biot * np.asarray(pp, float) + tectonic


def overburden(depth_m, rho_b_kgm3, rho_top: float = 2000.0):
    """Integrated overburden stress [bar] from a bulk-density log (trapezoid; top interval uses rho_top)."""
    d = np.asarray(depth_m, float)
    r = np.asarray(rho_b_kgm3, float)
    seg = np.diff(d, prepend=0.0)
    r_use = np.where(np.isfinite(r), r, np.nanmean(r) if np.isfinite(r).any() else rho_top)
    return np.cumsum(seg * r_use) * G / 1e5


def eaton_pore_pressure(sigma_v, p_normal, dt_obs, dt_normal, exponent: float = 3.0):
    """Eaton sonic: Pp = Sv - (Sv - Pn) (dt_n/dt_o)^x. Equals Pn when dt_obs = dt_normal."""
    return np.asarray(sigma_v, float) - (np.asarray(sigma_v, float) - np.asarray(p_normal, float)) * (np.asarray(dt_normal, float) / np.asarray(dt_obs, float)) ** exponent


def dynamic_to_static(e_dyn_gpa, factor: float = 0.7):
    """RULE OF THUMB: E_static ~ 0.5-0.9 x E_dynamic (tight/hard rocks nearer 0.8-0.9). Calibrate with core / DFIT."""
    return np.asarray(e_dyn_gpa, float) * factor


def brittleness_index(e_gpa, nu, e_range=(6.9, 55.2), nu_range=(0.15, 0.40)):
    """Rickman-style BI in [0,1] = mean(normalised E, normalised -nu). Ranges ~1-8 Mpsi, 0.15-0.4 (editable). Index, not a physical property."""
    e = np.clip((np.asarray(e_gpa, float) - e_range[0]) / (e_range[1] - e_range[0]), 0, 1)
    n = np.clip((np.asarray(nu, float) - nu_range[1]) / (nu_range[0] - nu_range[1]), 0, 1)
    return 0.5 * (e + n)


def gradient(p_bar, tvd_m):
    """bar/m (multiply by 100 for kPa/m... 1 bar/m = 10.2 SG... returned as bar/m)."""
    return np.asarray(p_bar, float) / np.asarray(tvd_m, float)


def frac_gradient(sigma_h_bar, tvd_m, net_pressure_bar: float = 0.0):
    """Breakdown/propagation gradient estimate: (sigma_h + net pressure)/TVD."""
    return gradient(np.asarray(sigma_h_bar, float) + net_pressure_bar, tvd_m)


def barrier_contrast(sh_target, sh_barrier):
    """Stress contrast barrier - target [bar]; >~ 30-50 bar (500-700 psi) usually contains height (rule of thumb; depends on toughness)."""
    return np.asarray(sh_barrier, float) - np.asarray(sh_target, float)


def stress_profile(log: pd.DataFrame, biot: float = 1.0, tectonic: float = 0.0, static_factor: float = 0.7, e_is_dynamic: bool = True) -> Result:
    """log columns: depth_m, rho_b (kg/m3), vp-derived E_gpa (dynamic or static), nu, pp_bar (optional; hydrostatic if missing).
    -> Result(value=DataFrame with sv, pp, sh_min, E_static, BI, closure gradient)."""
    res = Result("Stress profile")
    need = ["depth_m", "nu"]
    if any(c not in log for c in need) or ("e_gpa" not in log):
        return res.fail("log needs columns depth_m, e_gpa, nu (and optionally rho_b, pp_bar)")
    d = log.sort_values("depth_m").reset_index(drop=True).copy()
    if "rho_b" not in d:
        d["rho_b"] = 2450.0
        res.assumptions.append("rho_b missing: 2450 kg/m3 assumed for overburden")
    d["sv_bar"] = overburden(d["depth_m"], d["rho_b"])
    if "pp_bar" not in d:
        d["pp_bar"] = 1.03 * d["depth_m"] * G * 1000 / 1e5 * 1.0
        res.assumptions.append("pp_bar missing: hydrostatic (1.03 SG) pore pressure assumed")
    d["e_static_gpa"] = dynamic_to_static(d["e_gpa"], static_factor) if e_is_dynamic else d["e_gpa"]
    if e_is_dynamic:
        res.assumptions.append(f"E_static = {static_factor} x E_dynamic (rule of thumb)")
    d["sh_bar"] = sigma_hmin(d["nu"], d["sv_bar"], d["pp_bar"], biot, tectonic)
    d["bi"] = brittleness_index(d["e_static_gpa"], d["nu"])
    d["closure_grad_bar_m"] = gradient(d["sh_bar"], d["depth_m"])
    res.value = d
    res.status = Status.WARN
    res.messages.append("Log-derived stresses are uncalibrated: tie to DFIT/minifrac closure pressure before design use.")
    if (d["sh_bar"] > d["sv_bar"]).any():
        res.messages.append("sigma_h > sigma_v in some intervals (thrust regime or tectonic term too large) - vertical fractures not guaranteed there.")
    return res


def quality_score(df: pd.DataFrame, weights: dict | None = None, invert: tuple = ("sh_bar",)) -> pd.Series:
    """Transparent weighted score 0-100: each column is min-max scaled (inverted for those in `invert`) and weighted.
    default weights: bi 0.3, porosity 0.25, perm_md(log) 0.25, sh_bar(low) 0.1, toc/gas_sat optional 0.1"""
    w = weights or {"bi": 0.3, "porosity": 0.25, "perm_md": 0.25, "sh_bar": 0.1}
    tot, acc = 0.0, np.zeros(len(df))
    for c, wt in w.items():
        if c not in df or not df[c].notna().any():
            continue
        x = np.log10(df[c].clip(lower=1e-6)) if c in ("perm_md",) else df[c].astype(float)
        rng = x.max() - x.min()
        s = (x - x.min()) / rng if rng > 0 else x * 0 + 0.5
        acc += wt * (1 - s if c in invert else s).fillna(0.5).values
        tot += wt
    return pd.Series(100 * acc / tot if tot else acc, index=df.index, name="quality_score")


def selftest() -> dict:
    assert abs(float(sigma_hmin(0.25, 500, 300)) - (200 / 3 + 300)) < 1e-9
    assert abs(float(eaton_pore_pressure(500, 300, 100, 100)) - 300) < 1e-9
    assert float(eaton_pore_pressure(500, 300, 120, 100)) > 300          # slower sonic -> overpressure
    b = brittleness_index([7, 55], [0.4, 0.15])
    assert b[0] < b[1] and 0 <= b[0] <= 1 and 0 <= b[1] <= 1
    d = pd.DataFrame(dict(depth_m=np.arange(2000, 2100, 10.0), e_gpa=40.0, nu=0.22))
    r = stress_profile(d)
    assert r.ok and (r.value["sh_bar"] < r.value["sv_bar"]).all()
    return dict(sh=float(r.value["sh_bar"].iloc[0]), sv=float(r.value["sv_bar"].iloc[0]))
