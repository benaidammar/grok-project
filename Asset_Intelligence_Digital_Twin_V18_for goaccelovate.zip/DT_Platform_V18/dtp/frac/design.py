"""Fracture design SCREENING: 2D geometry (PKN / KGD / radial) with Carter leakoff, Nolte pump schedule, Prats / Cinco-Ley
productivity, LHS design-of-experiments + surrogate + constrained optimisation.
SCREENING ONLY - design requires a validated 3D fracture simulator, offset calibration and sign-off.
Width coefficients follow textbook forms (Perkins-Kern-Nordgren, Khristianovic-Geertsma-de Klerk, Sneddon); published coefficients
vary 2.0-3.3 with the width definition, so results are +-20-30 %.
Units (inputs): q m3/min, t min, h m, E GPa, mu cP, C_L m/sqrt(min), spurt m (m3/m2), pressures bar."""
from __future__ import annotations
from dataclasses import dataclass, replace

import numpy as np
import pandas as pd
from scipy.optimize import brentq
from scipy.special import gamma

from ..core.status import Result, Status

GEOMETRIES = ("PKN", "KGD", "Radial")
G = 9.80665


def e_plane(e_gpa, nu):
    """Plane-strain modulus E' = E/(1-nu^2) in Pa."""
    return e_gpa * 1e9 / (1 - nu ** 2)


def carter_g(alpha: float) -> float:
    """Leak-off integral factor for area growth A ~ t^alpha: g = Gamma(a+1)Gamma(1.5)/Gamma(a+1.5). (alpha=1 -> 2/3)"""
    return gamma(alpha + 1) * gamma(1.5) / gamma(alpha + 1.5)


@dataclass
class FracInputs:
    q_m3min: float = 8.0
    t_min: float = 60.0
    h_m: float = 40.0
    e_gpa: float = 30.0
    nu: float = 0.22
    mu_cp: float = 30.0
    cl_m_sqrtmin: float = 0.0006       # ~0.002 ft/sqrt(min)
    spurt_m: float = 0.0
    geometry: str = "PKN"
    coef: float = 2.5


def _shape(geom: str, L: float, h: float):
    """face area A [m2], width-average factor w_avg/w_max."""
    if geom == "Radial":
        return np.pi * L * L, 2.0 / 3.0
    return 2.0 * L * h, np.pi / 4.0


def _wmax(p: FracInputs, L: float) -> float:
    q = p.q_m3min / 60.0
    mu = p.mu_cp * 1e-3
    ep = e_plane(p.e_gpa, p.nu)
    if p.geometry == "PKN":
        return p.coef * (q * mu * L / ep) ** 0.25
    if p.geometry == "KGD":
        return 2.27 * (q * mu * L * L / (ep * p.h_m)) ** 0.25
    return p.coef * (q * mu * L / ep) ** 0.25


def geometry(p: FracInputs, t_min: float | None = None) -> dict:
    """Solve q t = w_avg A + leak-off (+spurt) for the half-length (PKN/KGD) or radius. Returns dict with L, w_max, w_avg, p_net [bar], eta, A."""
    t = (p.t_min if t_min is None else t_min) * 60.0
    vol = p.q_m3min / 60.0 * t
    cl = p.cl_m_sqrtmin / np.sqrt(60.0)
    eta, out = 0.8, None
    for _ in range(40):
        alpha = 0.5 + 0.3 * eta                                   # area-growth exponent: 0.5 (leaky) .. 0.8 (efficient)
        gl = carter_g(alpha)

        def f(L):
            A, k = _shape(p.geometry, L, p.h_m)
            return _wmax(p, L) * k * A + 4 * cl * A * np.sqrt(t) * gl + 2 * p.spurt_m * A - vol
        L = brentq(f, 1e-2, 5e4)
        A, k = _shape(p.geometry, L, p.h_m)
        w_max = _wmax(p, L)
        v_f = w_max * k * A
        eta_new = float(np.clip(v_f / vol, 0.01, 1.0))
        out = (L, A, w_max, k, v_f)
        if abs(eta_new - eta) < 1e-5:
            eta = eta_new
            break
        eta = eta_new
    L, A, w_max, k, v_f = out
    ep = e_plane(p.e_gpa, p.nu)
    if p.geometry == "PKN":
        pnet = ep * w_max / (2 * p.h_m)
    elif p.geometry == "KGD":
        pnet = ep * w_max / (4 * L)
    else:
        pnet = np.pi * ep * w_max / (8 * L)
    return dict(L_m=L, A_face_m2=A, w_max_mm=w_max * 1e3, w_avg_mm=w_max * k * 1e3, p_net_bar=pnet / 1e5, eta=eta, V_frac_m3=v_f, V_inj_m3=vol,
                geometry=p.geometry)


def pad_fraction(eta: float) -> float:
    """Nolte: pad / total = (1-eta)/(1+eta)."""
    return (1 - eta) / (1 + eta)


def pump_schedule(q_m3min: float, t_min: float, eta: float, prop_mass_kg: float, n_steps: int = 10, c_max_kgm3: float = 1200.0) -> Result:
    """Nolte power-law ramp c(t) = c_f ((t-t_pad)/(t_e-t_pad))^eps, eps = (1-eta)/(1+eta). M = q c_f (t_e - t_pad)/(1+eps)."""
    res = Result("Pump schedule (Nolte)")
    eps = pad_fraction(eta)
    t_pad = eps * t_min
    te = t_min - t_pad
    c_f = prop_mass_kg * (1 + eps) / (q_m3min * te) if te > 0 else np.nan
    if not np.isfinite(c_f):
        return res.fail("invalid schedule")
    if c_f > c_max_kgm3:
        res.warn(f"Final concentration {c_f:.0f} kg/m3 exceeds practical limit {c_max_kgm3:.0f}: reduce mass, increase volume or efficiency")
    edges = np.linspace(0, te, n_steps + 1)
    rows = [dict(step="PAD", t_start_min=0.0, t_end_min=t_pad, clean_vol_m3=q_m3min * t_pad, conc_kgm3=0.0, prop_kg=0.0)]
    for i in range(n_steps):
        a, b = edges[i], edges[i + 1]
        mass = q_m3min * c_f * te / (1 + eps) * ((b / te) ** (1 + eps) - (a / te) ** (1 + eps))
        rows.append(dict(step=f"S{i+1}", t_start_min=t_pad + a, t_end_min=t_pad + b, clean_vol_m3=q_m3min * (b - a),
                         conc_kgm3=c_f * (b / te) ** eps, prop_kg=mass))
    d = pd.DataFrame(rows)
    res.value = d
    res.meta = dict(pad_frac=eps, c_final=c_f, total_prop_kg=float(d["prop_kg"].sum()))
    return res


def kf_pack(closure_stress_bar: float, proppant: str = "sand 20/40", damage: float = 0.5) -> float:
    """Generic placeholder pack permeability [mD] vs closure stress (REPLACE with lab/vendor data): log-linear fit through generic points,
    times a damage factor (gel residue, non-Darcy, embedment)."""
    tab = {"sand 20/40": ([140, 280, 410, 550], [500e3, 250e3, 100e3, 35e3]),
           "ceramic 20/40": ([140, 280, 410, 550, 690], [1100e3, 800e3, 500e3, 300e3, 160e3]),
           "sand 40/70": ([140, 280, 410, 550], [200e3, 110e3, 55e3, 20e3])}
    s, k = tab.get(proppant, tab["sand 20/40"])
    return float(np.exp(np.interp(closure_stress_bar, s, np.log(k)))) * damage


def prats_f(fcd):
    """Economides unified-design fit f = s_f + ln(xf/rw);  u=ln FcD;  f=(1.65-0.328u+0.116u^2)/(1+0.18u+0.064u^2+0.005u^3)."""
    u = np.log(np.clip(np.asarray(fcd, float), 1e-3, 1e4))
    return (1.65 - 0.328 * u + 0.116 * u ** 2) / (1 + 0.18 * u + 0.064 * u ** 2 + 0.005 * u ** 3)


def rw_eq_ratio(fcd):
    """r_w'/x_f  (-> 0.5 for infinite conductivity)."""
    return np.exp(-prats_f(fcd))


def productivity_ratio(fcd, xf_m, rw_m: float = 0.11, re_m: float = 400.0, s0: float = 0.0):
    """J_frac/J_0 for pseudo-steady radial drainage: ln(re/rw)+s0 over ln(re/rw)+ s_f_total with s_f = f - ln(xf/rw)."""
    sf = prats_f(fcd) - np.log(np.asarray(xf_m, float) / rw_m)
    base = np.log(re_m / rw_m) + s0
    return base / np.maximum(np.log(re_m / rw_m) + sf, 0.2)


def settling_velocity(d_mm: float, rho_p: float, rho_f: float, mu_cp: float, c_vol: float = 0.0) -> float:
    """Stokes with hindered settling (Richardson-Zaki (1-c)^4.65) [m/s]. Valid Re<<1 (viscous gels); slickwater -> overestimates retention, check with Re."""
    d = d_mm * 1e-3
    v = G * d * d * (rho_p - rho_f) / (18 * mu_cp * 1e-3)
    return v * (1 - c_vol) ** 4.65


def evaluate(par: dict, base: FracInputs, res_in: dict) -> dict:
    """One design -> geometry, propped width, FcD, productivity ratio, risks.  par keys override: prop_kg, q_m3min, t_min, mu_cp, cl_m_sqrtmin.
    res_in: k_md, closure_bar, rw_m, re_m, rho_p, phi_p, d_prop_mm, propped_frac, proppant, damage, p_net_max_bar, h_m."""
    p = replace(base, **{k: v for k, v in par.items() if k in FracInputs.__dataclass_fields__})
    g = geometry(p)
    eta = g["eta"]
    mass = par.get("prop_kg", 50000.0)
    xf_p = g["L_m"] * res_in.get("propped_frac", 0.7)
    if p.geometry == "Radial":
        a_prop = np.pi * xf_p ** 2
    else:
        a_prop = 2 * xf_p * p.h_m
    wp = mass / (res_in.get("rho_p", 2650.0) * (1 - res_in.get("phi_p", 0.38)) * a_prop)
    kf = kf_pack(res_in["closure_bar"], res_in.get("proppant", "sand 20/40"), res_in.get("damage", 0.5))
    fcd = kf * wp / (res_in["k_md"] * xf_p)
    jr = float(productivity_ratio(fcd, xf_p, res_in.get("rw_m", 0.11), res_in.get("re_m", 400.0), res_in.get("s0", 0.0)))
    d_prop = res_in.get("d_prop_mm", 0.6)
    width_ratio = g["w_avg_mm"] / (3 * d_prop)                       # <1: bridging / screen-out risk (rule of 3 grain diameters)
    c_f = pad_fraction(eta)
    return dict(**g, prop_kg=mass, xf_prop_m=xf_p, w_prop_mm=wp * 1e3, kf_mD=kf, FcD=fcd, JR=jr, width_ratio=width_ratio,
                p_net_ok=g["p_net_bar"] <= res_in.get("p_net_max_bar", 1e9), pad_frac=c_f)


def lhs_doe(bounds: dict, n: int = 200, seed: int = 0) -> pd.DataFrame:
    from scipy.stats import qmc
    keys = list(bounds)
    s = qmc.LatinHypercube(d=len(keys), seed=seed).random(n)
    lo = np.array([bounds[k][0] for k in keys])
    hi = np.array([bounds[k][1] for k in keys])
    return pd.DataFrame(qmc.scale(s, lo, hi), columns=keys)


def run_doe(base: FracInputs, res_in: dict, bounds: dict, n: int = 400, seed: int = 0) -> pd.DataFrame:
    doe = lhs_doe(bounds, n, seed)
    rows = []
    for _, r in doe.iterrows():
        try:
            out = evaluate(r.to_dict(), base, res_in)
            rows.append({**r.to_dict(), **{k: out[k] for k in ("L_m", "w_avg_mm", "p_net_bar", "eta", "FcD", "JR", "width_ratio", "p_net_ok", "xf_prop_m")}})
        except Exception:                     # noqa: BLE001
            continue
    return pd.DataFrame(rows)


def fit_surrogate(doe: pd.DataFrame, feats: list, target: str = "JR", seed: int = 0) -> dict:
    """Gradient-boosting surrogate with honest hold-out R2 (30 %)."""
    from sklearn.ensemble import GradientBoostingRegressor
    from sklearn.metrics import r2_score
    from sklearn.model_selection import train_test_split
    Xtr, Xte, ytr, yte = train_test_split(doe[feats], doe[target], test_size=0.3, random_state=seed)
    m = GradientBoostingRegressor(n_estimators=250, max_depth=3, learning_rate=0.08, random_state=seed).fit(Xtr, ytr)
    return dict(model=m, r2_holdout=float(r2_score(yte, m.predict(Xte))), feats=feats, n=len(doe))


def optimise(base: FracInputs, res_in: dict, bounds: dict, n: int = 600, seed: int = 0, base_rate_sm3d: float = 2e5,
             gas_price_usd_ksm3: float = 120.0, horizon_years: float = 3.0, cost_prop_usd_t: float = 600.0, cost_fluid_usd_m3: float = 40.0,
             cost_hhp_usd_per_hhp: float = 0.0, min_width_ratio: float = 1.0) -> Result:
    """DOE (Latin hypercube) + physics evaluation + surrogate check + constrained choice + Pareto front (proppant mass vs JR).
    Constraints: p_net <= p_net_max (stress barrier), width_ratio >= min (screen-out), final slurry conc <= practical limit."""
    res = Result("Frac design optimisation", status=Status.UNVALIDATED)
    doe = run_doe(base, res_in, bounds, n, seed)
    if doe.empty:
        return res.fail("no valid design evaluated")
    doe["fluid_m3"] = doe.get("q_m3min", base.q_m3min) * doe.get("t_min", base.t_min)
    doe["cost_usd"] = doe["prop_kg"] / 1e3 * cost_prop_usd_t + doe["fluid_m3"] * cost_fluid_usd_m3
    doe["value_usd"] = (doe["JR"] - 1) * base_rate_sm3d * 365 * horizon_years * 0.6 / 1e3 * gas_price_usd_ksm3     # 0.6 = crude decline averaging
    doe["net_usd"] = doe["value_usd"] - doe["cost_usd"]
    c_ok = doe["prop_kg"] * (1 + (1 - doe["eta"]) / (1 + doe["eta"])) / (doe["fluid_m3"] * (1 - (1 - doe["eta"]) / (1 + doe["eta"]))) <= 1200.0    # kg/m3 mean conc check
    doe["feasible"] = doe["p_net_ok"] & (doe["width_ratio"] >= min_width_ratio) & c_ok
    feas = doe[doe["feasible"]]
    sur = fit_surrogate(doe, [c for c in bounds], "JR", seed)
    res.meta = dict(n=len(doe), n_feasible=len(feas), surrogate_r2=sur["r2_holdout"])
    if feas.empty:
        res.value = dict(doe=doe, best=None, pareto=pd.DataFrame(), surrogate=sur)
        return res.fail("No feasible design in the given bounds: relax net-pressure limit / minimum width ratio or widen ranges")
    best = feas.sort_values("net_usd", ascending=False).iloc[0]
    fs = feas.sort_values("prop_kg")
    pareto = fs[fs["JR"] >= fs["JR"].cummax()].copy()
    res.value = dict(doe=doe, best=best, pareto=pareto, surrogate=sur)
    res.assumptions += ["gas value = (JR-1) x base rate x years x 0.6 decline-averaging factor x price: crude", "pack permeability = generic table x damage factor (replace with lab data)",
                        "propped length = hydraulic length x propped fraction (assumed)"]
    res.messages += ["SCREENING ONLY: result requires a validated 3D simulator, offset calibration, engineering review / MoC and approvals."]
    if sur["r2_holdout"] < 0.8:
        res.warn(f"Surrogate hold-out R2 = {sur['r2_holdout']:.2f} < 0.8: use physics DOE directly")
    return res


def selftest() -> dict:
    # PKN, no leak-off: L ~ t^0.8
    p = FracInputs(cl_m_sqrtmin=0.0, geometry="PKN")
    g1, g2 = geometry(p, 30), geometry(p, 60)
    expo = np.log(g2["L_m"] / g1["L_m"]) / np.log(2)
    assert abs(expo - 0.8) < 0.02, expo
    assert abs(g2["eta"] - 1) < 0.02 and abs(g2["w_avg_mm"] * 1e-3 * g2["A_face_m2"] - g2["V_inj_m3"]) / g2["V_inj_m3"] < 0.01
    # leak-off reduces efficiency & length
    gl = geometry(replace(p, cl_m_sqrtmin=0.002), 60)
    assert gl["eta"] < 0.85 and gl["L_m"] < g2["L_m"]
    # KGD radial run
    for geo in ("KGD", "Radial"):
        assert geometry(replace(p, geometry=geo), 60)["L_m"] > 0
    # Prats limits
    assert abs(float(rw_eq_ratio(1000.0)) - 0.5) < 0.04, rw_eq_ratio(1000.0)
    assert float(rw_eq_ratio(0.1)) < 0.06 and float(rw_eq_ratio(1.6)) > float(rw_eq_ratio(0.5))
    assert 0.0 < float(pad_fraction(1.0)) + 1e-9 and pad_fraction(0.2) > pad_fraction(0.8)
    sch = pump_schedule(8, 60, 0.3, 60000)
    assert abs(sch.value["prop_kg"].sum() - 60000) < 1
    # Stokes
    assert settling_velocity(0.6, 2650, 1000, 100) < settling_velocity(0.6, 2650, 1000, 10)
    res_in = dict(k_md=0.01, closure_bar=450, p_net_max_bar=80, d_prop_mm=0.6)
    bounds = dict(prop_kg=(20000, 150000), q_m3min=(4, 14), t_min=(40, 120), mu_cp=(5, 60))
    o = optimise(FracInputs(), res_in, bounds, n=250)
    assert o.value is not None and o.meta["surrogate_r2"] > 0.5
    return dict(pkn_exponent=expo, surrogate_r2=o.meta["surrogate_r2"], n_feasible=o.meta["n_feasible"])
