"""Hub topics: managerial intelligence."""
from .engine import mk

M = "mgmt"
TOPICS = [
    mk("mg-kpi-definitions", M, "KPI definitions that survive audit", "basics", "Define each KPI once: formula, unit, source, owner, frequency (production, uptime, deferment, cost per boe, HSE).", "Prevents ten versions of the same number.", "Before building any dashboard.", "—", None,
       "List KPIs|Write formula and source|Assign owner|Version", "reports", "KPI dictionary", "—", "Mixing allocated and test-based volumes", "Reproduce the monthly report", "", "Management", ["mg-gap-bridge"]),
    mk("mg-gap-bridge", M, "Gap-to-target waterfall", "intermediate", "Decompose target − actual into downtime, natural decline, new-well shortfall, constraints, other.", "Turns 'we missed target' into actions.", "Monthly review.", "Without downtime data the 'other' bucket is large.",
       None, "Take target|Subtract measured losses|Attribute decline|Residual = unexplained|Assign actions", "production, downtime, targets", "waterfall + actions", "Attribution is only as good as downtime coding", "Double counting", "Buckets sum to the gap", "dtp.mgmt.manage.gap_bridge", "Management:Gap", ["mg-deferment-reason-codes"]),
    mk("mg-deferment-reason-codes", M, "Deferment reason codes", "basics", "Consistent categories: planned, unplanned, constraint, reservoir, third party.", "Enables root-cause statistics.", "Downtime logging.", "—", None,
       "Define taxonomy|Train operators|Audit monthly", "downtime log", "Pareto of losses", "—", "'Other' dominating", "<10 % 'other'", "", "Management", ["mg-gap-bridge"]),
    mk("mg-target-forecast-governance", M, "Target vs forecast governance", "intermediate", "Targets are commitments; forecasts are expectations; keep them separate and review the difference.", "Prevents sandbagging and wishful forecasts.", "Annual and quarterly cycles.", "—", None,
       "Freeze target|Update forecast monthly|Explain gap|Track bias", "target, forecast", "variance log", "—", "Re-basing targets silently", "Version history", "", "Management", ["fc-bias"]),
    mk("mg-budget-eac-etc", M, "Budget, EAC and ETC", "intermediate", "Estimate at completion = actual + estimate to complete; compare with budget; CAPEX/OPEX split.", "Spend control.", "Monthly cost review.", "—",
       [("EAC", r"EAC=AC+ETC", "")], "Collect actual and commitments|Estimate remaining|Variance", "budget table", "EAC, variance", "Commitments often missing", "Ignoring accruals", "Reconcile with ERP", "dtp.mgmt.manage.budget_variance", "Management:Budget", ["mg-opportunity-register"]),
    mk("mg-opportunity-register", M, "Opportunity register and ranking", "intermediate", "A single list of actions with gain (boe/d), capex, opex, decline, NPV, risk.", "Capital goes to the best projects.", "Planning.", "—",
       [("NPV", r"NPV=-C+\sum_t\frac{q_tP-OPEX}{(1+r)^t}", "")], "Estimate gain|Cost|NPV|Rank|Risk adjust", "estimates", "ranked list", "Gains highly uncertain", "Optimism bias", "Back-check delivered vs promised", "dtp.mgmt.manage.rank_opportunities", "Management:Opportunities", ["mg-risk-adjusted-value"]),
    mk("mg-risk-adjusted-value", M, "Risk-adjusted value", "intermediate", "Multiply value by probability of technical and commercial success; use P10-P90 ranges.", "Avoids ranking by hope.", "Portfolio decisions.", "—",
       [("Risked NPV", r"E[NPV]=P_s\,NPV_s-(1-P_s)\,C_{dry}", "")], "Assign Ps|Compute|Compare", "estimates", "risked NPV", "Ps subjective", "Reusing Ps without history", "Calibrate with outcomes", "", "Management", ["mg-opportunity-register"]),
]
