"""Hub calculators: small tested helpers used on the hub page."""
from __future__ import annotations
import numpy as np

RHO_CO2_STD = 1.872          # kg/Sm3 at 15 degC, 1 atm


def co2_from_gas(gas_sm3d: float, co2_pct: float, years: float = 1.0) -> dict:
    """CO2 mass from a gas rate and mole % (ideal-gas volume = mole fraction)."""
    t_d = gas_sm3d * co2_pct / 100.0 * RHO_CO2_STD / 1e3
    return dict(t_per_day=t_d, t_per_year=t_d * 365.25, over_years_Mt=t_d * 365.25 * years / 1e6, co2_sm3d=gas_sm3d * co2_pct / 100.0)


def gradient_to_pressure(rho_kgm3: float, height_m: float) -> float:
    return rho_kgm3 * 9.80665 * height_m / 1e5


def bar_to_psi(x): return x * 14.5038
def sm3_to_scf(x): return x * 35.3147 * (288.7 / 288.15) if False else x * 35.3147
def m3_to_bbl(x): return x * 6.28981


def pressure_convert(value: float, frm: str, to: str, patm: float = 1.01325) -> float:
    f = {"bara": 1.0, "barg": 1.0, "psia": 14.5038, "psig": 14.5038, "kPa": 100.0, "MPa": 0.1}
    bar = value / f[frm]
    if frm.endswith("g"): bar += patm
    out = bar * f[to]
    if to.endswith("g"): out -= patm * f[to]
    return out


def selftest():
    c = co2_from_gas(1e6, 2.0)
    assert abs(c["t_per_day"] - 37.44) < 0.1, c
    assert abs(pressure_convert(10, "barg", "bara") - 11.01325) < 1e-6
    assert abs(pressure_convert(145.038, "psia", "bara") - 10.0) < 1e-3
    assert abs(gradient_to_pressure(1000, 100) - 9.80665) < 1e-6
    return True
