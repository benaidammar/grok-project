"""Knowledge-hub engine: topic schema, loader, search, learning paths, validation.

Topic (dict) keys - every topics_*.py module exposes TOPICS: list[dict] built with `mk(...)`:
  id, domain, title, level (basics|intermediate|advanced), summary, why_it_matters, when_to_use, when_NOT_to_use,
  key_equations [{name, latex, variables}], workflow_steps [str], inputs_needed [str], outputs [str],
  assumptions_limits [str], common_pitfalls [str], validation_checks [str], python_entry_points [str],
  platform_tool ('page:Tab' or ''), related [ids], references [str], maturity (str), worked_example (str)
"""
from __future__ import annotations
import importlib
import re
from functools import lru_cache

LEVELS = ["basics", "intermediate", "advanced"]
REQUIRED_TEXT = ["id", "domain", "title", "level", "summary", "why_it_matters", "when_to_use", "when_NOT_to_use", "maturity"]
REQUIRED_LIST = ["workflow_steps", "inputs_needed", "outputs", "assumptions_limits", "common_pitfalls", "validation_checks", "references"]
OPTIONAL_LIST = ["key_equations", "python_entry_points", "related"]
TOPIC_MODULES = ["topics_core", "topics_gascond", "topics_ai", "topics_mgmt", "topics_lift", "topics_frac", "topics_ccus"]
TECHNICAL = {"gascond", "network", "forecast", "lift", "frac", "ccus", "ai"}


def mk(id, domain, title, level, summary, why, use, notuse, eq=None, steps=None, inputs=None, outputs=None, limits=None,
       pitfalls=None, checks=None, py=None, tool="", related=None, refs=None, maturity="Established method.", example="") -> dict:
    """Compact constructor. eq = [(name, latex, variables), ...]; list args may be '|' separated strings."""
    refs = refs or "AI Oil & Gas Asset Intelligence Digital Twin Handbook v1 (project basis)"
    sp = lambda v: [s.strip() for s in v.split("|") if s.strip()] if isinstance(v, str) else list(v or [])
    return dict(id=id, domain=domain, title=title, level=level, summary=summary, why_it_matters=why, when_to_use=use, when_NOT_to_use=notuse,
                key_equations=[dict(name=n, latex=l, variables=v) for n, l, v in (eq or [])], workflow_steps=sp(steps), inputs_needed=sp(inputs),
                outputs=sp(outputs), assumptions_limits=sp(limits), common_pitfalls=sp(pitfalls), validation_checks=sp(checks),
                python_entry_points=sp(py), platform_tool=tool, related=sp(related), references=sp(refs), maturity=maturity, worked_example=example)


@lru_cache(maxsize=1)
def load_all_topics() -> list:
    out, seen = [], set()
    for m in TOPIC_MODULES:
        try:
            mod = importlib.import_module(f"dtp.hub.{m}")
        except Exception:                       # missing / broken sibling file must not break the hub
            continue
        for t in getattr(mod, "TOPICS", []):
            if t.get("id") and t["id"] not in seen:
                seen.add(t["id"])
                out.append(t)
    return out


def topic_by_id(tid: str):
    return next((t for t in load_all_topics() if t["id"] == tid), None)


def domains() -> list:
    return sorted({t["domain"] for t in load_all_topics()})


def topic_text(t: dict) -> str:
    parts = [t["title"] * 1, t["title"], t["summary"], t["why_it_matters"], t["when_to_use"], t["when_NOT_to_use"]]
    for k in ("workflow_steps", "inputs_needed", "outputs", "assumptions_limits", "common_pitfalls", "validation_checks", "python_entry_points"):
        parts += t.get(k, [])
    parts += [e["name"] for e in t.get("key_equations", [])]
    return " ".join(str(p) for p in parts)


_TOK = re.compile(r"[a-z0-9]+")


def search(query: str, domain: str | None = None, level: str | None = None, tool: str | None = None, limit: int = 40) -> list:
    """TF-IDF (sklearn) with title boost; falls back to token-overlap score. Empty query -> filtered list."""
    ts = [t for t in load_all_topics() if (not domain or t["domain"] == domain) and (not level or t["level"] == level)
          and (not tool or t["platform_tool"].split(":")[0] == tool)]
    q = query.strip().lower()
    if not q:
        return sorted(ts, key=lambda t: (t["domain"], LEVELS.index(t["level"]), t["title"]))[:limit]
    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, stop_words="english")
        docs = [topic_text(t).lower() for t in ts]
        m = vec.fit_transform(docs + [q])
        sims = (m[:-1] @ m[-1].T).toarray().ravel()
    except Exception:                           # noqa: BLE001
        qt = set(_TOK.findall(q))
        sims = [len(qt & set(_TOK.findall(topic_text(t).lower()))) / max(len(qt), 1) for t in ts]
    qt = set(_TOK.findall(q))
    scored = []
    for t, s in zip(ts, sims):
        boost = 0.5 * len(qt & set(_TOK.findall(t["title"].lower()))) / max(len(qt), 1) + (0.3 if q in t["title"].lower() else 0)
        scored.append((float(s) + boost, t))
    return [t for s, t in sorted(scored, key=lambda x: -x[0]) if s > 0.02][:limit]


def to_markdown(t: dict) -> str:
    L = [f"# {t['title']}", f"*{t['domain']} · {t['level']} · {t['maturity']}*", "", t["summary"], "", f"**Why it matters.** {t['why_it_matters']}",
         f"**Use when.** {t['when_to_use']}", f"**Do NOT use when.** {t['when_NOT_to_use']}", ""]
    for e in t["key_equations"]:
        L.append(f"- {e['name']}: `{e['latex']}` - {e['variables']}")
    for k, lab in (("workflow_steps", "Workflow"), ("inputs_needed", "Inputs"), ("outputs", "Outputs"), ("assumptions_limits", "Assumptions / limits"),
                   ("common_pitfalls", "Pitfalls"), ("validation_checks", "Validation"), ("python_entry_points", "Python"), ("references", "References")):
        if t[k]:
            L += ["", f"**{lab}**"] + [f"- {x}" for x in t[k]]
    if t["worked_example"]:
        L += ["", f"**Worked example.** {t['worked_example']}"]
    return "\n".join(L)


def library_markdown() -> str:
    return "\n\n---\n\n".join(to_markdown(t) for t in sorted(load_all_topics(), key=lambda t: (t["domain"], t["title"])))


def library_df():
    import pandas as pd
    return pd.DataFrame([dict(id=t["id"], domain=t["domain"], title=t["title"], level=t["level"], tool=t["platform_tool"], summary=t["summary"],
                              maturity=t["maturity"]) for t in load_all_topics()])


LEARNING_PATHS = {
    "Gas-condensate well engineer in 10 steps": ["data-units-datum", "gc-pvt-z-visc", "gc-pseudo-pressure", "gc-dewpoint-dropout", "gc-pz-material-balance",
                                                "gc-backpressure-deliverability", "gc-lit-deliverability", "gc-nodal-gas-well", "gc-condensate-banking", "gc-liquid-loading-turner"],
    "Data foundation - first week": ["data-units-datum", "data-test-validation", "data-multirate-tests", "data-outliers-gaps", "data-packs", "data-asset-hierarchy",
                                    "data-lineage-audit", "data-allocation"],
    "Gathering network in 8 steps": ["net-pipe-flow-equations", "net-general-flow-weymouth", "net-wetgas-multiphase", "net-erosional-velocity", "net-looping-upsizing",
                                    "net-compression-backpressure", "net-choke-allocation", "net-utg-constraints"],
    "Forecasting you can defend": ["fc-arps", "fc-modified-hyperbolic", "fc-rate-transient", "fc-pz-forecast", "fc-probabilistic", "fc-backtesting", "fc-bias"],
    "Managerial dashboard from scratch": ["mg-kpi-definitions", "mg-gap-bridge", "mg-deferment-reason-codes", "mg-target-forecast-governance", "mg-budget-eac-etc",
                                         "mg-opportunity-register", "mg-risk-adjusted-value"],
    "AI without the hype": ["ai-baselines-first", "ai-gradient-boosting", "ai-survival", "ai-changepoint", "ai-anomaly-detection", "ai-pca-t2-spe", "ai-explainability",
                           "ai-conformal", "ai-validation-protocol", "ai-drift-governance", "ai-shadow-mode"],
    "Advanced AI - benchmark before you believe": ["ai-hybrid-residual", "ai-pinn", "ai-neural-operators", "ai-transformers-tft", "ai-gnn", "ai-foundation-ts", "ai-rag-agents",
                                                  "ai-rl-sandbox", "ai-bayes-opt"],
    "Governance & multi-asset": ["gov-moc", "gov-human-in-loop", "gov-roles-permissions", "gov-audit-trail", "gov-multi-asset-config", "gov-security", "ai-model-cards"],
}

ROADMAP = [
    ("V12", "Baseline audit", "ESP twin: physics, QC, PCA monitor, survival, optimisation; Streamlit upload philosophy", "implemented"),
    ("V13", "Architecture & data foundation", "Modular `dtp` package, asset config JSON, common data model, units/datum, QC, audit log, model registry", "implemented"),
    ("V14", "Managerial intelligence", "Actual vs target vs forecast, gap bridge, root causes, budget / EAC", "implemented"),
    ("V15", "Artificial lift", "ESP, SRP, gas-lift toolboxes + lift selection", "implemented"),
    ("V16", "Gas-condensate engineering", "PVT, deliverability, banking screen, network hydraulics, forecasting, optimisation", "implemented"),
    ("V17", "Frac & CCUS", "Frac lifecycle workflows; CO2 inventory, capture, transport, utilisation, storage, MRV", "implemented"),
    ("V18", "Advanced AI & multi-asset", "Hybrid, PINN, transformer, GNN, agent, benchmarks; configuration-based multi-asset", "implemented (research-grade, benchmark-gated)"),
]
PHASES = [(0, "Architecture & requirements", "docs/CONTRACT.md, config schema"), (1, "Common foundation", "ingest, QC, units, audit, registry"),
          (2, "Management MVP", "page 1"), (3, "First engineering vertical", "gas-condensate + network on Field data"), (4, "AI/ML layer", "forecast challengers, anomaly, uncertainty"),
          (5, "Artificial lift verticals", "ESP / SRP / gas lift"), (6, "Gas-condensate vertical", "page 3 / 3b"), (7, "Frac vertical", "page 4"),
          (8, "CCUS vertical", "page 5"), (9, "Advanced AI research", "page 6 (benchmark-gated)"), (10, "Scale & governance", "page 8, config per asset")]


def concept_graph():
    import networkx as nx
    G = nx.Graph()
    ids = {t["id"] for t in load_all_topics()}
    for t in load_all_topics():
        G.add_node(t["id"], title=t["title"], domain=t["domain"])
        for r in t["related"]:
            if r in ids:
                G.add_edge(t["id"], r)
    return G


def validate() -> list:
    errs, ts = [], load_all_topics()
    ids = {t["id"] for t in ts}
    for t in ts:
        for k in REQUIRED_TEXT:
            if not str(t.get(k, "")).strip():
                errs.append(f"{t.get('id')}: empty {k}")
        for k in REQUIRED_LIST:
            if not t.get(k):
                errs.append(f"{t['id']}: empty {k}")
        if t["level"] not in LEVELS:
            errs.append(f"{t['id']}: bad level")
        if t["domain"] in TECHNICAL and not t.get("key_equations") and t["level"] != "basics" and not t["id"].startswith(("ai-rag", "ai-rl", "ai-drift", "ai-shadow", "ai-model", "ai-valid", "ai-baselines")):
            errs.append(f"{t['id']}: technical topic without equations")
        for r in t["related"]:
            if r not in ids:
                errs.append(f"{t['id']}: unknown related '{r}'")
    for p, lst in LEARNING_PATHS.items():
        for i in lst:
            if i not in ids and any(t["id"].startswith(i.split("-")[0] + "-") for t in ts) and i.split("-")[0] in {"data", "gc", "net", "fc", "mg", "ai", "gov"}:
                errs.append(f"path '{p}': unknown topic {i}")
    return errs


def selftest() -> dict:
    ts = load_all_topics()
    assert len(ts) >= 70, len(ts)
    errs = validate()
    assert not errs, errs[:10]
    hits = search("liquid loading critical rate")
    assert hits and any("loading" in h["title"].lower() for h in hits[:3]), [h["id"] for h in hits[:3]]
    assert any("deliverab" in h["title"].lower() or "back" in h["title"].lower() for h in search("back-pressure exponent n")[:5])
    from . import calculators as C
    C.selftest()
    from collections import Counter
    return dict(n=len(ts), by_domain=dict(Counter(t["domain"] for t in ts)))
