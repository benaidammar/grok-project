"""Asset configuration: one JSON file describes a field. A second field = a second JSON, no code change.
Every default is an ASSUMPTION until the user edits it; modules report which assumptions they used."""
from __future__ import annotations
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

import pandas as pd

WORKSPACE = Path(__file__).resolve().parents[2] / "workspace"


@dataclass
class AssetConfig:
    asset_name: str = "My field"
    country: str = ""
    currency: str = "USD"
    # standard conditions for volumes (Sm3 = 15 C, 1.01325 bar unless changed)
    t_std_c: float = 15.0
    p_std_bar: float = 1.01325
    # fluid
    gas_sg: float = 0.70                 # gas gravity (air = 1)  - ASSUMPTION until edited
    co2_pct: float = 2.0                 # mol % CO2 in produced gas
    h2s_ppm: float = 0.0
    n2_pct: float = 0.0
    cond_density_kgm3: float = 765.0     # stock-tank condensate density
    cond_api: float = 0.0                # if >0 overrides density
    water_sg: float = 1.05
    # reservoir (field level default; per-well values in well_table override)
    t_res_c: float = 110.0
    p_res_init_bara: float = 350.0
    p_res_now_bara: float = 250.0
    datum_tvd_m: float = 3300.0
    tubing_id_in: float = 4.0
    # economics (all editable)
    gas_price_usd_per_ksm3: float = 120.0
    cond_price_usd_per_m3: float = 520.0
    carbon_price_usd_per_t: float = 50.0
    discount_rate: float = 0.10
    # unit choices per dataset: {"well_tests": {...UnitChoice...}}
    units: dict = field(default_factory=dict)
    # per well overrides: {"Field52": {"tvd_m":..,"lift":"flowing","tubing_id_in":..,"p_res_bara":..}}
    wells: dict = field(default_factory=dict)
    user_set: list = field(default_factory=list)       # keys the user edited (the rest are assumptions)
    notes: str = ""

    def mark(self, *keys):
        for k in keys:
            if k not in self.user_set:
                self.user_set.append(k)

    def assumed(self, *keys) -> list:
        """Subset of `keys` still on default values (to be reported by the modules)."""
        return [k for k in keys if k not in self.user_set]

    def well(self, name: str, key: str, default=None):
        w = self.wells.get(name, {})
        if key in w and w[key] is not None:
            return w[key]
        fallback = {"tvd_m": self.datum_tvd_m, "tubing_id_in": self.tubing_id_in, "p_res_bara": self.p_res_now_bara,
                    "t_res_c": self.t_res_c, "lift": "flowing"}
        return fallback.get(key, default)

    def cond_density(self) -> float:
        return 141.5 / (self.cond_api + 131.5) * 1000.0 if self.cond_api > 0 else self.cond_density_kgm3

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)

    def save(self, name: str | None = None) -> Path:
        WORKSPACE.mkdir(exist_ok=True)
        p = WORKSPACE / f"{name or self.asset_name.replace(' ', '_')}_config.json"
        p.write_text(self.to_json(), encoding="utf-8")
        return p

    @classmethod
    def from_json(cls, text: str) -> "AssetConfig":
        d = json.loads(text)
        ok = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        return cls(**ok)

    @classmethod
    def load(cls, path) -> "AssetConfig":
        return cls.from_json(Path(path).read_text(encoding="utf-8"))

    def well_table(self, wells: list) -> pd.DataFrame:
        rows = []
        for w in wells:
            rows.append(dict(well=w, lift=self.well(w, "lift"), tvd_m=self.well(w, "tvd_m"), tubing_id_in=self.well(w, "tubing_id_in"),
                             p_res_bara=self.well(w, "p_res_bara"), t_res_c=self.well(w, "t_res_c")))
        return pd.DataFrame(rows)


Field_EXAMPLE = AssetConfig(asset_name="Field cluster (example)", country="Algeria", gas_sg=0.70, co2_pct=2.0)
