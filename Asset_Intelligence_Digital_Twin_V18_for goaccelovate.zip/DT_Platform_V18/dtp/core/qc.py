"""Data-quality engine. Each check returns rows of an issues table:
severity (error/warning/info), dataset, where, rule, message, action.  Nothing is fixed silently."""
from __future__ import annotations
import math

import numpy as np
import pandas as pd

COLS = ["severity", "dataset", "where", "rule", "message", "action"]


def _issue(sev, ds, where, rule, msg, action=""):
    return dict(severity=sev, dataset=ds, where=where, rule=rule, message=msg, action=action)


def robust_z(x: pd.Series) -> pd.Series:
    med = x.median()
    mad = (x - med).abs().median()
    return (x - med) / (1.4826 * mad) if mad > 0 else x * 0.0


def qc_well_tests(w: pd.DataFrame) -> pd.DataFrame:
    """w = canonical well_tests frame (schema.normalize_well_tests)."""
    I = []
    ds = "well_tests"
    if w.empty:
        return pd.DataFrame([_issue("error", ds, "-", "empty", "No rows after parsing", "Check column mapping and date format")], columns=COLS)
    dup = w.duplicated(["well", "date", "whp_bara", "gas_sm3d"], keep="first")
    if dup.any():
        I.append(_issue("warning", ds, f"{int(dup.sum())} rows", "duplicate", "Exact duplicate test rows", "Remove duplicates"))
    neg = (w[["gas_sm3d", "cond_m3d", "water_m3d"]] < 0).any(axis=1)
    if neg.any():
        I.append(_issue("error", ds, f"{int(neg.sum())} rows", "negative_rate", "Negative rate", "Fix or delete"))
    if (w["whp_bara"] < 1).any():
        I.append(_issue("warning", ds, f"{int((w['whp_bara'] < 1).sum())} rows", "whp_low", "WHP < 1 bara: wrong unit or gauge/absolute choice?", "Check units in the sidebar"))
    if (w["whp_bara"] > 1000).any():
        I.append(_issue("error", ds, "WHP", "whp_high", "WHP > 1000 bara: unit probably psi, not bar", "Change pressure unit"))
    miss = w[["whp_bara", "gas_sm3d"]].isna().mean()
    for c, f in miss.items():
        if f > 0:
            I.append(_issue("warning" if f < 0.2 else "error", ds, c, "missing", f"{f:.0%} missing", "Rows with missing values are excluded from fits"))
    for well, g in w.groupby("well"):
        for col, label in (("cgr_m3_mmsm3", "CGR"), ("gas_sm3d", "gas rate")):
            s = g[col].replace([np.inf, -np.inf], np.nan).dropna()
            if len(s) >= 8:
                z = robust_z(np.log10(s.clip(lower=1e-6)) if col == "cgr_m3_mmsm3" else s)
                bad = z.abs() > 6
                if bad.any():
                    I.append(_issue("info", ds, f"{well}: {int(bad.sum())} pts", "outlier", f"{label} outlier(s) vs the well's own history (robust z>6)", "Review test; kept in data"))
        s = g.sort_values("date")
        if s["date"].is_monotonic_increasing is False:
            I.append(_issue("warning", ds, well, "date_order", "Dates not monotonic", "Sorted automatically"))
        gap = s["date"].diff().dt.days.max()
        if pd.notna(gap) and gap > 365 * 4:
            I.append(_issue("info", ds, well, "long_gap", f"Longest gap between tests {gap/365.25:.1f} years", "Forecasts across the gap are uncertain"))
    if (w["water_m3d"].fillna(0) == 0).mean() > 0.2 and w["water_m3d"].notna().any():
        I.append(_issue("info", ds, "water_m3d", "zero_water", f"{(w['water_m3d'].fillna(0) == 0).mean():.0%} of tests have water = 0 (or TRACES); late-life zeros look like 'not measured'", "Confirm whether zero = no water or no measurement"))
    if w["well"].str.len().min() == 0:
        I.append(_issue("error", ds, "well", "blank_well", "Blank well name", "Fix"))
    n_multi = int((w["n_pts_day"] > 1).groupby([w["well"], w["date"]]).first().sum()) if "n_pts_day" in w else 0
    if n_multi:
        I.append(_issue("info", ds, f"{n_multi} well-days", "multi_rate", "Several rates on one day = multi-rate (back-pressure) tests: used for deliverability analysis", ""))
    return pd.DataFrame(I, columns=COLS)


def qc_network(nodes: pd.DataFrame, tol: float = 1.0) -> pd.DataFrame:
    """nodes = canonical network frame (schema.normalize_network). Checks topology and geometry."""
    I = []
    ds = "network"
    names = set(nodes["site"])
    idx = nodes.set_index("site")
    for _, r in nodes.iterrows():
        if r["identity"] != "facility" and r["to_node"] not in names:
            I.append(_issue("error", ds, r["site"], "dangling", f"Downstream node '{r['to_node']}' does not exist", "Fix to_node"))
        if r["identity"] != "facility" and not np.isfinite(r["diameter_in"]):
            I.append(_issue("error", ds, r["site"], "no_diameter", "Missing diameter", "Enter diameter"))
        if r["identity"] != "facility" and not np.isfinite(r["length_m"]):
            I.append(_issue("error", ds, r["site"], "no_length", "Missing length", "Enter length"))
        if not (np.isfinite(r["x"]) and np.isfinite(r["y"])):
            I.append(_issue("warning", ds, r["site"], "no_coord", "No usable coordinates", "Straight-line length check skipped"))
    # topology: every node must reach a facility without cycles
    for s in nodes["site"]:
        seen, cur = set(), s
        while cur in idx.index and idx.loc[cur, "identity"] != "facility":
            if cur in seen:
                I.append(_issue("error", ds, s, "cycle", "Loop in network", "Fix to_node"))
                break
            seen.add(cur)
            cur = idx.loc[cur, "to_node"]
        else:
            if cur not in idx.index:
                I.append(_issue("error", ds, s, "unreachable", "Does not reach a facility", "Check to_node chain"))
    # geometry: a pipe cannot be shorter than the straight line between its end points
    for _, r in nodes.iterrows():
        if r["identity"] == "facility" or r["to_node"] not in idx.index:
            continue
        d = idx.loc[r["to_node"]]
        if all(np.isfinite([r["x"], r["y"], d["x"], d["y"], r["length_m"]])):
            sl = math.hypot(r["x"] - d["x"], r["y"] - d["y"])
            ratio = r["length_m"] / sl if sl > 0 else np.nan
            if ratio < 1 - tol * 0.05:
                I.append(_issue("error", ds, r["site"], "length_lt_straight", f"Stated length {r['length_m']:.0f} m is SHORTER than the straight line to '{r['to_node']}' ({sl:.0f} m)",
                                "Impossible: confirm length or coordinates before using hydraulics"))
            elif ratio > 3:
                I.append(_issue("warning", ds, r["site"], "length_gt_3x", f"Stated length {r['length_m']:.0f} m is {ratio:.1f}x the straight line ({sl:.0f} m)",
                                "Check for a typo or a very tortuous route"))
        # elevation
    if nodes["elevation_m"].isna().all():
        I.append(_issue("info", ds, "elevation", "no_elev", "No elevations: pipes treated as horizontal", ""))
    return pd.DataFrame(I, columns=COLS)


def qc_summary(issues: pd.DataFrame) -> dict:
    if issues.empty:
        return {"error": 0, "warning": 0, "info": 0}
    return issues["severity"].value_counts().reindex(["error", "warning", "info"]).fillna(0).astype(int).to_dict()
