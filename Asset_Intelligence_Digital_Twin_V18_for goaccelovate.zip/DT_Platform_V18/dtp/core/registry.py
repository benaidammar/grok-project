"""Audit trail + model registry (JSON-lines in ./workspace). Governance layer of the handbook:
every run is logged with data hash, parameters, status; models get version + approval state."""
from __future__ import annotations
import hashlib
import json
import time
from pathlib import Path

import pandas as pd

from .config import WORKSPACE

LOG = WORKSPACE / "audit_log.jsonl"
REG = WORKSPACE / "model_registry.json"


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def df_hash(df) -> str:
    try:
        return hashlib.sha1(pd.util.hash_pandas_object(df, index=True).values.tobytes()).hexdigest()[:12]
    except Exception:           # noqa: BLE001
        return "n/a"


def log_event(module: str, action: str, status: str = "OK", **details):
    try:
        WORKSPACE.mkdir(exist_ok=True)
        rec = dict(ts=_now(), module=module, action=action, status=status, **{k: _jsonable(v) for k, v in details.items()})
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
    except Exception:           # noqa: BLE001  (logging must never break an analysis)
        pass


def _jsonable(v):
    try:
        json.dumps(v)
        return v
    except TypeError:
        return str(v)


def read_log(n: int = 500) -> pd.DataFrame:
    if not LOG.exists():
        return pd.DataFrame(columns=["ts", "module", "action", "status"])
    rows = [json.loads(l) for l in LOG.read_text(encoding="utf-8").splitlines()[-n:] if l.strip()]
    return pd.DataFrame(rows).iloc[::-1].reset_index(drop=True)


def _load() -> dict:
    if REG.exists():
        try:
            return json.loads(REG.read_text(encoding="utf-8"))
        except Exception:       # noqa: BLE001
            return {}
    return {}


def register_model(model_id: str, purpose: str, data_window: str, features: list, metrics: dict, limitations: str = "", status: str = "UNVALIDATED") -> dict:
    """Model card. Version auto-increments; approval stays 'pending' until a human approves it."""
    reg = _load()
    ver = len(reg.get(model_id, [])) + 1
    card = dict(model_id=model_id, version=ver, created=_now(), purpose=purpose, data_window=data_window, features=features,
                metrics={k: (round(v, 5) if isinstance(v, float) else v) for k, v in metrics.items()}, limitations=limitations, status=status,
                approval="pending", approved_by=None)
    reg.setdefault(model_id, []).append(card)
    try:
        WORKSPACE.mkdir(exist_ok=True)
        REG.write_text(json.dumps(reg, indent=1), encoding="utf-8")
    except Exception:           # noqa: BLE001
        pass
    log_event("registry", "register_model", model=model_id, version=ver)
    return card


def list_models() -> pd.DataFrame:
    rows = [c for cards in _load().values() for c in cards]
    return pd.DataFrame(rows) if rows else pd.DataFrame(columns=["model_id", "version", "created", "status", "approval"])


def approve_model(model_id: str, version: int, by: str):
    reg = _load()
    for c in reg.get(model_id, []):
        if c["version"] == version:
            c["approval"], c["approved_by"] = "approved", by
    REG.write_text(json.dumps(reg, indent=1), encoding="utf-8")
    log_event("registry", "approve_model", model=model_id, version=version, by=by)
