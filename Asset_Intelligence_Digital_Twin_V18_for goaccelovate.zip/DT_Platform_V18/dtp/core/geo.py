"""Coordinates: DMS / decimal / UTM. Pure python (pyproj used only if present as a cross-check)."""
from __future__ import annotations
import math
import re

_A, _F = 6378137.0, 1 / 298.257223563      # WGS84
_K0 = 0.9996


def parse_dms(s) -> float | None:
    """'29°35'32.17"N' -> 29.5922. Works when the degree sign is corrupted (Latin-1 / UTF-8 mix-ups)."""
    if s is None:
        return None
    if isinstance(s, (int, float)):
        return float(s)
    t = str(s).strip().replace(",", ".")
    nums = re.findall(r"\d+(?:\.\d+)?", t)
    if not nums:
        return None
    v = [float(n) for n in nums[:3]] + [0.0] * (3 - len(nums[:3]))
    deg = v[0] + v[1] / 60.0 + v[2] / 3600.0
    if re.search(r"[SsWw]", t):
        deg = -deg
    return deg


def dms_axis(s) -> str | None:
    """'lat' if the text carries N/S, 'lon' if it carries E/W, else None."""
    t = str(s).upper()
    if re.search(r"\d\s*[\"'\u2033]?\s*[NS]\b", t):
        return "lat"
    if re.search(r"\d\s*[\"'\u2033]?\s*[EW]\b", t):
        return "lon"
    return None


def looks_dms(s) -> bool:
    t = str(s)
    return bool(re.search(r"\d+\D+\d+\D+\d+(?:[.,]\d+)?\D*[NSEWnsew]?", t)) and not re.fullmatch(r"\s*-?\d+(?:[.,]\d+)?\s*", t)


def utm_zone(lon: float) -> int:
    return int((lon + 180) // 6) + 1


def latlon_to_utm(lat: float, lon: float, zone: int | None = None) -> tuple[float, float, int]:
    """WGS84 lat/lon (deg) -> UTM easting, northing (north-hemisphere formulation extended for south), zone."""
    zone = zone or utm_zone(lon)
    lon0 = math.radians((zone - 1) * 6 - 180 + 3)
    phi, lam = math.radians(lat), math.radians(lon)
    n = _F / (2 - _F)
    A = _A / (1 + n) * (1 + n ** 2 / 4 + n ** 4 / 64)
    a = [n / 2 - 2 * n ** 2 / 3 + 5 * n ** 3 / 16, 13 * n ** 2 / 48 - 3 * n ** 3 / 5, 61 * n ** 3 / 240]
    t = math.sinh(math.atanh(math.sin(phi)) - (2 * math.sqrt(n) / (1 + n)) *
                  math.atanh(2 * math.sqrt(n) / (1 + n) * math.sin(phi)))
    xi = math.atan2(t, math.cos(lam - lon0))
    eta = math.atanh(math.sin(lam - lon0) / math.sqrt(1 + t * t))
    E = 500000.0 + _K0 * A * (eta + sum(a[j] * math.cos(2 * (j + 1) * xi) * math.sinh(2 * (j + 1) * eta) for j in range(3)))
    N = _K0 * A * (xi + sum(a[j] * math.sin(2 * (j + 1) * xi) * math.cosh(2 * (j + 1) * eta) for j in range(3)))
    if lat < 0:
        N += 10000000.0
    return E, N, zone


def dist(p, q) -> float:
    return math.hypot(p[0] - q[0], p[1] - q[1])


def infer_zone_for(lon: float, utm_points: list[tuple[float, float]], lat: float) -> int:
    """Pick the zone (neighbours of the natural one) that puts (lat,lon) closest to the given UTM cloud."""
    base = utm_zone(lon)
    best, bd = base, 1e18
    cx = sum(p[0] for p in utm_points) / len(utm_points)
    cy = sum(p[1] for p in utm_points) / len(utm_points)
    for z in (base - 1, base, base + 1):
        e, n, _ = latlon_to_utm(lat, lon, z)
        d = math.hypot(e - cx, n - cy)
        if d < bd:
            best, bd = z, d
    return best
