"""Optional dependencies: the platform runs on numpy/pandas/scipy/sklearn/plotly/streamlit.
Everything else is optional and every feature that needs it has a built-in fallback."""
from __future__ import annotations
import importlib
import importlib.util
import subprocess
import sys

CORE = {"numpy": "numpy", "pandas": "pandas", "scipy": "scipy", "sklearn": "scikit-learn",
        "plotly": "plotly", "streamlit": "streamlit", "openpyxl": "openpyxl", "networkx": "networkx"}
OPTIONAL = {"lifelines": "lifelines", "optuna": "optuna", "ruptures": "ruptures", "torch": "torch",
            "xgboost": "xgboost", "lightgbm": "lightgbm", "shap": "shap", "pyproj": "pyproj",
            "statsmodels": "statsmodels", "CoolProp": "CoolProp"}


def has(mod: str) -> bool:
    return importlib.util.find_spec(mod) is not None


def try_import(mod: str):
    try:
        return importlib.import_module(mod)
    except Exception:          # noqa: BLE001
        return None


def ensure_packages(include_optional: bool = False):
    want = dict(CORE)
    if include_optional:
        want.update({k: v for k, v in OPTIONAL.items() if k != "torch"})
    missing = [pip for mod, pip in want.items() if not has(mod)]
    if not missing:
        return
    print("Installing missing packages:", ", ".join(missing), "- first run only, needs internet...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", *missing])
    except Exception as exc:                                   # noqa: BLE001
        raise SystemExit(f"\nAutomatic install failed ({exc}).\nRun:\n  py -m pip install {' '.join(missing)}") from exc
    importlib.invalidate_caches()


def availability() -> dict:
    return {m: has(m) for m in list(CORE) + list(OPTIONAL)}
