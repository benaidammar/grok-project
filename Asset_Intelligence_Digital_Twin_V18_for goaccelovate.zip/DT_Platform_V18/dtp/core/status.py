"""Visible status for every result: a failed or unvalidated model must say so (handbook rule)."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Status(str, Enum):
    OK = "OK"                    # calculation ran, inputs complete, checks passed
    WARN = "WARN"                # ran, but with assumptions / data issues the user must read
    FAIL = "FAIL"                # could not run or result not credible - do not use the numbers
    UNVALIDATED = "UNVALIDATED"  # ran, but model not benchmarked against field data


ICON = {Status.OK: "🟢", Status.WARN: "🟠", Status.FAIL: "🔴", Status.UNVALIDATED: "🟡"}


@dataclass
class Result:
    """Standard return object of every engineering / AI routine.

    value      - main payload (DataFrame, dict, float ... module specific)
    status     - Status
    messages   - human readable notes (assumptions used, data problems, fail reason)
    assumptions- inputs that came from defaults, not from the user's data
    meta       - provenance: model name/version, parameters, row counts ...
    """
    name: str
    value: Any = None
    status: Status = Status.OK
    messages: list = field(default_factory=list)
    assumptions: list = field(default_factory=list)
    meta: dict = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.status in (Status.OK, Status.WARN, Status.UNVALIDATED) and self.value is not None

    def warn(self, msg: str):
        self.messages.append(msg)
        if self.status == Status.OK:
            self.status = Status.WARN
        return self

    def fail(self, msg: str):
        self.messages.append(msg)
        self.status = Status.FAIL
        return self

    def badge(self) -> str:
        return f"{ICON[self.status]} {self.status.value}"


def failed(name: str, msg: str, **meta) -> Result:
    return Result(name=name, value=None, status=Status.FAIL, messages=[msg], meta=meta)
