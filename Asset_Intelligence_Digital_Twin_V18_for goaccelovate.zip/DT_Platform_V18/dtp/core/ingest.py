"""Robust file reading: CSV/TXT/Excel, any encoding, ';' or ',' separators, decimal commas,
placeholders ('/', 'TRACES', '<'), day-first dates. Returns a DataFrame and a ReadReport."""
from __future__ import annotations
import io
import re
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

NA_TOKENS = {"", "/", "-", "--", "n/a", "na", "nan", "null", "none", "#n/a", "#value!", "?", "<", ">", "nd", "n.d."}
TRACE_TOKENS = {"trace", "traces", "tr", "tr."}


@dataclass
class ReadReport:
    name: str = ""
    encoding: str = ""
    sep: str = ""
    n_rows: int = 0
    n_cols: int = 0
    numeric_cols: list = field(default_factory=list)
    date_cols: list = field(default_factory=list)
    notes: list = field(default_factory=list)


def _get_bytes(source) -> tuple[bytes, str]:
    if isinstance(source, (str, Path)):
        p = Path(source)
        return p.read_bytes(), p.name
    if isinstance(source, (bytes, bytearray)):
        return bytes(source), "bytes"
    name = getattr(source, "name", "upload")
    if hasattr(source, "getvalue"):
        return source.getvalue(), name
    return source.read(), name


def decode_bytes(raw: bytes) -> tuple[str, str]:
    for enc in ("utf-8-sig", "utf-8"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            pass
    for enc in ("cp1252", "latin-1"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            pass
    return raw.decode("latin-1", errors="replace"), "latin-1"


def detect_sep(text: str) -> str:
    lines = [l for l in text.splitlines()[:8] if l.strip()]
    if not lines:
        return ","
    best, score = ",", -1
    for sep in (";", "\t", "|", ","):
        counts = [l.count(sep) for l in lines]
        if counts[0] == 0:
            continue
        consistent = sum(c == counts[0] for c in counts)
        s = counts[0] * 10 + consistent
        if sep == ",":                       # a comma is often a decimal comma: penalise
            s -= 5
        if s > score:
            best, score = sep, s
    return best


def parse_number(v) -> tuple[float, str]:
    """-> (value, flag). flag in {'', 'na', 'trace', 'censored', 'bad'}."""
    if v is None:
        return np.nan, "na"
    if isinstance(v, (int, float, np.integer, np.floating)):
        return (float(v), "") if np.isfinite(v) else (np.nan, "na")
    s = str(v).strip().replace(" ", "").replace(" ", "")
    low = s.lower()
    if low in NA_TOKENS:
        return np.nan, "na"
    if low in TRACE_TOKENS:
        return 0.0, "trace"
    if s[:1] in "<>" and len(s) > 1:
        return np.nan, "censored"
    if re.search(r"\d\s*['\u2032\u2019]\s*\d", s):          # degrees-minutes-seconds text, not a number
        return np.nan, "bad"
    s = re.sub(r"[^\d,.\-+eE]", "", s)
    if not s:
        return np.nan, "bad"
    if "," in s and "." in s:
        s = s.replace(",", "") if s.rfind(".") > s.rfind(",") else s.replace(".", "").replace(",", ".")
    elif s.count(",") == 1:
        s = s.replace(",", ".")
    elif s.count(",") > 1:
        s = s.replace(",", "")
    try:
        return float(s), ""
    except ValueError:
        return np.nan, "bad"


_DATE_FORMATS = ["%d/%m/%Y", "%d/%m/%Y %H:%M", "%d/%m/%Y %H:%M:%S", "%Y-%m-%d", "%Y-%m-%d %H:%M",
                 "%Y-%m-%d %H:%M:%S", "%d-%m-%Y", "%d.%m.%Y", "%m/%d/%Y", "%Y/%m/%d", "%d/%m/%y", "%b-%y", "%b %Y"]


def parse_dates(s: pd.Series, dayfirst: bool = True) -> tuple[pd.Series, float]:
    """-> (datetime series, parsed fraction)."""
    x = s.astype(str).str.strip()
    x = x.where(~x.str.lower().isin(NA_TOKENS), None)
    best, bf = None, 0.0
    fmts = list(_DATE_FORMATS)
    if not dayfirst:
        fmts = ["%m/%d/%Y"] + [f for f in fmts if f != "%m/%d/%Y"]
    for f in fmts:
        d = pd.to_datetime(x, format=f, errors="coerce")
        frac = d.notna().sum() / max(x.notna().sum(), 1)
        if frac > bf:
            best, bf = d, frac
        if frac > 0.98:
            break
    if bf < 0.9:
        d = pd.to_datetime(x, errors="coerce", dayfirst=dayfirst)
        frac = d.notna().sum() / max(x.notna().sum(), 1)
        if frac > bf:
            best, bf = d, frac
    return best, bf


def coerce_frame(df: pd.DataFrame, dayfirst: bool = True, rep: ReadReport | None = None) -> pd.DataFrame:
    """Convert text columns to numbers / dates where the data clearly supports it."""
    rep = rep or ReadReport()
    out = df.copy()
    for c in out.columns:
        col = out[c]
        if pd.api.types.is_numeric_dtype(col) or pd.api.types.is_datetime64_any_dtype(col):
            continue
        sv = col.astype(str).str.strip()
        nonblank = sv[~sv.str.lower().isin(NA_TOKENS)]
        if nonblank.empty:
            continue
        looks_date = nonblank.str.contains(r"^\d{1,4}[/\-.]\d{1,2}[/\-.]\d{1,4}", regex=True).mean() > 0.8
        if looks_date:
            d, frac = parse_dates(col, dayfirst)
            if frac > 0.9:
                out[c] = d
                rep.date_cols.append(c)
                if frac < 1:
                    rep.notes.append(f"{c}: {int((1 - frac) * len(nonblank))} unparseable dates set to NaT")
                continue
        parsed = [parse_number(v) for v in col]
        vals = np.array([p[0] for p in parsed])
        flags = [p[1] for p in parsed]
        ok = np.isfinite(vals).sum()
        n_bad = flags.count("bad")
        if n_bad and ok > 0:
            rep.notes.append(f"{c}: {n_bad} value(s) are not plain numbers (e.g. degrees-minutes-seconds): column kept as text")
            continue
        if n_bad:
            continue
        if ok >= 0.7 * len(nonblank) and not looks_date:
            out[c] = vals
            rep.numeric_cols.append(c)
            nt, nc = flags.count("trace"), flags.count("censored")
            if nt:
                rep.notes.append(f"{c}: {nt} 'TRACES' value(s) read as 0")
            if nc:
                rep.notes.append(f"{c}: {nc} censored value(s) such as '<5' set to NaN")
    return out


def read_table(source, sheet=None, sep: str = "auto", dayfirst: bool = True, name: str | None = None
               ) -> tuple[pd.DataFrame, ReadReport]:
    raw, nm = _get_bytes(source)
    rep = ReadReport(name=name or nm)
    if nm.lower().endswith((".xlsx", ".xlsm", ".xls")):
        df = pd.read_excel(io.BytesIO(raw), sheet_name=sheet or 0, dtype=object)
        rep.encoding, rep.sep = "excel", ""
        df = df.astype(object).where(df.notna(), None)
        df = df.map(lambda v: v if v is None or not isinstance(v, str) else v.strip()) if hasattr(df, "map") else df
    else:
        text, enc = decode_bytes(raw)
        rep.encoding = enc
        rep.sep = detect_sep(text) if sep == "auto" else {"tab": "\t"}.get(sep, sep)
        df = pd.read_csv(io.StringIO(text), sep=rep.sep, dtype=str, keep_default_na=False, skipinitialspace=True,
                         engine="python", on_bad_lines="skip")
    df.columns = [str(c).strip().replace("﻿", "") for c in df.columns]
    df = df.dropna(how="all")
    df = df.loc[~(df.astype(str).apply(lambda r: r.str.strip().eq("").all(), axis=1))].reset_index(drop=True)
    df = coerce_frame(df, dayfirst=dayfirst, rep=rep)
    rep.n_rows, rep.n_cols = df.shape
    return df, rep


def sniff_sheets(source) -> list[str]:
    raw, nm = _get_bytes(source)
    if nm.lower().endswith((".xlsx", ".xlsm", ".xls")):
        return pd.ExcelFile(io.BytesIO(raw)).sheet_names
    return []
