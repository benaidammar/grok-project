"""Unit conversion. Canonical internal units (every module works in these):

  pressure  bara            temperature  degC            length  m          diameter  m
  gas rate  Sm3/d (15C, 1.01325 bar)     liquid rate  m3/d      time  pandas Timestamp
  CO2       mol fraction (0-1) internally; UI shows %.      money  user currency

Pressure datum (gauge / absolute) is always explicit - never inferred silently (handbook rule).
"""
from __future__ import annotations
import numpy as np

ATM_BAR = 1.01325

# factor to bar
_P = {"bar": 1.0, "psi": 0.0689475729, "kpa": 0.01, "mpa": 10.0, "pa": 1e-5,
      "kgf/cm2": 0.980665, "atm": 1.01325, "psig": 0.0689475729, "psia": 0.0689475729,
      "barg": 1.0, "bara": 1.0}
PRESSURE_UNITS = ["psi", "bar", "kPa", "MPa", "kgf/cm2", "atm"]

# factor to Sm3/d
_GAS = {"sm3/d": 1.0, "1000 sm3/d": 1e3, "ksm3/d": 1e3, "msm3/d": 1e6, "mmsm3/d": 1e6,
        "mscf/d": 28.3168, "mmscf/d": 28316.8, "scf/d": 0.0283168, "bcf/d": 28.3168e6}
GAS_UNITS = ["Sm3/d", "1000 Sm3/d", "MMSm3/d", "Mscf/d", "MMscf/d"]

# factor to m3/d
_LIQ = {"m3/d": 1.0, "sm3/d": 1.0, "bbl/d": 0.158987, "stb/d": 0.158987, "bpd": 0.158987, "l/d": 1e-3}
LIQ_UNITS = ["m3/d", "bbl/d"]

_LEN = {"m": 1.0, "ft": 0.3048, "km": 1000.0, "in": 0.0254, "inch": 0.0254, "mm": 1e-3, "cm": 0.01, "mile": 1609.344}
SALINITY_UNITS = ["mg/L", "g/L", "ppm", "kppm"]
_SAL = {"mg/l": 1.0, "g/l": 1000.0, "ppm": 1.0, "kppm": 1000.0}      # to mg/L (ppm ~ mg/L, flagged as approximation)


def p_to_bara(x, unit: str = "psi", datum: str = "gauge"):
    """Pressure -> bara. datum: 'gauge' adds one atmosphere, 'absolute' does not.
    'psig'/'barg' force gauge, 'psia'/'bara' force absolute."""
    u = unit.lower()
    f = _P[u]
    if u in ("psig", "barg"):
        datum = "gauge"
    elif u in ("psia", "bara"):
        datum = "absolute"
    x = np.asarray(x, dtype=float) if not np.isscalar(x) else float(x)
    out = x * f
    return out + ATM_BAR if datum == "gauge" else out


def bara_to(x, unit: str = "psi", datum: str = "gauge"):
    u = unit.lower()
    f = _P[u]
    x = np.asarray(x, dtype=float) if not np.isscalar(x) else float(x)
    y = x - ATM_BAR if datum == "gauge" and u not in ("psia", "bara") else x
    return y / f


def gas_to_sm3d(x, unit="Sm3/d"):
    return (np.asarray(x, dtype=float) if not np.isscalar(x) else float(x)) * _GAS[unit.lower()]


def sm3d_to(x, unit="MMSm3/d"):
    return (np.asarray(x, dtype=float) if not np.isscalar(x) else float(x)) / _GAS[unit.lower()]


def liq_to_m3d(x, unit="m3/d"):
    return (np.asarray(x, dtype=float) if not np.isscalar(x) else float(x)) * _LIQ[unit.lower()]


def len_to_m(x, unit="m"):
    return (np.asarray(x, dtype=float) if not np.isscalar(x) else float(x)) * _LEN[unit.lower()]


def sal_to_mgl(x, unit="mg/L"):
    return (np.asarray(x, dtype=float) if not np.isscalar(x) else float(x)) * _SAL[unit.lower()]


def c_to_k(t):
    return np.asarray(t, dtype=float) + 273.15 if not np.isscalar(t) else float(t) + 273.15


def f_to_c(t):
    return (np.asarray(t, dtype=float) - 32.0) / 1.8 if not np.isscalar(t) else (float(t) - 32.0) / 1.8


def bbl_per_m3():
    return 6.28981


def sm3_to_scf(x):
    return x / 0.0283168


# --- CO2 mass conversion ------------------------------------------------------
def co2_density_std(t_c: float = 15.0, p_bar: float = ATM_BAR) -> float:
    """kg/Sm3 of CO2 at the standard condition (ideal-gas with a small real-gas correction, Z~0.994 at 15C)."""
    z = 0.994 if t_c <= 20 else 0.995
    return 44.01e-3 * p_bar * 1e5 / (z * 8.314462 * (t_c + 273.15))


def guess_pressure_unit(values) -> tuple[str, str]:
    """Heuristic only - returned with a reason so the user can confirm. (unit, reason)"""
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v)]
    if v.size == 0:
        return "bar", "no numeric values"
    med = float(np.median(v))
    if med > 600:
        return "psi", f"median {med:,.0f}: too high for bar in a gas well, typical of psi"
    if med > 60:
        return "bar", f"median {med:,.0f}: typical of bar (could also be kgf/cm2)"
    return "bar", f"median {med:,.1f}"


def guess_gas_unit(values) -> tuple[str, str]:
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v) & (v > 0)]
    if v.size == 0:
        return "Sm3/d", "no numeric values"
    med = float(np.median(v))
    if med > 5e4:
        return "Sm3/d", f"median {med:,.0f}: whole Sm3/d"
    if med > 50:
        return "1000 Sm3/d", f"median {med:,.0f}: probably thousands of Sm3/d (or Mscf/d)"
    return "MMSm3/d", f"median {med:,.2f}: probably millions of Sm3/d (or MMscf/d)"
