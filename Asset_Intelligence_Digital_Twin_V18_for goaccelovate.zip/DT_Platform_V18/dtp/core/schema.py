"""Common data model: dataset kinds, column synonyms (EN/FR), auto-detection and normalisation to
canonical columns and canonical units.  This is the contract every toolbox reads from."""
from __future__ import annotations
import re
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from . import units as U
from .geo import dms_axis, infer_zone_for, latlon_to_utm, looks_dms, parse_dms
from .ingest import parse_number


@dataclass
class Kind:
    key: str
    title: str
    required: list
    optional: list
    synonyms: dict            # canonical -> list of header fragments (lower case)
    description: str = ""


def _k(key, title, required, optional, syn, desc=""):
    return Kind(key, title, required, optional, syn, desc)


KINDS: dict[str, Kind] = {k.key: k for k in [
    _k("well_tests", "Well tests / rates", ["well", "date", "gas_rate"],
       ["whp", "cond_rate", "water_rate", "salinity", "oil_rate", "choke", "flp", "bhp", "co2_pct", "temp"],
       {"well": ["well", "puits", "site", "name", "uwi"], "date": ["date", "time", "stamp", "jour"],
        "whp": ["whp", "wellhead", "tubing_head", "thp", "pt_tete", "p_tete"], "gas_rate": ["gas_rate", "gas", "qg", "q_gas", "gaz"],
        "cond_rate": ["cond", "qc", "condensate", "condensat"], "water_rate": ["water", "eau", "qw", "wat"],
        "oil_rate": ["oil", "huile", "qo"], "salinity": ["salin", "cl_", "chlor", "tds"], "choke": ["choke", "duse", "beam"],
        "flp": ["flp", "flowline", "line_press"], "bhp": ["bhp", "bottomhole", "pwf"], "co2_pct": ["co2"], "temp": ["temp", "t_"]},
       "Multi-rate / periodic well tests: one row per test point."),
    _k("network", "Gathering network", ["site", "identity", "to_node"],
       ["x", "y", "elevation", "length_m", "diameter_inch", "roughness_mm", "wall_mm"],
       {"site": ["site", "node", "name", "from"], "identity": ["identity", "type", "kind", "nature"],
        "to_node": ["to_node", "to", "dest", "downstream", "vers"], "x": ["x_coord", "easting", "x", "lon"],
        "y": ["y_coord", "northing", "y", "lat"], "elevation": ["elev", "alt", "z"],
        "length_m": ["length", "long", "len"], "diameter_inch": ["diam", "dn", "id_in", "od"],
        "roughness_mm": ["rough", "rugos"], "wall_mm": ["wall", "epais"]},
       "Tree/graph of wells -> manifolds -> facility with coordinates, length, diameter."),
    _k("production_daily", "Daily / monthly production", ["date"], ["well", "oil", "gas", "cond", "water", "injection", "uptime_h", "choke"],
       {"date": ["date", "time", "month", "mois", "period"], "well": ["well", "puits", "asset", "field"], "oil": ["oil", "huile"],
        "gas": ["gas", "gaz"], "cond": ["cond"], "water": ["water", "eau"], "injection": ["inj"], "uptime_h": ["uptime", "hours", "heures", "on_stream"],
        "choke": ["choke"]}, "Allocated production history (actuals)."),
    _k("targets", "Targets / budget production plan", ["date"], ["target_oil", "target_gas", "target_cond", "target_water", "well"],
       {"date": ["date", "month", "period"], "target_oil": ["target_oil", "oil_target", "plan_oil"], "target_gas": ["target_gas", "gas_target", "plan_gas", "target"],
        "target_cond": ["target_cond", "cond_target"], "target_water": ["target_water"], "well": ["well", "asset"]}, "Approved production target / plan."),
    _k("downtime", "Downtime / deferment events", ["start", "end"], ["well", "planned", "reason", "lost_rate", "system"],
       {"start": ["start", "debut", "from"], "end": ["end", "fin", "to"], "well": ["well", "puits", "asset"],
        "planned": ["planned", "planifie"], "reason": ["reason", "cause", "motif", "code"], "lost_rate": ["lost", "deferred", "perte"],
        "system": ["system", "equip"]}, "Reason-coded downtime and deferment."),
    _k("budget", "Budget / cost", ["period", "category", "budget"], ["actual", "commitment", "forecast", "cost_centre", "type"],
       {"period": ["period", "month", "date", "mois"], "category": ["category", "categorie", "item", "wbs", "activity"], "budget": ["budget"],
        "actual": ["actual", "reel", "spent"], "commitment": ["commit", "engag"], "forecast": ["forecast", "etc", "eac"],
        "cost_centre": ["cost_centre", "cost_center", "cc", "centre"], "type": ["type", "capex", "opex"]}, "Finance extract: budget, actual, commitments."),
    _k("esp_ts", "ESP time series", ["time", "freq", "pintake", "pdisch", "tmotor", "current"], ["thp", "voltage", "vibration", "power"],
       {"time": ["time", "date", "stamp"], "freq": ["freq", "hz", "vsd"], "pintake": ["intake", "pip"], "pdisch": ["disch", "pdis"],
        "tmotor": ["motor", "tmot", "temp"], "current": ["curr", "amp"], "thp": ["thp", "wellhead", "whp"], "voltage": ["volt"],
        "vibration": ["vib"], "power": ["kw", "power"]}, "ESP sensor history (hourly)."),
    _k("esp_fleet", "ESP run-life fleet", ["run_days", "failed"], ["gvf", "water_cut", "freq_c", "starts", "well"],
       {"run_days": ["run", "life", "days", "dur"], "failed": ["fail", "event", "pull", "status"], "gvf": ["gvf", "gas"], "water_cut": ["water", "wc"],
        "freq_c": ["freq"], "starts": ["start"], "well": ["well"]}, "One row per ESP run."),
    _k("srp_cards", "SRP dynamometer cards", ["well", "date", "position", "load"], ["card_id"],
       {"well": ["well"], "date": ["date", "time"], "position": ["position", "pos", "disp"], "load": ["load", "charge"], "card_id": ["card", "id"]},
       "Surface dynamometer cards (long format: one row per point)."),
    _k("srp_ts", "SRP operating data", ["well", "date"], ["spm", "stroke_in", "pump_depth_m", "fluid_level_m", "pprl", "mprl", "power_kw", "fillage"],
       {"well": ["well"], "date": ["date", "time"], "spm": ["spm", "strokes"], "stroke_in": ["stroke"], "pump_depth_m": ["pump_depth", "depth"],
        "fluid_level_m": ["fluid_level", "level", "fl_"], "pprl": ["pprl", "peak"], "mprl": ["mprl", "min"], "power_kw": ["kw", "power"],
        "fillage": ["fill"]}, "SRP controller / well-check data."),
    _k("gaslift_ts", "Gas-lift well data", ["well", "date", "qinj"], ["whp", "casing_p", "qliq", "water_cut", "gor", "tubing_p"],
       {"well": ["well"], "date": ["date", "time"], "qinj": ["qinj", "inj", "gl_rate", "gas_inj"], "whp": ["whp", "thp"], "casing_p": ["casing", "cp", "annulus"],
        "qliq": ["qliq", "liquid", "q_l", "qoil"], "water_cut": ["wc", "water"], "gor": ["gor"], "tubing_p": ["tubing"]}, "Gas-lift injection and response."),
    _k("frac_stage", "Frac stage summary", ["well", "stage"], ["md_top", "md_bot", "fluid_m3", "proppant_t", "rate_m3min", "isip_bar", "pmax_bar", "pavg_bar", "closure_bar", "e_gpa", "poisson", "porosity", "perm_md"],
       {"well": ["well"], "stage": ["stage"], "md_top": ["top"], "md_bot": ["bottom", "bot"], "fluid_m3": ["fluid", "slurry", "volume"], "proppant_t": ["prop", "sand"],
        "rate_m3min": ["rate"], "isip_bar": ["isip"], "pmax_bar": ["max_p", "pmax"], "pavg_bar": ["avg_p", "pavg"], "closure_bar": ["closure"], "e_gpa": ["young", "e_gpa"],
        "poisson": ["poisson", "nu"], "porosity": ["poro"], "perm_md": ["perm"]}, "Stage-level design and results."),
    _k("frac_ts", "Frac treatment time series", ["time", "pressure", "rate"], ["prop_conc", "stage", "well", "bhp"],
       {"time": ["time", "date", "stamp"], "pressure": ["press", "wh_p", "treating"], "rate": ["rate", "slurry"], "prop_conc": ["conc", "prop"],
        "stage": ["stage"], "well": ["well"], "bhp": ["bhp", "bottom"]}, "Treating pressure / rate / proppant concentration."),
    _k("ccus_source", "CO2 source / stream", ["date"], ["gas_rate", "co2_pct", "pressure", "temp", "h2s_ppm", "well"],
       {"date": ["date", "time"], "gas_rate": ["gas"], "co2_pct": ["co2"], "pressure": ["press"], "temp": ["temp"], "h2s_ppm": ["h2s"], "well": ["well"]},
       "CO2 content of the produced gas by date/well (percent)."),
]}

_ID_ALIASES = {"well": ["well", "puits", "producer"], "manifold": ["manifold", "collecteur", "mc"], "facility": ["facility", "plant", "usine", "unit"],
               "junction": ["junction", "node", "tee"], "wellhead": ["wellhead"]}


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(s).lower()).strip("_")


def suggest_mapping(df: pd.DataFrame, kind: str) -> dict:
    """canonical -> column name (or None). Exact header match preferred, then fragment match."""
    k = KINDS[kind]
    cols = list(df.columns)
    ncols = {c: _norm(c) for c in cols}
    used, mp = set(), {}
    for canon in k.required + k.optional:
        hit = None
        if canon in ncols.values():
            hit = next(c for c, n in ncols.items() if n == canon and c not in used)
        if hit is None:
            for frag in k.synonyms.get(canon, []):
                cand = [c for c, n in ncols.items() if c not in used and (n == frag or n.startswith(frag) or (len(frag) > 2 and frag in n))]
                if cand:
                    hit = min(cand, key=lambda c: len(ncols[c]))
                    break
        mp[canon] = hit
        if hit:
            used.add(hit)
    return mp


def detect_kind(df: pd.DataFrame) -> list[tuple[str, float]]:
    """Ranked [(kind, score)] - score = share of required fields found, small bonus for optionals."""
    out = []
    ncol = max(len(df.columns), 1)
    for key, k in KINDS.items():
        mp = suggest_mapping(df, key)
        req = sum(mp[c] is not None for c in k.required) / max(len(k.required), 1)
        explained = sum(v is not None for v in mp.values()) / ncol          # how much of the file this kind explains
        out.append((key, round(req * 0.55 + min(explained, 1.0) * 0.45, 3)))
    return sorted(out, key=lambda t: -t[1])


@dataclass
class UnitChoice:
    pressure: str = "psi"
    datum: str = "gauge"
    gas: str = "Sm3/d"
    liquid: str = "m3/d"
    salinity: str = "mg/L"
    length: str = "m"
    diameter: str = "inch"
    dayfirst: bool = True


def guess_units(df: pd.DataFrame, mapping: dict) -> tuple[UnitChoice, list]:
    u, why = UnitChoice(), []
    if mapping.get("whp") and mapping["whp"] in df:
        u.pressure, r = U.guess_pressure_unit(pd.to_numeric(df[mapping["whp"]], errors="coerce"))
        why.append(f"pressure: {u.pressure} ({r})")
    if mapping.get("gas_rate") and mapping["gas_rate"] in df:
        u.gas, r = U.guess_gas_unit(pd.to_numeric(df[mapping["gas_rate"]], errors="coerce"))
        why.append(f"gas rate: {u.gas} ({r})")
    return u, why


def normalize_well_tests(df: pd.DataFrame, mp: dict, u: UnitChoice) -> pd.DataFrame:
    """-> canonical frame: well, date, whp_bara, gas_sm3d, cond_m3d, water_m3d, salinity_mgl, cgr_m3_per_MMsm3, wgr, tag cols.
    Keeps the original row index in column src_row."""
    g = lambda k: df[mp[k]] if mp.get(k) and mp[k] in df else None
    out = pd.DataFrame({"src_row": np.arange(len(df))})
    out["well"] = g("well").astype(str).str.strip().values
    out["date"] = pd.to_datetime(g("date"), errors="coerce").values
    num = lambda k: pd.to_numeric(g(k), errors="coerce").values if g(k) is not None else np.full(len(df), np.nan)
    out["whp_bara"] = U.p_to_bara(num("whp"), u.pressure, u.datum)
    out["gas_sm3d"] = U.gas_to_sm3d(num("gas_rate"), u.gas)
    out["cond_m3d"] = U.liq_to_m3d(num("cond_rate"), u.liquid)
    out["water_m3d"] = U.liq_to_m3d(num("water_rate"), u.liquid)
    if g("oil_rate") is not None:
        out["oil_m3d"] = U.liq_to_m3d(num("oil_rate"), u.liquid)
    out["salinity_mgl"] = U.sal_to_mgl(num("salinity"), u.salinity)
    for extra, col in (("flp", "flp_bara"), ("bhp", "bhp_bara")):
        if g(extra) is not None:
            out[col] = U.p_to_bara(num(extra), u.pressure, u.datum)
    if g("choke") is not None:
        out["choke"] = num("choke")
    if g("co2_pct") is not None:
        out["co2_pct"] = num("co2_pct")
    out["cgr_m3_mmsm3"] = out["cond_m3d"] / (out["gas_sm3d"] / 1e6)            # m3 condensate / million Sm3 gas
    out["wgr_m3_mmsm3"] = out["water_m3d"] / (out["gas_sm3d"] / 1e6)
    out = out.dropna(subset=["date"]).sort_values(["well", "date"]).reset_index(drop=True)
    # several tests on one day for one well = multi-rate test: number them
    out["test_pt"] = out.groupby(["well", "date"]).cumcount() + 1
    out["n_pts_day"] = out.groupby(["well", "date"])["well"].transform("size")
    return out


def normalize_network(df: pd.DataFrame, mp: dict, u: UnitChoice, utm_zone: int | None = None) -> tuple[pd.DataFrame, list]:
    """-> (nodes frame with x,y in UTM metres, notes). Mixed UTM / DMS coordinates are unified."""
    g = lambda k: df[mp[k]] if mp.get(k) and mp[k] in df else pd.Series([None] * len(df))
    rows, notes = [], []
    utm_pts = []
    for xv, yv in zip(g("x"), g("y")):
        a, b = parse_number(xv)[0], parse_number(yv)[0]
        if np.isfinite(a) and np.isfinite(b) and abs(a) > 1000 and abs(b) > 1000:
            utm_pts.append((a, b))
    for i in range(len(df)):
        xv, yv = g("x").iloc[i], g("y").iloc[i]
        a, b = parse_number(xv)[0], parse_number(yv)[0]
        r = dict(site=str(g("site").iloc[i]).strip(), identity=str(g("identity").iloc[i]).strip().lower(),
                 to_node=str(g("to_node").iloc[i]).strip(), elevation_m=parse_number(g("elevation").iloc[i])[0],
                 length_m=parse_number(g("length_m").iloc[i])[0], diameter_in=parse_number(g("diameter_inch").iloc[i])[0],
                 x=np.nan, y=np.nan, coord_src="")
        if np.isfinite(a) and np.isfinite(b) and abs(a) > 1000 and abs(b) > 1000:
            r["x"], r["y"], r["coord_src"] = a, b, "UTM"
        elif looks_dms(xv) and looks_dms(yv):
            ax, ay = dms_axis(xv), dms_axis(yv)
            if ax == "lat" or ay == "lon":                      # columns swapped in the file: hemisphere letters decide
                la, lo = parse_dms(xv), parse_dms(yv)
                notes.append(f"{r['site']}: x/y columns hold latitude/longitude (N/E letters) - swapped back automatically")
            else:
                lo, la = parse_dms(xv), parse_dms(yv)
            if utm_zone is None and utm_pts:
                utm_zone = infer_zone_for(lo, utm_pts, la)
            e, n, z = latlon_to_utm(la, lo, utm_zone)
            r["x"], r["y"], r["coord_src"] = e, n, f"DMS->UTM{z}"
        rows.append(r)
    nodes = pd.DataFrame(rows)
    nodes["identity"] = nodes["identity"].replace({k: v for v, ks in _ID_ALIASES.items() for k in ks})
    if utm_zone:
        notes.append(f"DMS coordinates converted to UTM zone {utm_zone} (matched to the UTM points in the file)")
    return nodes, notes


def template(kind: str, n: int = 3) -> pd.DataFrame:
    """Empty template with canonical headers (download from the UI)."""
    k = KINDS[kind]
    return pd.DataFrame({c: [] for c in k.required + k.optional})


def normalize_generic(df: pd.DataFrame, mp: dict) -> pd.DataFrame:
    """Rename mapped columns to canonical names (unmapped columns are kept as they are), numeric coercion for non-text fields."""
    ren = {v: k for k, v in mp.items() if v is not None and v in df.columns}
    out = df.rename(columns=ren).copy()
    text_like = {"well", "category", "reason", "type", "cost_centre", "system", "identity", "site", "to_node", "planned", "failed", "card_id", "stage"}
    for c in out.columns:
        if c in text_like or pd.api.types.is_datetime64_any_dtype(out[c]) or pd.api.types.is_numeric_dtype(out[c]):
            continue
        conv = out[c].map(lambda v: parse_number(v)[0])
        if conv.notna().mean() > 0.8:
            out[c] = conv
    return out
