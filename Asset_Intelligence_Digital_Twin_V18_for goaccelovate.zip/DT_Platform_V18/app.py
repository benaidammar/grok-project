"""AI Oil & Gas Asset Intelligence Digital Twin - V18.   Run:  streamlit run app.py   (or double-click / F5 RUN_ME.py)"""
import importlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import streamlit as st

st.set_page_config(page_title="Asset Intelligence Digital Twin V18", page_icon="🛢️", layout="wide")

from dtp.ui.bootstrap import build_ctx
from dtp.ui.pages import PAGES

ctx = build_ctx(st)
with st.sidebar:
    st.title("🛢️ Asset Intelligence DT")
    st.caption("V18 · upload your field data → every page works on it")
    titles = [p[1] for p in PAGES]
    page = st.radio("Navigate", titles, key="nav_page", label_visibility="collapsed")
    st.divider()
    st.caption(f"**Asset:** {ctx.cfg.asset_name}")
    loaded = [k for k in ctx.datasets if ctx.has(k)]
    st.caption("**Loaded:** " + (", ".join(loaded) if loaded else "nothing yet - open *0 · Data foundation*"))
    st.caption("Status labels: OK · WARN · FAIL · UNVALIDATED. Outputs are decision support: they pass human review / MoC and are never sent to control systems.")

spec = dict((p[1], p[2]) for p in PAGES)[page]
mod, fn = spec.split(":")
try:
    getattr(importlib.import_module(mod), fn)(ctx)
except Exception as exc:                                                  # noqa: BLE001
    st.error(f"FAIL - this page could not be rendered: {type(exc).__name__}: {exc}")
    with st.expander("Technical details"):
        import traceback
        st.code(traceback.format_exc())
